import { createHash } from "node:crypto";
import { expect, test } from "vitest";
import { paintSurface } from "yage/streaming/shadow-pass";

/**
 * A made-up atlas (4 x 3 cells of 24 x 32 px; a fixed-seed pattern): each cell's art an opaque blob, its
 * heights a few stacked solids, some held up off the ground and some touching, with gaps between.
 */
const atlas = () => {
  const [cw, ch, cols, rows] = [24, 32, 4, 3];
  const [width, height] = [cw * cols, ch * rows];
  const art = { width, height, data: new Uint8ClampedArray(width * height * 4) };
  const heights = { width, height, data: new Uint8ClampedArray(width * height * 4) };
  let seed = 7;
  const next = () => (seed = (seed * 1103515245 + 12345) >>> 0) / 2 ** 32;
  for (let c = 0; c < cols * rows; c++) {
    const [x0, y0] = [(c % cols) * cw, Math.floor(c / cols) * ch];
    for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) {
      const k = 4 * ((y0 + y) * width + x0 + x);
      const r = Math.hypot(x - cw / 2, y - ch / 2.4);
      art.data[k + 3] = r < 9 + next() * 3 ? 255 : r < 13 ? 4 : 0;
    }
    for (let s = 0; s < 3; s++) {
      const [sx, sy, sw, sh] = [2 + Math.floor(next() * 14), 10 + Math.floor(next() * 16), 3 + Math.floor(next() * 6), 2 + Math.floor(next() * 5)];
      const base = s === 1 ? Math.floor(next() * 6) : 0, top = base + 1 + Math.floor(next() * 12);
      for (let y = sy; y < Math.min(ch, sy + sh); y++) for (let x = sx; x < Math.min(cw, sx + sw); x++) {
        const k = 4 * ((y0 + y) * width + x0 + x);
        [heights.data[k], heights.data[k + 1], heights.data[k + 2], heights.data[k + 3]] = [top, base, s + 1, 255];
      }
    }
  }
  return { art: art as unknown as ImageData, heights: heights as unknown as ImageData, cell: [cw, ch] as [number, number] };
};

test("each art texel's surface is the first solid its view ray meets down its cell, fringes the nearest's", () => {
  const { art, heights, cell } = atlas();
  const out = paintSurface(art, heights, cell, 2, 3, 0.75);
  // Recorded from the step-a-px-at-a-time march before it skipped the open heights between solids.
  expect(createHash("sha256").update(out.data).digest("hex")).toBe("0b89ab41387b07b1bf514ac2e5d66b1f71260625609d911f3ef1a0ab83c595c2");
});
