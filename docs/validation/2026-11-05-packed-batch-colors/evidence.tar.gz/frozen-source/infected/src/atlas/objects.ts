/**
 * World objects (docs/OBJECTS.md): buildings built once in their own local tile space and placed
 * with a free transform, and roads, paths and rails as vector polylines with a cross-section.
 * The ground grid keeps only terrain, water and fields; these sit on top of it.
 *
 * Coordinates are global tiles as floats unless a field says otherwise. Angles are radians,
 * clockwise from +x on screen (y down), any value.
 */
import type { Template } from "../worldgen/terrain/models";
import type { FeatureId } from "./ids";
import type { NativeUnit } from "../worldgen/native-floor";
import type { BuildingUse, RoadClass, Vec, WaterKind } from "./model";

// ---------------------------------------------------------------------------------------------
// Frames

/**
 * Building-local → world. Local (0, 0) is the plan's top-left corner; local +x runs along
 * (cos a, sin a) and local +y along (−sin a, cos a).
 */
export type Frame = {
  x: number;
  y: number;
  angle: number;
  /** World tiles per building-local tile; omitted means one. */
  scale?: number;
};

/** cos and sin of an angle, exact at quarter turns so grid frames land on whole tiles. */
export const cosSin = (a: number): [number, number] => {
  const q = a / (Math.PI / 2);
  const r = Math.round(q);
  if (Math.abs(q - r) < 1e-12) return [[1, 0], [0, 1], [-1, 0], [0, -1]][((r % 4) + 4) % 4] as [number, number];
  return [Math.cos(a), Math.sin(a)];
};

export const toWorld = (f: Frame, lx: number, ly: number): Vec => {
  const [c, s] = cosSin(f.angle);
  const scale = f.scale ?? 1;
  const x = lx * scale, y = ly * scale;
  return { x: f.x + x * c - y * s, y: f.y + x * s + y * c };
};

export const toLocal = (f: Frame, wx: number, wy: number): Vec => {
  const [c, s] = cosSin(f.angle);
  const dx = wx - f.x;
  const dy = wy - f.y;
  const scale = f.scale ?? 1;
  return { x: (dx * c + dy * s) / scale, y: (-dx * s + dy * c) / scale };
};

/** A frame shifted by (dx, dy): e.g. into a chunk's local tiles with (−cx·128, −cy·128). */
export const shiftFrame = (f: Frame, dx: number, dy: number): Frame => ({ ...f, x: f.x + dx, y: f.y + dy });

// ---------------------------------------------------------------------------------------------
// Buildings

export type RoofKind = "gable" | "hip" | "flat" | "mansard";

/**
 * A building as built, in its own local tiles: one of the game's parametric templates
 * (src/templates.ts), unturned. The door is on the bottom row and opens to local +y.
 * Culture-free: the renderer picks materials per culture and style.
 */
export type BuildingPlan = {
  /** `${unit}/${w}x${h}`. */
  key: string;
  /** Template family: a PlaceKind number, "terrace", or a service (hospital, clinic, university). */
  unit: number | "terrace" | "hospital" | "clinic" | "university" | "church" | "mosque";
  w: number;
  h: number;
  /** w × h Tile ids (src/terrain.ts): Floor, Wall, furniture, stairs; the door tile is Floor. */
  tiles: Uint8Array;
  /** Inside walls on the cell edges (worldgen/templates/edges.ts: EDGE_WEST, EDGE_NORTH bits). */
  edges?: Uint8Array;
  /** Source-shaped interiors carry their own template instead of a rectangular family clamp. */
  template?: Template;
  native?: { poly: Vec[]; holes: Vec[][]; mask: Uint8Array; inward: Vec };
  door: [number, number];
  beds: [number, number][];
  spots: [number, number][];
  stairs?: { tiles: [number, number][]; up: number };
  floorCap: number;
  /** Furniture and fittings, local tiles (x, y at the tile's top-left) and quarter turns. */
  items: { item: string; x: number; y: number; rot: number }[];
  /** Ridge along local x (0) or local y (1). */
  roof: { kind: RoofKind; ridge: 0 | 1 };
};

export type BuildingInstance = {
  id: FeatureId;
  /** BuildingPlan key. */
  plan: string;
  frame: Frame;
  w: number;
  h: number;
  /** World corners of the w × h rectangle: local (0,0), (w,0), (w,h), (0,h). */
  footprint: [Vec, Vec, Vec, Vec];
  /** Centre of the door tile, and the point in front of it on the sidewalk or path. */
  door: Vec;
  outside: Vec;
  /** The chunk holding `outside`: it owns the residents, the place and the draw. */
  owner: { cx: number; cy: number };
  use: BuildingUse;
  style: string;
  culture: string;
  storeys: number;
  seed: number;
};

// ---------------------------------------------------------------------------------------------
// Roads and rails

export type RoadSurface = "road" | "trail" | "path" | "gravel" | "dirt" | "park";
export type RoadMarkings = "none" | "centre" | "dashed" | "double-yellow";
/** How a road ends: at a junction, dead, at the plan's edge, or at a tunnel portal (it goes underground there: a ramp down into its mouth). */
export type RoadEnd = "junction" | "dead" | "edge" | "portal";

/**
 * One road between junctions or dead ends. The cross-section is the carriageway (`width`), then
 * a kerb and `sidewalk` tiles on each side.
 */
export type Road = {
  /** Explicitly generated connector, rather than a surveyed road. */
  generated?: boolean;
  /** Imported transport classification, retained through road-chain compilation. */
  highway?: boolean;
  sourceClass?: string;
  /** Source vertical level; absent means ground. */
  level?: number;
  /** Separate surveyed carriageway with a median; no invented opposite direction. */
  divided?: boolean;
  ramp?: boolean;
  oneWay?: boolean;
  id: FeatureId;
  cls: RoadClass;
  points: Vec[];
  /** Source continuation used only by native paint, never navigation or cell ownership. */
  renderPoints?: Vec[];
  renderOffset?: number;
  width: number;
  sidewalk: number;
  kerb: boolean;
  surface: RoadSurface;
  markings: RoadMarkings;
  lanes?: number;
  /** Decks, as distances along the polyline. */
  bridges?: { from: number; to: number; water: WaterKind }[];
  ends: [RoadEnd, RoadEnd];
  link?: FeatureId;
  settlement?: FeatureId;
  /** The plan's street pieces this road was chained from. */
  streets: FeatureId[];
  /**
   * Wholly inside the carriageway of the junctions at its ends (two crossings closer than their
   * cut-backs, as where a diagonal avenue crosses the grid near a corner): asphalt only, no kerb,
   * sidewalk or markings of its own.
   */
  inner?: boolean;
};

export type JunctionKind = "cross" | "tee" | "merge";

/** Where roads meet. `poly` is the carriageway area; each leg says where its road is cut back to it. */
export type Junction = {
  id: FeatureId;
  at: Vec;
  kind: JunctionKind;
  roads: FeatureId[];
  /** `inner`: the leg's road is inner (see Road); no kerb fillet on the corners either side of it. */
  legs: { road: FeatureId; end: 0 | 1; cut: number; inner?: boolean }[];
  poly: Vec[];
  crossings: boolean;
  signals?: boolean;
  /**
   * Park walks meeting (no carriageway: `poly` is the paved outline round the node, legs uncut):
   * each inner corner's fillet, an arc about `o` of radius `r` from `a` (on one leg's edge) to `b`
   * (on the next's), filling the corner back to `c`, where the two edges would meet.
   */
  fillets?: WalkFillet[];
};

/** A park-walk junction's rounded inner corner (Junction.fillets), tiles. */
export type WalkFillet = { o: Vec; r: number; a: Vec; b: Vec; c: Vec };

/** A railway or tram line's centre line; `tracks` run `offset` either side of it. */
export type RailLine = {
  id: FeatureId;
  kind: "main" | "tram" | "siding";
  points: Vec[];
  tracks: number;
  offset: number;
  bridges?: { from: number; to: number; water: WaterKind }[];
};

/** Everything of the road network one chunk touches, global coordinates. */
export type ChunkObjects = { roads: Road[]; junctions: Junction[]; rails: RailLine[] };

/**
 * A building as one chunk's art lists it (chunk-local tiles; ChunkArt.prefabs). Listed in every
 * chunk its footprint's bounding box touches, under one id; `home` is true only in the owner chunk.
 */
/**
 * A stretch of a building's wall that another building stands against (a party wall: no alley, so
 * no windows): edge (render/fronts.ts topLayout: 0 local y = h, 1 x = w, 2 y = 0, 3 x = 0), its run
 * along the edge (tiles from the edge's start, as the face is drawn), and the neighbour's storeys.
 */
export type PartyWall = [edge: number, from: number, to: number, storeys: number];

export type PrefabListing = {
  id: FeatureId;
  /** BuildingPlan key. */
  key: string;
  /** Where the plan's local origin (top-left corner) lands, and its rotation. */
  x: number;
  y: number;
  angle: number;
  scale?: number;
  culture: string;
  style: string;
  use: BuildingUse;
  storeys: number;
  seed: number;
  home: boolean;
  /** Where neighbours stand against its walls (worldgen/prefabs/party.ts): no windows there below their roofs. */
  party?: PartyWall[];
  /**
   * A generated (native) plan's floor spec: the key alone cannot rebuild it, and the thread that
   * draws the listing need not be the one that planned it (catalog.ts listingPlan registers it).
   */
  native?: NativeUnit;
};

/** Objects mode's additions to a chunk's art (ChunkArt.roads, junctionAreas, rails2, prefabs), chunk-local. */
export type ObjectsArt = { roads: Road[]; junctionAreas: Junction[]; rails2: RailLine[]; prefabs: PrefabListing[]; parkEdges?: { points: Vec[] }[]; crosswalks?: { points: Vec[]; width: number }[] };
