/**
 * Identity for the world model: spaces, chunk addresses, stable feature ids, layered seeds and
 * campaign entity ids.
 *
 * Why `src/atlas/` and not `src/world/`: `src/world.ts` (chunk constants) already exists, and
 * `import "./world"` would be ambiguous between the file and a directory index. Everything that
 * the world plan (docs/WORLD_PLAN.md §17) puts in `src/world/` lives here instead.
 */

// ---------------------------------------------------------------------------------------------
// Spaces and chunk addresses

/**
 * A persistent playable map. `index` is the u16 the streaming protocol carries (yage spaces:
 * 0 is the engine's default space, kept for the legacy single-map game); `key` is the stable
 * content name saved in manifests and saves.
 */
export type SpaceRef = { index: number; key: string };

/** A runtime chunk: which space it belongs to and its coordinates there. Mirrors yage's ChunkAddress. */
export type ChunkAddress = { space: number; cx: number; cy: number };

export const addressString = (a: ChunkAddress) => `${a.space}:${a.cx},${a.cy}`;

// ---------------------------------------------------------------------------------------------
// Hashing

/** 32-bit FNV-1a of a string, finished with a murmur mix. Stable across platforms and runs. */
export const hashString = (text: string): number => {
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  h ^= h >>> 16;
  h = Math.imul(h, 0x85ebca6b);
  h ^= h >>> 13;
  h = Math.imul(h, 0xc2b2ae35);
  h ^= h >>> 16;
  return h >>> 0;
};

/** Mixes integers into a 32-bit hash. */
export const mix = (...values: number[]) => {
  let h = 0x9e3779b9;
  for (const value of values) {
    h = Math.imul(h ^ (value | 0), 0x85ebca6b);
    h ^= h >>> 13;
    h = Math.imul(h, 0xc2b2ae35);
    h ^= h >>> 16;
  }
  return h >>> 0;
};

// ---------------------------------------------------------------------------------------------
// Stable feature ids and layered seeds (plan §6)

/**
 * Every generated feature has one canonical id built from its parent's id and a local name, e.g.
 * `riverford/s:ashby/d:core/b:12`. Ids are strings so they read well in saves and previews; the
 * numeric form (`fidHash`) is for compact chunk outputs.
 */
export type FeatureId = string;

export const fid = (parent: FeatureId, kind: string, local: string | number): FeatureId => `${parent}/${kind}:${local}`;
export const fidHash = (id: FeatureId) => hashString(id);

/**
 * Generation layers. Each draws from its own seed, derived from the world seed, the layer and a
 * stable feature id, so adding a tree variant (vegetation) can't move a road (streets) or shuffle
 * households (population).
 */
export const enum Layer {
  Region = 1,
  Water = 2,
  Settlements = 3,
  Links = 4,
  Districts = 5,
  Streets = 6,
  Parcels = 7,
  Buildings = 8,
  Population = 9,
  Countryside = 10,
  Vegetation = 11,
}

export const seedOf = (worldSeed: number, layer: Layer, id: FeatureId = "") => mix(worldSeed, layer, hashString(id));

/** mulberry32: a small fast seeded generator in [0, 1). */
export const rng = (seed: number) => {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

export type Rng = () => number;
export const between = (r: Rng, lo: number, hi: number) => lo + (hi - lo) * r();
export const pick = <T>(r: Rng, items: readonly T[]) => items[Math.floor(r() * items.length) % items.length];
export const pickWeighted = <T>(r: Rng, items: readonly (readonly [T, number])[]) => {
  let total = 0;
  for (const [, w] of items) total += w;
  let roll = r() * total;
  for (const [item, w] of items) {
    roll -= w;
    if (roll < 0) return item;
  }
  return items[items.length - 1][0];
};

// ---------------------------------------------------------------------------------------------
// Campaign entity ids (plan §17: "replace [gidFor] with saved campaign allocations")

/**
 * Typed namespaces inside the u32 id space, so people, animals, vehicles and response units never
 * collide however many spaces exist. Ids are allocated from saved counters, never derived from
 * chunk coordinates, and never reused within a campaign.
 */
export const enum IdKind {
  Person = 0,
  Animal = 1,
  Vehicle = 2,
  Unit = 3,
  Trip = 4,
}

/** First id and size of each namespace. People get 3/4 of the space (≈3.2 billion). */
export const ID_RANGES: Record<IdKind, readonly [number, number]> = {
  [IdKind.Person]: [1, 0xc0000000 - 1],
  [IdKind.Animal]: [0xc0000000, 0x10000000],
  [IdKind.Vehicle]: [0xd0000000, 0x10000000],
  [IdKind.Unit]: [0xe0000000, 0x08000000],
  [IdKind.Trip]: [0xe8000000, 0x17ffffff],
};

export const idKindOf = (id: number): IdKind => {
  for (const kind of [IdKind.Trip, IdKind.Unit, IdKind.Vehicle, IdKind.Animal, IdKind.Person]) {
    const [first, size] = ID_RANGES[kind];
    if (id >= first && id < first + size) return kind;
  }
  throw new RangeError(`Id ${id} is in no namespace`);
};

/** Hands out campaign ids. Its state is part of the save. */
export class IdAllocator {
  private next: number[];

  constructor(state?: readonly number[]) {
    this.next = state ? [...state] : [0, 0, 0, 0, 0];
  }

  /** Reserves `count` consecutive ids of `kind` and returns the first. */
  take(kind: IdKind, count = 1): number {
    const [first, size] = ID_RANGES[kind];
    const used = this.next[kind];
    if (used + count > size) throw new RangeError(`Id namespace ${kind} is exhausted`);
    this.next[kind] = used + count;
    return first + used;
  }

  save(): number[] {
    return [...this.next];
  }
}
