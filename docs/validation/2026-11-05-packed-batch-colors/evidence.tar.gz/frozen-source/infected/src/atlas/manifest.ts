import { SPACE_MAX } from "yage/streaming";
import type { DailyRoutineProfile } from "../domain/people/daily-routine";
import type { ForecastFrame } from "../realworld/forecast";
/**
 * World manifest (plan §4, §6 step 1): the reproducible identity of a scenario. It names the
 * generator and content versions, the simulated population budget, the clock settings, data
 * sources, and the playable spaces with their geographic context.
 *
 * Population semantics (plan §3): `population.simulated` is a gameplay budget — every simulated
 * person counts as one person — and is unrelated to real populations, which are stored separately
 * on settlements as reference data with source and year.
 */
import type { BiomeId } from "./model";

export const GENERATOR_VERSION = 1;

export type SourceRecord = {
  id: string;
  name: string;
  /** What was used, and how (e.g. "hand-authored compact skeleton"). */
  use: string;
  licence: string;
  /** Pinned version or retrieval date, if imported. */
  version?: string;
};

export type GeoRegion = {
  name: string;
  country?: string;
  /** Reference point of the space's origin. */
  latitude: number;
  longitude: number;
  /** Fixed scenario offset from campaign time, hours. */
  utcOffset: number;
  dailyRoutine?: DailyRoutineProfile;
  biome: BiomeId;
  /** Yearly mean temperature °C and moisture 0..1 at the reference point. */
  meanTemperature: number;
  moisture: number;
};

export type SpaceDef = {
  /** Native population owner for a complete geographic region. */
  populationCell?: number;
  /** Centre chunk of a geographically positioned space; omitted for a space centred at zero. */
  origin?: { cx: number; cy: number };
  /** Dated regional forecast used by this scenario, in seconds from its start. */
  forecast?: ForecastFrame[];
  /** u16 carried by the streaming protocol. 0 is reserved for the legacy single-map game. */
  index: number;
  key: string;
  name: string;
  /** Profile that generates the space (src/worldgen/profiles). */
  profile: string;
  region: GeoRegion;
  /** Size in chunks; the space spans chunks [-w/2, w/2) × [-h/2, h/2). */
  chunks: [number, number];
  /** Metres per tile of compressed map (gameplay scale; distances are not geographic). */
  metresPerTile: number;
  /** Share of the simulated population budget. */
  populationWeight: number;
};

export type WorldManifest = {
  id: string;
  seed: number;
  generator: number;
  content: Record<string, number>;
  population: { simulated: number };
  clock: { tickRate: number; maxLead: number };
  sources: SourceRecord[];
  spaces: SpaceDef[];
};

/** Problems with a manifest, empty when it is valid. */
export const validateManifest = (manifest: WorldManifest, knownProfiles: readonly string[] = []): string[] => {
  const errors: string[] = [];
  if (!/^[a-z0-9-]+$/.test(manifest.id)) errors.push(`world id "${manifest.id}" must be lower-case letters, digits and dashes`);
  if (!Number.isInteger(manifest.seed) || manifest.seed < 0 || manifest.seed > 0xffffffff) errors.push("seed must be a u32");
  if (manifest.generator !== GENERATOR_VERSION) errors.push(`generator ${manifest.generator} is not this build's (${GENERATOR_VERSION}); migrate the save`);
  if (!Number.isInteger(manifest.population.simulated) || manifest.population.simulated < 0) errors.push("simulated population must be a non-negative integer");
  if (manifest.clock.tickRate <= 0) errors.push("tick rate must be positive");
  const indices = new Set<number>();
  const keys = new Set<string>();
  let weight = 0;
  for (const space of manifest.spaces) {
    if (!Number.isInteger(space.index) || space.index < 1 || space.index > SPACE_MAX) errors.push(`space ${space.key}: index must be 1..${SPACE_MAX} (0 is the legacy map)`);
    if (indices.has(space.index)) errors.push(`space index ${space.index} is used twice`);
    if (keys.has(space.key)) errors.push(`space key ${space.key} is used twice`);
    indices.add(space.index);
    keys.add(space.key);
    if (knownProfiles.length && !knownProfiles.includes(space.profile)) errors.push(`space ${space.key}: unknown profile ${space.profile}`);
    const [w, h] = space.chunks;
    if (space.populationCell !== undefined) {
      const origin = space.origin;
      if (!Number.isInteger(space.populationCell) || space.populationCell < 0 || !origin || !Number.isInteger(w) || !Number.isInteger(h) || w < 1 || h < 1 || w > 512 || h > 512 || !Number.isInteger(origin.cx - w / 2) || !Number.isInteger(origin.cy - h / 2)) errors.push(`space ${space.key}: invalid geographic cell bounds`);
    } else if (!(w > 0 && h > 0 && w % 2 === 0 && h % 2 === 0 && w <= 512 && h <= 512)) errors.push(`space ${space.key}: chunk size must be even and 2..512`);
    if (Math.abs(space.region.latitude) > 90 || Math.abs(space.region.longitude) > 180) errors.push(`space ${space.key}: bad coordinates`);
    if (Math.abs(space.region.utcOffset) > 14) errors.push(`space ${space.key}: utc offset out of range`);
    if (space.populationWeight < 0) errors.push(`space ${space.key}: negative population weight`);
    weight += space.populationWeight;
  }
  if (manifest.spaces.length && weight <= 0 && manifest.population.simulated > 0) errors.push("population weights sum to zero");
  for (const source of manifest.sources) if (!source.licence) errors.push(`source ${source.id} has no licence note`);
  return errors;
};

/**
 * Splits `total` into integer shares proportional to `weights` (largest remainder, ties by `tie`
 * when given, then by index), each capped at `caps` when given. The parts always sum to `total`
 * unless the caps can't hold it, which throws. Deterministic.
 */
export const allocateExact = (total: number, weights: readonly number[], caps?: readonly number[], tie?: readonly number[]): number[] => {
  const n = weights.length;
  const out = new Array<number>(n).fill(0);
  if (total === 0 || n === 0) return out;
  if (caps && caps.reduce((s, c) => s + c, 0) < total) throw new Error(`Capacity ${caps.reduce((s, c) => s + c, 0)} can't hold ${total}`);
  const room = (i: number) => (caps ? caps[i] - out[i] : Infinity);
  let left = total;
  while (left > 0) {
    // Positive weights first; once they are all full, everyone with room shares equally.
    let open = weights.map((_, i) => i).filter((i) => weights[i] > 0 && room(i) > 0);
    let weight = (i: number) => weights[i];
    if (!open.length) {
      open = weights.map((_, i) => i).filter((i) => room(i) > 0);
      weight = () => 1;
    }
    const sum = open.reduce((s, i) => s + weight(i), 0);
    const share = open.map((i) => (left * weight(i)) / sum);
    const add = share.map((v, k) => Math.min(Math.floor(v), room(open[k])));
    let given = add.reduce((s, v) => s + v, 0);
    // Largest remainders (ties by `tie`, then index) take the leftover units while they have room.
    const order = open.map((i, k) => ({ i, k, frac: share[k] - Math.floor(share[k]) })).sort((a, b) => b.frac - a.frac || (tie ? tie[a.i] - tie[b.i] : 0) || a.i - b.i);
    for (const { i, k } of order) {
      if (given >= left) break;
      if (room(i) - add[k] > 0) {
        add[k]++;
        given++;
      }
    }
    open.forEach((i, k) => (out[i] += add[k]));
    left -= given;
  }
  return out;
};
