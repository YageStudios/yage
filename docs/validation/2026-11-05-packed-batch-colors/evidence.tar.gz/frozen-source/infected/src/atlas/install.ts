import { realWorldSnapshot } from "../realworld/runtime";
/**
 * The ATLAS flag: when on, the game's terrain (settlements, chunk layouts, tiles) comes from one
 * space of the world atlas instead of the legacy procedural world, and person ids carry the
 * space so they never collide with another space's. Process entries (the page boot, chunk
 * workers, the Node host, the preview pages and the test setup) call `installRequestedAtlas` once;
 * nothing installs on import, and every reader below an entry takes its planning context explicitly.
 *
 * Off unless asked for: `?atlas=1` or `?atlas=valley` streams the valley, `?atlas=newyork` (or
 * `2`) New York. Workers get the page's query string as their name (see main.ts). Node hosts read
 * INFECTED_ATLAS. Otherwise src/atlas/config.ts decides.
 */
import { ALPHA } from "../domain/worlds";
import { setTerrainSource, terrainSource } from "../worldgen/terrain/source";
import { AtlasTerrain } from "../worldgen/layout";
import { AtlasSource } from "../worldgen/runtime";
import { ATLAS_CONFIG, objectsRequest } from "./config";
import { FIELD_SIZES, fieldSource } from "../simlab/field";

const SPACE_KEYS: Record<string, string> = { "1": "valley", valley: "valley", "2": "newyork", ny: "newyork", newyork: "newyork" };

/** The space key the flag asks for, or null for the legacy world. */
export const atlasRequest = (): string | null => {
  const g = globalThis as { location?: { search?: string }; name?: string; process?: { env?: Record<string, string | undefined> }; document?: unknown };
  const fromQuery = (search: string | undefined) => {
    if (!search) return undefined;
    const params = new URLSearchParams(search);
    if (params.has("world")) return "earth";
    return params.has("atlas") ? (params.get("atlas") ?? "") : undefined;
  };
  const value = (g.document ? fromQuery(g.location?.search) : fromQuery(typeof g.name === "string" ? g.name : undefined)) ?? g.process?.env?.INFECTED_ATLAS ?? ATLAS_CONFIG.space;
  if (value === null || value === undefined || value === "0" || value === "off") return null;
  return value === "earth" ? "earth" : SPACE_KEYS[value] ?? "valley";
};

export { objectsRequest };

/**
 * Turns the atlas on for a space key (or off with null). Tests call this directly. The installed
 * terrain source (worldgen/terrain/source.ts's planning context) owns the terrain; this module keeps
 * no copy of it.
 */
export const installAtlas = (key: string | null, objects = false) => {
  if (!key) {
    setTerrainSource(null);
    return null;
  }
  const manifest = key === "earth" ? realWorldSnapshot()?.manifest : ALPHA;
  if (!manifest) throw new Error("World data has not loaded");
  const def = manifest.spaces.find((s) => s.key === key);
  if (!def) throw new Error(`No atlas space ${key}`);
  const terrain = new AtlasTerrain(new AtlasSource(manifest, undefined, objects, key === "earth" ? realWorldSnapshot()?.geography : undefined), def.index);
  setTerrainSource(terrain);
  return terrain;
};

/** The installed atlas terrain, or null for the legacy world (or any other source). */
export const activeAtlas = (): AtlasTerrain | null => {
  const source = terrainSource();
  return source instanceof AtlasTerrain ? source : null;
};

/**
 * The simulation lab's empty field (`?field=<n>`, n × n chunks; INFECTED_FIELD in Node), or 0 for
 * none. It takes the place of the atlas (src/simlab/field.ts).
 */
export const fieldRequest = (): number => {
  const g = globalThis as { location?: { search?: string }; name?: string; process?: { env?: Record<string, string | undefined> }; document?: unknown };
  const search = g.document ? g.location?.search : typeof g.name === "string" ? g.name : undefined;
  const value = (search ? new URLSearchParams(search).get("field") : null) ?? g.process?.env?.INFECTED_FIELD;
  const n = Math.round(Number(value));
  return Number.isFinite(n) && n > 0 ? Math.min(n, FIELD_SIZES[FIELD_SIZES.length - 1]) : 0;
};

/** Process entry only: installs the terrain the flags ask for (see the module comment): the lab's field, else the atlas. */
export const installRequestedAtlas = () => {
  const field = fieldRequest();
  if (field) {
    setTerrainSource(fieldSource(field));
    return null;
  }
  return installAtlas(atlasRequest(), objectsRequest());
};
