/**
 * Uniform-grid spatial index over bounding boxes, for "which features touch this chunk" and
 * "is anything near this point". Results come back sorted by insertion order, so callers that
 * insert in a canonical order get canonical results whatever order they query in.
 */
import type { Rect } from "./model";

export class GridIndex<T> {
  private readonly cells = new Map<number, number[]>();
  private readonly items: { item: T; box: Rect }[] = [];

  constructor(readonly cell = 64) {}

  get size() {
    return this.items.length;
  }

  private key(i: number, j: number) {
    return (i + 33554432) * 67108864 + (j + 33554432);
  }

  insert(item: T, box: Rect) {
    const index = this.items.length;
    this.items.push({ item, box });
    const { cell } = this;
    for (let j = Math.floor(box.y0 / cell); j <= Math.floor(box.y1 / cell); j++) {
      for (let i = Math.floor(box.x0 / cell); i <= Math.floor(box.x1 / cell); i++) {
        const key = this.key(i, j);
        let list = this.cells.get(key);
        if (!list) this.cells.set(key, (list = []));
        list.push(index);
      }
    }
  }

  /** Per-item mark of the last multi-cell query that saw it (dedupes without a Set). */
  private seen = new Uint32Array(64);
  private tick = 0;

  /** Items whose boxes intersect `box`, in insertion order, each once. */
  query(box: Rect): T[] {
    const { cell, items } = this;
    const i0 = Math.floor(box.x0 / cell);
    const i1 = Math.floor(box.x1 / cell);
    const j0 = Math.floor(box.y0 / cell);
    const j1 = Math.floor(box.y1 / cell);
    const out: T[] = [];
    if (i0 === i1 && j0 === j1) {
      // One cell: its list is already in insertion order, each item once.
      const list = this.cells.get(this.key(i0, j0));
      if (list) {
        for (const index of list) {
          const b = items[index].box;
          if (b.x0 <= box.x1 && b.x1 >= box.x0 && b.y0 <= box.y1 && b.y1 >= box.y0) out.push(items[index].item);
        }
      }
      return out;
    }
    if (this.seen.length < items.length) {
      const grown = new Uint32Array(Math.max(items.length, this.seen.length * 2));
      grown.set(this.seen);
      this.seen = grown;
    }
    if (++this.tick === 0xffffffff) {
      this.seen.fill(0);
      this.tick = 1;
    }
    const { seen, tick } = this;
    const hits: number[] = [];
    this.lists(i0, i1, j0, j1, (list) => {
      for (const index of list) {
        if (seen[index] === tick) continue;
        seen[index] = tick;
        const b = items[index].box;
        if (b.x0 <= box.x1 && b.x1 >= box.x0 && b.y0 <= box.y1 && b.y1 >= box.y0) hits.push(index);
      }
    });
    hits.sort((a, b) => a - b);
    for (const index of hits) out.push(items[index].item);
    return out;
  }

  /**
   * Whether any item whose box holds the point (x, y) passes `test`: `query` of the point's box and
   * `some`, without building the list (a point lies in one cell, whose list is in insertion order).
   */
  some(x: number, y: number, test: (item: T) => boolean): boolean {
    const list = this.cells.get(this.key(Math.floor(x / this.cell), Math.floor(y / this.cell)));
    if (!list) return false;
    const { items } = this;
    for (const index of list) {
      const b = items[index].box;
      if (b.x0 <= x && b.x1 >= x && b.y0 <= y && b.y1 >= y && test(items[index].item)) return true;
    }
    return false;
  }

  /**
   * The items whose boxes meet `r`, for point tests inside it: `near(r).some(x, y, test)` answers
   * `some(x, y, test)` for any point in r (an item whose box holds the point meets r), without a
   * cell lookup per point. Taken once for a box tested at many points; nothing may be inserted between.
   */
  near(r: Rect): NearItems<T> {
    const { cell, items } = this;
    const out: { item: T; box: Rect }[] = [];
    this.visitIndexes(Math.floor(r.x0 / cell), Math.floor(r.x1 / cell), Math.floor(r.y0 / cell), Math.floor(r.y1 / cell), (index) => {
      const b = items[index].box;
      if (b.x0 <= r.x1 && b.x1 >= r.x0 && b.y0 <= r.y1 && b.y1 >= r.y0) out.push(items[index]);
    });
    return new NearItems(out);
  }

  /**
   * The first item (in insertion order, as `query` lists them) whose box intersects `box` and that
   * passes `test`, without building the list; null if none. `test` must not query this index.
   */
  first(box: Rect, test: (item: T) => boolean): T | null {
    const { cell, items } = this;
    const i0 = Math.floor(box.x0 / cell);
    const i1 = Math.floor(box.x1 / cell);
    const j0 = Math.floor(box.y0 / cell);
    const j1 = Math.floor(box.y1 / cell);
    const hit = (index: number) => {
      const b = items[index].box;
      return b.x0 <= box.x1 && b.x1 >= box.x0 && b.y0 <= box.y1 && b.y1 >= box.y0;
    };
    if (i0 === i1 && j0 === j1) {
      for (const index of this.cells.get(this.key(i0, j0)) ?? []) if (hit(index) && test(items[index].item)) return items[index].item;
      return null;
    }
    const hits: number[] = [];
    this.visitIndexes(i0, i1, j0, j1, (index) => hit(index) && hits.push(index));
    hits.sort((a, b) => a - b);
    for (const index of hits) if (test(items[index].item)) return items[index].item;
    return null;
  }

  /** Each item index listed in cells i0..i1 × j0..j1, once (shares the dedupe marks). */
  private visitIndexes(i0: number, i1: number, j0: number, j1: number, fn: (index: number) => unknown) {
    if (this.seen.length < this.items.length) {
      const grown = new Uint32Array(Math.max(this.items.length, this.seen.length * 2));
      grown.set(this.seen);
      this.seen = grown;
    }
    if (++this.tick === 0xffffffff) {
      this.seen.fill(0);
      this.tick = 1;
    }
    const { seen, tick } = this;
    this.lists(i0, i1, j0, j1, (list) => {
      for (const index of list) {
        if (seen[index] === tick) continue;
        seen[index] = tick;
        fn(index);
      }
    });
  }

  /**
   * Each occupied cell's list in i0..i1 × j0..j1, in no particular order. A box wider than the index
   * is occupied (a view spanning two far-apart places, at one tile a metre) walks the occupied cells
   * instead of every empty cell between them: the same lists, bounded by what the index holds.
   */
  private lists(i0: number, i1: number, j0: number, j1: number, fn: (list: number[]) => void) {
    if ((i1 - i0 + 1) * (j1 - j0 + 1) > this.cells.size) {
      for (const [key, list] of this.cells) {
        const i = Math.floor(key / 67108864) - 33554432,
          j = (key % 67108864) - 33554432;
        if (i >= i0 && i <= i1 && j >= j0 && j <= j1) fn(list);
      }
      return;
    }
    for (let j = j0; j <= j1; j++) {
      for (let i = i0; i <= i1; i++) {
        const list = this.cells.get(this.key(i, j));
        if (list) fn(list);
      }
    }
  }

  /**
   * Calls `fn` for each item whose box intersects `box`, each once, in no particular order and
   * without building a list: for callers that fold the hits order-independently (a minimum, a test).
   * `fn` must not query this index (the two share the dedupe marks).
   */
  visit(box: Rect, fn: (item: T) => void) {
    const { cell, items } = this;
    const i0 = Math.floor(box.x0 / cell);
    const i1 = Math.floor(box.x1 / cell);
    const j0 = Math.floor(box.y0 / cell);
    const j1 = Math.floor(box.y1 / cell);
    const one = i0 === i1 && j0 === j1;
    let seen = this.seen;
    let tick = 0;
    if (!one) {
      if (seen.length < items.length) {
        const grown = new Uint32Array(Math.max(items.length, seen.length * 2));
        grown.set(seen);
        this.seen = seen = grown;
      }
      if (++this.tick === 0xffffffff) {
        seen.fill(0);
        this.tick = 1;
      }
      tick = this.tick;
    }
    this.lists(i0, i1, j0, j1, (list) => {
      for (const index of list) {
        if (!one) {
          if (seen[index] === tick) continue;
          seen[index] = tick;
        }
        const b = items[index].box;
        if (b.x0 <= box.x1 && b.x1 >= box.x0 && b.y0 <= box.y1 && b.y1 >= box.y0) fn(items[index].item);
      }
    });
  }

  all(): T[] {
    return this.items.map((entry) => entry.item);
  }
}

/** A GridIndex's items near a box (GridIndex.near), tested at points inside it. */
export class NearItems<T> {
  constructor(private readonly list: readonly { item: T; box: Rect }[]) {}

  /** Whether any item whose box holds the point (x, y) passes `test`. */
  some(x: number, y: number, test: (item: T) => boolean): boolean {
    for (const { item, box: b } of this.list) if (b.x0 <= x && b.x1 >= x && b.y0 <= y && b.y1 >= y && test(item)) return true;
    return false;
  }

  /** Whether any item whose box meets `r` (inside the box these were taken for) passes `test`: `query(r).some(test)`. */
  someMeeting(r: Rect, test: (item: T) => boolean): boolean {
    for (const { item, box: b } of this.list) if (b.x0 <= r.x1 && b.x1 >= r.x0 && b.y0 <= r.y1 && b.y1 >= r.y0 && test(item)) return true;
    return false;
  }
}
