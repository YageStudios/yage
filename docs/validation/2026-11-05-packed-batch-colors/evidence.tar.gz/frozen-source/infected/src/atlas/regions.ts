/**
 * Spaces and their environment (plan §4 "Geographic region", §7). Climate comes from the space's
 * geographic region plus local fields (elevation, water), never from chunk rows, so chunk (0, 0)
 * of two spaces has two different climates.
 */
import { seasonalTemperature } from "./clock";
import type { SpaceDef, WorldManifest } from "./manifest";

export type Climate = {
  /** °C now (yearly mean + season + elevation lapse). */
  temperature: number;
  moisture: number;
  /** Latitude the season was computed for (daylight itself lives in time.ts). */
  latitude: number;
};

/** The game's coarse heat/cold tolerance bands (disease.ts uses cold/temperate/hot). */
export const enum ClimateBand {
  Cold = 0,
  Temperate = 1,
  Hot = 2,
}

export const climateBand = (temperature: number): ClimateBand => (temperature < 6 ? ClimateBand.Cold : temperature > 22 ? ClimateBand.Hot : ClimateBand.Temperate);

/** Climate at a point of a space; `elevation` in metres (lapse 6.5 °C/km). */
export const climateAt = (space: SpaceDef, day: number, elevation = 0, wetness = 0): Climate => ({
  temperature: space.region.meanTemperature + seasonalTemperature(day, space.region.latitude) - elevation * 0.0065,
  moisture: Math.min(1, Math.max(0, space.region.moisture + wetness)),
  latitude: space.region.latitude,
});

export class SpaceRegistry {
  private readonly byIndex = new Map<number, SpaceDef>();
  private readonly byKey = new Map<string, SpaceDef>();

  constructor(readonly manifest: WorldManifest) {
    for (const space of manifest.spaces) {
      this.byIndex.set(space.index, space);
      this.byKey.set(space.key, space);
    }
  }

  get(index: number) {
    const space = this.byIndex.get(index);
    if (!space) throw new Error(`No space ${index} in world ${this.manifest.id}`);
    return space;
  }

  key(key: string) {
    const space = this.byKey.get(key);
    if (!space) throw new Error(`No space "${key}" in world ${this.manifest.id}`);
    return space;
  }

  all() {
    return [...this.byIndex.values()];
  }

  /** Whether a chunk exists in a space (spaces are bounded). */
  hasChunk(index: number, cx: number, cy: number) {
    const space = this.byIndex.get(index);
    if (!space) return false;
    const [w, h] = space.chunks;
    const { cx: ox, cy: oy } = space.origin ?? { cx: 0, cy: 0 };
    return cx >= ox - w / 2 && cx < ox + w / 2 && cy >= oy - h / 2 && cy < oy + h / 2;
  }
}
