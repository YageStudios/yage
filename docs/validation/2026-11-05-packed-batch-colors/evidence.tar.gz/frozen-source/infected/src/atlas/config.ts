/**
 * Module config for the world atlas flag (docs/WORLD_INTEGRATION.md). The URL (`?atlas=1`,
 * `?atlas=newyork`, `?atlas=off` for the legacy procedural world, `?objects=0` for plain tile
 * plans) or the INFECTED_ATLAS / INFECTED_OBJECTS environment variables override it; `space: null`
 * keeps the legacy procedural world. The game starts in the valley, in objects mode.
 */
export const ATLAS_CONFIG: { space: string | null; objects: boolean } = { space: "valley", objects: true };

/**
 * Objects mode (docs/OBJECTS.md): `?atlas=<space>&objects` (`&objects=0` for plain plans),
 * INFECTED_OBJECTS=1 (or 0), else the config (on). Buildings and roads are placed objects instead
 * of tiles. Only meaningful with the atlas on.
 */
export const objectsRequest = (): boolean => {
  const g = globalThis as { location?: { search?: string }; name?: string; process?: { env?: Record<string, string | undefined> }; document?: unknown };
  const search = g.document ? g.location?.search : typeof g.name === "string" ? g.name : undefined;
  const params = search ? new URLSearchParams(search) : null;
  if (params?.has("objects")) return !["0", "off", "false"].includes(params.get("objects") ?? "");
  const env = g.process?.env?.INFECTED_OBJECTS;
  if (env !== undefined) return env === "1";
  return ATLAS_CONFIG.objects;
};
