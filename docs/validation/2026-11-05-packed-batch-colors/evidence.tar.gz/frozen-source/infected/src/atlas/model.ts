/**
 * World data model (plan §4): immutable structure produced by the generator. Physical, social and
 * administrative layers stay separate: water and terrain are not settlements, a district's
 * grammar is not its architecture style, and a building's use is not its style.
 *
 * Units: positions are in **tiles** of a space (1 tile ≈ 1 m of compressed playable map; the
 * chunk grid is `CHUNK_TILES` tiles). Angles are radians, measured from +x (east) towards +y
 * (south, screen down). Geographic bearings convert with `bearingToAngle`.
 */
import type { FeatureId } from "./ids";
import type { Frame } from "./objects";
import type { NativeUnit } from "../worldgen/native-floor";

export type Vec = { x: number; y: number };
export type Poly = Vec[];
export type Rect = { x0: number; y0: number; x1: number; y1: number };

/** Geographic bearing (degrees clockwise from north) → map angle. North is up (−y). */
export const bearingToAngle = (bearing: number) => ((bearing - 90) * Math.PI) / 180;

/** An oriented box: centre, half extents along its axes, rotation. Its "front" is the +v side. */
export type Obb = { cx: number; cy: number; hu: number; hv: number; angle: number };

// ---------------------------------------------------------------------------------------------
// Physical

export type WaterKind = "river" | "stream" | "canal" | "lake" | "sea";

/** Linear water (rivers, streams) as a centreline with widths, or areal water as a polygon. */
export type Water = {
  id: FeatureId;
  kind: WaterKind;
  name?: string;
  path?: Vec[];
  /** Width per path vertex, tiles. */
  widths?: number[];
  poly?: Poly;
  holes?: Poly[];
  /** Narrow water people wade (creeks, brooks): painted shallow and walkable, roads cross on small bridges. */
  wade?: boolean;
};

export type BiomeId = "temperate-broadleaf" | "temperate-grassland" | "mediterranean" | "boreal" | "semi-arid";

// ---------------------------------------------------------------------------------------------
// Settlements and districts

export type SizeClass = "hamlet" | "village" | "town" | "city" | "metro";
export type VillageForm = "clustered" | "linear" | "bridge" | "fishing" | "dispersed";
export type EconomicRole = "administration" | "market" | "manufacturing" | "port" | "university" | "tourism" | "commuter" | "services" | "agriculture";

/** District road/block grammars (plan §9). */
export type Grammar =
  | "grid"
  | "organic"
  | "suburb"
  | "terrace"
  | "industrial"
  | "village-green"
  | "village-linear"
  | "main-street"
  | "park";

export type DistrictLayer = "core" | "old-core" | "expansion" | "industrial" | "suburb" | "village" | "open";

export type District = {
  id: FeatureId;
  settlement: FeatureId;
  name: string;
  layer: DistrictLayer;
  grammar: Grammar;
  /** Boundary polygon. */
  poly: Poly;
  /** Street grid orientation (radians). */
  angle: number;
  /** Block size along/across the grid axis, tiles (grid grammars). */
  block: [number, number];
  /** Architecture style id (src/domain/styles.ts). */
  style: string;
  /** 0..1, scales storeys and coverage. */
  density: number;
  /** Generation order: lower layers claim ground first. */
  order: number;
};

export type Settlement = {
  id: FeatureId;
  name: string;
  size: SizeClass;
  form?: VillageForm;
  roles: Partial<Record<EconomicRole, number>>;
  center: Vec;
  /** Approximate extent radius, tiles. */
  radius: number;
  districts: District[];
  /** True for places the scenario invented (plan §5). */
  fictional: boolean;
  /** Real reference population and its source; never the simulated population. */
  reference?: { population: number; year: number; source: string };
  /** Simulated population allocated here (sum of its buildings' residents). */
  population: number;
};

// ---------------------------------------------------------------------------------------------
// Networks

export type RoadClass = "arterial" | "collector" | "local" | "lane" | "track" | "path";

/** One street segment. Streets meet where their endpoints coincide (after snapping). */
export type Street = {
  /** Explicitly generated connector, rather than a surveyed road. */
  generated?: boolean;
  /** Imported transport classification, retained through road-chain compilation. */
  highway?: boolean;
  sourceClass?: string;
  sourceId?: string;
  /** Surveyed polyline owner: preserves distinct nearby vertices, without isolating road connections. */
  sourcePath?: FeatureId;
  sourceJoints?: { a?: string; b?: string };
  /** Source vertical level; absent means ground. */
  level?: number;
  /** Separate surveyed carriageway with a median; no invented opposite direction. */
  divided?: boolean;
  ramp?: boolean;
  oneWay?: boolean;
  id: FeatureId;
  cls: RoadClass;
  a: Vec;
  b: Vec;
  /** Carriageway width, tiles; sidewalks are added by class. */
  width: number;
  settlement?: FeatureId;
  /** Set on segments that are part of a regional link. */
  link?: FeatureId;
  /** Surface the compiler paints: sealed road, packed trail or footpath. */
  surface: "road" | "trail" | "path" | "park";
  /** Sidewalk width on each side, tiles (0 for country roads and lanes). */
  sidewalk: number;
  /** Set when this piece is the deck of an explicit bridge. */
  bridge?: FeatureId;
};

/** An explicit water crossing: the only way a street passes over water. */
export type Bridge = {
  id: FeatureId;
  street: FeatureId;
  water: FeatureId;
  a: Vec;
  b: Vec;
  width: number;
};

export type Link = { id: FeatureId; from: FeatureId; to: FeatureId; cls: RoadClass; path: Vec[] };

// ---------------------------------------------------------------------------------------------
// Rail

export type RailKind = "main" | "tram" | "siding";

/** One straight piece of track. Main lines and sidings lie on ballast; trams run in the street. */
export type Rail = {
  underground?: boolean;
  id: FeatureId;
  line: FeatureId;
  kind: RailKind;
  a: Vec;
  b: Vec;
  /** Ballast (or, for trams, rail-set) width, tiles. */
  width: number;
  /** Set where the piece crosses water: the sim keeps the water tiles, art draws the deck. */
  bridge?: boolean;
};

/** A stop on a line: the platform beside the track and the station building behind it. */
export type Station = {
  id: FeatureId;
  name: string;
  line: FeatureId;
  settlement: FeatureId;
  /** Where trains stop, on the track centre line. */
  at: Vec;
  /** Platforms: oriented boxes either side of the tracks. */
  platforms: Obb[];
  /** The station building's id when it was built. */
  building?: FeatureId;
};

// ---------------------------------------------------------------------------------------------
// Sites and buildings

export type BuildingUse =
  | "house"
  | "terrace"
  | "apartment"
  | "tower"
  | "shop"
  | "office"
  | "workshop"
  | "warehouse"
  | "factory"
  | "school"
  | "civic"
  | "church"
  | "farmhouse"
  | "barn"
  | "station"
  /** Objects mode only (worldgen/services.ts): a city's hospitals, a town's clinic, universities. */
  | "hospital"
  | "clinic"
  | "university"
  /** Objects mode only (worldgen/services.ts): where a culture's faith is Islam, its house of worship; and inns. */
  | "mosque"
  | "tavern";

export type Building = {
  id: FeatureId;
  district?: FeatureId;
  settlement?: FeatureId;
  use: BuildingUse;
  style: string;
  /** Footprint. Its +v side faces the street the entrance opens onto. */
  box: Obb;
  /** Entrance: just inside the front wall, and the point on the street side it opens to. */
  door: Vec;
  outside: Vec;
  /** Where the front path meets the street. */
  street: Vec;
  storeys: number;
  /** Households the building can house (homes) and jobs/places it offers. */
  homes: number;
  jobs: number;
  /** Comfortable occupancy (people inside at once), all floors. */
  capacity: number;
  /** Contact zones: one per floor (plan §10: two floors don't share an exposure cell). */
  zones: number;
  /** Simulated residents allocated (exact allocation, see worldgen/population.ts). */
  residents: number;
  /** The game template the building was fitted to (worldgen/units/), axis-aligned on the tile grid. */
  unit?: BuildingUnit;
};

/**
 * A building as the game stamps it: one of the life sim's templates (src/terrain.ts), turned `rot`
 * quarter turns clockwise so its door faces the street. Tiles are global and inclusive.
 */
export type BuildingUnit = {
  /**
   * A measured footprint: what generates its interior (planByKey builds it on demand by the spec's
   * key). The plan keeps only this, not the interior, so a region stays small in every realm.
   */
  native?: NativeUnit;
  /** Template key: a PlaceKind number, "terrace", or a service (src/templates.ts ServiceKey). */
  key: number | "terrace" | "hospital" | "clinic" | "university" | "church" | "mosque";
  /** Template size before turning: frontage and depth, walls included (src/templates.ts). */
  w: number;
  h: number;
  rot: number;
  x0: number;
  y0: number;
  x1: number;
  y1: number;
  /** Door tile, and the tile just outside it. */
  doorX: number;
  doorY: number;
  outX: number;
  outY: number;
  /** Door side: 0 N, 1 E, 2 S, 3 W. */
  facing: number;
  /** Most residents the template houses at the building's storeys. */
  cap: number;
  /**
   * Objects mode: where the unturned template's local tiles land, at any angle (docs/OBJECTS.md).
   * Then x0..y1 bound the footprint, rot and facing are the nearest quarter turn, and the door
   * and doorstep tiles are the floors of the exact points in `Building.door` and `outside`.
   */
  frame?: Frame;
};

export type OpenKind = "park" | "green" | "plaza" | "field" | "pasture" | "meadow" | "wood" | "yard" | "cemetery";

/** Open ground with a use: parks, greens, plazas and the countryside's fields. */
export type OpenSpace = {
  holes?: Poly[];
  id: FeatureId;
  kind: OpenKind;
  poly: Poly;
  /** Row/hedge orientation for fields. */
  angle: number;
  settlement?: FeatureId;
  /** Park laid out with winding paths, groves and lawn (compile/opens.ts parkGround). */
  landscaped?: boolean;
  name?: string;
};

/** A hedgerow or fence line; `gaps` are gate positions along it (0..1). */
export type Hedge = { id: FeatureId; a: Vec; b: Vec; gaps: number[] };

/** A protected site reserved before streets and parcels (parks, landmarks, civic squares). */
export type Reserved = {
  id: FeatureId;
  kind: "park" | "landmark" | "plaza" | "terminal";
  poly: Poly;
  holes?: Poly[];
  name?: string;
  landmark?: string;
  /** A real park laid out as one (compile/opens.ts): winding paths, groves and lawn, not the plain edge-path lawn. */
  landscaped?: boolean;
};

/** A named point a profile protects (plan §9: protected visual relationships). */
export type Anchor = { id: FeatureId; name: string; at: Vec; kind: "landmark" | "gateway" | "terminal" | "label" };
