/**
 * One authoritative campaign timeline (plan §3 "Coordinate contract", §19 phase 0).
 *
 * The game clock in `src/time.ts` turns a host tick into game seconds (the reference "campaign
 * time": day 0 starts at the reference meridian). This module adds what several spaces and
 * workers need on top of it:
 *
 * - **Committed epoch.** Workers report the ticks they have completed; the committed tick is the
 *   minimum, and transport commits and global totals are stamped with it. A worker may run at
 *   most `maxLead` ticks past it, so a delayed worker slows the campaign (explicit policy) rather
 *   than another worker advancing a flight past disease time it hasn't simulated. yage's ChunkPool
 *   implements the same rule on the wire (Op.Commit); `CampaignClock` is the pure model of it.
 * - **Local time per region.** Each region has an authored offset from campaign time (fixed per
 *   scenario; no daylight saving yet). Opening hours compile to world ticks per region.
 * - **Seasons by latitude/hemisphere.**
 */
import { clock, DAY_SECONDS, HOUR } from "../domain/time";
import { TICK_RATE } from "../domain/world";

export { DAY_SECONDS, HOUR, TICK_RATE };

/** Game days per game year. Short, so seasons are visible in play; a scenario setting. */
export const DAYS_PER_YEAR = 28;

// ---------------------------------------------------------------------------------------------
// Committed epoch

export type ClockPolicy = {
  /** Ticks a worker may run past the committed tick. 0: unbounded (not recommended with trips). */
  maxLead: number;
  /** Ticks a lagging worker may run per scheduling round to catch up. */
  catchUp: number;
};

export const DEFAULT_POLICY: ClockPolicy = { maxLead: 8, catchUp: 4 };

export class CampaignClock {
  /** Completed ticks per worker (a worker that has run ticks 0..n-1 reports n). */
  private readonly done = new Map<string, number>();
  committed = 0;

  constructor(readonly policy: ClockPolicy = DEFAULT_POLICY) {}

  join(worker: string, completed = this.committed) {
    this.done.set(worker, completed);
    this.recommit();
  }

  leave(worker: string) {
    this.done.delete(worker);
    this.recommit();
  }

  /** A worker finished ticks up to (not including) `completed`. Returns the committed tick. */
  report(worker: string, completed: number) {
    const before = this.done.get(worker) ?? 0;
    if (completed < before) throw new Error(`Worker ${worker} went back in time (${before} → ${completed})`);
    if (this.policy.maxLead > 0 && completed > this.committed + this.policy.maxLead) {
      throw new Error(`Worker ${worker} ran past the lead bound (${completed} > ${this.committed} + ${this.policy.maxLead})`);
    }
    this.done.set(worker, completed);
    return this.recommit();
  }

  private recommit() {
    let min = Infinity;
    for (const value of this.done.values()) min = Math.min(min, value);
    if (Number.isFinite(min) && min > this.committed) this.committed = min;
    return this.committed;
  }

  completed(worker: string) {
    return this.done.get(worker) ?? 0;
  }

  /**
   * How many ticks `worker` may run now, when wall time says the campaign should be at `due`:
   * never past the lead bound, and a lagging worker at most `catchUp` per round (the rest of the
   * campaign waits for it through the lead bound instead of skipping its simulation).
   */
  allowance(worker: string, due: number) {
    const done = this.completed(worker);
    const lead = this.policy.maxLead > 0 ? this.committed + this.policy.maxLead - done : Infinity;
    const behind = due - done;
    return Math.max(0, Math.min(lead, behind, behind > 1 ? this.policy.catchUp : 1));
  }
}

// ---------------------------------------------------------------------------------------------
// Local time

/** Campaign game-seconds at a tick (see time.ts). */
export const campaignSeconds = (tick: number) => clock(tick);

/** Local game-seconds since local midnight of local day 0, for a region `offsetHours` from campaign time. */
export const localSeconds = (tick: number, offsetHours: number) => clock(tick) + offsetHours * HOUR;
export const localDay = (tick: number, offsetHours: number) => Math.floor(localSeconds(tick, offsetHours) / DAY_SECONDS);
/** Local hour of day in [0, 24). */
export const localHour = (tick: number, offsetHours: number) => {
  const s = localSeconds(tick, offsetHours);
  return (((s % DAY_SECONDS) + DAY_SECONDS) % DAY_SECONDS) / HOUR;
};

/**
 * The first world tick at or after local `hour` on local `day` in a region: how a venue's opening
 * time or a timetabled departure compiles onto the shared timeline.
 */
export const tickAtLocal = (day: number, hour: number, offsetHours: number) => {
  const seconds = day * DAY_SECONDS + hour * HOUR - offsetHours * HOUR;
  // Invert clock(): seconds = tick / TICK_RATE + clock(0).
  return Math.ceil((seconds - clock(0)) * TICK_RATE - 1e-9) + 0;
};

/** Opening hours compiled for one local day: [openTick, closeTick). Close may pass midnight. */
export const openingTicks = (day: number, open: number, close: number, offsetHours: number): [number, number] => [
  tickAtLocal(day, open, offsetHours),
  tickAtLocal(close > open ? day : day + 1, close, offsetHours),
];

// ---------------------------------------------------------------------------------------------
// Seasons

/**
 * Seasonal phase in [0, 1): 0 midwinter, 0.5 midsummer, for a latitude in degrees. The southern
 * hemisphere is half a year out; near the equator seasons fade (`seasonStrength`).
 */
export const seasonPhase = (day: number, latitude: number) => {
  const year = (((day / DAYS_PER_YEAR) % 1) + 1) % 1;
  // Day 0 is midwinter in the north.
  return latitude >= 0 ? year : (year + 0.5) % 1;
};
export const seasonStrength = (latitude: number) => Math.min(1, Math.abs(latitude) / 45);
/** Temperature offset (°C) from the yearly mean: −amp at midwinter, +amp at midsummer. */
export const seasonalTemperature = (day: number, latitude: number, amplitude = 10) =>
  -Math.cos(seasonPhase(day, latitude) * Math.PI * 2) * amplitude * seasonStrength(latitude);
