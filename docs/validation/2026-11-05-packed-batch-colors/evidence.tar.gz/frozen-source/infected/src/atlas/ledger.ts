/**
 * Population ownership ledger (plan §14). A person has exactly one authoritative owner at any time:
 * a local simulation location (a chunk of a space), a background representation, a trip, or a
 * retained dead record. Detailed agents are working copies of these records, not extra people.
 *
 * Ownership only changes through transactions with a stable id. Applying a transaction is all or
 * nothing (every listed person must currently have the stated owner) and idempotent (a repeated
 * id changes nothing), so retries after a lost acknowledgement cannot duplicate or lose people.
 * Counts are kept incrementally and can be checked against a full recount (`audit`).
 *
 * Health travels with the record while nobody simulates the person in detail (trips, background):
 * `state` and `timer` mirror the Condition component (src/components/Condition.ts).
 */
import { ID_RANGES, IdKind } from "./ids";

export const enum Owner {
  /** Not registered (an id never added). */
  None = 0,
  /** Simulated at a location: `space` and chunk key (yage spaceChunkKey) in `where`. */
  Location = 1,
  /** Scheduled background resident of a space: `where` is a site or district reference. */
  Background = 2,
  /** On a trip: `space` holds the trip id. */
  Trip = 3,
  Dead = 4,
}

export type OwnerRef =
  | { kind: Owner.Location; space: number; where: number }
  | { kind: Owner.Background; space: number; where: number }
  | { kind: Owner.Trip; trip: number }
  | { kind: Owner.Dead };

export type Transaction = {
  txn: number;
  /** Tick (committed epoch) the change happens at. */
  tick: number;
  ids: readonly number[];
  from: OwnerRef;
  to: OwnerRef;
};

export type ApplyResult = "applied" | "duplicate" | "rejected";

export type Counts = {
  registered: number;
  living: number;
  dead: number;
  located: number;
  background: number;
  inTransit: number;
};

const FIRST = ID_RANGES[IdKind.Person][0];

const sameOwner = (kind: number, a: number, b: number, ref: OwnerRef) => {
  if (kind !== ref.kind) return false;
  switch (ref.kind) {
    case Owner.Location:
    case Owner.Background:
      return a === ref.space && b === ref.where;
    case Owner.Trip:
      return a === ref.trip;
    default:
      return true;
  }
};

const grow = <T extends Uint8Array | Uint32Array | Float64Array | Float32Array>(array: T, size: number): T => {
  if (array.length >= size) return array;
  const next = new (array.constructor as new (n: number) => T)(Math.max(size, array.length * 2));
  next.set(array);
  return next;
};

export class PopulationLedger {
  private kind = new Uint8Array(1024);
  private a = new Uint32Array(1024);
  private b = new Float64Array(1024);
  /** Health state and stage timer (see Health), current while the ledger owns the person's progression. */
  readonly health = { state: new Uint8Array(1024), timer: new Float32Array(1024) };
  private size = 0;
  private readonly applied = new Map<number, number>();
  private readonly count: Counts = { registered: 0, living: 0, dead: 0, located: 0, background: 0, inTransit: 0 };
  /** Ownership changes in order, for saves, replays and debugging. Bounded by `journalLimit`. */
  readonly journal: Transaction[] = [];
  journalLimit = 10_000;

  /** Index of a person in `health` arrays. */
  slotOf(id: number) {
    return this.index(id);
  }

  private index(id: number) {
    const i = id - FIRST;
    if (i < 0 || i >= 0xc0000000) throw new RangeError(`${id} is not a person id`);
    return i;
  }

  /** Registers people at their first owner (generation or a loaded save). */
  register(ids: readonly number[], owner: OwnerRef, state = 0, timer = 0) {
    for (const id of ids) {
      const i = this.index(id);
      if (i < this.size && this.kind[i] !== Owner.None) throw new Error(`Person ${id} is already registered`);
      this.ensure(i + 1);
      this.write(i, owner);
      this.health.state[i] = state;
      this.health.timer[i] = timer;
      this.count.registered++;
      this.adjust(owner.kind, +1);
    }
  }

  private ensure(size: number) {
    if (size <= this.size) return;
    this.kind = grow(this.kind, size);
    this.a = grow(this.a, size);
    this.b = grow(this.b, size);
    this.health.state = grow(this.health.state, size);
    this.health.timer = grow(this.health.timer, size);
    this.size = size;
  }

  private write(i: number, owner: OwnerRef) {
    this.kind[i] = owner.kind;
    switch (owner.kind) {
      case Owner.Location:
      case Owner.Background:
        this.a[i] = owner.space;
        this.b[i] = owner.where;
        break;
      case Owner.Trip:
        this.a[i] = owner.trip;
        this.b[i] = 0;
        break;
      default:
        this.a[i] = 0;
        this.b[i] = 0;
    }
  }

  private adjust(kind: Owner, by: number) {
    if (kind === Owner.Dead) this.count.dead += by;
    else this.count.living += by;
    if (kind === Owner.Location) this.count.located += by;
    if (kind === Owner.Background) this.count.background += by;
    if (kind === Owner.Trip) this.count.inTransit += by;
  }

  ownerOf(id: number): OwnerRef | null {
    const i = id - FIRST;
    if (i < 0 || i >= this.size || this.kind[i] === Owner.None) return null;
    switch (this.kind[i] as Owner) {
      case Owner.Location:
        return { kind: Owner.Location, space: this.a[i], where: this.b[i] };
      case Owner.Background:
        return { kind: Owner.Background, space: this.a[i], where: this.b[i] };
      case Owner.Trip:
        return { kind: Owner.Trip, trip: this.a[i] };
      default:
        return { kind: Owner.Dead };
    }
  }

  /** Applies an ownership change once. A repeated txn id is a no-op; a stale `from` rejects the whole change. */
  apply(change: Transaction): ApplyResult {
    if (this.applied.has(change.txn)) return "duplicate";
    const indices: number[] = [];
    const seen = new Set<number>();
    for (const id of change.ids) {
      const i = id - FIRST;
      if (seen.has(id) || i < 0 || i >= this.size || !sameOwner(this.kind[i], this.a[i], this.b[i], change.from)) return "rejected";
      seen.add(id);
      indices.push(i);
    }
    for (const i of indices) {
      this.adjust(this.kind[i] as Owner, -1);
      this.write(i, change.to);
      this.adjust(change.to.kind, +1);
    }
    this.applied.set(change.txn, change.tick);
    this.journal.push(change);
    if (this.journal.length > this.journalLimit) this.journal.splice(0, this.journal.length - this.journalLimit);
    return "applied";
  }

  wasApplied(txn: number) {
    return this.applied.has(txn);
  }

  counts(): Counts {
    return { ...this.count };
  }

  /** People owned by trip `trip`, in id order. */
  passengers(trip: number) {
    const out: number[] = [];
    for (let i = 0; i < this.size; i++) if (this.kind[i] === Owner.Trip && this.a[i] === trip) out.push(i + FIRST);
    return out;
  }

  /** Physically present at locations of a space (residents elsewhere or in transit are not). */
  presentIn(space: number) {
    let n = 0;
    for (let i = 0; i < this.size; i++) if ((this.kind[i] === Owner.Location || this.kind[i] === Owner.Background) && this.a[i] === space) n++;
    return n;
  }

  /** Recounts everything; throws if the incremental counts drifted or anyone has no owner. */
  audit(): Counts {
    const recount: Counts = { registered: 0, living: 0, dead: 0, located: 0, background: 0, inTransit: 0 };
    for (let i = 0; i < this.size; i++) {
      const kind = this.kind[i] as Owner;
      if (kind === Owner.None) continue;
      recount.registered++;
      if (kind === Owner.Dead) recount.dead++;
      else recount.living++;
      if (kind === Owner.Location) recount.located++;
      if (kind === Owner.Background) recount.background++;
      if (kind === Owner.Trip) recount.inTransit++;
    }
    for (const key of Object.keys(recount) as (keyof Counts)[]) {
      if (recount[key] !== this.count[key]) throw new Error(`Ledger ${key} drifted: counted ${recount[key]}, kept ${this.count[key]}`);
    }
    if (recount.living + recount.dead !== recount.registered) throw new Error("Living + dead ≠ registered");
    return recount;
  }

  // -------------------------------------------------------------------------------------------
  // Persistence

  save(): LedgerSave {
    return {
      version: 1,
      size: this.size,
      kind: Array.from(this.kind.subarray(0, this.size)),
      a: Array.from(this.a.subarray(0, this.size)),
      b: Array.from(this.b.subarray(0, this.size)),
      state: Array.from(this.health.state.subarray(0, this.size)),
      timer: Array.from(this.health.timer.subarray(0, this.size)),
      applied: [...this.applied],
    };
  }

  static load(save: LedgerSave): PopulationLedger {
    if (save.version !== 1) throw new Error(`Unknown ledger save version ${save.version}`);
    const ledger = new PopulationLedger();
    ledger.ensure(save.size);
    ledger.kind.set(save.kind);
    ledger.a.set(save.a);
    ledger.b.set(save.b);
    ledger.health.state.set(save.state);
    ledger.health.timer.set(save.timer);
    for (const [txn, tick] of save.applied) ledger.applied.set(txn, tick);
    for (let i = 0; i < save.size; i++) {
      const kind = ledger.kind[i] as Owner;
      if (kind === Owner.None) continue;
      ledger.count.registered++;
      ledger.adjust(kind, +1);
    }
    return ledger;
  }
}

export type LedgerSave = {
  version: 1;
  size: number;
  kind: number[];
  a: number[];
  b: number[];
  state: number[];
  timer: number[];
  applied: [number, number][];
};
