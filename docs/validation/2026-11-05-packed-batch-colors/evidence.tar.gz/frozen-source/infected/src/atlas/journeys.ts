/**
 * Journeys (plan §13 "Journey lifecycle"): a trip has a stable id, a conserved manifest, an
 * origin and destination terminal, departure and arrival ticks on the campaign timeline, a
 * capacity, a status and a passenger contact context.
 *
 * Boarding, departure and arrival are ledger transactions: ownership moves from the boarding
 * location to the trip once, and from the trip to the arrival location once. While a trip is
 * under way its passengers' health keeps progressing (`progress`) and they meet each other in the
 * trip's contact context, never at an invisible copy at the origin.
 */
import { Owner, type ApplyResult, type OwnerRef, type PopulationLedger } from "./ledger";
import { mix } from "./ids";

export const enum TripStatus {
  Scheduled = 0,
  Boarding = 1,
  InTransit = 2,
  Arrived = 3,
  Cancelled = 4,
  /** Arrived, but the destination could not take everyone yet (arrival queue). */
  Queued = 5,
}

export type Terminal = { space: number; where: number; site?: string };

export type Trip = {
  id: number;
  mode: "walk" | "road" | "bus" | "rail" | "ferry" | "air";
  origin: Terminal;
  destination: Terminal;
  departTick: number;
  arriveTick: number;
  capacity: number;
  status: TripStatus;
  /** Passenger ids, in boarding order: the conserved manifest. */
  manifest: number[];
  /** Last tick health and contacts were advanced to. */
  advancedTo: number;
};

/** Disease progression for people the ledger owns: returns the new [state, timer] after `seconds`. */
export type Progress = (state: number, timer: number, seconds: number) => [number, number];

/** Passenger contacts for one advance: which of `states` become exposed. Default: nobody. */
export type Contacts = (states: readonly number[], seconds: number, salt: number) => boolean[];

export const holdTimers: Progress = (state, timer, seconds) => [state, Math.max(0, timer - seconds)];

export type TripBookSave = { version: 1; trips: Trip[] };

const txnFor = (trip: number, step: number, salt = 0) => mix(trip, step, salt);

export class TripBook {
  readonly trips = new Map<number, Trip>();

  constructor(
    readonly ledger: PopulationLedger,
    readonly tickRate: number,
    readonly progress: Progress = holdTimers,
    readonly contacts?: Contacts
  ) {}

  schedule(trip: Omit<Trip, "status" | "manifest" | "advancedTo">): Trip {
    if (this.trips.has(trip.id)) throw new Error(`Trip ${trip.id} already exists`);
    if (trip.arriveTick < trip.departTick) throw new Error(`Trip ${trip.id} arrives before it departs`);
    const full: Trip = { ...trip, status: TripStatus.Scheduled, manifest: [], advancedTo: trip.departTick };
    this.trips.set(trip.id, full);
    return full;
  }

  private get(id: number) {
    const trip = this.trips.get(id);
    if (!trip) throw new Error(`Unknown trip ${id}`);
    return trip;
  }

  /**
   * Boards people standing at the origin. `request` names this boarding attempt so a retry is
   * recognised. Rejected when the trip is full, gone, or someone is not at the origin.
   */
  board(id: number, people: readonly number[], tick: number, request: number): ApplyResult {
    const trip = this.get(id);
    const txn = txnFor(id, 1, request);
    if (this.ledger.wasApplied(txn)) return "duplicate";
    if (trip.status !== TripStatus.Scheduled && trip.status !== TripStatus.Boarding) return "rejected";
    if (trip.manifest.length + people.length > trip.capacity) return "rejected";
    const from: OwnerRef = { kind: Owner.Location, space: trip.origin.space, where: trip.origin.where };
    const result = this.ledger.apply({ txn, tick, ids: people, from, to: { kind: Owner.Trip, trip: id } });
    if (result === "applied") {
      trip.manifest.push(...people);
      trip.status = TripStatus.Boarding;
    }
    return result;
  }

  depart(id: number, tick: number) {
    const trip = this.get(id);
    if (trip.status === TripStatus.Boarding || trip.status === TripStatus.Scheduled) {
      trip.status = TripStatus.InTransit;
      trip.advancedTo = tick;
    }
  }

  /** Advances health and passenger contacts of every trip in transit to `tick`. */
  advance(tick: number) {
    for (const trip of this.trips.values()) {
      if (trip.status !== TripStatus.InTransit && trip.status !== TripStatus.Queued) continue;
      const until = Math.max(trip.advancedTo, tick);
      const seconds = (until - trip.advancedTo) / this.tickRate;
      trip.advancedTo = until;
      if (seconds <= 0) continue;
      this.advancePeople(trip, seconds, until);
    }
  }

  private advancePeople(trip: Trip, seconds: number, tick: number) {
    const { state, timer } = this.ledger.health;
    const indices = trip.manifest.map((id) => this.ledger.slotOf(id));
    const exposed = this.contacts?.(indices.map((i) => state[i]), seconds, mix(trip.id, tick));
    indices.forEach((i, k) => {
      const [nextState, nextTimer] = this.progress(state[i], timer[i], seconds);
      state[i] = nextState;
      timer[i] = nextTimer;
      if (exposed?.[k] && state[i] === 0) state[i] = 1;
    });
  }

  /**
   * Hands the passengers to the destination once. `capacityLeft` is how many the destination can
   * take now; if fewer than the manifest, nobody leaves the trip (status Queued) and a later call
   * retries. Returns the ledger result.
   */
  arrive(id: number, tick: number, capacityLeft = Infinity): ApplyResult {
    const trip = this.get(id);
    const txn = txnFor(id, 2);
    if (this.ledger.wasApplied(txn)) return "duplicate";
    if (trip.status !== TripStatus.InTransit && trip.status !== TripStatus.Queued) return "rejected";
    this.advance(tick);
    if (capacityLeft < trip.manifest.length) {
      trip.status = TripStatus.Queued;
      return "rejected";
    }
    const to: OwnerRef = { kind: Owner.Location, space: trip.destination.space, where: trip.destination.where };
    const result = this.ledger.apply({ txn, tick, ids: trip.manifest, from: { kind: Owner.Trip, trip: id }, to });
    if (result === "applied") trip.status = TripStatus.Arrived;
    return result;
  }

  /** Cancels a trip that has not left: passengers go back to the origin. Trips under way can't be cancelled. */
  cancel(id: number, tick: number): ApplyResult {
    const trip = this.get(id);
    if (trip.status === TripStatus.InTransit || trip.status === TripStatus.Queued || trip.status === TripStatus.Arrived) return "rejected";
    const txn = txnFor(id, 3);
    const back: OwnerRef = { kind: Owner.Location, space: trip.origin.space, where: trip.origin.where };
    const result = trip.manifest.length
      ? this.ledger.apply({ txn, tick, ids: trip.manifest, from: { kind: Owner.Trip, trip: id }, to: back })
      : "applied";
    if (result !== "rejected") trip.status = TripStatus.Cancelled;
    return result;
  }

  save(): TripBookSave {
    return { version: 1, trips: [...this.trips.values()].map((t) => ({ ...t, manifest: [...t.manifest], origin: { ...t.origin }, destination: { ...t.destination } })) };
  }

  static load(save: TripBookSave, ledger: PopulationLedger, tickRate: number, progress?: Progress, contacts?: Contacts) {
    if (save.version !== 1) throw new Error(`Unknown trip save version ${save.version}`);
    const book = new TripBook(ledger, tickRate, progress, contacts);
    for (const trip of save.trips) book.trips.set(trip.id, { ...trip, manifest: [...trip.manifest] });
    return book;
  }
}
