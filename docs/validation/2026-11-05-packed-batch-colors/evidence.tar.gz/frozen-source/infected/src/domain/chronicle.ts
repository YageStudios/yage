/**
 * The event log behind the Log tab: what happened, when (game day and clock), by category.
 *
 * Two sources, so nothing is told twice:
 * - The response's append-only series (ladder steps, governments falling, borders, evacuations,
 *   walls, firebombs, burn squads) and the track (settlements reached), read with their own ticks,
 *   so the log has every one of them even when the toasts were throttled. Plus what the HUD sees
 *   cross a line: towns starting cure research, first deaths and death tolls, cure milestones.
 * - The HUD's signals (toasts) for everything else: mutations, weather, healthcare, the host.
 *   Signals that repeat a series event are skipped.
 *
 * Pure: no DOM.
 */
import type { Series, TownEvent, TownResponse } from "./response/measures";
import { dayNumber, timeOfDay } from "./time";

export type LogCat = "mutation" | "towns" | "military" | "deaths" | "weather" | "cure";
export const LOG_CATS: readonly { id: LogCat; label: string; icon: string }[] = [
  { id: "mutation", label: "Mutations", icon: "flask" },
  { id: "towns", label: "Towns", icon: "pin" },
  { id: "military", label: "Military", icon: "shield" },
  { id: "deaths", label: "Deaths", icon: "skull" },
  { id: "weather", label: "Weather", icon: "wind" },
  { id: "cure", label: "Cure", icon: "medical" },
];

/** good/bad as the toasts use them: good for the infection (green), bad for it (red). */
export type LogTone = "good" | "bad" | "gold";
/** `place`: the map place it happened in, when there is one (the log line flies the camera there). */
export type LogEntry = { seq: number; tick: number; cat: LogCat; tone: LogTone; text: string; place?: number };

/** "D3 14:05": the game day (from 1) and clock of a tick (debug back-dated events before the start read as the start). */
export const stamp = (at: number) => {
  const tick = Math.max(0, at);
  const minutes = Math.floor(timeOfDay(tick) * 24 * 60);
  return `D${dayNumber(tick) + 1} ${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
};

// Toasts the series already tell (with their exact tick), and UI hints that aren't events.
const SKIP =
  /orders masks|closes its schools|imposes a curfew|goes into lockdown|sets up checkpoints|lifts its last measures|the government falls|shuts its borders|is being evacuated|walled off by the army|is firebombed|The infection reached|isn't infected yet|Nobody out|No other bloomed host|Objectives? met/;
const RULES: [RegExp, LogCat][] = [
  [/mutat|Unlocked|Unlock point/i, "mutation"],
  [/storm|blizzard|heat wave|bitter cold|river|flood|the road .* (closed|reopens)|^(winter|spring|summer|autumn)\b/i, "weather"],
  [/vaccin|cure/i, "cure"],
  [/morgue|graves|died|dying|\bdead\b/i, "deaths"],
  [/soldier|army|convoy|burn squad|martial/i, "military"],
];

/** A toast's category in the log, or null when the log has it from the series (or it isn't an event). */
export const classifySignal = (text: string, kind: LogTone): LogCat | null => {
  if (SKIP.test(text)) return null;
  if (kind === "gold") return "mutation";
  for (const [re, cat] of RULES) if (re.test(text)) return cat;
  return "towns";
};

const LEVEL_NEWS = ["lifts its last measures", "orders masks", "closes its schools and shops", "imposes a curfew", "goes into lockdown", "sets up checkpoints and cuts transit"];
const LEVEL_WORDS = ["no measures", "masks", "closures", "a curfew", "lockdown", "checkpoints"];
const DEATH_TOLLS = [100, 1000, 10000];
const CURE_STEPS = [0.1, 0.25, 0.5, 0.75, 0.9];

export type LogInput = {
  tick: number;
  names: readonly string[];
  tallies: readonly { reachedAt: number; dead: number }[];
  towns: readonly { research: number }[];
  shared: readonly TownResponse[];
  cure: number;
};

/** What the scan has already told: series entries read per town and key, and lines crossed. */
export type LogCursor = { read: Map<string, number>; told: Set<string>; cureStep: number };
export const newLogCursor = (): LogCursor => ({ read: new Map(), told: new Set(), cureStep: 0 });

type Fresh = Omit<LogEntry, "seq">;

/** New entries since the cursor (in no particular order; the log sorts by tick). */
export const scanLog = (input: LogInput, cursor: LogCursor): Fresh[] => {
  const out: Fresh[] = [];
  const { tick, names } = input;
  const once = (key: string) => (cursor.told.has(key) ? false : (cursor.told.add(key), true));
  const unread = <T>(i: number, key: string, list: readonly T[] | undefined): [T, number][] => {
    if (!list?.length) return [];
    const k = `${i}:${key}`;
    const from = cursor.read.get(k) ?? 0;
    if (from >= list.length) return [];
    cursor.read.set(k, list.length);
    return list.slice(from).map((v, j) => [v, from + j]);
  };
  input.shared.forEach((s, i) => {
    const name = names[i] ?? "A town";
    const events = s.events as TownEvent[] | undefined;
    for (const [[level, at], j] of unread(i, "events", events)) {
      const prev = j > 0 ? events![j - 1][0] : 0;
      if (level > prev) out.push({ place: i, tick: at, cat: "towns", tone: "bad", text: `${name} ${LEVEL_NEWS[level] ?? "steps up its measures"}` });
      else if (level === 0) out.push({ place: i, tick: at, cat: "towns", tone: "good", text: `${name} ${LEVEL_NEWS[0]}` });
      else out.push({ place: i, tick: at, cat: "towns", tone: "good", text: `${name} eases to ${LEVEL_WORDS[level]}` });
    }
    for (const [[v, at]] of unread(i, "fallen", s.fallen as Series | undefined)) if (v > 0) out.push({ place: i, tick: at, cat: "towns", tone: "good", text: `${name}: the government falls` });
    for (const [[v, at]] of unread(i, "border", s.border as Series | undefined))
      out.push({ place: i, tick: at, cat: "military", tone: v > 0 ? "bad" : "good", text: v > 0 ? `${name} shuts its borders` : `${name} opens its borders` });
    const evac = s.evac as Series | undefined;
    for (const [[to, at], j] of unread(i, "evac", evac)) if (j === 0) out.push({ place: i, tick: at, cat: "military", tone: "bad", text: `${name} is being evacuated to ${names[to] ?? "the next town"}` });
    for (const [[v, at]] of unread(i, "cordon", s.cordon as Series | undefined)) {
      if (v === 1) out.push({ place: i, tick: at, cat: "military", tone: "bad", text: `${name} is walled off by the army` });
      else if (v === 2) out.push({ place: i, tick: at, cat: "military", tone: "bad", text: `${name} is firebombed` });
    }
    for (const [[v, at]] of unread(i, "burn", s.burn as Series | undefined)) if (v > 0) out.push({ place: i, tick: at, cat: "military", tone: "bad", text: `Burn squads out in ${name}` });
  });
  input.tallies.forEach((t, i) => {
    const name = names[i] ?? "a town";
    if (t.reachedAt >= 0 && once(`reach:${i}`)) out.push({ place: i, tick: t.reachedAt, cat: "towns", tone: "good", text: `The infection reached ${name}` });
    if (t.dead > 0 && once(`dead:${i}:1`)) out.push({ place: i, tick, cat: "deaths", tone: "good", text: `First death in ${name}` });
    for (const n of DEATH_TOLLS) if (t.dead >= n && once(`dead:${i}:${n}`)) out.push({ place: i, tick, cat: "deaths", tone: "good", text: `${name}: ${n.toLocaleString("en-US")} dead` });
  });
  input.towns.forEach((t, i) => {
    if (t.research > 0 && once(`research:${i}`)) out.push({ place: i, tick, cat: "cure", tone: "bad", text: `${names[i] ?? "A town"} starts researching a cure` });
  });
  while (cursor.cureStep < CURE_STEPS.length && input.cure >= CURE_STEPS[cursor.cureStep]) {
    out.push({ tick, cat: "cure", tone: "bad", text: `The cure is ${Math.round(CURE_STEPS[cursor.cureStep] * 100)}% done` });
    cursor.cureStep++;
  }
  return out;
};

/** The place a toast talks about: the longest place name in its text, or undefined. */
export const placeIn = (text: string, names: readonly string[]) => {
  let best = -1;
  names.forEach((name, i) => {
    if (name && text.includes(name) && (best < 0 || name.length > names[best].length)) best = i;
  });
  return best >= 0 ? best : undefined;
};

/** The log itself: entries in tick order (ties in arrival order), the oldest dropped past `cap`. */
export type Log = { entries: LogEntry[]; seq: number; cap: number; version: number };
export const newLog = (cap = 400): Log => ({ entries: [], seq: 0, cap, version: 0 });

export const addToLog = (log: Log, fresh: readonly Fresh[]) => {
  if (!fresh.length) return;
  for (const f of fresh) log.entries.push({ ...f, seq: log.seq++ });
  log.entries.sort((a, b) => a.tick - b.tick || a.seq - b.seq);
  if (log.entries.length > log.cap) log.entries.splice(0, log.entries.length - log.cap);
  log.version++;
};

/** Newest first, only the categories switched on, at most `limit`. */
export const filterLog = (log: Log, on: ReadonlySet<LogCat>, limit = 120): LogEntry[] => {
  const out: LogEntry[] = [];
  for (let i = log.entries.length - 1; i >= 0 && out.length < limit; i--) if (on.has(log.entries[i].cat)) out.push(log.entries[i]);
  return out;
};
