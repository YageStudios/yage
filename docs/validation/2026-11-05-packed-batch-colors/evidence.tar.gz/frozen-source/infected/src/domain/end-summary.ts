import type { EndSummary } from "../ui/model";
import { fmt, pct } from "../ui/format";

export const endSummary = (won: boolean, summary: { absorbed: number; people: number; dead: number; day: number; traits: number }, cured = false): EndSummary => ({
  won,
  icon: won ? "bio" : cured ? "flask" : "skull",
  title: won ? "The world is ours" : cured ? "Humanity has a cure" : "The infection has died out",
  lines: [won
    ? "The hive has absorbed enough of humanity that nothing can stop it now."
    : cured
      ? "The labs finished their work. Doses are going out, and the infection will not survive them. Reload to try again."
      : "Nobody carries the infection any more. Reload to try again."],
  metrics: [
    { label: "Absorbed", value: `${fmt(summary.absorbed)} · ${pct(summary.people ? summary.absorbed / summary.people : 0)}` },
    { label: "Dead", value: fmt(summary.dead) },
    { label: "Days", value: String(summary.day + 1) },
    { label: "Mutations", value: String(summary.traits) },
  ],
});

