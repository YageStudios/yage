import { chunkKey } from "yage/streaming";
import { plannedStartTowns } from "../worldgen/start-towns";
/**
 * Disease states, traits, decay, the human response rules and the numbers the page
 * and the workers both need. Pure: no workers, no Pixi.
 *
 * Tunable numbers of the game loop live in `RULES` and `BASE_TRAITS` here; cards, pathogens and the
 * passive tree in mutations.ts.
 */
import { CONTENT } from "../content/runtime";
import { Kind } from "../worldgen/terrain/index";
import { planningPlan, planningSettlement, type PlanningContext } from "../worldgen/commute/context";
import { gidFor, WORLD_MAX, WORLD_MIN } from "./world";

export const enum State {
  Susceptible = 0,
  /** Infected and contagious, but showing nothing yet. */
  Incubating = 1,
  /** Part of the hive: contagious, visible, steerable. */
  Infected = 2,
  Dead = 3,
}

/** Atlas rows: what a pawn looks like, by disease state (and role). */
export const enum SpriteSet {
  Healthy = 0,
  Incubating = 1,
  Infected = 2,
  Dead = 3,
  Soldier = 4,
}
/** Looks per sprite set (atlas columns). */
export const SPRITE_VARIANTS = 4;

/** Role.kind values. */
export const enum RoleKind {
  Civilian = 0,
  Soldier = 1,
}

export type Traits = {
  /** Which pathogen the player chose (see PATHOGENS in mutations.ts); workers only log it. */
  pathogen: string;
  /** Gid of the person the player chose as patient zero; -1 before the game starts. */
  start: number;
  /** Scales every source of viral load (breath, clouds, surfaces); 1 = base. See load.ts. */
  infectivity: number;
  /** Load at which an uninfected person turns (load.ts). */
  dose: number;
  /** Share of their load a person clears per second while away from every source. */
  clearance: number;
  /** Load per second breathed face to face with a contagious person (falls off with distance). */
  breath: number;
  /** Coughs, sneezes and vomits per minute of a symptomatic host (0 = that symptom isn't picked). */
  cough: number;
  sneeze: number;
  vomit: number;
  /** Load one cough puts in the air, how wide its cloud spreads (tiles) and how long it hangs (s). */
  cloudLoad: number;
  cloudSize: number;
  cloudLife: number;
  /** Surface load per second a symptomatic host leaves on what it touches (sweat, rash: 0 without). */
  touch: number;
  /** Half-life of surface load, seconds. */
  persistence: number;
  /** How much feverish hosts stumble (0 none, 1 clearly). */
  stagger: number;
  /** Seconds from infection to symptoms. */
  incubation: number;
  /** Life of a bloomed host in seconds at decay 1 (each host rolls ±RULES.lifeJitter). */
  lifespan: number;
  /** How fast bloomed hosts use up their life (1 = one second per second). */
  decay: number;
  /**
   * How far contact reaches. Warm chunks: 0 own 4×4-tile cell, 1 also the 4 side cells, 2 all 8
   * around, at `reachWeight`. Hot chunks: breath carries further by reach × reachWeight.
   */
  reach: number;
  reachWeight: number;
  /** Corpses stay contagious with this weight, and soil the ground they lie on (0 = harmless). */
  corpses: number;
  /**
   * Rage: chance a bloomed host breaks from its routine to go after an uninfected person nearby
   * (0 = off, the default; hosts otherwise live their normal scheduled lives). Late cards only.
   */
  aggression: number;
  /** Extra speed for symptomatic hosts (0.5 = 50% faster). */
  frenzy: number;
  /**
   * Bite (> 0 on): bloomed hosts bite the healthy, and the player's host can. Without rage a bite
   * infects (mania); with rage it tries to kill, and who lives through it is infected (BiteSystem).
   */
  bite: number;
  /** Reanimation (> 0 on): who a raging bite kills rises bloomed, and every bite feeds the biter's life. */
  reanimate: number;
  /** Corpse eating (FeedSystem): bloomed hosts eat the dead and live longer for it. */
  scavenge: number;
  /**
   * Efficient metabolism (0..1): bloomed hosts burn their life slower, living off what's wild about
   * them (deer, worms, fish): far longer in the sparse countryside, hardly longer in a city.
   */
  metabolism: number;
  /**
   * Breeding (0..1): the bloomed have young, born bloomed into the homes of the long dead, more where
   * the land is wild and its homes stand empty: their numbers can hold, and grow back.
   */
  breed: number;
  /**
   * Feral animals (0..1): the town's strays and crows catch it from its sick and dead and go for the
   * living, biting (a raging strain's bite kills; a reanimating one's killed rise).
   */
  beasts: number;
  /**
   * Mutation (0..1): that share (× RULES.mutantShare) of the bloomed grow into super mutants, each of
   * a kind its entity says (src/entities/mutants.json5: faster, armoured, stronger).
   */
  mutation: number;
  /** How noticeable symptomatic hosts are: scales the alert threshold and soldiers' aim. */
  visibility: number;
  /** Chance a hit symptomatic host shrugs it off (capped at 0.9). */
  armor: number;
  /** Spread multiplier kept in cold / hot climate bands (1 = unaffected). */
  cold: number;
  heat: number;
  /** Page only: scales the evolution-point thresholds for card offers (lower = more often). */
  pickRate: number;
  /** Page only: every card picked multiplies infectivity by (1 + cascade). */
  cascade: number;
  /** Page only: the cure fills this much slower (Drug Resistance, Hardening). */
  cureResist: number;
  /** Page only: Genetic Reshuffles picked; each knocks the cure back. */
  reshuffle: number;
  /** Testing finds a symptomatic host this much less often (Hardening, stealth). */
  evasion: number;
  /**
   * Animal and water routes (src/critters.ts, src/response/routes.ts): how strongly rats, birds
   * and livestock carry it, and how far it fouls a town's water supply (0 = not a route).
   */
  rodent: number;
  bird: number;
  livestock: number;
  water: number;
  /** Stray dogs and mosquitoes carry it too (src/critters.ts): 0 = not a route. */
  dog: number;
  mosquito: number;
  /** Bleeds per minute of a symptomatic host: blood on the ground that infects whoever steps in it. */
  bleed: number;
  /** Collapses per minute of a host past SYMPTOMS.collapseFrom of its life (symptoms.ts). */
  collapse: number;
  /** Spore bursts per minute (fungi): big, slow clouds; the dead burst too. */
  spores: number;
  /** Share of a bloomed host's life with no outward sign (prions): no symptoms, not visible. */
  silent: number;
  /** How little the sickness slows and confines hosts (parasites keep theirs mixing), 0–1. */
  steady: number;
  /** Page only: mutations it picks up on its own per game day (viruses). */
  drift: number;
};

/** The numbers are data (content/disease.json5). */
export const BASE_TRAITS: Traits = CONTENT.disease.traits;

/** The numeric traits (everything cards and tree nodes can change). */
export type Stat = Exclude<keyof Traits, "pathogen" | "start">;

/** Everything the owner tunes about the loop, in one place; data in content/disease.json5. */
export const RULES = CONTENT.disease.rules;

export type Climate = "temperate" | "cold" | "hot";
export const climateOf = (cy: number): Climate => (cy < RULES.coldBelowCy ? "cold" : cy > RULES.hotAboveCy ? "hot" : "temperate");
export const climateFactor = (cy: number, traits: Traits) => {
  const climate = climateOf(cy);
  return climate === "cold" ? traits.cold : climate === "hot" ? traits.heat : 1;
};

/** A chunk is alerted when its visible infected stand out enough. */
export const isAlerted = (people: number, visible: number, traits: Traits) =>
  visible >= RULES.alertMinimum && visible * traits.visibility >= people * RULES.alertShare;

/** Soldiers an alerted chunk wants. */
export const soldiersWanted = (people: number, visible: number) =>
  Math.min(Math.floor(people * RULES.maxSoldierShare), Math.ceil(RULES.soldierSquad + visible * RULES.soldiersPerVisible));

// ---------------------------------------------------------------------------------------------
// Decay

/** Decay stage of a bloomed host by share of life left: 0 fresh, 1 waning, 2 failing, 3 dying. */
export const decayStage = (lifeShare: number) => {
  const [fresh, waning, failing] = RULES.decayStages;
  return lifeShare > fresh ? 0 : lifeShare > waning ? 1 : lifeShare > failing ? 2 : 3;
};

/**
 * `describe` byte (the locate entry's tint): state in the low 2 bits, seconds of life left in the
 * high 6 (bloomed hosts only). Codes 0–39 are whole seconds; 40–63 grow geometrically (~21% a step)
 * up to ~4000 s, so a long-lived steered host's countdown never saturates.
 */
const DESCRIBE_STEP = Math.pow(100, 1 / 24);
const describeSeconds = (code: number) => (code < 40 ? code : Math.round(40 * Math.pow(DESCRIBE_STEP, code - 39)));
export const encodeDescribe = (state: number, secondsLeft = 0) => {
  if (state !== State.Infected) return state;
  const s = Math.max(0, Math.ceil(secondsLeft));
  let code = Math.min(39, s);
  while (code < 63 && describeSeconds(code) < s) code++;
  return state | (code << 2);
};
/** State, and the seconds left as a range: more than `atLeast`, at most `secondsLeft`. */
export const decodeDescribe = (byte: number) => {
  const code = byte >> 2;
  return { state: byte & 3, secondsLeft: describeSeconds(code), atLeast: code ? describeSeconds(code - 1) : 0 };
};

/**
 * The page's countdown of a bloomed host's life: keeps its own smooth estimate (counted down between
 * reports) while it fits the reported range, else snaps into it (the middle, on a first report).
 */
export const followLife = (estimate: number, described: { secondsLeft: number; atLeast: number }) => {
  const { secondsLeft: hi, atLeast: lo } = described;
  if (!Number.isFinite(estimate)) return hi - lo <= 1 ? hi : (lo + hi) / 2;
  return Math.min(hi, Math.max(lo, estimate));
};

export const encodeTraits = (traits: Traits) => new TextEncoder().encode(JSON.stringify(traits));
export const decodeTraits = (bytes: Uint8Array): Traits => ({ ...BASE_TRAITS, ...JSON.parse(new TextDecoder().decode(bytes)) });

// ---------------------------------------------------------------------------------------------
// Patient zero

/** The town nearest the origin, where patient zero lives. */
export const startChunk = (context: PlanningContext): [number, number] => {
  const plan = planningPlan(context);
  if (plan?.skeleton.space.origin) {
    const town = plannedStartTowns(plan)[0];
    return town ? [town.cx, town.cy] : [plan.skeleton.space.origin.cx, plan.skeleton.space.origin.cy];
  }
  let best: [number, number] = [0, 0];
  let bestDistance = Infinity;
  for (let cy = -4; cy <= 4; cy++) {
    for (let cx = -4; cx <= 4; cx++) {
      const distance = cx * cx + cy * cy;
      if (planningSettlement(context, cx, cy).kind === Kind.Town && distance < bestDistance) {
        best = [cx, cy];
        bestDistance = distance;
      }
    }
  }
  return best;
};

export type StartTown = { cx: number; cy: number; name: string; climate: Climate; city: boolean; size: number };

// Place names: an English-sounding head and tail (Ashford, Kirkdale, Thornwick), one per
// settlement across the whole map. Cities pick first, then towns, then villages, nearest the
// origin first; a name already taken goes to the next pick, so every settlement is unique.
const HEADS = ["ash", "bram", "cal", "dun", "el", "fen", "gar", "hal", "kirk", "lin", "mor", "nor", "ock", "pen", "rid", "stan", "thorn", "wick", "ley", "bar", "black", "brad", "carl", "cold", "crow", "elm", "fair", "glen", "green", "har", "hay", "kings", "long", "mar", "mill", "oak", "red", "sal", "sand", "shel", "stone", "wald", "whit", "wil", "wolf", "ald", "bex", "cor"];
const TAILS = ["brook", "holt", "ford", "by", "ton", "ham", "wick", "ley", "dale", "mere", "stead", "field", "worth", "bury", "wood", "well", "moor", "thorpe", "cot", "hurst", "bridge", "gate", "den", "combe"];
const PREFIXES = ["Upper", "Lower", "Great", "Little", "North", "South", "East", "West", "Nether", "Old"];
const capital = (name: string) => name[0].toUpperCase() + name.slice(1);
/** A settlement's k-th choice of name. */
const nameChoice = (cx: number, cy: number, k: number) => {
  const h = (Math.imul(cx + 101, 73856093) ^ Math.imul(cy + 211, 19349663) ^ Math.imul(k + 1, 83492791)) >>> 0;
  const head = HEADS[h % HEADS.length];
  let tail = TAILS[(h >>> 10) % TAILS.length];
  if (tail === head) tail = TAILS[((h >>> 10) + 1) % TAILS.length];
  return capital(head + tail);
};
const nameKey = chunkKey;
const RANK = { [Kind.City]: 0, [Kind.Town]: 1, [Kind.Village]: 2 } as Record<number, number>;
/**
 * Every settlement's name under a planning context's terrain, keyed by chunk. Built by whoever owns the
 * map (the world map's places carry them); nothing here caches it across terrains.
 */
export type SettlementNames = ReadonlyMap<number, string>;
export const settlementNames = (context: PlanningContext): SettlementNames => {
  const found: [number, number, number][] = [];
  for (let cy = WORLD_MIN; cy <= WORLD_MAX; cy++)
    for (let cx = WORLD_MIN; cx <= WORLD_MAX; cx++) {
      const rank = RANK[planningSettlement(context, cx, cy).kind];
      if (rank !== undefined) found.push([cx, cy, rank]);
    }
  found.sort((a, b) => a[2] - b[2] || a[0] * a[0] + a[1] * a[1] - (b[0] * b[0] + b[1] * b[1]) || a[1] - b[1] || a[0] - b[0]);
  const taken = new Set<string>();
  const names = new Map<number, string>();
  for (const [cx, cy] of found) {
    let name = "";
    for (let k = 0; k < 64 && (!name || taken.has(name)); k++) name = nameChoice(cx, cy, k);
    for (let k = 0; taken.has(name); k++) name = `${PREFIXES[k % PREFIXES.length]} ${nameChoice(cx, cy, Math.floor(k / PREFIXES.length))}`;
    taken.add(name);
    names.set(nameKey(cx, cy), name);
  }
  return names;
};
/** A stable made-up name for a settlement chunk, unique across the map. */
export const townName = (names: SettlementNames, cx: number, cy: number) => names.get(nameKey(cx, cy)) ?? nameChoice(cx, cy, 0);

/**
 * Start-town choices: the default town, the nearest city, and the nearest towns in the cold north
 * and the hot south (where climate traits matter). Nearest to the origin first, no duplicates.
 */
export const startTowns = (nameOf: (cx: number, cy: number) => string, context: PlanningContext): StartTown[] => {
  const plan = planningPlan(context);
  if (plan?.skeleton.space.origin) return plannedStartTowns(plan);
  const found: StartTown[] = [];
  for (let cy = -32; cy < 32; cy++) {
    for (let cx = -32; cx < 32; cx++) {
      const s = planningSettlement(context, cx, cy);
      if (s.kind === Kind.Town || s.kind === Kind.City)
        found.push({ cx, cy, name: nameOf(cx, cy), climate: climateOf(cy), city: s.kind === Kind.City, size: s.size });
    }
  }
  const near = (a: StartTown, b: StartTown) => a.cx * a.cx + a.cy * a.cy - (b.cx * b.cx + b.cy * b.cy);
  found.sort(near);
  const [dcx, dcy] = startChunk(context);
  const picks = [
    found.find((t) => t.cx === dcx && t.cy === dcy),
    found.find((t) => t.city),
    found.find((t) => t.climate === "cold"),
    found.find((t) => t.climate === "hot"),
  ];
  const out: StartTown[] = [];
  for (const t of picks) if (t && !out.includes(t)) out.push(t);
  return out;
};

/**
 * The default patient zero: the first person of the default start town. A function, not a
 * constant: the start town reads the terrain, and under an atlas that is the whole world plan, so
 * computing it at import made every chunk worker build its own plan before it could adopt the
 * page's (about a second of worker startup).
 */
export const patientZero = (context: PlanningContext) => gidFor(...startChunk(context), 0, context);
/** Patient zero of a start town. */
export const startGid = (cx: number, cy: number, scope: number | PlanningContext) => gidFor(cx, cy, 0, scope);
/**
 * Generation no longer infects anyone: the player picks the pathogen and the start town, and the
 * traits config's `start` gid is infected by whichever chunk holds that person (see infection.ts).
 */
export const isPatientZero = (_cx: number, _cy: number, _index: number) => false;

// ---------------------------------------------------------------------------------------------
// Per-chunk stats

/** Stats each chunk sends after stepping: u24 counts. */
export const STAT_FIELDS = 6;
export type ChunkCounts = {
  people: number;
  incubating: number;
  infected: number;
  dead: number;
  /** Uninfected soldiers. */
  soldiers: number;
  /** 1 while the chunk is on alert. */
  alert: number;
};

export const encodeCounts = (people: number, incubating: number, infected: number, dead: number, soldiers = 0, alert = 0) => {
  const bytes = new Uint8Array(STAT_FIELDS * 3);
  [people, incubating, infected, dead, soldiers, alert].forEach((value, i) => {
    bytes[i * 3] = value & 255;
    bytes[i * 3 + 1] = (value >> 8) & 255;
    bytes[i * 3 + 2] = (value >> 16) & 255;
  });
  return bytes;
};

export const decodeCounts = (bytes: Uint8Array): ChunkCounts => {
  const at = (i: number) => (i * 3 + 2 < bytes.length ? bytes[i * 3] | (bytes[i * 3 + 1] << 8) | (bytes[i * 3 + 2] << 16) : 0);
  return { people: at(0), incubating: at(1), infected: at(2), dead: at(3), soldiers: at(4), alert: at(5) };
};

/** Everyone the hive ever reached: the living hive plus the dead (only the hive dies here). */
export const everInfected = (counts: Pick<ChunkCounts, "incubating" | "infected" | "dead">) => counts.incubating + counts.infected + counts.dead;

/** Evolution points earned for everyone ever infected: generous early, slower later. */
export const pointsEarned = (everInfected: number) => Math.floor(8 * Math.log2(1 + everInfected));
