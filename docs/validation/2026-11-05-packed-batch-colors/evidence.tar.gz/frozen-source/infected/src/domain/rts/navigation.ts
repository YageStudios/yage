import type { Point } from "./orders";

export type Walkable = (x: number, y: number) => boolean;
/** Unlike the visual line check, this never skips thin walls on a long order. */
export const clearRoute = (a: Point, b: Point, open: Walkable, sample = 4) => {
  const count = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / sample));
  let previous = a;
  for (let n = 1; n <= count; n++) {
    const x = a.x + (b.x - a.x) * n / count, y = a.y + (b.y - a.y) * n / count;
    if (!open(x, y)) return false;
    // A clear diagonal through two touching solid corners is not a walkable opening.
    if (x !== previous.x && y !== previous.y && (!open(x, previous.y) || !open(previous.x, y))) return false;
    previous = { x, y };
  }
  return true;
};

/** Advance through the chunk's hand-off margin, not just up to its boundary. */
export const chunkGoal = (from: Point, target: Point, size: number, margin: number): Point => {
  const dx = target.x - from.x, dy = target.y - from.y;
  let t = 1;
  if (dx > 0) t = Math.min(t, (size + margin - from.x) / dx);
  else if (dx < 0) t = Math.min(t, (-margin - from.x) / dx);
  if (dy > 0) t = Math.min(t, (size + margin - from.y) / dy);
  else if (dy < 0) t = Math.min(t, (-margin - from.y) / dy);
  return { x: from.x + dx * Math.max(0, t), y: from.y + dy * Math.max(0, t) };
};

type Node = { x: number; y: number; g: number; f: number; parent: Node | null; serial: number };
/** A* on a half-tile grid. Edge checks forbid corner-cutting and detect thin/rotated walls.
 * The fixed budget bounds a genuinely unreachable order; null means blocked, never teleport.
 * Maths and lookups only: caches and Wander writes belong to RtsMotionSystem. */
export const findRoute = (from: Point, goal: Point, open: Walkable, options: { step: number; min: number; max: number; budget?: number; tolerance?: number }): Point[] | null => {
  const { step, min, max, budget = 18000, tolerance = step * 1.5 } = options;
  if (![from.x, from.y, goal.x, goal.y, step, min, max].every(Number.isFinite) || step <= 0 || max < min) return null;
  if (clearRoute(from, goal, open, step / 2)) return [goal];
  const heap: Node[] = [];
  const best = new Map<string, number>();
  let serial = 0;
  const before = (a: Node, b: Node) => a.f < b.f || a.f === b.f && a.serial < b.serial;
  const push = (node: Node) => {
    let i = heap.length;
    heap.push(node);
    while (i > 0) { const p = (i - 1) >> 1; if (!before(node, heap[p])) break; heap[i] = heap[p]; i = p; }
    heap[i] = node;
  };
  const pop = () => {
    const first = heap[0], last = heap.pop()!;
    if (heap.length) {
      let i = 0;
      for (;;) {
        let c = i * 2 + 1;
        if (c >= heap.length) break;
        if (c + 1 < heap.length && before(heap[c + 1], heap[c])) c++;
        if (!before(heap[c], last)) break;
        heap[i] = heap[c]; i = c;
      }
      heap[i] = last;
    }
    return first;
  };
  const key = (x: number, y: number) => `${x},${y}`;
  // Start at the actual feet. Snapping first can put a person across a thin wall.
  const start: Node = { ...from, g: 0, f: Math.hypot(goal.x - from.x, goal.y - from.y), parent: null, serial: serial++ };
  push(start); best.set(key(start.x, start.y), 0);
  const directions = [[1, 0], [0, 1], [-1, 0], [0, -1], [1, 1], [-1, 1], [-1, -1], [1, -1]];
  for (let visited = 0; heap.length && visited < budget; visited++) {
    const node = pop();
    if (node.g !== best.get(key(node.x, node.y))) continue;
    const near = Math.hypot(node.x - goal.x, node.y - goal.y);
    if (near <= tolerance || near <= step * 3 && clearRoute(node, goal, open, step / 2)) {
      const path: Point[] = [];
      for (let at: Node | null = node; at?.parent; at = at.parent) path.push({ x: at.x, y: at.y });
      path.reverse();
      if (clearRoute(node, goal, open, step / 2)) path.push(goal);
      // Remove only collinear points. Smoothing across corners would undo edge collision tests.
      return path.filter((p, i) => {
        if (!i || i === path.length - 1) return true;
        const a = path[i - 1], b = path[i + 1];
        return Math.abs((p.x - a.x) * (b.y - p.y) - (p.y - a.y) * (b.x - p.x)) > 0.001;
      });
    }
    for (const [dx, dy] of directions) {
      const x = node.x + dx * step, y = node.y + dy * step;
      if (x < min || x > max || y < min || y > max) continue;
      if (!clearRoute(node, { x, y }, open, step / 2)) continue;
      if (dx && dy && (!open(node.x + dx * step, node.y) || !open(node.x, node.y + dy * step))) continue;
      const g = node.g + Math.hypot(dx, dy) * step, k = key(x, y);
      if (g >= (best.get(k) ?? Infinity)) continue;
      best.set(k, g);
      push({ x, y, g, f: g + Math.hypot(goal.x - x, goal.y - y), parent: node, serial: serial++ });
    }
  }
  return null;
};
