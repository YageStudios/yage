/**
 * Extreme weather as the towns feel it (weather.ts has the sky). Everything here is a pure
 * function of the map, the place and the time, so every thread and every chunk agrees:
 *
 * - Floods close low roads and bridges: where a regional link crosses a river or runs along its
 *   bank, it shuts while the flood there is past `EXTREMES.closeAt`, and opens again as it falls.
 *   A town with closed links is partly cut off (`cutOffAt`): commuters and trucks can't get through.
 * - Heat waves, bitter cold and blizzards send people to hospital (`admissionsAt`) and open the
 *   town's warming or cooling centre, where a queue forms (`shelterOpen`).
 * - Storms and seasons: the page's news reads `extremesOf` and `seasonAt` (stepExtremes).
 */
import { CHUNK_SIZE, TILE } from "../world";
import { clock } from "../time";
import {
  chunkWeather,
  EXTREMES,
  exposureAdmissions,
  floodAt,
} from "../weather";
import type { Point, WorldMap } from "../../worldmap/places";
import type { PlanningContext } from "../../worldgen/commute/context";
import { responseProjections, type GenerationInput } from "../../worldgen/source/owner";
import { perp } from "../../worldgen/geometry";
import {
  pointAt,
  runTime,
  type Run,
  type TransitLine,
} from "../../worldgen/transit";

/** A place a regional road is low: a bridge over a river, or a stretch along its bank (world units). */
export type LowPoint = {
  x: number;
  y: number;
  bridge: boolean;
  angle: number;
  /** How far either side the barriers stand (world units). */ reach: number;
};

const cross = (a: Point, b: Point, c: Point, d: Point): Point | null => {
  const rx = b.x - a.x;
  const ry = b.y - a.y;
  const sx = d.x - c.x;
  const sy = d.y - c.y;
  const den = rx * sy - ry * sx;
  if (Math.abs(den) < 1e-9) return null;
  const t = ((c.x - a.x) * sy - (c.y - a.y) * sx) / den;
  const u = ((c.x - a.x) * ry - (c.y - a.y) * rx) / den;
  return t >= 0 && t <= 1 && u >= 0 && u <= 1
    ? { x: a.x + rx * t, y: a.y + ry * t }
    : null;
};

const segDist = (p: Point, a: Point, b: Point) => {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const l2 = dx * dx + dy * dy;
  const t = l2
    ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2))
    : 0;
  return Math.hypot(a.x + dx * t - p.x, a.y + dy * t - p.y);
};

/** Per link (same order as `map.links`): its bridges and riverside stretches. Once per map. */
export const lowPointsOf = (map: WorldMap, owner: GenerationInput): LowPoint[][] => {
  const { lowPoints: lowCache } = responseProjections(owner);
  const hit = lowCache.get(map);
  if (hit) return hit;
  const out = map.links.map((l) => {
    const pts: LowPoint[] = [];
    const add = (p: Point, bridge: boolean, angle: number, reach: number) => {
      // One per half chunk along the road.
      if (pts.some((q) => Math.hypot(q.x - p.x, q.y - p.y) < CHUNK_SIZE / 2))
        return;
      pts.push({ x: p.x, y: p.y, bridge, angle, reach });
    };
    for (let i = 1; i < l.path.length; i++) {
      const a = l.path[i - 1];
      const b = l.path[i];
      const angle = Math.atan2(b.y - a.y, b.x - a.x);
      for (const r of map.rivers) {
        for (let k = 1; k < r.path.length; k++) {
          const x = cross(a, b, r.path[k - 1], r.path[k]);
          if (x) add(x, true, angle, r.width / 2 + 2.5 * TILE);
        }
      }
    }
    // Riverside stretches: road vertices just above the bank.
    for (let i = 0; i < l.path.length; i++) {
      const p = l.path[i];
      const next = l.path[Math.min(l.path.length - 1, i + 1)];
      const prev = l.path[Math.max(0, i - 1)];
      for (const r of map.rivers) {
        let near = Infinity;
        for (let k = 1; k < r.path.length; k++)
          near = Math.min(near, segDist(p, r.path[k - 1], r.path[k]));
        if (near < r.width / 2 + 5 * TILE)
          add(p, false, Math.atan2(next.y - prev.y, next.x - prev.x), 3 * TILE);
      }
    }
    return pts;
  });
  lowCache.set(map, out);
  return out;
};

/** `owner` is the run's planning context, whose weather caches answer. */
const floodOver = (p: Point, t: number, owner: PlanningContext) =>
  floodAt(p.x / CHUNK_SIZE, p.y / CHUNK_SIZE, t, undefined, owner);

/** How deep the worst flood on a link is at a tick (0 when nothing on it is low). */
export const linkFlood = (map: WorldMap, link: number, tick: number, owner: PlanningContext) => {
  const t = clock(tick);
  let v = 0;
  for (const p of lowPointsOf(map, owner)[link] ?? [])
    v = Math.max(v, floodOver(p, t, owner));
  return v;
};

/** Whether a flood shuts a link at a tick. */
export const linkClosed = (map: WorldMap, link: number, tick: number, owner: PlanningContext) =>
  linkFlood(map, link, tick, owner) >= EXTREMES.closeAt;

/** Whether a low point is under water at a tick (for its barriers). */
export const lowPointClosed = (p: Point, tick: number, owner: PlanningContext) =>
  floodOver(p, clock(tick), owner) >= EXTREMES.closeAt;

/** The share of a town's regional links that floods have shut (0 none … 1 cut off). */
export const cutOffAt = (
  town: number,
  tick: number,
  map: WorldMap,
  owner: PlanningContext
) => {
  if (town < 0) return 0;
  let n = 0;
  let shut = 0;
  map.links.forEach((l, i) => {
    if (l.from !== town && l.to !== town) return;
    n++;
    if (linkClosed(map, i, tick, owner)) shut++;
  });
  return n ? shut / n : 0;
};

/** Whether the road between two towns is open at a tick (any of their direct links; true when none is low). */
export const roadOpen = (
  a: number,
  b: number,
  tick: number,
  map: WorldMap,
  owner: PlanningContext
) => {
  let any = false;
  for (let i = 0; i < map.links.length; i++) {
    const l = map.links[i];
    if (!((l.from === a && l.to === b) || (l.from === b && l.to === a)))
      continue;
    any = true;
    if (!linkClosed(map, i, tick, owner)) return true;
  }
  return !any;
};

/** Every low point a flood has shut at a tick (barriers stand `reach` either side of each). */
export const closuresAt = (
  tick: number,
  map: WorldMap,
  owner: PlanningContext
): LowPoint[] => {
  const out: LowPoint[] = [];
  for (const pts of lowPointsOf(map, owner))
    for (const p of pts) if (lowPointClosed(p, tick, owner)) out.push(p);
  return out;
};

/** Whether a world point is inside a shut span (between a closed low point's two barriers). */
export const closedAt = (
  x: number,
  y: number,
  tick: number,
  map: WorldMap,
  owner: PlanningContext
) => {
  for (const pts of lowPointsOf(map, owner)) {
    for (const p of pts) {
      if (
        Math.abs(p.x - x) > p.reach + TILE ||
        Math.abs(p.y - y) > p.reach + TILE
      )
        continue;
      if (
        Math.hypot(p.x - x, p.y - y) <= p.reach + TILE &&
        lowPointClosed(p, tick, owner)
      )
        return true;
    }
  }
  return false;
};

/**
 * Where a route (a polyline in world units, e.g. a tram line or a commute) runs into a shut span:
 * each closure it passes, as distances along it of the near and far barrier. Vehicles stop or turn
 * back short of `from`; walkers queue there. Empty when the way is clear.
 */
export const closedSpansOn = (
  path: readonly Point[],
  tick: number,
  map: WorldMap,
  owner: PlanningContext
) => {
  const out: { from: number; to: number; at: LowPoint }[] = [];
  const shut = closuresAt(tick, map, owner);
  if (!shut.length) return out;
  let s = 0;
  for (let i = 1; i < path.length; i++) {
    const a = path[i - 1];
    const b = path[i];
    const len = Math.hypot(b.x - a.x, b.y - a.y);
    for (const p of shut) {
      if (segDist(p, a, b) > p.reach) continue;
      const t = len
        ? Math.max(
            0,
            Math.min(
              1,
              ((p.x - a.x) * (b.x - a.x) + (p.y - a.y) * (b.y - a.y)) /
                (len * len)
            )
          )
        : 0;
      const mid = s + t * len;
      if (out.some((o) => o.at === p)) continue;
      out.push({ from: Math.max(0, mid - p.reach), to: mid + p.reach, at: p });
    }
    s += len;
  }
  return out.sort((x, y) => x.from - y.from);
};

/** A transit line's shut spans now, as distances along its path in tiles (its own units). */
export const lineClosures = (
  line: TransitLine,
  tick: number,
  map: WorldMap,
  owner: PlanningContext
) => {
  const { linePaths: pxPaths } = responseProjections(owner);
  let px = pxPaths.get(line);
  if (!px)
    pxPaths.set(
      line,
      (px = line.path.map((p) => ({ x: p.x * TILE, y: p.y * TILE })))
    );
  return closedSpansOn(px, tick, map, owner).map((c) => ({
    from: c.from / TILE,
    to: c.to / TILE,
  }));
};

/**
 * A tram or bus with its line shut ahead (a flooded bridge): it runs to the last stop before the
 * near barrier, stands there a while and turns back out of service; nothing of that run goes on
 * past it. `spans` are lineClosures (tiles along the path). Undefined when the closures don't touch
 * the run (draw it where the timetable has it); null when it is out of service.
 * Pure in the line, run and time, like transit.ts vehicleAt (whose timing it follows).
 */
export const shortTurned = (
  line: TransitLine,
  run: Run,
  time: number,
  spans: readonly { from: number; to: number }[]
) => {
  const t = time - run.dep;
  if (!spans.length || t < 0 || t > runTime(line)) return undefined;
  const L = line.length;
  // Into the run's own direction: distance from its terminus.
  const own = spans
    .map((sp) =>
      run.dir === 0
        ? { a: sp.from, b: sp.to }
        : { a: L - sp.to, b: L - sp.from }
    )
    .filter((sp) => sp.b > 0)
    .sort((x, y) => x.a - y.a);
  if (!own.length) return undefined;
  const stops = (run.dir === 0 ? line.stops : [...line.stops].reverse()).map(
    (st, k) => {
      const s = run.dir === 0 ? st.s : L - st.s;
      const arrive = s / line.speed + k * line.dwell;
      return { s, arrive, leave: arrive + line.dwell };
    }
  );
  // Where it turns: the last stop clear of the barrier, or just short of it.
  const before = stops.filter((st) => st.s < own[0].a - 2);
  const hold = before.length
    ? before[before.length - 1].s
    : Math.max(0, own[0].a - 3);
  // Distance along the run at t (as vehicleAt has it).
  let d = 0;
  let s0 = 0;
  let t0 = 0;
  let found = false;
  for (const st of stops) {
    if (t < st.arrive) {
      d = s0 + (t - t0) * line.speed;
      found = true;
      break;
    }
    if (t < st.leave) {
      d = st.s;
      found = true;
      break;
    }
    s0 = st.s;
    t0 = st.leave;
  }
  if (!found) d = Math.min(L, s0 + (t - t0) * line.speed);
  if (d <= hold) return undefined;
  // When it got to the turn: standing there a couple of dwells, then gone.
  const at = before.length
    ? before[before.length - 1].arrive
    : (() => {
        let s1 = 0;
        let t1 = 0;
        for (const st of stops) {
          if (st.s > hold) break;
          s1 = st.s;
          t1 = st.leave;
        }
        return t1 + (hold - s1) / line.speed;
      })();
  if (t - at > Math.max(30, line.dwell * 3)) return null;
  const s = run.dir === 0 ? hold : L - hold;
  const { p, dir } = pointAt(line, s);
  const fwd = run.dir === 0 ? dir : { x: -dir.x, y: -dir.y };
  const side = perp(fwd);
  return {
    x: p.x - side.x * line.offset,
    y: p.y - side.y * line.offset,
    angle: Math.atan2(fwd.y, fwd.x),
  };
};

const placeChunk = (map: WorldMap, town: number) => {
  const p = map.places[town];
  return p
    ? { cx: Math.floor(p.x / CHUNK_SIZE), cy: Math.floor(p.y / CHUNK_SIZE) }
    : null;
};

/** What the weather is doing to a town at a tick: each 0..1. */
export type Extremes = {
  storm: number;
  blizzard: number;
  heatwave: number;
  cold: number;
  flood: number;
  cutOff: number;
};
export const extremesOf = (
  town: number,
  tick: number,
  map: WorldMap,
  owner: PlanningContext
): Extremes => {
  const c = placeChunk(map, town);
  if (!c)
    return { storm: 0, blizzard: 0, heatwave: 0, cold: 0, flood: 0, cutOff: 0 };
  const w = chunkWeather(c.cx, c.cy, tick, owner);
  const t = clock(tick);
  let flood = 0;
  for (let dy = -1; dy <= 1; dy++)
    for (let dx = -1; dx <= 1; dx++)
      flood = Math.max(flood, floodAt(c.cx + dx + 0.5, c.cy + dy + 0.5, t, undefined, owner));
  const snowing = Math.min(1, w.snow * 2);
  return {
    storm: w.storm * (1 - snowing),
    blizzard: w.storm * snowing,
    heatwave:
      w.temperature > 28
        ? Math.min(1, w.heat * 1.5) * Math.min(1, (w.temperature - 28) / 5)
        : 0,
    cold: Math.max(0, Math.min(1, (-4 - w.temperature) / 10)),
    flood,
    cutOff: cutOffAt(town, tick, map, owner),
  };
};

/** Hospital admissions from the weather in a town at a tick (share of a full ward). */
export const admissionsAt = (
  town: number,
  tick: number,
  map: WorldMap,
  owner: PlanningContext
) => {
  const c = placeChunk(map, town);
  return c ? exposureAdmissions(chunkWeather(c.cx, c.cy, tick, owner)) : 0;
};

/** Whether a town's warming or cooling centre is open, and which. */
export const shelterOpen = (
  town: number,
  tick: number,
  map: WorldMap,
  owner: PlanningContext
): "warming" | "cooling" | null => {
  const e = extremesOf(town, tick, map, owner);
  if (e.blizzard > 0.3 || e.cold > 0.3) return "warming";
  if (e.heatwave > 0.35) return "cooling";
  return null;
};

// ---------------------------------------------------------------------------------------------
// News (page): what changed since the last step, latched so a town on a threshold doesn't repeat.

import type { ExtremeMemory } from "../../components/response/ExtremeMemory";
export const createExtremeMemory = (): ExtremeMemory => ({
  closed: [],
  season: null,
});

export type WeatherNews = { text: string; kind: "good" | "bad" };

/**
 * The weather's news at a tick: storms, blizzards, heat waves and cold snaps arriving in a town,
 * rivers flooding and roads closing and reopening, and the season turning. Page-only bookkeeping;
 * what it reports is pure in the tick.
 */

