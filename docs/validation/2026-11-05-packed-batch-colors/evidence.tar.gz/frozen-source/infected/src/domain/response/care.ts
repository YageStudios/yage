import { chunkKey } from "yage/streaming";
import type { PlanningContext } from "../../worldgen/commute/context";
import { chunkCached, chunkCurrent } from "../../worldgen/commute/chunk-cache";
/**
 * Healthcare under strain, and the vaccine. Like the rest of the response, the page decides it
 * (stepCare, from the towns' counts) as append-only series on each town, and everything a chunk
 * draws or simulates from them is a pure function of those series, the tick and people's gids.
 *
 * - Staff: nurses and doctors fall sick as their town does, and burn out and quit while the wards
 *   overflow. Fewer staff run fewer beds and fewer ambulances.
 * - Field tents: once a town's wards are full, tents go up in a park or square near the hospital,
 *   adding beds (as far as there are staff to run them). Struck slowly once it's quiet.
 * - Triage: past `HOSPITAL.triageFrom` the sickest are sent home to die (measures.ts isolationOf).
 * - The dead: a town's morgue holds a few; then the cemetery's free plots take fresh graves, then
 *   trenches (mass graves) dug along its wall. `buried` only ever grows.
 * - The vaccine: once the cure research passes `trialAt`, towns researching it run campaigns at
 *   their clinics. The old go first, then working age, then children; some refuse, more as order
 *   breaks down (unrest.ts defiance). The vaccinated take in much less (`CARE.efficacy`).
 */
import { CONTENT } from "../../content/runtime";
import { hashUnit } from "../load/streams";
import { gidChunkX, gidChunkY, gidIndex } from "../people/identity";
import { planChunk } from "../../worldgen/population/planner";
import {
  responseState,
  townOf,
  valueAt,
  type Series,
  type TownResponse,
  type ResponseState,
} from "./measures";
import { unrestOf } from "./unrest";
import type { WorldResponse } from "./towns";

/** Owner-tunable numbers; data in content/response.json5. */
export const CARE = CONTENT.response.care;

// ---------------------------------------------------------------------------------------------
// Readers (any thread): pure in the shared series and the tick

export type Care = {
  /** Share of the staff still working (1 = all). */
  staff: number;
  /** Field tents' extra beds as a share of the hospital's own (0 = none up). */
  tents: number;
  /** The beds actually running, as a share of the hospital's own. */
  capacity: number;
  /** Vaccine coverage of those willing (0 = no campaign). */
  vax: number;
  /** Bodies buried so far (morgue overflow, fresh graves and mass graves). */
  buried: number;
};

export const NO_CARE: Care = {
  staff: 1,
  tents: 0,
  capacity: 1,
  vax: 0,
  buried: 0,
};

/** Beds running at a staff share and tents: tents add beds, staff run them. */
export const capacityOf = (staff: number, tents: number) =>
  Math.max(CARE.staffFloor, staff) * (1 + tents);

export const careOf = (town: TownResponse | undefined, tick: number): Care => {
  if (!town) return NO_CARE;
  const staff = valueAt(town.staff as Series | undefined, tick, 1);
  const tents = valueAt(town.tents as Series | undefined, tick);
  return {
    staff,
    tents,
    capacity: capacityOf(staff, tents),
    vax: valueAt(town.vax as Series | undefined, tick),
    buried: valueAt(town.buried as Series | undefined, tick),
  };
};

/** The share of a town refusing the vaccine at a tick. */
export const refusing = (
  town: number,
  tick: number,
  state: ResponseState
) =>
  Math.min(
    0.95,
    CARE.refuseBase +
      CARE.refuseDefiance *
        (town >= 0 ? unrestOf(state.towns[town], tick).defiance : 0)
  );

/** Where someone of this age stands in the queue (0 first … 1 last), by their group and their own hash. */
export const priorityOf = (gid: number, age: number) => {
  for (const [from, a, b] of CARE.groups)
    if (age >= from) return a + (b - a) * hashUnit(gid, 0x76617878, 5);
  return hashUnit(gid, 0x76617878, 5);
};

/** Whether this person refuses at this refusal share (the same people refuse as it rises). */
export const refuses = (gid: number, share: number) =>
  hashUnit(gid, 0x72656675, 6) < share;

/** Vaccinated at a coverage and refusal share. */
export const vaccinated = (
  gid: number,
  age: number,
  coverage: number,
  refuse: number
) => coverage > 0 && !refuses(gid, refuse) && priorityOf(gid, age) < coverage;

// Ages by home chunk, so the queue order never changes as people travel (kept apart from people.ts's small plan cache).
const AGE_CACHE = 512;
/** A person's age from their home chunk's plan (cached per chunk). */
export const ageOfGid = (gid: number, context: PlanningContext) => {
  const ages = context.ages;
  const cx = gidChunkX(gid, context);
  const cy = gidChunkY(gid, context);
  const key = chunkKey(cx, cy);
  let a = ages.get(key);
  if (a && !chunkCurrent(context, cx, cy, a)) a = undefined;
  if (!a) {
    a = planChunk(cx, cy, context).age.slice();
    if (ages.size >= AGE_CACHE) {
      const oldest = ages.keys().next().value;
      if (oldest !== undefined) ages.delete(oldest);
    }
    ages.set(key, chunkCached(context, cx, cy, a));
  }
  return a[gidIndex(gid, context)] ?? 30;
};

/** A chunk's vaccine campaign at a tick: coverage and refusal (null: none). */
export const vaccineAt = (
  cx: number,
  cy: number,
  tick: number,
  context: PlanningContext
): { coverage: number; refuse: number } | null => {
  const town = townOf(cx, cy, context);
  if (town < 0) return null;
  const coverage = valueAt(
    responseState(context).towns[town]?.vax as Series | undefined,
    tick
  );
  return coverage > 0 ? { coverage, refuse: refusing(town, tick, responseState(context)) } : null;
};

/** How much a person still takes in under a campaign (1 = all). */
export const vaccineFactor = (
  gid: number,
  v: { coverage: number; refuse: number } | null,
  context: PlanningContext
) =>
  v && vaccinated(gid, ageOfGid(gid, context), v.coverage, v.refuse)
    ? 1 - CARE.efficacy
    : 1;

/** Morgue capacity of a town of `people`. */
export const morgueOf = (people: number) =>
  Math.max(CARE.morgueMin, Math.round(people * CARE.morgue));

/** The tick body `k` (0-based) was buried at, from the series (null: not yet). */
export const buriedAt = (
  buried: Series | undefined,
  k: number,
  tick: number
): number | null => {
  if (buried)
    for (const [value, at] of buried) {
      if (at > tick) break;
      if (value > k) return at;
    }
  return null;
};

// ---------------------------------------------------------------------------------------------
// The page: deciding the series

export type CareNews = { town: number; text: string; kind: "good" | "bad" };

/**
 * Advances staff, tents, burials and the vaccine to `tick` (after stepWorldResponse, which set each
 * town's counts and demand). Returns whether the shared state grew, and adds news to `news`.
 */

/** For the HUD and end screens: people vaccinated in the world (expected, from coverage and refusal). */
export const vaccinatedPeople = (r: WorldResponse, tick: number) =>
  r.towns.reduce((sum, t, i) => {
    const v = careOf(r.shared.towns[i], tick).vax;
    return v > 0 ? sum + t.people * v * (1 - refusing(i, tick, r.shared)) : sum;
  }, 0);


/** Integrates one town; the owning system controls phase order and iteration. */
