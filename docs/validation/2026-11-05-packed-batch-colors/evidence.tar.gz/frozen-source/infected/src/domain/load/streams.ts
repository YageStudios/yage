/** Deterministic symptom event streams and averaged source rates. */
import type { Traits } from "../disease";
import { LOAD, SPORE } from "./constants";
import { TICK_RATE } from "../world";

export const enum Stream {
  Cough = 0,
  Sneeze = 1,
  Vomit = 2,
  WalkCough = 3,
  WalkSneeze = 4,
  Bleed = 5,
  Collapse = 6,
  Spore = 7,
}

/** Calls `fire(tick)` for each event of a stream with from < tick <= to, at `perMinute`. */
export const eventsBetween = (gid: number, stream: Stream, perMinute: number, from: number, to: number, fire: (tick: number) => void) => {
  if (perMinute <= 0 || to <= from) return;
  const window = (60 * TICK_RATE) / perMinute; // ticks
  const first = Math.floor((from + 1) / window);
  const last = Math.floor(to / window);
  for (let w = Math.max(first - 1, 0); w <= last; w++) {
    const tick = Math.floor(w * window + (hashUnit(gid, stream, w) * 0.8 + 0.1) * window);
    if (tick > from && tick <= to) fire(tick);
  }
};

/** Deterministic number in [0, 1) from integers. */
export const hashUnit = (a: number, b: number, c: number) => {
  let h = Math.imul(a ^ 0x9e3779b9, 0x85ebca6b) ^ Math.imul(b + 0x632be5ab, 0xc2b2ae35) ^ Math.imul(c + 0x27d4eb2f, 0x165667b1);
  h = Math.imul(h ^ (h >>> 15), 0x2c1b3c6d);
  h = Math.imul(h ^ (h >>> 12), 0x297a2d39);
  h ^= h >>> 15;
  return (h >>> 0) / 4294967296;
};

/** Cough and sneeze streams at rest and their extra share while walking (per minute). */
export const streamRates = (traits: Traits) => ({
  cough: traits.cough * LOAD.restingCough,
  sneeze: traits.sneeze * LOAD.restingCough,
  walkCough: traits.cough * (LOAD.walkingCough - LOAD.restingCough),
  walkSneeze: traits.sneeze * (LOAD.walkingCough - LOAD.restingCough),
  vomit: traits.vomit,
  spore: traits.spores,
});

/** Share of a bloomed host's life it shows its symptoms (prions hide the first `silent`): for the averaged models. */
export const showingShare = (traits: Traits) => 1 - Math.min(1, Math.max(0, traits.silent));

/**
 * Averaged (warm, cabin) cloud and ground sources of one bloomed host, per minute: coughs and
 * sneezes, spores as cough-sized clouds, vomit and blood as puddle-sized stains. Weighted by how
 * much of its life a host shows them.
 */
export const averagedSources = (traits: Traits) => {
  const show = showingShare(traits);
  return {
    spores: traits.spores * SPORE.load * show,
    /** Puddles' worth of stain a minute (blood at its mean severity, about two thirds). */
    puddles: (traits.vomit + (traits.bleed * 0.65 * LOAD.bleed) / LOAD.puddle) * show,
    show,
  };
};

