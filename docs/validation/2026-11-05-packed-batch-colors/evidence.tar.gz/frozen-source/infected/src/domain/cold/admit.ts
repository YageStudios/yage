/**
 * What the authority tells a warm chunk's host to take in from the cold tier (ChunkPool.command,
 * on the limit's tick): people of cold cells, by name and state, who are there now: commuters at
 * their work chunk in work hours, and those coming home to a warm chunk from a cold one
 * (systems/cold/ColdCrossingSystem.ts). The host spawns them where their day has them
 * (services/cold/admit.ts).
 */
const KIND_ADMIT = 1;

export type Admit = {
  /** The chunk they are let into. */
  cx: number;
  cy: number;
  /** gid, state, timer triples, by gid. */
  people: number[];
};

export const encodeAdmit = ({ cx, cy, people }: Admit): Uint8Array => new Uint8Array(Float64Array.from([KIND_ADMIT, cx, cy, people.length / 3, ...people]).buffer);

/** The admit `bytes` say, or null for any other command. */
export const decodeAdmit = (bytes: Uint8Array): Admit | null => {
  if (bytes.length < 32 || bytes.length % 8) return null;
  const values = new Float64Array(bytes.slice().buffer);
  if (values[0] !== KIND_ADMIT || values.length !== 4 + values[3] * 3) return null;
  return { cx: values[1], cy: values[2], people: Array.from(values.subarray(4)) };
};
