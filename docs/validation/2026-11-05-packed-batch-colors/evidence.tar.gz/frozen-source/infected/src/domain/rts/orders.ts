/** RTS state is keyed by global person id, never by a rendered slot or a chunk-local entity. */
export type Point = { x: number; y: number };
export type RtsPawn = Point & { gid: number };
export const ORDER_KINDS = ["move", "attack", "pursue", "hold", "rally", "withdraw", "follow", "breach"] as const;
export type OrderKind = typeof ORDER_KINDS[number];
/** A follow order's target is the leader and its x, y the slot's offset from the leader; every other order's x, y is a place (a breach's, the structure's). */
export type RtsOrder = Point & { id: number; kind: OrderKind; target: number; issued: number; structure?: string };
export type UnitStatus = "ordered" | "moving" | "holding" | "following" | "engaging" | "possessed" | "idle" | "blocked" | "lost" | "dead" | "released";
export type RtsUnit = RtsPawn & {
  state: number;
  stage: number;
  seen: number;
  orders: RtsOrder[];
  status: UnitStatus;
  reason: string;
  progressX: number;
  progressY: number;
  progressTick: number;
  completed: number;
  /** Region order owner. Direct tactical orders detach just this unit; possession does not. */
  operation?: number;
  /** Geometry revision when a route stalled; a breach/deployment invalidates that conclusion. */
  blockedRevision?: number;
};
export type RtsHorde = { id: number; name: string; members: number[] };
export type RtsContact = RtsPawn & { state: number; stage: number; tick: number };
export type RtsNotice = { tick: number; gid: number; order: number; text: string };
/** Each host receives only the current order. Queues and completion remain authority-owned.
 * A follow order's x, y is where the slot was last reported and ox, oy its offset from the leader. */
export type WorkerRtsOrder = RtsPawn & { id: number; kind: OrderKind; target: number; ox?: number; oy?: number; structure?: string };
export type RtsAction =
  | { kind: "rtsMode"; enabled: boolean }
  /** `leader`: the ridden host, laid out in the ranks with the units but given no order (the page walks it). */
  | { kind: "rtsOrder"; units: RtsPawn[]; order: OrderKind; at: Point; target?: number; append?: boolean; leader?: RtsPawn }
  | { kind: "rtsHorde"; units: RtsPawn[]; name?: string; horde?: number }
  | { kind: "rtsRelease"; gids: number[] };

export const RTS_LIMITS = { units: 1024, queue: 32, history: 64, hordes: 64 } as const;
export const pointValid = (v: unknown): v is Point => !!v && typeof v === "object" && Number.isFinite((v as Point).x) && Number.isFinite((v as Point).y);
export const gidValid = (gid: unknown): gid is number => Number.isInteger(gid) && Number(gid) >= 0 && Number(gid) <= 0xffff_ffff;

/** Checked before an intent reaches its owner; malformed remote/journal inputs never reach navigation. */
export const invalidRtsAction = (action: RtsAction): string => {
  if (action.kind === "rtsMode") return typeof action.enabled === "boolean" ? "" : "Not a command mode";
  if (action.kind === "rtsRelease") return Array.isArray(action.gids) && action.gids.length <= RTS_LIMITS.units && action.gids.every(gidValid) ? "" : "Not a selection";
  if (!Array.isArray(action.units) || !action.units.length || action.units.length > RTS_LIMITS.units || !action.units.every((p) => pointValid(p) && gidValid(p.gid))) return "Select infected first";
  if (action.kind === "rtsHorde") return (action.name === undefined || typeof action.name === "string") && (action.horde === undefined || Number.isSafeInteger(action.horde) && action.horde > 0) ? "" : "Not a horde";
  if (!ORDER_KINDS.includes(action.order) || !pointValid(action.at)) return "Not an order or destination";
  if (action.target !== undefined && !gidValid(action.target)) return "Not a target";
  if ((action.order === "pursue" || action.order === "follow") && action.target === undefined) return "Pursue and follow need a person to go after";
  if (action.target !== undefined && action.order !== "pursue" && action.order !== "attack" && action.order !== "follow") return "This order does not take a target";
  if (action.leader !== undefined && !(pointValid(action.leader) && gidValid(action.leader.gid))) return "Not a leader";
  return action.append === undefined || typeof action.append === "boolean" ? "" : "Not a queue option";
};

/** Formation slots facing the march. The front rank goes to the units already furthest forward and
 * each rank keeps its left-to-right order, so nobody cuts across the group to reach its slot. */
export const formationSlots = (units: readonly RtsPawn[], at: Point, spacing: number): Map<number, Point> => {
  const count = Math.max(1, units.length);
  const cx = units.reduce((sum, u) => sum + u.x, 0) / count, cy = units.reduce((sum, u) => sum + u.y, 0) / count;
  const length = Math.hypot(at.x - cx, at.y - cy);
  const dx = length > 1e-6 ? (at.x - cx) / length : 0, dy = length > 1e-6 ? (at.y - cy) / length : 1;
  const along = (u: Point) => (u.x - cx) * dx + (u.y - cy) * dy, across = (u: Point) => (u.y - cy) * dx - (u.x - cx) * dy;
  const columns = Math.ceil(Math.sqrt(count)), rows = Math.ceil(units.length / columns);
  const ordered = [...units].sort((a, b) => along(b) - along(a) || a.gid - b.gid);
  const slots = new Map<number, Point>();
  for (let row = 0; row < rows; row++) {
    const rank = ordered.slice(row * columns, (row + 1) * columns).sort((a, b) => across(a) - across(b) || a.gid - b.gid);
    const forward = ((rows - 1) / 2 - row) * spacing;
    rank.forEach((u, i) => {
      const side = (i - (rank.length - 1) / 2) * spacing;
      slots.set(u.gid, { x: at.x + dx * forward - dy * side, y: at.y + dy * forward + dx * side });
    });
  }
  return slots;
};

/**
 * How a kind of unit gathers, in tiles. Drilled people (soldiers) dress ranks (formationSlots); the
 * sick mob: each keeps roughly its place in the crowd, unevenly, with its own room around it, and
 * stops once it is about there (`slack`). A super mutant shoulders a wider berth.
 */
export const GROUPING = {
  soldier: { style: "ranks", spacing: 1, slack: 0.25 },
  infected: { style: "mob", spacing: 0.9, slack: 0.5 },
  mutant: { style: "mob", spacing: 1.8, slack: 0.5 },
} as const;
export type UnitKind = keyof typeof GROUPING;

/** A fixed 0…1 pair per person (no state, no Math.random): where in its room a mob member stands. */
const scatter = (gid: number) => {
  const a = Math.imul(gid ^ 0x9e3779b9, 0x85ebca6b) >>> 0, b = Math.imul(a ^ (a >>> 13), 0xc2b2ae35) >>> 0;
  return [a / 2 ** 32, b / 2 ** 32] as const;
};

/** A crowd going to `at`: the crowd's shape kept (drawn in when it is spread wider than a packed
 * crowd of its size), so nobody crosses it, each member jostled within its own room. */
export const mobSlots = (units: readonly RtsPawn[], at: Point, tile: number, kindOf: (gid: number) => UnitKind): Map<number, Point> => {
  const count = Math.max(1, units.length);
  const cx = units.reduce((sum, u) => sum + u.x, 0) / count, cy = units.reduce((sum, u) => sum + u.y, 0) / count;
  const room = units.reduce((sum, u) => sum + GROUPING[kindOf(u.gid)].spacing, 0) / count * tile;
  const packed = room * Math.sqrt(count) * 0.7, spread = Math.max(0, ...units.map((u) => Math.hypot(u.x - cx, u.y - cy)));
  const scale = spread > packed ? packed / spread : 1;
  const slots = new Map<number, Point>();
  for (const u of units) {
    const [r, t] = scatter(u.gid), jostle = GROUPING[kindOf(u.gid)].spacing * tile * 0.45 * Math.sqrt(r);
    slots.set(u.gid, { x: at.x + (u.x - cx) * scale + Math.cos(t * Math.PI * 2) * jostle, y: at.y + (u.y - cy) * scale + Math.sin(t * Math.PI * 2) * jostle });
  }
  return slots;
};

/** Where each unit of a group goes: ranks only when every member drills, else a mob. */
export const groupSlots = (units: readonly RtsPawn[], at: Point, tile: number, kindOf: (gid: number) => UnitKind): Map<number, Point> =>
  units.every((u) => GROUPING[kindOf(u.gid)].style === "ranks") ? formationSlots(units, at, tile * GROUPING.soldier.spacing) : mobSlots(units, at, tile, kindOf);

/** Shift-click toggles one unit; Shift-box adds the rectangle without removing existing members. */
export const selectionOf = (held: readonly number[], hits: readonly number[], additive: boolean, toggle = false): number[] => {
  if (!additive) return [...new Set(hits)].slice(0, RTS_LIMITS.units);
  const result = new Set(held);
  for (const gid of hits) if (toggle && result.has(gid)) result.delete(gid); else result.add(gid);
  return [...result].slice(0, RTS_LIMITS.units);
};

export const boxContains = (a: Point, b: Point, p: Point) => p.x >= Math.min(a.x, b.x) && p.x <= Math.max(a.x, b.x) && p.y >= Math.min(a.y, b.y) && p.y <= Math.max(a.y, b.y);
export const orderLabel = (order: Pick<RtsOrder, "kind" | "target">) => order.kind === "attack" && order.target < 0 ? "Attack-move" : order.kind[0].toUpperCase() + order.kind.slice(1);
