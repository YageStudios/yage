/**
 * How a ridden person's legs carry them (the simulation lab's player movement, walked by the page:
 * HostBody): Shift runs, Space rolls, and both spend stamina. How much stamina they have and how fast it comes back is their
 * condition's: a soldier is fit, the incubating are off, and a bloomed host runs on what the
 * strain has left it (its decay stage). Only soldiers and the strongest of the bloomed roll.
 */
import { SpriteSet } from "./disease";
import { hash } from "./world";

/** A lab person's own walking pace (world units a second): their group's speed, else their own (src/simlab/stage.ts spawn). */
export const labPace = (gid: number, speed?: number) => speed ?? 26 + (hash(gid, 31) % 15);

export const MOVES = {
  /** Speed while running, over walking. */
  run: 1.7,
  /** How far a roll carries anyone who rolls (tiles), whatever their pace: a long dive and tumble. */
  rollTiles: 5,
  /** Seconds a roll lasts, the stamina it costs, and seconds before the next. */
  rollSeconds: 0.5,
  rollCost: 0.3,
  rollCooldown: 0.8,
  /** Seconds after running (or a roll) before stamina comes back. */
  rest: 0.6,
  /** Run dry, someone is winded until this share of their stamina is back. */
  winded: 0.35,
};

/** A person's stamina: how much they have at most, the share of it a second of running spends and a second of rest brings back, and whether they roll. */
export type Legs = { cap: number; drain: number; recover: number; roll: boolean };

/** Bloomed hosts by decay stage (0 fresh … 3 dying): frenzied at first, spent at the end. */
const BLOOMED: Legs[] = [
  { cap: 1.1, drain: 1 / 7, recover: 1 / 3, roll: true },
  { cap: 0.8, drain: 1 / 6, recover: 1 / 5, roll: true },
  { cap: 0.5, drain: 1 / 5, recover: 1 / 8, roll: false },
  { cap: 0.25, drain: 1 / 4, recover: 1 / 12, roll: false },
];

/** The legs of someone drawn in sprite set `set` (and, bloomed, at decay stage `stage`). */
export const legsOf = (set: SpriteSet, stage = -1): Legs => {
  if (set === SpriteSet.Soldier) return { cap: 1, drain: 1 / 9, recover: 1 / 3, roll: true };
  if (set === SpriteSet.Incubating) return { cap: 0.7, drain: 1 / 5, recover: 1 / 6, roll: false };
  if (set === SpriteSet.Infected) return BLOOMED[Math.min(BLOOMED.length - 1, Math.max(0, stage))];
  if (set === SpriteSet.Dead) return { cap: 0, drain: 1, recover: 0, roll: false };
  return { cap: 1, drain: 1 / 6, recover: 1 / 4, roll: false };
};

/** Where someone's stamina stands: how much is left, seconds since they last spent any, and winded (run dry, not yet recovered). */
export type Breath = { stamina: number; rested: number; winded: boolean };

export const freshBreath = (legs: Legs): Breath => ({ stamina: legs.cap, rested: MOVES.rest, winded: false });

/** Whether someone may run now (they want to, are moving, and aren't winded). */
export const canRun = (b: Breath) => !b.winded && b.stamina > 0;

/** `dt` seconds of breathing, running or not: running spends, rest brings it back after a moment. */
export const breathe = (b: Breath, legs: Legs, dt: number, running: boolean) => {
  if (running) {
    b.stamina = Math.max(0, b.stamina - legs.cap * legs.drain * dt);
    b.rested = 0;
    if (b.stamina <= 0) b.winded = true;
  } else {
    b.rested += dt;
    if (b.rested >= MOVES.rest) b.stamina = Math.min(legs.cap, b.stamina + legs.cap * legs.recover * dt);
  }
  b.stamina = Math.min(b.stamina, legs.cap);
  if (b.winded && b.stamina >= legs.cap * MOVES.winded) b.winded = false;
  return b;
};

/**
 * How fast a roll carries someone (tiles a second) `s` of the way through it (0–1): slow off the
 * mark, fastest midway, slow again coming up (the rate of a smoothstep), covering rollTiles in all.
 */
export const rollPace = (s: number) => (MOVES.rollTiles / MOVES.rollSeconds) * 6 * s * (1 - s);

/** A roll, if these legs roll and have the stamina for one: spent, and true. */
export const spendRoll = (b: Breath, legs: Legs) => {
  if (!legs.roll || b.winded || b.stamina < MOVES.rollCost) return false;
  b.stamina -= MOVES.rollCost;
  b.rested = 0;
  return true;
};
