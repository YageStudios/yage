/**
 * A bite: the ridden bloomed host snaps at someone the page has drawn within reach (the page works
 * out who, the moment it is pressed: SimLabView, HostBite). Where it landed goes to the chunk the
 * target is drawn in as a command, "BIT1": the biter's gid, the bite's number and the target's gid,
 * each a u32 LE after the four magic bytes. That chunk only says whether it took (BiteSystem).
 * The same on every thread.
 */
import type { World } from "minecs";
import { TILE } from "./world";

export const BITE = {
  /** How far (world px) in front of the host a bite reaches someone. */
  reach: TILE,
  /** How wide (radians either side of where the host faces) it reaches. */
  arc: Math.PI / 3,
  /** Seconds between two bites. */
  cooldown: 1,
  /** The lunge into it (world px), page only. */
  lunge: TILE * 0.4,
} as const;

/**
 * `beast`: a feral animal's (BeastSystem), its biter an id for the draws alone, never a host's (an
 * animal's id shares the gids' space, so only the flag says nobody bit). Queued in the chunk only,
 * never sent: the command carries a host's bite.
 */
export type Bite = { biter: number; n: number; target: number; beast?: true };

/** What starts a bite's bytes ("BIT1"): nothing else a chunk takes starts so. */
const MAGIC = [0x42, 0x49, 0x54, 0x31];

export const encodeBite = ({ biter, n, target }: Bite): Uint8Array => {
  const bytes = new Uint8Array(16);
  bytes.set(MAGIC);
  const view = new DataView(bytes.buffer);
  view.setUint32(4, biter >>> 0, true);
  view.setUint32(8, n >>> 0, true);
  view.setUint32(12, target >>> 0, true);
  return bytes;
};

/** The bite `bytes` say, or null for any other command. */
export const decodeBite = (bytes: Uint8Array): Bite | null => {
  if (bytes.length !== 16 || MAGIC.some((b, i) => bytes[i] !== b)) return null;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  return { biter: view.getUint32(4, true), n: view.getUint32(8, true), target: view.getUint32(12, true) };
};

/** Bites landed in a chunk since its last step (sim/module.ts command), for BiteSystem. */
const BITES = new WeakMap<World, Bite[]>();

/** A bite for the chunk's next step. */
export const queueBite = (world: World, bite: Bite) => {
  const queue = BITES.get(world) ?? [];
  queue.push(bite);
  BITES.set(world, queue);
};

/** The chunk's bites since its last step, taken (none: undefined). */
export const takeBites = (world: World) => {
  const bites = BITES.get(world);
  BITES.delete(world);
  return bites;
};
