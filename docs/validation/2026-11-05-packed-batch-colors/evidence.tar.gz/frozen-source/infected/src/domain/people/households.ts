import { FLAT_BEDS } from "../../worldgen/terrain/blueprints";
import { PlaceKind } from "../../worldgen/terrain/kinds";
import { type Place } from "../../worldgen/terrain/models";
import { hash } from "../world";
import { Kin, NONE } from "./identity";
/** The flat a bed slot belongs to (apartments), or 0. */
export const flatOf = (place: Pick<Place, "kind">, slot: number) => (place.kind === PlaceKind.Apartment ? Math.floor(slot / FLAT_BEDS) : 0);
/** A household's shared key: siblings walk to school together, families eat together. */
export const familyKey = (cx: number, cy: number, home: number, flat: number) => hash(cx, cy, home, flat, 5);
/** The school a household's children go to (and a parent walks them to). */
export const householdSchool = (layout: {
  places: {
    kind: PlaceKind;
  }[];
}, family: number) => {
  let count = 0;
  for (const p of layout.places)
    if (p.kind === PlaceKind.School)
      count++;
  if (!count)
    return NONE;
  let k = family % count;
  for (let i = 0;i < layout.places.length;i++)
    if (layout.places[i].kind === PlaceKind.School && k-- === 0)
      return i;
  return NONE;
};
/** Members of a household of `size`: [kin, age], head first, then partner, children, grandparents. */
export const compose = (size: number, r: (salt: number) => number): [
  Kin,
  number
][] => {
  const adult = (lo: number, hi: number, salt: number) => lo + Math.floor(r(salt) * (hi - lo + 1));
  const out: [
    Kin,
    number
  ][] = [];
  const kinds = r(1);
  let couple = true;
  let children = 0;
  let grand = 0;
  let elderly = false;
  if (size === 1) {
    couple = false;
    elderly = kinds < 0.25;
  }
  else if (size === 2) {
    if (kinds < 0.25)
      elderly = true;
    else if (kinds > 0.85) {
      couple = false;
      children = 1;
    }
  }
  else if (size === 3) {
    if (kinds < 0.12)
      grand = 1;
    else if (kinds > 0.82) {
      couple = false;
      children = 2;
    }
    else
      children = 1;
  }
  else {
    grand = size === 6 ? (kinds < 0.4 ? 2 : 1) : size === 5 ? (kinds < 0.45 ? 1 : 0) : kinds < 0.22 ? 1 : 0;
    children = size - 2 - grand;
  }
  const headAge = elderly ? adult(65, 88, 2) : children ? adult(26, 52, 2) : grand ? adult(28, 50, 2) : adult(19, 60, 2);
  out.push([Kin.Head, headAge]);
  if (couple && size >= 2)
    out.push([Kin.Partner, Math.max(18, headAge + Math.floor(r(3) * 9) - 4)]);
  const young = Math.min(headAge, out.length > 1 ? out[1][1] : headAge);
  for (let c = 0;c < children;c++)
    out.push([Kin.Child, Math.max(0, Math.min(young - 18, Math.floor(r(20 + c) * Math.min(18, young - 18))))]);
  for (let g = 0;g < grand;g++)
    out.push([Kin.Grandparent, Math.min(96, Math.max(62, headAge + adult(24, 32, 30 + g)))]);
  return out;
};
