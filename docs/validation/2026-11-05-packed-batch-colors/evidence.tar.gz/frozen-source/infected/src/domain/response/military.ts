/**
 * Military operations on the street (pure, no drawing): patrols under martial law (stopping people
 * by day, turning back or arresting curfew stragglers by night), cars searched at roadblocks,
 * soldiers firing on the visibly sick at a walled town's wall, evacuation convoys pulling the
 * healthy-looking out of a fallen town before the wall goes up, and burn squads clearing the dead.
 *
 * Everything is a pure function of the plan, the shared response series and the game clock, so a
 * hot chunk, a warm one and one loaded late all see the same patrol at the same corner.
 *
 * The sim's people (life.ts, the NPC agent's) are moved and killed through the hooks at the end:
 * `shotOf`, `evacuationOf` and `clearedAt`. The pictures here don't wait on them.
 */
import { CONTENT } from "../../content/runtime";
import type { Vec } from "../../atlas/model";
import { hashUnit } from "../load/streams";
import { clock } from "../time";
import { TICK_RATE, TILE } from "../world";
import type { Plan } from "../../worldgen/plan";
import { responseProjections, type GenerationInput } from "../../worldgen/source/owner";
import type { WorldMap } from "../../worldmap/places";
import type { PlanningContext } from "../../worldgen/commute/context";
import { routeBetween } from "./ambulance";
import { COLLAPSE, collapseOf } from "./collapse";
import {
  curfewHours,
  Level,
  levelAt,
  responseState,
  type Series,
  type TownResponse,
} from "./measures";
import { pathLength, pointAlong, type Checkpoint } from "./street";

/** Owner-tunable military numbers (seconds are game seconds; distances tiles unless noted); data in content/response.json5. */
const military = CONTENT.response.military;
export const MILITARY = {
  ...military,
  patrolLevel: Level[military.patrolLevel],
};

// ---------------------------------------------------------------------------------------------
// Shared helpers

/** A point and heading `s` along a path, kept `side` to the right (world units in, world units out). */
const poseOn = (path: readonly Vec[], s: number, side = 0, reverse = false) => {
  const L = pathLength(path);
  const p = pointAlong(path, Math.max(0, Math.min(L, s)));
  const a = pointAlong(path, Math.max(0, s - 6));
  const b = pointAlong(path, Math.min(L, s + 6));
  let angle = Math.atan2(b.y - a.y, b.x - a.x);
  if (reverse) angle += Math.PI;
  return {
    x: p.x - Math.sin(angle) * side,
    y: p.y + Math.cos(angle) * side,
    angle,
  };
};

const ease = (x: number) => x * x * (3 - 2 * x);

// ---------------------------------------------------------------------------------------------
// Patrols

export type PatrolFigure = {
  x: number;
  y: number;
  /** Facing (radians). */
  angle: number;
  kind: "soldier" | "stopped" | "arrested";
  /** Look seed. */
  seed: number;
};

/**
 * A patrol's route: from the town's middle out to its `k`th road out and back (tiles in, world
 * units out), null off the roads. Cached per plan.
 */
export const patrolRoute = (
  plan: Plan,
  map: WorldMap,
  town: number,
  to: Checkpoint,
  owner: GenerationInput
): Vec[] | null => {
  const { patrolRoutes: byPlan } = responseProjections(owner);
  let cache = byPlan.get(plan);
  if (!cache) byPlan.set(plan, (cache = new Map()));
  const key = `${town}>${to.seed}`;
  let route = cache.get(key);
  if (route === undefined) {
    const p = map.places[town];
    const tiles = p
      ? routeBetween(
          plan,
          { x: p.x / TILE, y: p.y / TILE },
          { x: to.x / TILE, y: to.y / TILE },
          owner
        )
      : null;
    route =
      tiles && tiles.length >= 2
        ? tiles.map((v) => ({ x: v.x * TILE, y: v.y * TILE }))
        : null;
    cache.set(key, route);
  }
  return route;
};

/**
 * The patrol on a route at game second `t`: the squad in file, walking there and back, halting
 * every so often; while halted someone stands in front of them, and at curfew they're either sent
 * back the way they came or walked off between the soldiers until the next halt.
 */
export const patrolAt = (
  route: readonly Vec[],
  seed: number,
  t: number
): PatrolFigure[] => {
  const M = MILITARY;
  const L = pathLength(route);
  if (L < TILE) return [];
  const period = M.stopEvery + M.stopFor;
  const shifted = t + hashUnit(seed, 0x70617472, 1) * period * 7;
  const n = Math.floor(shifted / period);
  const u = shifted - n * period;
  const moved = (n * M.stopEvery + Math.min(u, M.stopEvery)) * M.walk * TILE;
  const out: PatrolFigure[] = [];
  /** Distance d (world units) folded onto there-and-back: s along, heading back? */
  const fold = (d: number) => {
    const m = ((d % (2 * L)) + 2 * L) % (2 * L);
    return m <= L ? { s: m, back: false } : { s: 2 * L - m, back: true };
  };
  const at = (d: number, side: number) => {
    const f = fold(d);
    // The same kerb both ways (no jump at the turn).
    return poseOn(route, f.s, f.back ? -side : side, f.back);
  };
  for (let i = 0; i < M.squad; i++) {
    // Two abreast-ish: the file staggers a little to each side of the lane.
    const p = at(
      moved - i * M.file * TILE,
      (i % 2 ? -0.35 : 0.35) * TILE + 0.9 * TILE
    );
    out.push({ ...p, kind: "soldier", seed: seed * 7 + i });
  }
  const lead = at(moved, 0.9 * TILE);
  const stopSeed = (seed * 131 + n * 977) >>> 0;
  if (u >= M.stopEvery) {
    // Halted: the person stopped stands a pace in front, facing them.
    const ahead = at(moved + 1.2 * TILE, 0.9 * TILE);
    out.push({
      x: ahead.x,
      y: ahead.y,
      angle: lead.angle + Math.PI,
      kind: "stopped",
      seed: stopSeed,
    });
  } else if (n > 0) {
    // The last halt's straggler, if it was curfew and they're being taken in.
    const prevSeed = (seed * 131 + (n - 1) * 977) >>> 0;
    const haltedAt = t - u - M.stopFor;
    if (
      curfewHours(tickOfSeconds(haltedAt)) &&
      hashUnit(prevSeed, 0x61727273, 2) < M.arrest
    ) {
      const p = at(moved - 0.5 * M.file * TILE, 0.9 * TILE);
      out.push({ ...p, kind: "arrested", seed: prevSeed });
    } else if (curfewHours(tickOfSeconds(haltedAt)) && u < 9) {
      // Sent home: walking back the way the patrol came, out of the way.
      const p = at(moved - u * 1.6 * TILE + 1.2 * TILE, 2.1 * TILE);
      out.push({
        x: p.x,
        y: p.y,
        angle: p.angle + Math.PI,
        kind: "stopped",
        seed: prevSeed,
      });
    }
  }
  return out;
};

/** The sim tick at a game second (inverse of time.ts clock). */
const tickOfSeconds = (seconds: number) =>
  Math.round((seconds - clock(0)) * TICK_RATE);

/** How many patrols a town runs at a tick (0 below martial law). */
export const patrolsOf = (
  town: TownResponse | undefined,
  tick: number,
  roadsOut: number
) =>
  town && levelAt(town.events, tick).level >= MILITARY.patrolLevel
    ? Math.min(MILITARY.patrols, roadsOut)
    : 0;

// ---------------------------------------------------------------------------------------------
// Roadblocks: cars searched at checkpoints

export type CarPose = {
  x: number;
  y: number;
  angle: number;
  seed: number;
  searched: number;
};

/**
 * Cars queued inbound at a checkpoint at game second `t`: the lead one searched (`searched` 0–1,
 * −1 for the rest), then waved through while the queue rolls up a place. `strength` is the
 * checkpoint's hold (0–1); `night` thins the queue.
 */
export const roadblockCars = (
  c: Pick<Checkpoint, "out" | "seed" | "half">,
  strength: number,
  night: number,
  t: number
): CarPose[] => {
  const M = MILITARY;
  const n = Math.round(M.cars * strength * (1 - 0.6 * night));
  if (n <= 0 || c.out.length < 2) return [];
  const room = pathLength(c.out);
  const shifted = t + hashUnit(c.seed, 0x63617273, 1) * M.search;
  const j = Math.floor(shifted / M.search);
  const u = shifted - j * M.search;
  const roll = u < M.roll ? ease(u / M.roll) : 1;
  // Heading into town (against `out`), by the crown of the road: the people's queue (render/response.ts
  // queuerAt) waits on one kerb and walks back out on the other, so the cars keep clear of both.
  const side = 0.12 * c.half;
  const slot = (k: number) => (3.5 + k * M.carGap) * TILE; // the first car's nose 1.25 m short of the line
  const out: CarPose[] = [];
  for (let k = 0; k < n; k++) {
    const s = slot(k + 1 - roll);
    if (s > room) break;
    const p = poseOn(c.out, s, side, true);
    out.push({
      ...p,
      seed: (c.seed * 977 + (j + k)) >>> 0,
      searched:
        k === 0 && u >= M.roll ? (u - M.roll) / (M.search - M.roll) : -1,
    });
  }
  // The last one searched, driving off into town while the rest roll up.
  if (u < M.roll) {
    const s = slot(0) - roll * 6 * TILE;
    const p = poseOn(c.out, Math.max(0, s), side, true);
    const past = Math.max(0, -s);
    out.push({
      x: p.x + Math.cos(p.angle) * past,
      y: p.y + Math.sin(p.angle) * past,
      angle: p.angle,
      seed: (c.seed * 977 + (j - 1)) >>> 0,
      searched: -1,
    });
  }
  return out;
};

// ---------------------------------------------------------------------------------------------
// The wall: the sick shot trying to get out

export type WallShot = {
  /** Where they are (world units), facing; down once shot. */
  x: number;
  y: number;
  angle: number;
  down: boolean;
  /** 0–1 through the volley (muzzle flashes), −1 outside it. */
  firing: number;
  seed: number;
};

/**
 * At a walled checkpoint at game second `t` (walled since game second `since`): the people walking
 * up to the wall from inside and the bodies of those already shot. `wallOut` is how far outside
 * the checkpoint the wall stands (world units).
 */
export const wallShots = (
  c: Pick<Checkpoint, "x" | "y" | "angle" | "half" | "seed">,
  since: number,
  wallOut: number,
  t: number
): WallShot[] => {
  const M = MILITARY;
  const [lo, hi] = M.shotEvery;
  const every = lo + hashUnit(c.seed, 0x73686f74, 1) * (hi - lo);
  const offset = hashUnit(c.seed, 0x73686f74, 2) * every;
  const walk = M.approach * TILE;
  const speed = 0.9 * TILE;
  const reach = walk / speed;
  const ax = Math.cos(c.angle);
  const ay = Math.sin(c.angle);
  const out: WallShot[] = [];
  const first = Math.max(
    0,
    Math.floor((t - M.bodyLies - reach - offset) / every)
  );
  for (let n = first; n * every + offset <= t; n++) {
    const start = n * every + offset;
    if (start < since) continue;
    const seed = (c.seed * 313 + n * 7919) >>> 0;
    const across = (hashUnit(seed, 0x61637273, 3) - 0.5) * 1.6 * c.half;
    // Shot short of the wall (its blocks and wire would hide them).
    const stop = wallOut - 1.6 * TILE;
    const age = t - start;
    if (age > reach + M.bodyLies) continue;
    const along = stop - walk + Math.min(walk, age * speed);
    const x = c.x + ax * along - ay * across;
    const y = c.y + ay * along + ax * across;
    const shotAt = reach;
    out.push({
      x,
      y,
      angle: c.angle,
      down: age >= shotAt + 0.4,
      firing:
        age >= shotAt - 0.3 && age < shotAt + 0.7 ? age - shotAt + 0.3 : -1,
      seed,
    });
  }
  return out;
};

// ---------------------------------------------------------------------------------------------
// Evacuation convoys

export type ConvoyVehicle = {
  x: number;
  y: number;
  angle: number;
  kind: "truck" | "bus";
  seed: number;
};

/** The road from a town's middle to another's (world units), cached per plan; null off the roads. */
export const convoyRoute = (
  plan: Plan,
  map: WorldMap,
  from: number,
  to: number,
  owner: GenerationInput
): Vec[] | null => {
  const { convoyRoutes: byPlan } = responseProjections(owner);
  let cache = byPlan.get(plan);
  if (!cache) byPlan.set(plan, (cache = new Map()));
  const key = `${from}>${to}`;
  let route = cache.get(key);
  if (route === undefined) {
    const a = map.places[from];
    const b = map.places[to];
    const tiles =
      a && b
        ? routeBetween(
            plan,
            { x: a.x / TILE, y: a.y / TILE },
            { x: b.x / TILE, y: b.y / TILE },
            owner
          )
        : null;
    route =
      tiles && tiles.length >= 2
        ? tiles.map((v) => ({ x: v.x * TILE, y: v.y * TILE }))
        : null;
    cache.set(key, route);
  }
  return route;
};

/** Convoys leaving between game seconds `from` and `until` (the wall), each `convoyEvery` apart: the vehicles on the road at `t`. */
export const convoysAt = (
  route: readonly Vec[],
  from: number,
  until: number,
  seed: number,
  t: number
): ConvoyVehicle[] => {
  const M = MILITARY;
  const L = pathLength(route);
  const speed = M.convoySpeed * TILE;
  const out: ConvoyVehicle[] = [];
  const last = Math.floor((Math.min(t, until) - from) / M.convoyEvery);
  for (
    let j = Math.max(0, Math.floor((t - from - L / speed) / M.convoyEvery) - 1);
    j <= last;
    j++
  ) {
    const left = from + j * M.convoyEvery;
    const head = (t - left) * speed;
    for (let v = 0; v < 4; v++) {
      const s = head - v * M.convoyGap * TILE;
      if (s < 0 || s > L) continue;
      const p = poseOn(route, s, 1.75 * TILE); // the middle of a 3.5 m lane
      out.push({
        ...p,
        kind: v % 2 ? "bus" : "truck",
        seed: (seed * 31 + j * 4 + v) >>> 0,
      });
    }
  }
  return out;
};

// ---------------------------------------------------------------------------------------------
// Burn squads

/** Share of a town dead (of the living and the dead), on at least a few hundred people. */

/**
 * Page side (after stepCollapse): each town's `burn` series, 1 while burn squads are out (martial
 * law and enough dead), 0 when they stand down. Returns whether the shared state grew.
 */
export type BurnPile = {
  /** 0–1 through the round: bags carried in, then burned, then ash. */
  phase: "bagging" | "burning" | "ash";
  /** Bags on the pile. */
  bags: number;
  /** 0–1 through the current phase. */
  k: number;
  round: number;
};

/** A burn cell's pile (BURN_CELLS a chunk's side; `cx`, `cy` in cells) at game second `t` (burn squads out since game second `since`), or null if none there this round. */
/** Burn cells along a chunk's side: a pile site in each, a share of them busy any round. */
export const BURN_CELLS = 3;

export const burnPileAt = (
  cx: number,
  cy: number,
  since: number,
  t: number
): BurnPile | null => {
  const M = MILITARY;
  const shifted = t + hashUnit(cx, cy, 0x6275726e) * M.burnRound;
  const round = Math.floor(shifted / M.burnRound);
  if (round * M.burnRound - hashUnit(cx, cy, 0x6275726e) * M.burnRound < since)
    return null;
  if (hashUnit(cx * 31 + round, cy, 0x70696c65) >= M.burnChunks) return null;
  const u = (shifted - round * M.burnRound) / M.burnRound;
  const bags = 3 + Math.floor(hashUnit(cx, cy * 17 + round, 0x62616773) * 6);
  if (u < 0.35)
    return {
      phase: "bagging",
      bags: Math.ceil(bags * (u / 0.35)),
      k: u / 0.35,
      round,
    };
  if (u < 0.75) return { phase: "burning", bags, k: (u - 0.35) / 0.4, round };
  return { phase: "ash", bags, k: (u - 0.75) / 0.25, round };
};

/** When burn squads came out in a town (tick), or null. */
export const burnSince = (town: TownResponse | undefined, tick: number) => {
  const s = town?.burn as Series | undefined;
  let since: number | null = null;
  if (s)
    for (const [v, at] of s) {
      if (at > tick) break;
      since = v > 0 ? since ?? at : null;
    }
  return since;
};

// ---------------------------------------------------------------------------------------------
// Hooks for the sim's people (life.ts): pure in (gid, town, tick)

/**
 * Whether someone visibly sick trying to leave `town` at `tick` is shot: likely at a walled town's
 * wall, sometimes at a shut border. The same person on the same day always gets the same answer.
 */
export const shotOf = (
  gid: number,
  town: number,
  tick: number,
  symptomatic: boolean,
  context: PlanningContext
) => {
  if (!symptomatic) return false;
  const c = collapseOf(responseState(context).towns[town], tick);
  const p =
    c.walled !== null
      ? MILITARY.shootWalled
      : c.border > 0
      ? MILITARY.shootBorder
      : 0;
  return p > 0 && hashUnit(gid, Math.floor(clock(tick) / 720), 0x73686f74) < p;
};

/**
 * Whether and when a person of `town` is taken out by the convoys, and where to: the
 * healthy-looking only (carriers too: nobody can tell), a share of them, spread over the
 * evacuation. Null if not (or not yet at `tick`).
 */
export const evacuationOf = (
  gid: number,
  town: number,
  tick: number,
  symptomatic: boolean,
  context: PlanningContext
): { at: number; to: number } | null => {
  if (symptomatic) return null;
  const c = collapseOf(responseState(context).towns[town], tick);
  if (!c.evac || hashUnit(gid, town, 0x65766163) >= MILITARY.evacShare)
    return null;
  const until = c.walled ?? c.evac.at + wallTicks();
  const at =
    c.evac.at + Math.floor(hashUnit(gid, town, 0x77686e) * (until - c.evac.at));
  return at <= tick ? { at, to: c.evac.to } : null;
};
const wallTicks = () => COLLAPSE.wallDelay * TICK_RATE;

/** Expected share of a town evacuated by `tick` (for the page's counts and the world map). */
export const evacueesOf = (town: TownResponse | undefined, tick: number) => {
  const c = collapseOf(town, tick);
  if (!c.evac) return 0;
  const until = c.walled ?? c.evac.at + wallTicks();
  return (
    MILITARY.evacShare *
    Math.min(
      1,
      Math.max(0, (tick - c.evac.at) / Math.max(1, until - c.evac.at))
    )
  );
};

/**
 * When a body that fell at `diedAt` in `town` is cleared by a burn squad (tick), or null if the
 * squads haven't come for it by `tick`. A body lies at least a while; squads take it within a round.
 */
export const clearedAt = (
  gid: number,
  town: number,
  diedAt: number,
  tick: number,
  context: PlanningContext
) => {
  const s = responseState(context).towns[town]?.burn as Series | undefined;
  if (!s) return null;
  for (let i = 0; i < s.length; i++) {
    const [v, from] = s[i];
    if (v <= 0) continue;
    const to = s[i + 1]?.[1] ?? Infinity;
    const start = Math.max(from, diedAt + 30 * TICK_RATE);
    if (start >= to) continue;
    const at =
      start +
      Math.floor(
        hashUnit(gid, town, 0x636c7272) * MILITARY.burnRound * TICK_RATE
      );
    if (at < to) return at <= tick ? at : null;
  }
  return null;
};

/** Integrates one town; the owning system controls phase order and iteration. */
