/** PlaceKind by its name, for definitions that name a place kind (content/**: `place: "Shop"`). */
import { PlaceKind } from "../worldgen/terrain/index";

const KINDS: Record<string, PlaceKind> = {
  Apartment: PlaceKind.Apartment,
  House: PlaceKind.House,
  Farmhouse: PlaceKind.Farmhouse,
  Hut: PlaceKind.Hut,
  Cabin: PlaceKind.Cabin,
  Shop: PlaceKind.Shop,
  Workshop: PlaceKind.Workshop,
  Office: PlaceKind.Office,
  School: PlaceKind.School,
  Tavern: PlaceKind.Tavern,
  Park: PlaceKind.Park,
  Plaza: PlaceKind.Plaza,
  Field: PlaceKind.Field,
  Pasture: PlaceKind.Pasture,
  Clearing: PlaceKind.Clearing,
  Green: PlaceKind.Green,
};

export const placeKindNamed = (name: string): PlaceKind => {
  const kind = KINDS[name];
  if (kind === undefined) throw new Error(`Unknown place kind ${name}`);
  return kind;
};
