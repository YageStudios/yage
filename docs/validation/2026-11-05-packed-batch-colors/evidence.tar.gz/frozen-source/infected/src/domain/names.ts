/** Fictional English-style place names for procedural regions (plan §5: invented places are flagged). */
import { type Rng, pick } from "../atlas/ids";
import { CONTENT } from "../content/runtime";

/** The name parts (content/place-names.json5). */
const { heads: HEADS, tails: TAILS, rivers: RIVERS, streams: STREAMS } = CONTENT.placeNames;

export const placeName = (r: Rng, taken: Set<string>) => {
  for (let i = 0; i < 50; i++) {
    const name = pick(r, HEADS) + pick(r, TAILS);
    if (!taken.has(name)) {
      taken.add(name);
      return name;
    }
  }
  const name = `${pick(r, HEADS)}${pick(r, TAILS)} ${taken.size}`;
  taken.add(name);
  return name;
};

export const riverName = (r: Rng) => `River ${pick(r, RIVERS)}`;
export const streamName = (r: Rng, taken: Set<string>) => {
  for (let i = 0; i < 20; i++) {
    const name = pick(r, STREAMS);
    if (!taken.has(name)) {
      taken.add(name);
      return name;
    }
  }
  return `Brook ${taken.size}`;
};

export const slug = (name: string) => name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
