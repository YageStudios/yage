/** Pure town-response readers, tuning data, debug edits and initial state construction.
 * TownsResponseSystem owns scheduled counts and awareness; the offices decide the ladder
 * (OfficeDecisionSystem, TownPolicySystem), and TownResearchSystem works the cure.
 */
import { CONTENT } from "../../content/runtime";
import type { Traits } from "../disease";
import type { Plan } from "../../worldgen/plan";
import { DAY_SECONDS } from "../time";
import { TILE } from "../world";
import { placeNear, type WorldMap } from "../../worldmap/places";
import { emptyTown, Level } from "./measures";

/** Owner-tunable numbers of awareness, the ladder and the cure; data in content/response.json5. */
export const RESPONSE = CONTENT.response.towns;

/** The numbers are data (content/response.json5). */
const { fullDays, fromLevel, ...cure } = CONTENT.response.cure;
export const CURE = {
  ...cure,
  fullSeconds: fullDays * DAY_SECONDS,
  fromLevel: Level[fromLevel],
};

export { TownResponseState as Town } from "../../components/response/TownResponseState";
export { WorldResponse } from "../../components/response/WorldResponse";
import type { TownResponseState as Town } from "../../components/response/TownResponseState";
import type { WorldResponse } from "../../components/response/WorldResponse";
import { createResponseMemory } from "./memory";

/** Towns linked by road (the map's links) and by transit (stops of one line near both). */
export const newsLinks = (map: WorldMap, plan: Plan | null): number[][] => {
  const out: Set<number>[] = map.places.map(() => new Set());
  const join = (a: number, b: number) => {
    if (a < 0 || b < 0 || a === b) return;
    out[a].add(b);
    out[b].add(a);
  };
  for (const l of map.links) join(l.from, l.to);
  const lines = plan?.lines ?? [];
  for (const line of lines) {
    const towns = [
      ...new Set(
        line.stops
          .map((s) => placeNear(map, s.at.x * TILE, s.at.y * TILE, 4 * TILE))
          .filter((i) => i >= 0)
      ),
    ];
    for (let i = 0; i < towns.length; i++)
      for (let j = i + 1; j < towns.length; j++) join(towns[i], towns[j]);
  }
  return out.map((s) => [...s].sort((a, b) => a - b));
};

export const newResponse = (
  map: WorldMap,
  links: number[][] | undefined = undefined,
  plan: Plan | null
): WorldResponse => ({
  towns: map.places.map(() => ({
    awareness: 0,
    heard: 0,
    level: 0,
    changed: -Infinity,
    research: 0,
    people: 0,
    visible: 0,
    incubating: 0,
    dead: 0,
    hospital: 0,
  })),
  shared: { towns: map.places.map(() => emptyTown()) },
  links: links ?? newsLinks(map, plan),
  cure: 0,
  reshuffles: 0,
  tick: 0,
  memory: createResponseMemory(),
  geometry: { plan: null, map: null, gates: [] },
});


/** What a town sees, 0–1. */
export const sighted = (
  t: Pick<Town, "people" | "visible" | "dead">,
  hospitalLoad: number,
  traits: Pick<Traits, "visibility">
) => {
  if (t.people <= 0) return 0;
  const people = Math.max(t.people, RESPONSE.minPeople);
  const sick = Math.max(0, t.visible - RESPONSE.quietSick);
  const dead = Math.max(0, t.dead - RESPONSE.quietDead);
  const seen =
    (sick / people) * RESPONSE.sickWeight * traits.visibility +
    (dead / people) * RESPONSE.deadWeight +
    hospitalLoad * RESPONSE.hospitalWeight;
  return 1 - Math.exp(-seen);
};

/** Research capacity of a place. */
export const capacityOf = (map: WorldMap, i: number) =>
  CURE.capacity[map.places[i].kind] ?? 0;


