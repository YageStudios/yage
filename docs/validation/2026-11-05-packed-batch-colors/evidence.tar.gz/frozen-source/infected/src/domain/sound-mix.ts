/**
 * The scene mix's pure rules (systems/audio/AudioEffects plays them): which preset a moment
 * plays, how sources and moments are placed, and how the nearest of a kind of source is found.
 * Positions are world px, so there is no air absorption.
 */
import type { VoiceOptions } from "yage/audio/types";
import type { SoundCues } from "../components/audio/SoundCues";
import type { Moment } from "../components/audio/SoundMoment";
import type { Source } from "../components/audio/SoundSource";
import { TILE } from "./world";

export const MOMENT_SOUND: Record<Moment, string> = { cough: "apt-cough", sneeze: "inf-sneeze", retch: "inf-retch", fall: "inf-fall", spores: "inf-spores", shot: "inf-gunshot", bite: "inf-bite", shriek: "inf-shriek", brawl: "inf-brawl", door: "inf-door" };
/** Moments started a frame at most (the nearest win). */
export const MOMENTS_PER_FRAME = 3;
/** The listener's height over the view at zoom 1 (world px); it rises as the camera zooms out. */
export const EAR = 300;
/** Sources and moments in world px: full level within this, then falling off as 1/distance. */
export const SPATIAL = { model: "equalpower", distance: "inverse", refDistance: 260, rolloff: 1, maxDistance: 1e6, air: false } as const;
/** Metres a world px (a tile is about a metre and a half), for thunder's delay. */
export const METRES = 1.5 / TILE;
/** Storm cells remembered for thunder. */
export const STRIKES_HELD = 64;

export const quantise = (v: number, step = 0.05) => Math.round(v / step) * step;
export const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

/** A voice placed at world (x, y). */
export const placedAt = (x: number, y: number): VoiceOptions => ({ position: [x, 0, y], spatial: SPATIAL });

/** The nearest of a kind's sources to (x, y), and how loud the ones round it are together. */
export const nearestSource = (cues: SoundCues, kind: Source, x: number, y: number) => {
  const list = cues.sources.filter((source) => source.kind === kind);
  if (!list.length) return null;
  let best = list[0];
  let bestD = Infinity;
  for (const s of list) {
    const d = (s.x - x) ** 2 + (s.y - y) ** 2;
    if (d < bestD) [best, bestD] = [s, d];
  }
  let level = 0;
  for (const s of list) if ((s.x - best.x) ** 2 + (s.y - best.y) ** 2 < (12 * TILE) ** 2) level += s.level;
  return { x: best.x, y: best.y, level: clamp01(level), count: list.length };
};

/** A storm cell's identity for its thunder window. */
export const strikeKey = (gx: number, gy: number) => (gx * 73856093) ^ (gy * 19349663);
