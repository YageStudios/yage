/**
 * Page-side hive control helpers: steering bytes from keys, and finding bloomed pawns in the
 * snapshots the scene is drawing. Pure apart from reading the snapshot objects it is given.
 */
import { EMPTY_SLOT, POSITION_SCALE, type Snapshot } from "yage/streaming";
import type { ChunkScene } from "yage/streaming/layer";
import { SpriteSet } from "./disease";
import { decayOf } from "./look/decay";
import { setOf } from "./look/sprites";

/** The sprite set a snapshot sprite index belongs to (inverse of look.ts `spriteFor`). */
export { setOf };

/** Steering input for the host: direction + 1 on each axis. */
export const steerBytes = (keys: ReadonlySet<string>) => {
  const dx = (keys.has("d") ? 1 : 0) - (keys.has("a") ? 1 : 0);
  const dy = (keys.has("s") ? 1 : 0) - (keys.has("w") ? 1 : 0);
  return new Uint8Array([dx + 1, dy + 1]);
};

/** What the page needs from a chunk view: its coordinates and its last two snapshots. */
export type PawnSource = {
  cx: number;
  cy: number;
  pair: { current: Snapshot | null; prevX: Int16Array; prevY: Int16Array; prevTick: number; alpha(now: number): number };
};

/** A bloomed pawn on screen; `stage` is its decay stage (0 fresh … 3 dying). */
export type Pawn = { gid: number; x: number; y: number; stage: number; /** Its atlas sprite, where drawnPawns read it. */ sprite?: number };

/** World position of snapshot slot `i`, interpolated like the shader draws it. */
/** The scene's loaded chunks that have people to draw, as pawn sources. */
export const pawnSources = (scene: ChunkScene): PawnSource[] => {
  const list: PawnSource[] = [];
  for (const v of scene.views.values()) if (v.layer) list.push({ cx: v.cx, cy: v.cy, pair: v.layer.pair });
  return list;
};

export const slotPosition = (source: PawnSource, i: number, alpha: number, chunkSize: number) => {
  const s = source.pair.current!;
  const px = source.pair.prevX[i];
  const py = source.pair.prevY[i];
  return {
    x: source.cx * chunkSize + (px + (s.x[i] - px) * alpha) / POSITION_SCALE,
    y: source.cy * chunkSize + (py + (s.y[i] - py) * alpha) / POSITION_SCALE,
  };
};

/** Every bloomed (steerable) pawn drawn in these sources, optionally inside bounds. */
export const bloomedPawns = (
  sources: Iterable<PawnSource>,
  now: number,
  chunkSize: number,
  bounds?: { minX: number; minY: number; maxX: number; maxY: number }
) => drawnPawns(sources, now, chunkSize, bounds, true);

/** Every pawn drawn in these sources (or only bloomed ones), optionally inside bounds. */
export const drawnPawns = (
  sources: Iterable<PawnSource>,
  now: number,
  chunkSize: number,
  bounds?: { minX: number; minY: number; maxX: number; maxY: number },
  bloomedOnly = false
) => {
  const pawns: Pawn[] = [];
  // Small bounds only (a door, a window): a view-sized query scans as before.
  const frame = bounds && Array.isArray(sources) && bounds.maxX - bounds.minX <= 4 * GRID && bounds.maxY - bounds.minY <= 4 * GRID ? frameOf(sources, now, chunkSize) : null;
  for (const source of sources) {
    const s = source.pair.current;
    if (!s) continue;
    if (bounds) {
      const x0 = source.cx * chunkSize;
      const y0 = source.cy * chunkSize;
      if (x0 > bounds.maxX + 64 || y0 > bounds.maxY + 64 || x0 + chunkSize < bounds.minX - 64 || y0 + chunkSize < bounds.minY - 64) continue;
    }
    if (frame && bounds) {
      sourceQuery(frame, source, s, bounds, bloomedOnly, pawns);
      continue;
    }
    const alpha = source.pair.alpha(now);
    for (let i = 0; i < s.count; i++) {
      if (s.tint[i] === EMPTY_SLOT || (bloomedOnly && setOf(s.sprite[i]) !== SpriteSet.Infected)) continue;
      const p = slotPosition(source, i, alpha, chunkSize);
      if (bounds && (p.x < bounds.minX || p.x > bounds.maxX || p.y < bounds.minY || p.y > bounds.maxY)) continue;
      pawns.push({ gid: s.gid[i], x: p.x, y: p.y, stage: decayOf(s.sprite[i], s.tint[i]), sprite: s.sprite[i] });
    }
  }
  return pawns;
};

/**
 * Bounded queries against one pawnSources list at one `now` (a frame's doors and windows) share a
 * grid of each queried chunk's drawn slots, built on its first query, instead of rescanning every
 * slot of the chunk per query. Results keep source then slot order, as the scan gives them.
 */
const GRID = 64;
type Slot = { slot: number; x: number; y: number };
type Frame = { now: number; chunkSize: number; grids: Map<PawnSource, Map<number, Slot[]>> };
const frames = new WeakMap<readonly PawnSource[], Frame>();
const frameOf = (sources: readonly PawnSource[], now: number, chunkSize: number) => {
  let frame = frames.get(sources);
  if (!frame || frame.now !== now || frame.chunkSize !== chunkSize) frames.set(sources, (frame = { now, chunkSize, grids: new Map() }));
  return frame;
};
const gridKey = (gx: number, gy: number) => gx * 2 ** 21 + gy;
const sourceQuery = (
  frame: Frame,
  source: PawnSource,
  s: Snapshot,
  bounds: { minX: number; minY: number; maxX: number; maxY: number },
  bloomedOnly: boolean,
  out: Pawn[]
) => {
  let grid = frame.grids.get(source);
  if (!grid) {
    grid = new Map();
    const alpha = source.pair.alpha(frame.now);
    for (let i = 0; i < s.count; i++) {
      if (s.tint[i] === EMPTY_SLOT) continue;
      const p = slotPosition(source, i, alpha, frame.chunkSize);
      const key = gridKey(Math.floor(p.x / GRID), Math.floor(p.y / GRID));
      let cell = grid.get(key);
      if (!cell) grid.set(key, (cell = []));
      cell.push({ slot: i, x: p.x, y: p.y });
    }
    frame.grids.set(source, grid);
  }
  const found: Slot[] = [];
  for (let gx = Math.floor(bounds.minX / GRID); gx <= Math.floor(bounds.maxX / GRID); gx++)
    for (let gy = Math.floor(bounds.minY / GRID); gy <= Math.floor(bounds.maxY / GRID); gy++) {
      const cell = grid.get(gridKey(gx, gy));
      if (!cell) continue;
      for (const p of cell) {
        if (p.x < bounds.minX || p.x > bounds.maxX || p.y < bounds.minY || p.y > bounds.maxY) continue;
        if (bloomedOnly && setOf(s.sprite[p.slot]) !== SpriteSet.Infected) continue;
        found.push(p);
      }
    }
  found.sort((a, b) => a.slot - b.slot);
  for (const { slot: i, x, y } of found) out.push({ gid: s.gid[i], x, y, stage: decayOf(s.sprite[i], s.tint[i]), sprite: s.sprite[i] });
};

/** The pawn nearest (x, y), optionally within `maxDistance`, skipping `except`. */
export const nearestPawn = (pawns: readonly Pawn[], x: number, y: number, maxDistance = Infinity, except = -1) => {
  let best: Pawn | null = null;
  let bestDistance = maxDistance * maxDistance;
  for (const pawn of pawns) {
    if (pawn.gid === except) continue;
    const d = (pawn.x - x) ** 2 + (pawn.y - y) ** 2;
    if (d < bestDistance) {
      best = pawn;
      bestDistance = d;
    }
  }
  return best;
};

/** Tab order: pawns sorted by distance from (x, y); the next one after `current` in that order. */
export const nextPawn = (pawns: readonly Pawn[], x: number, y: number, visited: Set<number>, current: number) => {
  const sorted = pawns.filter((p) => p.gid !== current).sort((a, b) => (a.x - x) ** 2 + (a.y - y) ** 2 - ((b.x - x) ** 2 + (b.y - y) ** 2));
  if (!sorted.length) return null;
  const fresh = sorted.find((p) => !visited.has(p.gid));
  if (fresh) return fresh;
  // Everyone in view has had a turn: start the cycle again.
  visited.clear();
  return sorted[0];
};

/** Finds a gid's slot in a source's current snapshot, trying the cached slot first. */
export const findSlot = (source: PawnSource, gid: number, cached: number) => {
  const s = source.pair.current;
  if (!s) return -1;
  if (cached >= 0 && cached < s.count && s.gid[cached] === gid && s.tint[cached] !== EMPTY_SLOT) return cached;
  for (let i = 0; i < s.count; i++) if (s.gid[i] === gid && s.tint[i] !== EMPTY_SLOT) return i;
  return -1;
};
