/**
 * Weapons and gear (content/arms.json5). The response's soldiers carry the rifle; the simulation
 * lab (src/simlab, scenarios/lab) hands anyone any of these. Pure lookups, the same on every thread.
 */
import { CONTENT } from "../content/runtime";
import type { Gear, PlayerAim, Weapon } from "../content/schema/sim";

export type { Gear, PlayerAim, Weapon };

export const WEAPONS: readonly Weapon[] = CONTENT.arms.weapons;
export const GEAR: readonly Gear[] = CONTENT.arms.gear;
/** The soldiers' standard issue. */
export const RIFLE: Weapon = WEAPONS.find((w) => w.id === "rifle")!;
/** A weapon by id, or undefined. */
export const weaponById = (id: string) => WEAPONS.find((w) => w.id === id);
/** How many times its range a shot the player fires carries. */
const PLAYER_CARRY = 3;
/** How far (tiles) a shot the player fires with `weapon` carries before it is spent. */
export const playerReach = (weapon: Weapon) => weapon.range * PLAYER_CARRY;
/** A weapon's aim in the player's hands (content's `aim`, else made from its spread and range). */
export const aimOf = (weapon: Weapon): PlayerAim => weapon.aim ?? { loose: weapon.spread, steady: weapon.spread / 2, doubles: weapon.range, settle: 0.8, kick: 0.2 };
/**
 * How wide (radians either side) a shot the player fires with `weapon` at a point `tiles` away may
 * go, `steadiness` (0 swinging … 1 settled on the target) into the aim: between the weapon's loose
 * and steady spread up close, widening the further the aim, twice it at the aim's `doubles`.
 */
export const playerSpread = (weapon: Weapon, tiles: number, steadiness = 0) => {
  const aim = aimOf(weapon);
  const s = Math.min(1, Math.max(0, steadiness));
  return (aim.loose + (aim.steady - aim.loose) * s) * (1 + Math.max(0, tiles) / aim.doubles);
};
/** Gear by id, or undefined. */
export const gearById = (id: string) => GEAR.find((g) => g.id === id);
/** Index of a weapon (its id's place in the table: what crosses the wire), -1 for none. */
export const weaponIndex = (id: string) => WEAPONS.findIndex((w) => w.id === id);
