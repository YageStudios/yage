/**
 * Where the world response stands on the street (pure geometry, no drawing): the checkpoints at a
 * town's edge. Pure functions of the plan and the world map, cached per plan.
 *
 * A checkpoint sits where a road leaves the town's chunks (the area its measures cover), a little
 * inside, pulled in along the road to the town's last buildings: the barrier across the carriageway, its guards at the kerbs, and the queue of people
 * turned back along the road outward.
 */
import { CONTENT } from "../../content/runtime";
import { chunkKey, chunkX, chunkY } from "yage/streaming";
import type { Vec } from "../../atlas/model";
import type { Road } from "../../atlas/objects";
import { networkOf } from "../../worldgen/network/network-of";
import type { Plan } from "../../worldgen/plan";
import { responseProjections, type GenerationInput } from "../../worldgen/source/owner";
import { CHUNK_TILES, TILE } from "../world";
import type { WorldMap } from "../../worldmap/places";

export type Checkpoint = {
  town: number;
  /** The barrier's middle (world units). */
  x: number;
  y: number;
  /** Along the road, outward (radians, +y south). */
  angle: number;
  /** Half the carriageway (world units). */
  half: number;
  /** The road outward from the barrier (world units), for the queue: at least `QUEUE_ROOM` long unless the road ends. */
  out: Vec[];
  /** Per checkpoint, for its people. */
  seed: number;
};

/** The numbers are data (content/response.json5). */
const checkpoint = CONTENT.response.checkpoint;
export const CHECKPOINT = {
  ...checkpoint,
  classes: new Set<string>(checkpoint.classes),
};

/** The town a tile point is in (-1: none), by its chunk. */
const townAtTile = (map: WorldMap, x: number, y: number) =>
  map.placeOf.get(
    chunkKey(Math.floor(x / CHUNK_TILES), Math.floor(y / CHUNK_TILES))
  ) ?? -1;

const lerp = (a: Vec, b: Vec, t: number): Vec => ({
  x: a.x + (b.x - a.x) * t,
  y: a.y + (b.y - a.y) * t,
});

/** The polyline from distance `s` along it onward, `length` long (or to its end). */
export const subPath = (
  path: readonly Vec[],
  s: number,
  length: number
): Vec[] => {
  const out: Vec[] = [];
  let at = 0;
  const end = s + length;
  for (let i = 0; i + 1 < path.length; i++) {
    const a = path[i];
    const b = path[i + 1];
    const L = Math.hypot(b.x - a.x, b.y - a.y);
    if (L <= 0) continue;
    const from = Math.max(s, at);
    const to = Math.min(end, at + L);
    if (
      to > from ||
      (to === from && !out.length && from >= at && from <= at + L)
    ) {
      if (!out.length) out.push(lerp(a, b, (from - at) / L));
      if (to > from) out.push(lerp(a, b, (to - at) / L));
    }
    at += L;
    if (at >= end) break;
  }
  return out;
};

/** The point `s` along a polyline (clamped to its ends). */
export const pointAlong = (path: readonly Vec[], s: number): Vec => {
  let at = 0;
  for (let i = 0; i + 1 < path.length; i++) {
    const a = path[i];
    const b = path[i + 1];
    const L = Math.hypot(b.x - a.x, b.y - a.y);
    if (at + L >= s && L > 0) return lerp(a, b, Math.max(0, (s - at) / L));
    at += L;
  }
  return path[path.length - 1];
};

export const pathLength = (path: readonly Vec[]) => {
  let L = 0;
  for (let i = 0; i + 1 < path.length; i++)
    L += Math.hypot(path[i + 1].x - path[i].x, path[i + 1].y - path[i].y);
  return L;
};

/**
 * Where a road leaves a town: for each crossing of the town's edge (by chunk), the distance along
 * the road and whether walking forward goes out. Bisected to a tenth of a tile.
 */
export const edgeCrossings = (
  map: WorldMap,
  town: number,
  points: readonly Vec[]
): { s: number; outward: boolean }[] => {
  const found: { s: number; outward: boolean }[] = [];
  let at = 0;
  for (let i = 0; i + 1 < points.length; i++) {
    const a = points[i];
    const b = points[i + 1];
    const L = Math.hypot(b.x - a.x, b.y - a.y);
    if (L <= 0) continue;
    // Step through chunk-sized pieces so a long segment can't skip a chunk.
    const steps = Math.max(1, Math.ceil(L / (CHUNK_TILES / 4)));
    let prev = townAtTile(map, a.x, a.y) === town;
    for (let k = 1; k <= steps; k++) {
      let lo = (k - 1) / steps;
      let hi = k / steps;
      const p = lerp(a, b, hi);
      const now = townAtTile(map, p.x, p.y) === town;
      if (now !== prev) {
        for (let n = 0; n < 24 && (hi - lo) * L > 0.1; n++) {
          const mid = (lo + hi) / 2;
          const q = lerp(a, b, mid);
          if ((townAtTile(map, q.x, q.y) === town) === prev) lo = mid;
          else hi = mid;
        }
        found.push({ s: at + ((lo + hi) / 2) * L, outward: prev });
        prev = now;
      }
    }
    at += L;
  }
  return found;
};

const reversed = (points: readonly Vec[]) => points.slice().reverse();

const angleAt = (path: readonly Vec[]) => {
  const a = path[0];
  const b = path.length > 1 ? path[1] : path[0];
  return Math.atan2(b.y - a.y, b.x - a.x);
};

/**
 * A town's checkpoints, from its roads (tile units in, world units out). With `gap` (tiles from a point
 * to the town's nearest building), a barrier where the town's chunks run past its last houses is
 * pulled in along the road to them, staying inside the town's chunks.
 */
export const checkpointsFor = (
  map: WorldMap,
  roads: readonly Road[],
  town: number,
  gap?: (p: Vec) => number
): Checkpoint[] => {
  const list: Checkpoint[] = [];
  const near: Vec[] = [];
  let ends: ((p: Vec) => Road[]) | undefined;
  for (const road of roads) {
    if (
      !CHECKPOINT.classes.has(road.cls) ||
      road.inner ||
      road.points.length < 2
    )
      continue;
    const length = pathLength(road.points);
    for (const cross of edgeCrossings(map, town, road.points)) {
      // Outward along the road from the crossing: forward if it leaves going forward, else backward.
      let path: readonly Vec[] = cross.outward
        ? road.points
        : reversed(road.points);
      let s = cross.outward ? cross.s : length - cross.s;
      let width = road.width;
      if (gap)
        ({ path, s, width } = pulledIn(
          map,
          town,
          (ends ??= endsOf(roads)),
          road,
          path,
          s,
          gap
        ));
      const from = Math.max(0, s - CHECKPOINT.inset);
      const out = subPath(path, from, CHECKPOINT.queueRoom + (s - from));
      if (out.length < 2) continue;
      const at = out[0];
      if (
        near.some((p) => Math.hypot(p.x - at.x, p.y - at.y) < CHECKPOINT.merge)
      )
        continue;
      near.push(at);
      list.push({
        town,
        x: at.x * TILE,
        y: at.y * TILE,
        angle: angleAt(out),
        half: (width / 2) * TILE,
        out: out.map((p) => ({ x: p.x * TILE, y: p.y * TILE })),
        seed: Math.round(at.x * 131 + at.y * 977) >>> 0,
      });
    }
  }
  return list;
};

type Pull = { path: Vec[]; s: number; width: number };

/** Roads by their end points, for walking on through a junction. */
const endsOf = (roads: readonly Road[]) => {
  const cell = (p: Vec) => `${Math.round(p.x / 4)},${Math.round(p.y / 4)}`;
  const at = new Map<string, Road[]>();
  for (const r of roads) {
    if (!CHECKPOINT.classes.has(r.cls) || r.inner || r.points.length < 2)
      continue;
    for (const p of [r.points[0], r.points[r.points.length - 1]]) {
      const k = cell(p);
      if (!at.get(k)?.includes(r)) at.set(k, [...(at.get(k) ?? []), r]);
    }
  }
  return (p: Vec) => {
    const out = new Set<Road>();
    const cx = Math.round(p.x / 4);
    const cy = Math.round(p.y / 4);
    for (let dy = -1; dy <= 1; dy++)
      for (let dx = -1; dx <= 1; dx++)
        for (const r of at.get(`${cx + dx},${cy + dy}`) ?? []) out.add(r);
    return [...out];
  };
};

/**
 * Where the barrier stands: from `s` along `path` (outward) back inward, on through junctions onto
 * the roads that lead in, inside the town's chunks, at the first point within CHECKPOINT.built of
 * a building; failing that, where it comes closest. The path returned runs from the barrier's road
 * out through the original crossing.
 */
const pulledIn = (
  map: WorldMap,
  town: number,
  ends: (p: Vec) => Road[],
  road: Road,
  path: readonly Vec[],
  s: number,
  gap: (p: Vec) => number
): Pull => {
  const step = 4;
  let best: Pull = { path: path.slice(), s, width: road.width };
  let bestGap = Infinity;
  const queue = [
    {
      path: path.slice(),
      from: s,
      width: road.width,
      used: 0,
      seen: new Set([road]),
    },
  ];
  for (let n = 0; n < queue.length && n < 64; n++) {
    const cur = queue[n];
    for (
      let d = 0;
      cur.used + d <= CHECKPOINT.pull && cur.from - d >= 0;
      d += step
    ) {
      const p = pointAlong(
        cur.path,
        Math.max(0, cur.from - d - CHECKPOINT.inset)
      );
      if (townAtTile(map, p.x, p.y) !== town) continue;
      const g = gap(p);
      if (g <= CHECKPOINT.built)
        return { path: cur.path, s: cur.from - d, width: cur.width };
      if (g < bestGap) {
        bestGap = g;
        best = { path: cur.path, s: cur.from - d, width: cur.width };
      }
    }
    const used = cur.used + cur.from;
    const start = cur.path[0];
    if (used > CHECKPOINT.pull || townAtTile(map, start.x, start.y) !== town)
      continue;
    for (const r of ends(start)) {
      if (cur.seen.has(r)) continue;
      const a = r.points[0];
      const b = r.points[r.points.length - 1];
      const into =
        Math.hypot(b.x - start.x, b.y - start.y) <= 3
          ? r.points
          : Math.hypot(a.x - start.x, a.y - start.y) <= 3
          ? reversed(r.points)
          : null;
      if (!into) continue;
      queue.push({
        path: [...into, ...cur.path],
        from: pathLength(into),
        width: r.width,
        used,
        seen: new Set([...cur.seen, r]),
      });
    }
  }
  return best;
};

/** A town's checkpoints in the active atlas (none without one). Cached per plan and map. */
export const checkpointsOf = (
  map: WorldMap,
  town: number,
  plan: Plan | null,
  owner: GenerationInput
): Checkpoint[] => {
  if (!plan) return [];
  const { checkpoints } = responseProjections(owner);
  let byMap = checkpoints.get(plan);
  if (!byMap) checkpoints.set(plan, (byMap = new WeakMap()));
  let cache = byMap.get(map);
  if (!cache) byMap.set(map, (cache = new Map()));
  let hit = cache.get(town);
  if (!hit) {
    const place = map.places[town];
    // Only roads near the town: a box round its chunks.
    let x0 = Infinity,
      y0 = Infinity,
      x1 = -Infinity,
      y1 = -Infinity;
    for (const key of place?.chunks ?? []) {
      const [cx, cy] = keyXY(key);
      x0 = Math.min(x0, cx * CHUNK_TILES);
      y0 = Math.min(y0, cy * CHUNK_TILES);
      x1 = Math.max(x1, (cx + 1) * CHUNK_TILES);
      y1 = Math.max(y1, (cy + 1) * CHUNK_TILES);
    }
    const roads = networkOf(plan, owner).roads.filter(
      (r) =>
        r.points.some(
          (p) =>
            p.x >= x0 - 2 && p.x <= x1 + 2 && p.y >= y0 - 2 && p.y <= y1 + 2
        ) || crossesBox(r.points, x0, y0, x1, y1)
    );
    const id = place?.id;
    const R = CHECKPOINT.built * 3;
    const gap = (p: Vec) => {
      let g = Infinity;
      for (const b of plan.index.buildings.query({
        x0: p.x - R,
        y0: p.y - R,
        x1: p.x + R,
        y1: p.y + R,
      })) {
        if (b.settlement === id)
          g = Math.min(
            g,
            Math.hypot(b.box.cx - p.x, b.box.cy - p.y) -
              Math.max(b.box.hu, b.box.hv)
          );
      }
      return g;
    };
    hit = Number.isFinite(x0) ? checkpointsFor(map, roads, town, gap) : [];
    cache.set(town, hit);
  }
  return hit;
};

const crossesBox = (
  points: readonly Vec[],
  x0: number,
  y0: number,
  x1: number,
  y1: number
) => {
  for (let i = 0; i + 1 < points.length; i++) {
    const a = points[i];
    const b = points[i + 1];
    if (
      Math.max(a.x, b.x) >= x0 &&
      Math.min(a.x, b.x) <= x1 &&
      Math.max(a.y, b.y) >= y0 &&
      Math.min(a.y, b.y) <= y1
    )
      return true;
  }
  return false;
};

const keyXY = (key: number): [number, number] => [chunkX(key), chunkY(key)];
