import { HOUR } from "./time";
import { PlaceKind } from "../worldgen/terrain/kinds";
/**
 * Seconds of game time a commute is comfortable within. The clock runs far faster than people
 * walk (an hour is 30 s, a walk about 60 tiles), so this is a feel, not 30 literal minutes: about
 * 110 tiles of walking, or across a city by subway. Tunable.
 */
export const COMMUTE_CAP = 2 * HOUR;
/** Nothing past this is offered at all (the few who go past the cap stop here). */
export const COMMUTE_LIMIT = 1.5 * COMMUTE_CAP;
/** Average walking pace (tiles a second) and how much streets wind per Manhattan tile. */
const WALK = 33 / 16;
const DETOUR = 1.15;
/** A line must still call at the stop for home this late (seconds into the day): nobody is stranded after work. */
export const FAR_HOME_BY = 20.5 * HOUR;

/** Seconds to walk `tiles` (Manhattan) at the average pace. */
export const walkTime = (tiles: number) => (tiles * DETOUR) / WALK;

/** How much a commute of `t` seconds puts people off: a gentle lean toward the nearer of two jobs. */
export const bearable = (t: number) => Math.exp(-t / (3 * COMMUTE_CAP));
/**
 * Share of workers who put up with a trip past the cap, up to the limit (for the job they want,
 * the train to the next town). Everyone else picks within it, unless nothing is.
 */
export const TOLERANT_SHARE = 0.08;

/** Staff a place takes: a 20-storey office employs more than a corner shop. */
export const staffOf = (p: { kind: PlaceKind; storeys: number }) => p.storeys * (p.kind === PlaceKind.Shop ? 4 : 8);

/** One chunk-key encoding for the whole game: yage's (±262144 chunks an axis, a true-scale Earth). */
export { chunkKey, chunkX as keyX, chunkY as keyY } from "yage/streaming";

