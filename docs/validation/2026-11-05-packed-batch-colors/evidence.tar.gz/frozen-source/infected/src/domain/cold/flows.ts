/**
 * Where a cold chunk's commuters work: each resident's planned work chunk (planChunk's wdir) that
 * isn't home, counted by key in key order. A pure function of the plan, so any host and any
 * replay derive the same flows.
 */
import { chunkKey } from "yage/streaming";
import { HOME_CHUNK } from "../people/identity";
import { workChunkOf } from "../people/jobs";
import { planChunk } from "../../worldgen/population/planner";
import type { PlanningContext } from "../../worldgen/commute/context";

export const commuteFlows = (cx: number, cy: number, context: PlanningContext) => {
  const plan = planChunk(cx, cy, context);
  const counts = new Map<number, number>();
  const at: number[] = [0, 0];
  for (let p = 0;p < plan.count;p++) {
    if (plan.wdir[p] === HOME_CHUNK) continue;
    workChunkOf(cx, cy, plan.wdir[p], at, context);
    const key = chunkKey(at[0], at[1]);
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  const flowTo = [...counts.keys()].sort((a, b) => a - b);
  return { flowTo, flowN: flowTo.map((key) => counts.get(key)!) };
};

/** A chunk's survey (ChunkModule.survey, on its host): its residents and their commute flows, without making it. */
export type Survey = { count: number; flowTo: number[]; flowN: number[] };

export const surveyChunk = (cx: number, cy: number, context: PlanningContext): Survey => ({ count: planChunk(cx, cy, context).count, ...commuteFlows(cx, cy, context) });

/** As float64s: count, flows, then each flow's key and its count. */
export const encodeSurvey = ({ count, flowTo, flowN }: Survey) => new Uint8Array(Float64Array.from([count, flowTo.length, ...flowTo, ...flowN]).buffer);

/** A survey's bytes; null for none (a chunk off the map, or a malformed answer). */
export const decodeSurvey = (bytes: Uint8Array): Survey | null => {
  if (bytes.byteLength < 16 || bytes.byteLength % 8) return null;
  const v = new Float64Array(bytes.slice().buffer);
  const n = v[1];
  if (v.length !== 2 + 2 * n) return null;
  return { count: v[0], flowTo: Array.from(v.subarray(2, 2 + n)), flowN: Array.from(v.subarray(2 + n)) };
};
