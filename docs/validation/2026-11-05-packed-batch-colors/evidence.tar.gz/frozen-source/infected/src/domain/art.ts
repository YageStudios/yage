/**
 * The art contract between the world generator and the renderer: everything a chunk's look needs
 * beyond its sim tiles. Produced by `artOf(plan, cx, cy)` (src/worldgen/art.ts, world agent) for
 * atlas spaces and by `fallbackArt` (src/render/chunkart.ts) for the legacy world. Pure data,
 * chunk-local tile coordinates (global − c × CHUNK_TILES), deterministic per chunk.
 */
import type { BiomeId, BuildingUse, RoadClass, Vec, WaterKind } from "../atlas/model";
import type { NativeUnit } from "../worldgen/native-floor";

export type ArtStreet = { cls: RoadClass; a: Vec; b: Vec; width: number; surface: "road" | "trail" | "path" | "park"; sidewalk: number; bridge?: boolean };
export type ArtBridge = { a: Vec; b: Vec; width: number; water: WaterKind; span: number };
export type ArtWater = { kind: WaterKind; poly?: Vec[]; path?: Vec[]; widths?: number[] };
export type ArtBuilding = {
  id: number | string;
  use: BuildingUse;
  style: string;
  /** Culture id (src/domain/architecture.ts CULTURE_IDS). */
  culture: string;
  x0: number;
  y0: number;
  x1: number;
  y1: number;
  rot: number;
  storeys: number;
  /** Door side: 0 N, 1 E, 2 S, 3 W. */
  facing: number;
};
/** `angle` (radians, optional): a free-angle item's exact heading (transit stops on diagonal streets); `rot` stays its nearest quarter turn. */
/**
 * `market`: a weekday 0..6; the item (a market stall) stands only on days whose
 * ((day % 7) + 7) % 7 equals it, through the market's morning (src/render/prefabs.ts).
 */
export type ArtItem = { item: string; x: number; y: number; rot: number; angle?: number; building?: number | string; market?: number; /** What it is called when inspected (a park's statue, gate...). */ label?: string; /** Its length along its own x, tiles, when longer than its footprint (a bridge spanning its water): drawn as a run of its art. */ span?: number };
export type ArtRail = { a: Vec; b: Vec; kind: "main" | "tram" | "siding" };
export type ArtStation = { box: { x0: number; y0: number; x1: number; y1: number }; platforms: { x0: number; y0: number; x1: number; y1: number }[] };

/**
 * Objects mode (docs/OBJECTS.md): roads, rails and buildings off the tile grid. All chunk-local
 * tiles as floats. A road or rail is listed whole in every chunk it crosses, under one id; a
 * prefab in every chunk its rotated footprint touches, with `home` true in exactly one.
 */
/** How a road ends: at a junction, dead, at the plan's edge, or at a tunnel portal (it goes underground there: a ramp down into its mouth). */
export type RoadEnd = "junction" | "dead" | "edge" | "portal";
export type ArtSpan = { from: number; to: number; water: WaterKind };
export type ArtRoad = {
  highway?: boolean;
  divided?: boolean;
  ramp?: boolean;
  oneWay?: boolean;
  level?: number;
  id: string;
  cls: RoadClass;
  points: Vec[];
  /** Carriageway width, tiles. */
  width: number;
  /** Sidewalk per side, tiles; 0 = none. */
  sidewalk: number;
  kerb: boolean;
  surface: "road" | "trail" | "path" | "gravel" | "dirt" | "park";
  markings: "none" | "centre" | "dashed" | "double-yellow";
  lanes?: number;
  /** Bridge spans, distance along the polyline in tiles. */
  bridges?: ArtSpan[];
  ends: [RoadEnd, RoadEnd];
  /** Wholly inside a junction's carriageway (a shallow crossing beside another): asphalt only, no kerb, sidewalk or markings. */
  inner?: boolean;
};
export type ArtJunction = {
  id: string;
  at: Vec;
  roads: string[];
  kind: "cross" | "tee" | "merge";
  poly: Vec[];
  /** Which end of which road meets here (and the plan's cut-back to `poly`, tiles). */
  legs?: { road: string; end: 0 | 1; cut: number; inner?: boolean }[];
  crossings: boolean;
  signals?: boolean;
  /** Park walks meeting: the rounded inner corners (atlas/objects WalkFillet), chunk-local tiles. */
  fillets?: { o: Vec; r: number; a: Vec; b: Vec; c: Vec }[];
};
export type ArtRail2 = { id: string; kind: "main" | "tram" | "siding"; points: Vec[]; tracks?: number; offset?: number; bridges?: ArtSpan[] };
/** A building plan placed at any angle: world = (x, y) + lx·(cos a, sin a) + ly·(−sin a, cos a). */
export type ArtPrefab = {
  /** Measured outline and floor specification carried by geographic listings. */
  native?: NativeUnit;
  id: string;
  /** Plan key, e.g. "apartment/18x13". */
  key: string;
  x: number;
  y: number;
  angle: number;
  scale?: number;
  culture: string;
  style: string;
  use: BuildingUse;
  storeys: number;
  seed: number;
  /** True in the one chunk that owns (and draws) the building. */
  home: boolean;
  /** Where neighbours stand against its walls: [edge, from, to (tiles along the face), their storeys]. */
  party?: [number, number, number, number][];
};

export type ChunkArt = {
  biome: BiomeId;
  climate?: { temp: number; rain: number };
  /** Culture of the chunk's open ground (street furniture, fences); buildings carry their own. */
  culture: string;
  /** Every item is in `items`: skip the renderer's own tile-derived dressing (src/render/dress.ts). */
  dressed?: boolean;
  /** Urban chunk (sealed roads, kerbs, lamps) rather than country. */
  urban: boolean;
  /** One MaterialId per tile (src/domain/materials.ts), 0 = the tile's default look. */
  materials: Uint8Array;
  streets: ArtStreet[];
  bridges: ArtBridge[];
  water: ArtWater[];
  buildings: ArtBuilding[];
  items: ArtItem[];
  rails?: ArtRail[];
  stations?: ArtStation[];
  /** Per-tile street class (src/worldgen/art.ts RoadTile): 0 none, 1 carriageway, 2 sidewalk, 3 kerb edge, 4 trail, 5 apron, 6 crossing. */
  roadTiles?: Uint8Array;
  /** Where streets meet, and how many legs leave each junction. */
  junctions?: { x: number; y: number; legs: number }[];
  /** Objects mode: vector roads, their junction areas, rail lines and placed building plans. */
  roads?: ArtRoad[];
  /** Objects mode: hedges round landscaped parks, chunk-local polylines (worldgen/park-paths.ts). */
  parkEdges?: { points: Vec[] }[];
  /** Objects mode: zebra crossings kerb to kerb (`points`, chunk-local tiles), `width` tiles along the street (worldgen/park-paths.ts). */
  crosswalks?: { points: Vec[]; width: number }[];
  junctionAreas?: ArtJunction[];
  rails2?: ArtRail2[];
  prefabs?: ArtPrefab[];
  /** Objects mode: parks, greens and plazas overlapping the chunk, dressed by src/render/dress.ts. */
  opens?: ArtOpen[];
};

/** An open space: its whole polygon in chunk-local tiles (it may overhang the chunk; neighbours see the same shape). */
export type ArtOpen = {
  id: string;
  kind: "park" | "green" | "plaza" | "cemetery";
  poly: Vec[];
  /** A landscaped park: its walks are planned streets and its furniture plan items (worldgen/park-paths.ts); no path cross. */
  landscaped?: boolean;
  /** Cemetery: its boundary (stone wall, iron railing or hedge) on `ring`, open at the gate (`angle` faces out to the street). */
  wall?: { kind: "stone" | "railing" | "hedge"; ring: Vec[]; gate: { at: Vec; width: number; angle: number } };
  /** Cemetery: its paths' centre lines and widths (tiles): gate path from the kerb, ring path inside the wall, central and cross paths. */
  paths?: { kind: "gate" | "ring" | "central" | "cross"; points: Vec[]; width: number }[];
};
