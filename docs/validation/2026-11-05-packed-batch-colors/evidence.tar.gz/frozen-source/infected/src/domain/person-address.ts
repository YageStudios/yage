export type PersonHome = { cx: number; cy: number; index: number };

/** A terrain source owns both directions; camera movement never allocates identities. */
export type PersonAddresses = {
  id(home: PersonHome): number | null;
  home(gid: number): PersonHome | null;
};

export type PersonAddressContext = {
  space: number;
  source: { personAddresses?: PersonAddresses } | null;
};
