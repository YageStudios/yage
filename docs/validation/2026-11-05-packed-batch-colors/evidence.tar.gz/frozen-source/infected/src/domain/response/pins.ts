/**
 * URL debug pins (ResponseDebugPins, and tests standing a town somewhere): each puts one town's
 * rows, or the region's borders, where the pin says, back-dated as if it had got there on its own.
 * They write only the rows and town state they are handed; the response systems carry on from there.
 */
import type { TownMilitary } from "../../components/response/TownMilitary";
import type { TownUnrest } from "../../components/response/TownUnrest";
import type { GenerationInput } from "../../worldgen/source/owner";
import type { Plan } from "../../worldgen/plan";
import type { WorldMap } from "../../worldmap/places";
import { bordersOf, GateStatus } from "./borders";
import { Cordon, push } from "./collapse";
import type { Series, TownResponse as TownSeries } from "./measures";
import { RESPONSE, type Town, type WorldResponse } from "./towns";
import { TICK_RATE } from "../world";

/** A series' next point, when it moved at least a series step (or back to 0). */
export const appendSeries = (town: TownSeries, key: "aware" | "hospital", value: number, tick: number) => {
  const s = town[key];
  const last = s.length ? s[s.length - 1][0] : 0;
  if (Math.abs(value - last) >= RESPONSE.seriesStep || (value === 0 && last !== 0)) s.push([Math.round(value * 1000) / 1000, tick]);
};

/** Sets a town's hospital load (0 = empty, 1 = full, above = overflowing); whether its series grew. */
export const setHospitalLoad = (series: TownSeries, load: number, tick: number) => {
  const n = series.hospital.length;
  appendSeries(series, "hospital", load, tick);
  return series.hospital.length !== n;
};

/**
 * Puts a town on `level` as if it had climbed there rung by rung, each rung `spacing` ticks apart
 * and the top one reached `ago` ticks before `tick`, and pins it there.
 */
export const forceLadder = (t: Town, series: TownSeries, level: number, tick: number, ago = 600 * TICK_RATE, spacing = 60 * TICK_RATE) => {
  const events = series.events;
  const last = events.length ? events[events.length - 1][1] : -Infinity;
  for (let l = 1; l <= level; l++) events.push([l, Math.max(last + l, tick - ago - (level - l) * spacing)]);
  t.level = level;
  t.changed = tick;
  t.pinned = level ? RESPONSE.levels[level - 1] + RESPONSE.hysteresis : 0;
  t.awareness = Math.max(t.awareness, t.pinned);
};

/** `&care=`: back-dates a town's strain: staff down, tents up, the dead buried, a campaign under way. */
export const forceCare = (
  t: Town,
  shared: TownSeries,
  tick: number,
  opts: { staff?: number; tents?: number; buried?: number; vax?: number }
) => {
  const at = tick - 60 * TICK_RATE;
  const held = (t.care ??= { staff: 1, tents: 0, vax: 0 });
  if (opts.staff !== undefined && Number.isFinite(opts.staff)) held.staff = opts.staff;
  if (opts.tents !== undefined && Number.isFinite(opts.tents)) held.tents = opts.tents;
  if (opts.vax !== undefined && Number.isFinite(opts.vax)) held.vax = opts.vax;
  // After anything already held (series are append-only).
  const after = (s: Series) => (s.length ? s[s.length - 1][1] + 1 : -Infinity);
  if (opts.staff !== undefined && Number.isFinite(opts.staff)) {
    const s = ((shared.staff as Series | undefined) ??= []);
    s.push([opts.staff, Math.max(after(s), at)]);
  }
  if (opts.tents !== undefined && Number.isFinite(opts.tents)) {
    const s = ((shared.tents as Series | undefined) ??= []);
    s.push([opts.tents, Math.max(after(s), at)]);
  }
  if (opts.buried !== undefined && Number.isFinite(opts.buried)) {
    const s = ((shared.buried as Series | undefined) ??= []);
    // Spread over the last few minutes, so some are covered over and some are fresh.
    const from = Math.max(after(s), tick - 240 * TICK_RATE);
    for (let k = 1; k <= 8; k++) s.push([Math.round((opts.buried * k) / 8), Math.round(from + ((tick - from) * k) / 9)]);
  }
  if (opts.vax !== undefined && Number.isFinite(opts.vax)) {
    const s = ((shared.vax as Series | undefined) ??= []);
    s.push([opts.vax, Math.max(after(s), at)]);
  }
};

/**
 * `&unrest=0.8&order=0.2`: back-dates a town's unrest as if it had climbed to `value` over the `ago`
 * ticks before `tick` (so shops are already looted and fires have caught and burnt at their own
 * points on the way), and holds it there; `order` likewise, if given.
 */
export const pinUnrest = (shared: TownSeries, unrest: TownUnrest, value: number, tick: number, order?: number, ago = 600 * TICK_RATE) => {
  const s = (shared.unrest ??= []) as Series;
  const last = s.length ? s[s.length - 1][1] : -Infinity;
  const steps = 20;
  for (let k = 1; k <= steps; k++) {
    const at = Math.max(last + k, tick - ago + Math.round((ago * k) / steps));
    s.push([Math.round(value * (k / steps) * 1000) / 1000, at]);
  }
  if (order !== undefined) ((shared.order ??= []) as Series).push([order, Math.max(last + steps + 1, tick)]);
  unrest.unrest = value;
  unrest.pin = { pinned: true, unrest: value, order: order ?? null };
};

/** `&collapse=fallen|evacuating|walled|firebombed`: puts a town there as of `ago` ticks before `tick` (evacuated to its first link). */
export const forceCollapse = (shared: TownSeries, links: readonly number[], what: string, tick: number, ago = 300 * TICK_RATE) => {
  const at = tick - ago;
  if (!shared.fallen?.length) push(shared, "fallen", 1, at);
  const to = links[0];
  if (what !== "fallen" && to !== undefined && !shared.evac?.length) push(shared, "evac", to, what === "evacuating" ? tick - 30 * TICK_RATE : at);
  if (what === "walled" || what === "firebombed") push(shared, "cordon", Cordon.Walled, at + 1);
  if (what === "firebombed") push(shared, "cordon", Cordon.Firebombed, at + 2);
};

/** `&burn=1`: the town's burn squads out, back-dated, and kept out whatever the dead. */
export const pinBurn = (shared: TownSeries, military: TownMilitary, tick: number) => {
  (shared.burn ??= []).push([1, tick - 200 * TICK_RATE]);
  military.burnPin = true;
};

/** `&borders=screen|closed`: every gate at that status from now, held, with people in its pen. */
export const forceBorders = (r: WorldResponse, map: WorldMap, status: GateStatus, tick: number, plan: Plan | null, owner: GenerationInput) => {
  const b = bordersOf(r, map, plan, owner);
  b.pinned = status;
  b.gate.forEach((s) => {
    s.status.push([status, Math.max(0, tick - 200 * TICK_RATE)]);
    s.changed = tick;
    // Back-dated: some already held in the pen, a few already smuggled past.
    if (status !== GateStatus.Open) s.held = Math.max(s.held, 9);
    if (status === GateStatus.Closed) s.smuggled = Math.max(s.smuggled, 1);
  });
};
