import { critterMemory } from "../sim/host-state";
import type { PlanningContext } from "../worldgen/commute/context";
/**
 * Critters: the rats, birds and livestock of the streets and fields. They are the world's ambient
 * life, so they are always there, and once the strain learns an animal route they carry it.
 *
 * Like the weather, everything here is a pure function: which critters a chunk has comes from its
 * tiles (and, in objects mode, its building footprints), and where each one is comes from game
 * time t (seconds, `clock(tick)`). So the page and the worker (hot or warm) see the same rat in the
 * same alley at the same moment, and a chunk turning hot needs nothing filled in.
 *
 * - Rats keep to alleys: walkable, open-air tiles against a wall (or kerbside paving in objects
 *   mode). They dash between a few nearby holes and lie up between dashes, mostly by day.
 * - Birds go in flocks: pigeons on paving and plazas in towns, crows and sparrows on grass in the
 *   country. A flock settles, pecks about, then lifts off and flies to its next spot; at night it roosts.
 * - Livestock (sheep or cows) graze pasture beside fields, and the open grass of the country: a herd
 *   drifts slowly between spots and each animal ambles round the herd.
 * - Stray dogs run in small packs through town streets: they trot from corner to corner, then
 *   flop down for a while, sleeping out the small hours.
 * - Mosquitoes hang in swarms over standing water (ponds and river banks, and rain puddles on
 *   grass) from dusk to morning. How thick a swarm is comes from the weather there (warmth, wet
 *   ground; none in the cold or snow): `swarmActivity`, a pure function of weatherAt.
 * - Rats below ground (sewers and subway tunnels) are never drawn; they foul station platforms
 *   (src/services/routes.ts platformRats, into the platform pools of src/services/cabin.ts).
 *
 * Counts are soft: they follow how much of each habitat a chunk has, with a little noise, so dense
 * city blocks swarm with rats, plazas have pigeons and only farmland has herds.
 */
import { CONTENT } from "../content/runtime";
import type { CritterNumbers } from "../content/schema/sim";
import { type ObjectsNav, Tile, walkable } from "../worldgen/terrain/index";
import { DAY_SECONDS } from "./time";
import { CHUNK_TILES, hash, SEED, TILE } from "./world";
export const enum CritterKind {
  Rat = 0,
  Bird = 1,
  Sheep = 2,
  Cow = 3,
  Dog = 4,
  Mosquito = 5
}
export const CRITTER_NAMES = ["rat", "bird", "sheep", "cow", "dog", "mosquito"] as const;
/** Owner-tunable numbers (content/critters.json5; counts are per chunk, speeds in px per second). */
export const CRITTERS: CritterNumbers = CONTENT.critters;
export type Critter = {
  id: number;
  kind: CritterKind;
  /** Spots (chunk-local px): a rat's holes, a flock's or herd's resting places. */
  spots: Float32Array;
  /**
   * Per spot, how far (px) a member may stand off it before reaching a wall, a building or water:
   * a flock's pecking ring and a herd's amble are squeezed into this, so nobody stands in a wall.
   */
  room: Float32Array;
  /** Members of a flock or herd share its spots and differ by `member`. */
  group: number;
  member: number;
};
export type CritterPose = {
  x: number;
  y: number;
  /** Heading in radians (0 = east). */
  angle: number;
  moving: boolean;
  /** In the air (birds): touches nobody. */
  flying: boolean;
  /** Lying up in a hole, or roosting: not out at all. */
  hidden: boolean;
};
const unit = (h: number) => h / 4294967296;
const N = CHUNK_TILES;
type Navigation = ObjectsNav | null;
/** Roofed tiles (weather.ts has the same rule): floors and what stands on them. */
const indoor = (t: number) => t === Tile.Floor || (t >= Tile.Bed && t <= Tile.Shelf) || t === Tile.Partition || (t >= Tile.StairsN && t <= Tile.StairsW);
/** Whether a critter may stand at a chunk-local tile: walkable open ground, never in a building. */
const standable = (tiles: Uint8Array, cx: number, cy: number, tx: number, ty: number, nav: Navigation) => {
  if (tx < 0 || ty < 0 || tx >= N || ty >= N)
    return false;
  const t = tiles[ty * N + tx];
  if (!walkable(t) || indoor(t) || t === Tile.Water)
    return false;
  if (nav && (nav.solidAt(cx, cy, tx + 0.5, ty + 0.5) || nav.inBuilding(cx, cy, tx + 0.5, ty + 0.5)))
    return false;
  return true;
};
/** Whether the straight run between two spots (px) stays on standable ground (a few samples). */
const clearRun = (tiles: Uint8Array, cx: number, cy: number, ax: number, ay: number, bx: number, by: number, nav: Navigation) => {
  const steps = Math.max(2, Math.ceil(Math.hypot(bx - ax, by - ay) / (TILE * 1.5)));
  for (let i = 1;i < steps;i++) {
    const k = i / steps;
    if (!standable(tiles, cx, cy, Math.floor((ax + (bx - ax) * k) / TILE), Math.floor((ay + (by - ay) * k) / TILE), nav))
      return false;
  }
  return true;
};
/** Whether the straight walk between two points (chunk-local px) stays on grass: country herds don't wander onto lanes. */
const grassRun = (tiles: Uint8Array, ax: number, ay: number, bx: number, by: number) => {
  const steps = Math.max(2, Math.ceil(Math.hypot(bx - ax, by - ay) / TILE));
  for (let i = 0;i <= steps;i++) {
    const k = i / steps;
    const t = tiles[Math.floor((ay + (by - ay) * k) / TILE) * N + Math.floor((ax + (bx - ax) * k) / TILE)];
    if (t !== Tile.Grass && t !== Tile.DryGrass)
      return false;
  }
  return true;
};
/** Furthest any member strays from its spot (px): a flock's pecking ring, a herd's amble (the widest). */
const ROOM_BIRD = 2.5 * TILE;
const ROOM_MAX = 4 * TILE;
/** Clearance kept between a critter's middle and the nearest blocked ground (px): a bird's half-length, a cow's. */
const ROOM_MARGIN = 4;
const HERD_MARGIN = 10;
/** Whether a point (chunk-local px) is open ground a critter may stand on (the point itself, for footprints off the grid). */
export const openAt = (tiles: Uint8Array, cx: number, cy: number, x: number, y: number, nav: Navigation) => {
  const tx = Math.floor(x / TILE);
  const ty = Math.floor(y / TILE);
  if (tx < 0 || ty < 0 || tx >= N || ty >= N)
    return false;
  const t = tiles[ty * N + tx];
  if (!walkable(t) || indoor(t) || t === Tile.Water)
    return false;
  return !nav || !(nav.solidAt(cx, cy, x / TILE, y / TILE) || nav.inBuilding(cx, cy, x / TILE, y / TILE));
};
/** Quarter-tile sample offsets round a spot out to ROOM_MAX, nearest first (so the first blocked one is the answer). */
const ROOM_STEP = TILE / 4;
const ROOM_SAMPLES = (() => {
  const reach = Math.ceil((ROOM_MAX + HERD_MARGIN + ROOM_STEP) / ROOM_STEP) + 1;
  const out: [
    number,
    number,
    number
  ][] = [];
  for (let j = -reach;j <= reach;j++)
    for (let i = -reach;i <= reach;i++) {
      const d = Math.hypot(i, j) * ROOM_STEP;
      if (d <= (reach - 0.5) * ROOM_STEP)
        out.push([i * ROOM_STEP, j * ROOM_STEP, d]);
    }
  return out.sort((a, b) => a[2] - b[2]);
})();
/** How far (px) round a spot is open, to `max`: to the nearest blocked point on a quarter-tile grid, less a margin. */
export const roomAt = (tiles: Uint8Array, cx: number, cy: number, x: number, y: number, max: number, margin: number, nav: Navigation) => {
  const limit = max + margin + ROOM_STEP;
  for (const [dx, dy, d] of ROOM_SAMPLES) {
    if (d > limit)
      break;
    // A blocked sample stands for the quarter-tile around it.
    if (!openAt(tiles, cx, cy, x + dx, y + dy, nav))
      return Math.max(0, Math.min(max, d - ROOM_STEP / 2 - margin));
  }
  return max;
};
const roomsOf = (tiles: Uint8Array, cx: number, cy: number, spots: readonly number[], max: number, margin: number, nav: Navigation) => {
  const out = new Float32Array(spots.length / 2);
  for (let i = 0;i < out.length;i++)
    out[i] = roomAt(tiles, cx, cy, spots[i * 2], spots[i * 2 + 1], max, margin, nav);
  return out;
};
/** Squeezes an offset (px) into a spot's room, keeping its direction. */
const squeeze = (ox: number, oy: number, room: number) => {
  const d = Math.hypot(ox, oy);
  return d <= room || d === 0 ? { x: ox, y: oy } : { x: (ox * room) / d, y: (oy * room) / d };
};
const CACHE = 2048;
/**
 * The critters living in a chunk (stable for the chunk's tiles). Pure: the same tiles and chunk
 * always give the same critters.
 */
export const crittersOf = (cx: number, cy: number, tiles: Uint8Array, nav: Navigation, context: PlanningContext): Critter[] => {
  const cache = critterMemory(context).chunks;
  const key = `${cx},${cy}`;
  const hit = cache.get(key);
  if (hit && hit.tiles === tiles && hit.nav === nav)
    return hit.critters;
  const critters = nav?.withChunk
    ? nav.withChunk(cx, cy, () => placeCritters(cx, cy, tiles, nav))
    : placeCritters(cx, cy, tiles, nav);
  if (cache.size >= CACHE) {
    const oldest = cache.keys().next().value;
    if (oldest !== undefined)
      cache.delete(oldest);
  }
  cache.set(key, { tiles, nav, critters });
  return critters;
};
/**
 * The ground as critters read it. In objects mode roads, sidewalks and paths are objects over
 * plain ground, so they're stamped back in from the nav (carriageway → Road, sidewalk →
 * Sidewalk, path → Footpath): dogs find the streets, rats the kerbs, herds keep off the lanes.
 */
const groundOf = (cx: number, cy: number, tiles: Uint8Array, nav: Navigation) => {
  if (!nav)
    return tiles;
  const out = tiles.slice();
  for (let ty = 0;ty < N;ty++) {
    for (let tx = 0;tx < N;tx++) {
      const i = ty * N + tx;
      if (!walkable(out[i]) || indoor(out[i]) || out[i] === Tile.Water)
        continue;
      const on = nav.onStreet(cx, cy, tx + 0.5, ty + 0.5);
      if (on)
        out[i] = on === 1 ? Tile.Road : on === 2 ? Tile.Sidewalk : Tile.Footpath;
    }
  }
  return out;
};
const placeCritters = (cx: number, cy: number, raw: Uint8Array, nav: Navigation): Critter[] => {
  const objects = nav !== null;
  const tiles = groundOf(cx, cy, raw, nav);
  // Habitat tiles, gathered once.
  const alleys: number[] = [];
  const paving: number[] = [];
  const grass: number[] = [];
  const streets: number[] = [];
  const banks: number[] = [];
  const BLOCK = 8;
  const B = N / BLOCK;
  const fieldBlock = new Uint8Array(B * B);
  for (let ty = 0;ty < N;ty++) {
    for (let tx = 0;tx < N;tx++) {
      const t = tiles[ty * N + tx];
      if (t === Tile.Soil || t === Tile.Crop)
        fieldBlock[Math.floor(ty / BLOCK) * B + Math.floor(tx / BLOCK)]++;
      if (!walkable(t) || indoor(t) || t === Tile.Water)
        continue;
      const i = ty * N + tx;
      if (t === Tile.Paving || t === Tile.Sidewalk || t === Tile.Bench)
        paving.push(i);
      else if (t === Tile.Grass || t === Tile.DryGrass)
        grass.push(i);
      if (t === Tile.Paving || t === Tile.Sidewalk || t === Tile.Road)
        streets.push(i);
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = tx + dx;
        const ny = ty + dy;
        if (nx >= 0 && ny >= 0 && nx < N && ny < N && tiles[ny * N + nx] === Tile.Water) {
          banks.push(i);
          break;
        }
      }
      // Alleys: against a wall; in objects mode (no walls on the tiles), kerbside paving.
      let wall = false;
      if (!objects) {
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nx = tx + dx;
          const ny = ty + dy;
          if (nx >= 0 && ny >= 0 && nx < N && ny < N && tiles[ny * N + nx] === Tile.Wall)
            wall = true;
        }
      }
      else
        wall = raw[i] === Tile.Sidewalk || raw[i] === Tile.Paving;
      if (wall)
        alleys.push(i);
    }
  }
  const out: Critter[] = [];
  const ok = (i: number) => !nav || standable(tiles, cx, cy, i % N, Math.floor(i / N), nav);
  const pick = (list: number[], salt: number, near?: {
    x: number;
    y: number;
    r: number;
  }) => {
    for (let tries = 0;tries < 12;tries++) {
      const i = list[hash(SEED, cx, cy, salt, tries, 0xc417) % list.length];
      const x = (i % N) + 0.5;
      const y = Math.floor(i / N) + 0.5;
      if (near && Math.hypot(x * TILE - near.x, y * TILE - near.y) > near.r)
        continue;
      if (ok(i))
        return { x: x * TILE, y: y * TILE };
    }
    return null;
  };
  /** A spot with room round it for a flock or herd to spread: the roomiest of a few picks (stops at one with room enough). */
  const roomy = (list: number[], salt: number, max: number, margin: number) => {
    let best: {
      x: number;
      y: number;
      room: number;
    } | null = null;
    for (let k = 0;k < 6;k++) {
      const p = pick(list, salt + k * 7919);
      if (!p)
        continue;
      const room = roomAt(tiles, cx, cy, p.x, p.y, max, margin, nav);
      if (!best || room > best.room)
        best = { ...p, room };
      if (room >= max * 0.6)
        break;
    }
    return best;
  };
  const soft = (expected: number, max: number, salt: number) => Math.min(max, Math.floor(expected + unit(hash(SEED, cx, cy, salt, 0x50f7))));
  // Rats.
  if (alleys.length) {
    const count = soft(alleys.length * CRITTERS.ratsPerAlley, CRITTERS.maxRats, 1);
    for (let r = 0;r < count;r++) {
      const home = pick(alleys, 1000 + r * 13);
      if (!home)
        continue;
      const spots: number[] = [home.x, home.y];
      for (let s = 1;s < 4;s++) {
        const p = pick(alleys, 1000 + r * 13 + s, { x: home.x, y: home.y, r: 9 * TILE });
        if (p && clearRun(tiles, cx, cy, spots[spots.length - 2], spots[spots.length - 1], p.x, p.y, nav))
          spots.push(p.x, p.y);
      }
      out.push({ id: hash(SEED, cx, cy, CritterKind.Rat, r), kind: CritterKind.Rat, spots: new Float32Array(spots), room: new Float32Array(spots.length / 2), group: r, member: 0 });
    }
  }
  // Birds: pigeons where there is paving, otherwise country birds on grass.
  const perch = paving.length > grass.length * 0.15 ? paving : grass;
  if (perch.length) {
    const flocks = soft(perch.length * CRITTERS.flocksPerTile * (perch === paving ? 4 : 1), CRITTERS.maxFlocks, 2);
    for (let f = 0;f < flocks;f++) {
      const spots: number[] = [];
      const rooms: number[] = [];
      for (let s = 0;s < 4;s++) {
        const p = roomy(perch, 2000 + f * 17 + s, ROOM_BIRD, ROOM_MARGIN);
        if (p)
          spots.push(p.x, p.y), rooms.push(p.room);
      }
      if (!spots.length)
        continue;
      const [lo, hi] = CRITTERS.flock;
      const size = lo + (hash(SEED, cx, cy, f, 0xb1d) % (hi - lo + 1));
      const s = new Float32Array(spots);
      const room = new Float32Array(rooms);
      for (let m = 0;m < size;m++)
        out.push({ id: hash(SEED, cx, cy, CritterKind.Bird, f, m), kind: CritterKind.Bird, spots: s, room, group: f, member: m });
    }
  }
  // Livestock: pasture blocks next to fields.
  const pasture: number[] = [];
  for (let by = 0;by < B;by++) {
    for (let bx = 0;bx < B;bx++) {
      if (fieldBlock[by * B + bx] > 6)
        continue;
      let field = false;
      for (let dy = -1;dy <= 1 && !field;dy++)
        for (let dx = -1;dx <= 1 && !field;dx++) {
          const nx = bx + dx;
          const ny = by + dy;
          field = nx >= 0 && ny >= 0 && nx < B && ny < B && fieldBlock[ny * B + nx] > 20;
        }
      if (field)
        pasture.push(by * B + bx);
    }
  }
  if (pasture.length) {
    const herds = soft(pasture.length * CRITTERS.herdsPerBlock, CRITTERS.maxHerds, 3);
    const grassOf = (b: number) => {
      const bx = (b % B) * BLOCK;
      const by = Math.floor(b / B) * BLOCK;
      for (let tries = 0;tries < 10;tries++) {
        const h = hash(SEED, cx, cy, b, tries, 0x9a5);
        const tx = bx + (h % BLOCK);
        const ty = by + ((h >>> 8) % BLOCK);
        const t = tiles[ty * N + tx];
        if ((t === Tile.Grass || t === Tile.DryGrass) && standable(tiles, cx, cy, tx, ty, nav))
          return { x: (tx + 0.5) * TILE, y: (ty + 0.5) * TILE };
      }
      return null;
    };
    for (let g = 0;g < herds;g++) {
      const first = pasture[hash(SEED, cx, cy, g, 0x4e4d) % pasture.length];
      const home = grassOf(first);
      if (!home)
        continue;
      const spots: number[] = [home.x, home.y];
      // A few more resting spots in nearby pasture.
      for (let s = 1;s < 4;s++) {
        const b = pasture[hash(SEED, cx, cy, g, s, 0x4e4e) % pasture.length];
        const p = grassOf(b);
        if (p && Math.hypot(p.x - home.x, p.y - home.y) < 24 * TILE && clearRun(tiles, cx, cy, spots[spots.length - 2], spots[spots.length - 1], p.x, p.y, nav))
          spots.push(p.x, p.y);
      }
      const cows = unit(hash(SEED, cx, cy, g, 0xc0)) < 0.4;
      const [lo, hi] = CRITTERS.herd;
      const size = lo + (hash(SEED, cx, cy, g, 0x5e) % (hi - lo + 1)) - (cows ? 1 : 0);
      const s = new Float32Array(spots);
      const room = roomsOf(tiles, cx, cy, spots, ROOM_MAX, HERD_MARGIN, nav);
      const kind = cows ? CritterKind.Cow : CritterKind.Sheep;
      for (let m = 0;m < size;m++)
        out.push({ id: hash(SEED, cx, cy, kind, g, m), kind, spots: s, room, group: g, member: m });
    }
  }
  // Country herds on open grass (pasture fields are grass too), away from towns.
  if (paving.length < N * N * 0.01) {
    const open: number[] = [];
    for (let by = 0;by < B;by++) {
      for (let bx = 0;bx < B;bx++) {
        let g = 0;
        for (let ty = by * BLOCK;ty < by * BLOCK + BLOCK;ty++)
          for (let tx = bx * BLOCK;tx < bx * BLOCK + BLOCK;tx++) {
            const t = tiles[ty * N + tx];
            if (t === Tile.Grass || t === Tile.DryGrass)
              g++;
          }
        if (g >= BLOCK * BLOCK - 4)
          open.push(by * B + bx);
      }
    }
    const herds = soft(open.length * CRITTERS.meadowHerdsPerBlock, CRITTERS.maxMeadowHerds, 4);
    for (let g = 0;g < herds;g++) {
      const spots: number[] = [];
      for (let s = 0;s < 4;s++) {
        const b = open[hash(SEED, cx, cy, g, s, 0x3ead) % open.length];
        const x = ((b % B) * BLOCK + BLOCK / 2) * TILE;
        const y = (Math.floor(b / B) * BLOCK + BLOCK / 2) * TILE;
        if (!standable(tiles, cx, cy, Math.floor(x / TILE), Math.floor(y / TILE), nav))
          continue;
        if (spots.length && (Math.hypot(x - spots[0], y - spots[1]) > 30 * TILE || !clearRun(tiles, cx, cy, spots[spots.length - 2], spots[spots.length - 1], x, y, nav) || !grassRun(tiles, spots[spots.length - 2], spots[spots.length - 1], x, y)))
          continue;
        spots.push(x, y);
      }
      if (!spots.length)
        continue;
      const group = 16 + g;
      const cows = unit(hash(SEED, cx, cy, group, 0xc0)) < 0.45;
      const [lo, hi] = CRITTERS.herd;
      const size = lo + (hash(SEED, cx, cy, group, 0x5e) % (hi - lo + 1));
      const s = new Float32Array(spots);
      const room = roomsOf(tiles, cx, cy, spots, ROOM_MAX, HERD_MARGIN, nav);
      const kind = cows ? CritterKind.Cow : CritterKind.Sheep;
      for (let m = 0;m < size;m++)
        out.push({ id: hash(SEED, cx, cy, kind, group, m), kind, spots: s, room, group, member: m });
    }
  }
  // Stray dogs: packs on town streets, roaming wide.
  if (streets.length > N * 2) {
    const packs = soft(streets.length * CRITTERS.packsPerStreet, CRITTERS.maxPacks, 5);
    for (let k = 0;k < packs;k++) {
      const home = pick(streets, 5000 + k * 31);
      if (!home)
        continue;
      const spots: number[] = [home.x, home.y];
      for (let s = 1;s < 6 && spots.length < 8;s++) {
        const p = pick(streets, 5000 + k * 31 + s, { x: home.x, y: home.y, r: 40 * TILE });
        if (p && clearRun(tiles, cx, cy, spots[spots.length - 2], spots[spots.length - 1], p.x, p.y, nav))
          spots.push(p.x, p.y);
      }
      const [lo, hi] = CRITTERS.pack;
      const size = lo + (hash(SEED, cx, cy, k, 0xd09) % (hi - lo + 1));
      const s = new Float32Array(spots);
      const room = roomsOf(tiles, cx, cy, spots, 2 * TILE, ROOM_MARGIN, nav);
      for (let m = 0;m < size;m++)
        out.push({ id: hash(SEED, cx, cy, CritterKind.Dog, k, m), kind: CritterKind.Dog, spots: s, room, group: k, member: m });
    }
  }
  // Mosquitoes: swarms over banks (member 0), and over grass where rain leaves puddles (member 1).
  const swarms = (list: number[], per: number, puddle: number, salt: number, room: number) => {
    const n = soft(list.length * per, CRITTERS.maxSwarms, salt);
    for (let k = 0;k < n;k++) {
      const p = pick(list, 7000 + salt * 97 + k * 11);
      if (!p)
        continue;
      const q = pick(list, 7000 + salt * 97 + k * 11 + 5, { x: p.x, y: p.y, r: 6 * TILE });
      const spots = q ? [p.x, p.y, q.x, q.y] : [p.x, p.y];
      out.push({ id: hash(SEED, cx, cy, CritterKind.Mosquito, salt, k), kind: CritterKind.Mosquito, spots: new Float32Array(spots), room: new Float32Array(spots.length / 2).fill(room), group: salt * 100 + k, member: puddle });
    }
  };
  if (banks.length)
    swarms(banks, CRITTERS.swarmsPerBank, 0, 6, TILE);
  if (grass.length)
    swarms(grass, CRITTERS.swarmsPerGrass, 1, 7, TILE);
  return out;
};
// ---------------------------------------------------------------------------------------------
// Where a critter is at time t
const hourOf = (t: number) => ((t % DAY_SECONDS) + DAY_SECONDS) % DAY_SECONDS / (DAY_SECONDS / 24);
const spot = (c: Critter, k: number) => {
  const n = c.spots.length / 2;
  const i = ((k % n) + n) % n;
  return { x: c.spots[i * 2], y: c.spots[i * 2 + 1], room: c.room[i] };
};
/** Where a critter is at game time t (seconds), and what it is doing. */
export const critterAt = (c: Critter, t: number): CritterPose => {
  switch (c.kind) {
    case CritterKind.Rat:
      return ratAt(c, t);
    case CritterKind.Bird:
      return birdAt(c, t);
    case CritterKind.Dog:
      return dogAt(c, t);
    case CritterKind.Mosquito:
      return swarmAt(c, t);
    default:
      return grazerAt(c, t);
  }
};
const ratAt = (c: Critter, t: number): CritterPose => {
  // Cycles of 8–14 s: lie up at a hole, then dash to the next one.
  const period = 8 + (c.id % 7);
  const k = Math.floor((t + (c.id % 97)) / period);
  const u = (t + (c.id % 97)) / period - k;
  const from = spot(c, hash(c.id, k) % 4);
  const to = spot(c, hash(c.id, k + 1) % 4);
  const dist = Math.hypot(to.x - from.x, to.y - from.y);
  const dash = Math.min(0.6, dist / CRITTERS.ratSpeed / period);
  const start = 1 - dash;
  // Out mostly at night: by day most cycles are spent down a hole.
  const h = hourOf(t);
  const night = h < 5 || h > 21 ? 1 : h < 7 || h > 19 ? 0.6 : 0.25;
  const hidden = unit(hash(c.id, k, 0x7a7)) > night;
  if (u < start || dist < 1)
    return { x: from.x, y: from.y, angle: (c.id % 628) / 100, moving: false, flying: false, hidden };
  const f = (u - start) / dash;
  return { x: from.x + (to.x - from.x) * f, y: from.y + (to.y - from.y) * f, angle: Math.atan2(to.y - from.y, to.x - from.x), moving: true, flying: false, hidden };
};
const birdAt = (c: Critter, t: number): CritterPose => {
  // Flock cycles of 40–64 s: settled for most of it, then a short flight to the next spot.
  const period = 40 + (c.group * 7) % 25;
  const offset = (c.group * 13.7) % period;
  const k = Math.floor((t + offset) / period);
  const u = (t + offset) / period - k;
  const from = spot(c, k);
  const to = spot(c, k + 1);
  const h = hourOf(t);
  const hidden = h < 6 || h > 20.5;
  // Each bird keeps its own place in the flock, and hops about it every second or so.
  const ring = 0.6 + unit(hash(c.id, 1)) * 1.4;
  const a0 = unit(hash(c.id, 2)) * Math.PI * 2;
  const hop = Math.floor(t * 0.8 + unit(hash(c.id, 3)) * 5);
  const hx = (unit(hash(c.id, hop)) - 0.5) * TILE * 0.8;
  const hy = (unit(hash(c.id, hop, 1)) - 0.5) * TILE * 0.8;
  const o = squeeze(Math.cos(a0) * ring * TILE + hx, Math.sin(a0) * ring * TILE + hy, from.room);
  const ox = o.x;
  const oy = o.y;
  const dist = Math.hypot(to.x - from.x, to.y - from.y);
  const fly = Math.min(0.35, dist / CRITTERS.birdSpeed / period + 0.03);
  const start = 1 - fly;
  if (u < start || dist < 1) {
    const facing = unit(hash(c.id, hop, 2)) * Math.PI * 2;
    return { x: from.x + ox, y: from.y + oy, angle: facing, moving: false, flying: false, hidden };
  }
  const f = (u - start) / fly;
  const e = f * f * (3 - 2 * f);
  // Spread wider in the air, landing into the next spot's room.
  const land = squeeze(Math.cos(a0) * ring * TILE + hx, Math.sin(a0) * ring * TILE + hy, to.room);
  const air = Math.sin(Math.PI * f) * 0.6;
  const fx = (ox + (land.x - ox) * e) * (1 + air);
  const fy = (oy + (land.y - oy) * e) * (1 + air);
  return { x: from.x + (to.x - from.x) * e + fx, y: from.y + (to.y - from.y) * e + fy, angle: Math.atan2(to.y - from.y, to.x - from.x), moving: true, flying: true, hidden };
};
const grazerAt = (c: Critter, t: number): CritterPose => {
  // The herd moves between its spots every few minutes, at a walk.
  const period = 200 + (c.group * 37) % 120;
  const k = Math.floor(t / period);
  const u = t / period - k;
  const from = spot(c, k);
  const to = spot(c, k + 1);
  const dist = Math.hypot(to.x - from.x, to.y - from.y);
  const walk = Math.min(0.8, dist / CRITTERS.grazeSpeed / period);
  const start = 1 - walk;
  const f = u < start ? 0 : (u - start) / walk;
  const hx = from.x + (to.x - from.x) * f;
  const hy = from.y + (to.y - from.y) * f;
  // Each animal ambles to a new place round the herd every 15–30 s.
  const step = 15 + (c.id % 16);
  const j = Math.floor((t + (c.id % 31)) / step);
  const v = (t + (c.id % 31)) / step - j;
  const place = (n: number) => {
    const r = (1 + unit(hash(c.id, n)) * 2.6) * TILE;
    const a = unit(hash(c.id, n, 1)) * Math.PI * 2;
    return { x: Math.cos(a) * r, y: Math.sin(a) * r };
  };
  const p0 = place(j);
  const p1 = place(j + 1);
  const amble = Math.min(1, Math.max(0, (v - 0.7) / 0.3));
  // Round the herd's spot, or (walking) whichever of its two spots is tighter.
  const room = f <= 0 ? from.room : f >= 1 ? to.room : Math.min(from.room, to.room);
  const o = squeeze(p0.x + (p1.x - p0.x) * amble, p0.y + (p1.y - p0.y) * amble, room);
  const ox = o.x;
  const oy = o.y;
  const herdMoving = u >= start && dist > 1;
  const moving = herdMoving || (amble > 0 && amble < 1);
  const angle = herdMoving ? Math.atan2(to.y - from.y, to.x - from.x) : moving ? Math.atan2(p1.y - p0.y, p1.x - p0.x) : unit(hash(c.id, j, 3)) < 0.5 ? 0 : Math.PI;
  return { x: hx + ox, y: hy + oy, angle, moving, flying: false, hidden: false };
};
const dogAt = (c: Critter, t: number): CritterPose => {
  // The pack trots corner to corner (cycles of 50–90 s), lying about for most of each cycle; it
  // sleeps out the small hours. Each dog keeps its own place round the leader.
  const period = 50 + ((c.group * 23) % 41);
  const offset = (c.group * 17.3) % period;
  const k = Math.floor((t + offset) / period);
  const u = (t + offset) / period - k;
  const n = c.spots.length / 2;
  // The pack's own seed (its members share spots): its group and home spot.
  const pack = hash(c.group, Math.floor(c.spots[0]), Math.floor(c.spots[1]));
  const from = spot(c, hash(pack, k, 0xd0) % n);
  const to = spot(c, hash(pack, k + 1, 0xd0) % n);
  const h = hourOf(t);
  const asleep = h > 1 && h < 5;
  const dist = asleep ? 0 : Math.hypot(to.x - from.x, to.y - from.y);
  const trot = Math.min(0.7, dist / CRITTERS.dogSpeed / period);
  const start = 1 - trot;
  const a = c.member * 2.1 + unit(hash(pack, 0xd1)) * 6;
  const r = c.member === 0 ? 0 : (0.7 + 0.4 * c.member) * TILE;
  if (u < start || dist < 1) {
    // Lying about: a little apart round the spot.
    const o = squeeze(Math.cos(a) * r * 1.3, Math.sin(a) * r * 1.3, from.room);
    return { x: from.x + o.x, y: from.y + o.y, angle: unit(hash(c.id, k, 0xd2)) * Math.PI * 2, moving: false, flying: false, hidden: false };
  }
  const f = (u - start) / trot;
  const heading = Math.atan2(to.y - from.y, to.x - from.x);
  // On the move, in a loose file behind the leader.
  const back = c.member * 1.1 * TILE;
  const side = (c.member % 2 ? 1 : -1) * 0.4 * TILE * (c.member > 0 ? 1 : 0);
  const along = Math.max(0, f * dist - back);
  return {
    x: from.x + Math.cos(heading) * along - Math.sin(heading) * side,
    y: from.y + Math.sin(heading) * along + Math.cos(heading) * side,
    angle: heading,
    moving: true,
    flying: false,
    hidden: false,
  };
};
const swarmAt = (c: Critter, t: number): CritterPose => {
  // Out from dusk till mid-morning; the swarm drifts slowly between its spots, bobbing.
  const h = hourOf(t);
  const hidden = h >= 9.5 && h < 17.5;
  const period = 30 + (c.id % 20);
  const k = Math.floor(t / period);
  const u = t / period - k;
  const from = spot(c, k);
  const to = spot(c, k + 1);
  const e = u * u * (3 - 2 * u);
  const bob = Math.sin(t * 1.3 + (c.id % 11)) * 0.3 * TILE;
  return { x: from.x + (to.x - from.x) * e, y: from.y + (to.y - from.y) * e + bob, angle: 0, moving: true, flying: false, hidden };
};
/**
 * How thick a mosquito swarm is (0–1) in the weather there: warm and wet, thickest in a heat wave
 * after rain; none in the cold, snow or a gale. Puddle swarms (member 1) need wet ground; bank
 * swarms always have their water.
 */
export const swarmActivity = (c: Pick<Critter, "member">, w: {
  temperature: number;
  wetness: number;
  heat: number;
  snowCover: number;
  wind: number;
}) => {
  const warm = Math.max(0, Math.min(1, (w.temperature - 10) / 12));
  if (warm <= 0 || w.snowCover > 0.3)
    return 0;
  const wet = c.member === 1 ? Math.min(1, w.wetness * 1.5) : 0.55 + 0.45 * w.wetness;
  return Math.min(1, warm * wet * (1 + 0.5 * w.heat) * (1 - 0.7 * w.wind));
};
// ---------------------------------------------------------------------------------------------
// Sickness
/** The trait level that makes a kind a carrier (0 = not one). */
export const routeLevel = (kind: CritterKind, traits: {
  rodent: number;
  bird: number;
  livestock: number;
  dog?: number;
  mosquito?: number;
}) => kind === CritterKind.Rat
    ? traits.rodent
    : kind === CritterKind.Bird
      ? traits.bird
      : kind === CritterKind.Dog
        ? (traits.dog ?? 0)
        : kind === CritterKind.Mosquito
          ? (traits.mosquito ?? 0)
          : traits.livestock;
/**
 * Whether a critter carries the strain on game day `day`: a share of its kind, as large as the
 * town's animal reservoir (`fauna`, 0–1) times the strain's level for that kind. Re-rolled daily.
 */
export const critterSick = (c: Critter, fauna: number, level: number, day: number) => level > 0 && fauna > 0 && unit(hash(c.id, day, 0x51c)) < Math.min(1, fauna * level);

/** The kinds that turn feral (the beasts trait): strays and birds (crows) go for the living; the rest only carry it. */
export const FERAL_KINDS: ReadonlySet<CritterKind> = new Set([CritterKind.Dog, CritterKind.Bird]);

/**
 * Whether a critter has turned feral on game day `day` (the beasts trait at `beasts`): a share of
 * the strays and birds as large as the town's animal reservoir (`fauna`, 0–1) times the trait,
 * drawn apart from critterSick's. Re-rolled daily; never the livestock, rats or swarms.
 */
export const critterTurned = (c: Critter, fauna: number, beasts: number, day: number) =>
  beasts > 0 && fauna > 0 && FERAL_KINDS.has(c.kind) && unit(hash(c.id, day, 0xbea5)) < Math.min(1, fauna * beasts);
