/** The mechanical decay-stage contract carried in infected snapshot tints. */
import { CONTENT } from "../../content/runtime";
import { setOf } from "./sprites";

/**
 * Bloomed hosts are dying, in four stages: 0 fresh, 1 waning, 2 failing, 3 dying (pulse). For
 * pawns whose sprite is in the Infected set (setOf(sprite) === SpriteSet.Infected, i.e. sprite
 * 100–149, and the super mutants' rows past the sets), the tint's skin field (bits 6–7) carries the stage instead of a skin tone; clothes
 * (bits 0–2) and hair (bits 3–5) are unchanged. Every other sprite set keeps the plain tint.
 */
export const DECAY_STAGES = 4;
/** Suggested glow colours per stage: green, yellow, orange, red. */
export const DECAY_COLOURS = CONTENT.looks.pawn.decayColours;

/** A bloomed host's tint with its decay stage in the skin bits (never the empty-slot 255). */
export const withDecay = (tint: number, stage: number) => {
  const packed = (tint & 63) | (Math.min(DECAY_STAGES - 1, Math.max(0, stage)) << 6);
  // Flak (clothes 7) + white hair (7) + stage 3 would be 255, the engine's empty slot: grey hair.
  return packed === 255 ? 247 : packed;
};

/** A pawn's decay stage from its snapshot sprite and tint, or -1 if it isn't a bloomed host. */
export const decayOf = (sprite: number, tint: number) => (setOf(sprite) === 2 /* SpriteSet.Infected; super mutants too */ ? tint >> 6 : -1);
