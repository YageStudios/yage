/**
 * What a cold chunk is made warm with (ChunkPool.generate's init bytes): its cell's counts at the
 * tick it joins, the people it knows by name (overrides), its residents who are somewhere else
 * as people now (excluded: they are not spawned again) and the cast in its counts (pinned: each
 * keeps the state and stage their record has, out of the counts, domain/cold/cast.ts). The chunk host's materialize
 * (services/cold/materialize.ts) makes the chunk's people from it; absorb (services/cold/absorb.ts)
 * makes a cell of a chunk's people again, so the two round-trip.
 */
import type { Cold } from "./step";
import { STAGES } from "./step";

const VERSION = 2;

export type ColdInit = {
  tick: number;
  /** The strain's mean incubation and lifespan as of `tick`, so the stages' timers are the run's. */
  incubation: number;
  lifespan: number;
  s: number;
  e: number[];
  i: number[];
  d: number;
  /** gid, state, timer triples. */
  overrides: number[];
  /** gids, ascending. */
  exclude: number[];
  /** gid, state, stage triples: cast residents in the counts, by gid. */
  pins: number[];
};

export const encodeColdInit = (cell: Pick<Cold, "s" | "e" | "i" | "d" | "overrides">, exclude: readonly number[], tick: number, incubation: number, lifespan: number, pins: readonly number[] = []): Uint8Array => {
  const values = [VERSION, tick, incubation, lifespan, cell.s, ...cell.e, ...cell.i, cell.d, cell.overrides.length / 3, ...cell.overrides, exclude.length, ...[...exclude].sort((a, b) => a - b), pins.length / 3, ...pins];
  return new Uint8Array(Float64Array.from(values).buffer);
};

export const decodeColdInit = (bytes: Uint8Array): ColdInit => {
  const values = new Float64Array(bytes.slice().buffer);
  if (values[0] !== VERSION) throw new Error(`cold init: version ${values[0]} isn't ${VERSION}`);
  let at = 4;
  const take = (n: number) => Array.from(values.subarray(at, (at += n)));
  const s = values[at++];
  const e = take(STAGES);
  const i = take(STAGES);
  const d = values[at++];
  const overrides = take(values[at++] * 3);
  const exclude = take(values[at++]);
  const pins = take(values[at++] * 3);
  return { tick: values[1], incubation: values[2], lifespan: values[3], s, e, i, d, overrides, exclude, pins };
};

/** A stage's timer, its middle: what's left of `total` for someone in stage `k` of STAGES. */
export const stageTimer = (k: number, total: number) => Math.fround(total * (1 - (k + 0.5) / STAGES));

/** The stage someone with `timer` of `total` left is in. */
export const stageOf = (timer: number, total: number) => Math.max(0, Math.min(STAGES - 1, Math.floor((1 - timer / total) * STAGES)));
