/**
 * Building events: what a building nobody can see into shows and sounds of the people on its roster
 * when the player's view is near (BuildingEventsSystem, hot chunks only), without unpacking it.
 * Someone at a window, a shriek inside, a fight (noise, the building shaking), someone bursting out
 * of the door (fleeing, or bloomed), the lights flicking. The worker decides them from the roster's
 * state; they ride the overlay to the page (Overlay.buildings), which draws and sounds them from the
 * one table below (BuildingEventsView). Placeholder art and sound: the table is where real art goes.
 * The same on every thread.
 */

export const enum BuildingEvent {
  /** Someone at a window: a lit pane with a figure in it. */
  Window = 1,
  /** The lights flick: a pane blinking. */
  Lights = 2,
  /** A shriek or scream from inside. */
  Shriek = 3,
  /** A fight: noise, and the building shaking (moved rigidly, never skewed). */
  Fight = 4,
  /** Someone bursts out of the door, fleeing (they are in the street now). */
  BurstFlee = 5,
  /** A bloomed host bursts out of the door. */
  BurstInfected = 6,
}

/** One event: its kind, where (chunk-relative world px, as the overlay's emits) and a byte of detail (a fight's strength, a window's pane). */
export type BuildingMoment = { kind: BuildingEvent; x: number; y: number; arg: number };

/** The page's sounds for building events (components/audio/SoundMoment, domain/sound-mix). */
export type BuildingSound = "shriek" | "brawl" | "door";

/**
 * How each kind is drawn and heard, page side. `shape`: a pane (a lit rectangle, `w`×`h` px, a
 * figure in it when `figure`), a ring (grows to `r` px), a shake (the building moved up to `r` px
 * side to side, rigidly) or a flash (at the door, `r` px). `ms`: how long it shows; `blink`: on/off
 * flicks over that time. `colour`: 0xRRGGBB. `sound`: what it sounds like, if anything.
 */
export type BuildingArt = {
  shape: "pane" | "ring" | "shake" | "flash";
  colour: number;
  ms: number;
  w?: number;
  h?: number;
  r?: number;
  figure?: boolean;
  blink?: number;
  sound?: BuildingSound;
};

export const BUILDING_ART: Record<BuildingEvent, BuildingArt> = {
  [BuildingEvent.Window]: { shape: "pane", colour: 0xffe2a0, ms: 2600, w: 9, h: 11, figure: true },
  [BuildingEvent.Lights]: { shape: "pane", colour: 0xfff4d0, ms: 1400, w: 9, h: 11, blink: 5 },
  [BuildingEvent.Shriek]: { shape: "ring", colour: 0xff5a4a, ms: 900, r: 26, sound: "shriek" },
  [BuildingEvent.Fight]: { shape: "shake", colour: 0xffffff, ms: 1200, r: 1.6, sound: "brawl" },
  [BuildingEvent.BurstFlee]: { shape: "flash", colour: 0xfff0c0, ms: 500, r: 10, sound: "door" },
  [BuildingEvent.BurstInfected]: { shape: "flash", colour: 0xc04040, ms: 600, r: 12, sound: "door" },
};

/** Most events a chunk holds for its next overlay (oldest dropped). */
export const MAX_BUILDING_EVENTS = 48;
