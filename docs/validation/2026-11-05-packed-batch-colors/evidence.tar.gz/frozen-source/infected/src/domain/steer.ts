import { magnetSteer } from "yage/physics/magnet";
import { TILE } from "./world";

/** The host's body radius in the hot world (entities/npc.json5). */
export const HOST_RADIUS = 3.2;
/** How far ahead (world units) the steered host looks for the open way. */
export const STEER_LOOK = TILE * 2.5;

/** A ball's share (0…1) of a move it makes straight before a wall (yage lean castBall, in some walls). */
export type WallCast = (x: number, y: number, radius: number, dx: number, dy: number) => number;

/**
 * The way the steered host at (x, y) walks for the keys' way (dx, dy, not both 0): bent toward the
 * open way by the walls `cast` meets (yage magnetSteer), so it walks a turned hallway along its axis
 * and turns in at a door off a diagonal. The sim (HostSteerSystem) and the page walking it
 * (HostBody) bend alike over the hot world's walls. The cast ball is a little smaller than the
 * body, so a host already against a wall still sees the way along it.
 */
export const steerWay = (dx: number, dy: number, x: number, y: number, cast: WallCast) =>
  magnetSteer(dx, dy, (ux, uy) => cast(x, y, HOST_RADIUS * 0.9, ux * STEER_LOOK, uy * STEER_LOOK));
