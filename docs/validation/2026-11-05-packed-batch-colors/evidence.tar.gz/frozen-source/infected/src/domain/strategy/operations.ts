import type { Point, RtsUnit } from "../rts/orders";
import type { WorldMap } from "../../worldmap/places";
import { State } from "../disease";
import { CHUNK_SIZE } from "../world";
export const OBJECTIVES = ["advance", "spread", "secure", "withdraw"] as const;
export type Objective = typeof OBJECTIVES[number];
export type OperationStatus = "active" | "holding" | "blocked" | "complete" | "cancelled" | "lost";
export type OperationTask = { horde: number; members: number[]; route: Point[]; leg: number; sent: boolean; status: OperationStatus; reason: string; phase?: "securing"; sweep?: number };
export type Operation = { id: number; objective: Objective; place: number; name: string; at: Point; created: number; updated: number; tasks: OperationTask[]; status: OperationStatus };
export type OperationEvent = Point & { id: number; tick: number; operation: number; text: string };
export type StrategyAction = { kind: "strategyOrder"; hordes: number[]; objective: Objective; place: number } | { kind: "strategyCancel"; operation: number };
export const STRATEGY_LIMITS = { active: 32, retained: 128, events: 256, route: 2048 } as const;
export const invalidStrategyAction = (a: StrategyAction): string => {
  if (a.kind === "strategyCancel") return Number.isSafeInteger(a.operation) && a.operation > 0 ? "" : "Not an operation";
  if (!OBJECTIVES.includes(a.objective) || !Number.isInteger(a.place) || a.place < 0) return "Choose a town and objective";
  return Array.isArray(a.hordes) && a.hordes.length > 0 && a.hordes.length <= 64 && a.hordes.every((id) => Number.isSafeInteger(id) && id > 0) ? "" : "Select a persistent horde first";
};
export const forceCentre = (units: readonly RtsUnit[]): Point | null => {
  const live = units.filter((u) => u.state === State.Infected);
  return live.length ? { x: live.reduce((n, u) => n + u.x, 0) / live.length, y: live.reduce((n, u) => n + u.y, 0) / live.length } : null;
};
const distance = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y);
/** Dijkstra over the map's actual regional roads, retaining their geometry. Never invent a sea crossing. */
export const regionalRoute = (map: WorldMap, from: Point, destination: number, townCosts?: readonly number[]): Point[] | null => {
  if (!map.places[destination] || !map.places.length) return null;
  let start = 0;
  for (let i = 1; i < map.places.length; i++) if (distance(from, map.places[i]) < distance(from, map.places[start])) start = i;
  if (start === destination) return physicalRoute(from, [map.places[destination]]);
  const costs = map.places.map(() => Infinity), previous = new Map<number, { town: number; link: number }>(), visited = new Set<number>();
  costs[start] = 0;
  for (let n = 0; n < map.places.length; n++) {
    let town = -1;
    for (let i = 0; i < costs.length; i++) if (!visited.has(i) && Number.isFinite(costs[i]) && (town < 0 || costs[i] < costs[town])) town = i;
    if (town < 0) return null;
    if (town === destination) break;
    visited.add(town);
    map.links.forEach((link, index) => {
      const next = link.from === town ? link.to : link.to === town ? link.from : -1;
      if (next < 0 || visited.has(next) || link.path.length < 2) return;
      const length = link.path.slice(1).reduce((sum, p, i) => sum + distance(link.path[i], p), 0);
      const weight = townCosts?.[next] ?? 1;
      const cost = costs[town] + Math.max(1, length) * (Number.isFinite(weight) ? Math.max(1, weight) : 1);
      if (cost < costs[next]) { costs[next] = cost; previous.set(next, { town, link: index }); }
    });
  }
  if (!previous.has(destination)) return null;
  const legs: Point[][] = [];
  for (let at = destination; at !== start;) {
    const p = previous.get(at); if (!p) return null;
    const link = map.links[p.link];
    const path = link.from === p.town ? link.path : [...link.path].reverse();
    legs.unshift(path); at = p.town;
  }
  const result: Point[] = [];
  for (const p of legs.flat()) if (!result.length || distance(result[result.length - 1], p) > 8) result.push({ x: p.x, y: p.y });
  const end = map.places[destination];
  if (!result.length || distance(result[result.length - 1], end) > 8) result.push({ x: end.x, y: end.y });
  return physicalRoute(from, result);
};
/** Intermediate physical destinations keep even long approaches inside local navigation's horizon. */
const physicalRoute = (from: Point, points: readonly Point[]): Point[] | null => {
  const route: Point[] = []; let last = from;
  for (const p of points) {
    const count = Math.max(1, Math.ceil(distance(last, p) / (CHUNK_SIZE / 2)));
    for (let i = 1; i <= count; i++) route.push({ x: last.x + (p.x - last.x) * i / count, y: last.y + (p.y - last.y) * i / count });
    last = p;
    if (route.length > STRATEGY_LIMITS.route) return null;
  }
  return route;
};
