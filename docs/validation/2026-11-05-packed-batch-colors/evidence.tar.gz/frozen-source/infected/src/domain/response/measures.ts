import type { SiegeSnapshot } from "../siege/types";
import type { WorkerRtsOrder } from "../rts/orders";
import type { PlanningContext } from "../../worldgen/commute/context";
import { unrestOf } from "./unrest";
import { collapseOf } from "./collapse";
import { workerMeasures } from "../../sim/host-state";
/**
 * The world response as every chunk sees it: each town's quarantine ladder as an append-only list
 * of (level, sinceTick) events, and what the ladder means at any tick. Everything here is a pure
 * function of the events, the tick and a person's gid, so hot and warm chunks agree, and a chunk
 * loaded late (or turning hot after a gap) needs nothing replayed.
 *
 * The page decides the events (towns.ts) and sends them to the chunk hosts with the traits
 * (`encodeConfig`); workers look a chunk's town up on the world map.
 *
 * Ladder: 0 nothing, 1 masks, 2 closures (schools and shops), 3 curfew (streets empty at night) and
 * contact tracing, 4 lockdown (stay home), 5 checkpoints at the town's edge and transit cut.
 */
import { CONTENT } from "../../content/runtime";
import { hashUnit } from "../load/streams";
import { timeOfDay } from "../time";
import { TICK_RATE } from "../world";
import { worldMapOf, placeAt } from "../../worldmap/places";
import type { WorkerDirective } from "../directive";

export enum Level {
  None = 0,
  Masks = 1,
  Closures = 2,
  Curfew = 3,
  Lockdown = 4,
  Checkpoints = 5,
}

/** One step of a town's ladder: the level it moved to and the tick it did. */
export type TownEvent = [level: number, at: number];

/** A value that steps at ticks: [value, fromTick] in tick order. */
export type Series = [value: number, at: number][];

/**
 * One town as every chunk host sees it: its ladder events, and its awareness and hospital load as
 * step series. All append-only. Other systems may add their own series (unrest…).
 */
export { TownResponseSeries as TownResponse } from "../../components/response/TownResponseSeries";
export { ResponseState } from "../../components/response/ResponseState";
import type { TownResponseSeries as TownResponse } from "../../components/response/TownResponseSeries";
import type { ResponseState } from "../../components/response/ResponseState";
import type { LabRoster } from "../../simlab/protocol";

export const emptyTown = (): TownResponse => ({
  events: [],
  aware: [],
  hospital: [],
});

/** Owner-tunable response numbers (the cure race's are in towns.ts); data in content/response.json5. */
const { curfewFromHour, curfewToHour, ...measures } = CONTENT.response.measures;
export const MEASURES = {
  ...measures,
  curfewFrom: curfewFromHour / 24,
  curfewTo: curfewToHour / 24,
};

/** The level a town stands at at `tick`, and since when (−Infinity at level 0 from the start). */
export const levelAt = (
  events: readonly TownEvent[] | undefined,
  tick: number
): { level: number; since: number } => {
  let level = 0;
  let since = -Infinity;
  if (events)
    for (const [l, at] of events) {
      if (at > tick) break;
      level = l;
      since = at;
    }
  return { level, since };
};

/** When a town first reached `level` in its current run at or above it (null if it's below now). */
export const reachedAt = (
  events: readonly TownEvent[] | undefined,
  level: number,
  tick: number
): number | null => {
  let at: number | null = null;
  if (events)
    for (const [l, t] of events) {
      if (t > tick) break;
      if (l >= level) at ??= t;
      else at = null;
    }
  return at;
};

/** 0 → 1 as a measure takes hold `seconds` after it started. */
const ramp = (seconds: number, tau: number) =>
  seconds <= 0 ? 0 : 1 - Math.exp(-seconds / tau);

/** The share of a town in masks at `tick`: gradual, so a crowd fills with masks over minutes. */
export const maskUptake = (
  events: readonly TownEvent[] | undefined,
  tick: number
) => {
  const at = reachedAt(events, Level.Masks, tick);
  return at === null
    ? 0
    : MEASURES.maskCap * ramp((tick - at) / TICK_RATE, MEASURES.maskRamp);
};

/** Whether this person wears a mask: everyone has their own threshold, so uptake spreads person by person. */
export const masked = (gid: number, uptake: number) =>
  uptake > 0 && hashUnit(gid, 0x6d61736b, 1) < uptake;

/** How far a measure at `level` has taken hold at `tick` (0 off, → 1). */
export const compliance = (
  events: readonly TownEvent[] | undefined,
  level: number,
  tick: number
) => {
  const at = reachedAt(events, level, tick);
  return at === null ? 0 : ramp((tick - at) / TICK_RATE, MEASURES.complyRamp);
};

/** Whether it's curfew hours at `tick`. */
export const curfewHours = (tick: number) => {
  const t = timeOfDay(tick);
  return t >= MEASURES.curfewFrom || t < MEASURES.curfewTo;
};

/** What a town's ladder means at a tick: each 0–1 (how far it has taken hold). */
export type Measures = {
  level: number;
  masks: number;
  /** Schools and shops shut. */
  closed: number;
  /** Off the streets: curfew at night (0 by day), lockdown always. */
  curfew: number;
  lockdown: number;
  /** Checkpoints at the town's edge, transit cut. */
  checkpoints: number;
};

export const NO_MEASURES: Measures = {
  level: 0,
  masks: 0,
  closed: 0,
  curfew: 0,
  lockdown: 0,
  checkpoints: 0,
};

export const measuresOf = (
  events: readonly TownEvent[] | undefined,
  tick: number
): Measures => {
  if (!events?.length) return NO_MEASURES;
  const { level } = levelAt(events, tick);
  if (level === 0) return NO_MEASURES;
  return {
    level,
    masks: maskUptake(events, tick),
    closed: compliance(events, Level.Closures, tick),
    curfew: curfewHours(tick) ? compliance(events, Level.Curfew, tick) : 0,
    lockdown: compliance(events, Level.Lockdown, tick),
    checkpoints: compliance(events, Level.Checkpoints, tick),
  };
};

// ---------------------------------------------------------------------------------------------
// Hospitals: testing, contact tracing, isolation wards, home care

/** Owner-tunable hospital numbers; data in content/response.json5. */
export const HOSPITAL = CONTENT.response.hospital;

export enum Isolation {
  None = 0,
  /** In a hospital bed: out of circulation. */
  Ward = 1,
  /** Found, but no bed: cared for at home. */
  Home = 2,
}

/** The share of a town's visibly sick (`infected`) and incubating that testing and tracing have found at `tick`. */
export const foundShare = (
  events: readonly TownEvent[] | undefined,
  tick: number,
  evasion: number
) => {
  if (!events?.length) return { infected: 0, incubating: 0 };
  let infected = 0;
  HOSPITAL.testing.forEach(
    (share, k) => (infected += share * compliance(events, k + 1, tick))
  );
  const miss = 1 - Math.min(1, Math.max(0, evasion));
  return {
    infected: infected * miss,
    incubating:
      HOSPITAL.tracing * compliance(events, Level.Curfew, tick) * miss,
  };
};

/**
 * Whether a carrier is isolated, and where: everyone has their own thresholds, so as testing spreads
 * the same people stay found. Beds go by another threshold against the town's load (soft capacity).
 */
export const isolationOf = (
  gid: number,
  infected: boolean,
  town: TownResponse | undefined,
  tick: number,
  evasion: number,
  severity = 0
): Isolation => {
  if (!town) return Isolation.None;
  const found = foundShare(town.events, tick, evasion);
  const share = infected ? found.infected : found.incubating;
  if (share <= 0 || hashUnit(gid, 0x74657374, 2) >= share)
    return Isolation.None;
  const load = valueAt(town.hospital, tick);
  // Triage: an overflowing ward sends the dying home.
  if (
    infected &&
    load > HOSPITAL.triageFrom &&
    severity > HOSPITAL.triageSeverity
  )
    return Isolation.Home;
  return hashUnit(gid, 0x62656473, 3) < 1 / Math.max(1, load)
    ? Isolation.Ward
    : Isolation.Home;
};

/** A chunk's carrier's isolation (none in the countryside). */
export const isolationAt = (
  cx: number,
  cy: number,
  gid: number,
  infected: boolean,
  tick: number,
  evasion: number,
  context: PlanningContext
) => {
  const town = townOf(cx, cy, context);
  return town < 0
    ? Isolation.None
    : isolationOf(
        gid,
        infected,
        workerMeasures(context).state.towns[town],
        tick,
        evasion
      );
};

/** The page's expected hospital load for a town (patients over beds) from its counts. */
export const expectedLoad = (
  events: readonly TownEvent[] | undefined,
  tick: number,
  evasion: number,
  c: { people: number; infected: number; incubating: number }
) => {
  const found = foundShare(events, tick, evasion);
  const patients =
    c.infected * found.infected + c.incubating * found.incubating;
  return patients / Math.max(1, c.people * HOSPITAL.beds);
};

// ---------------------------------------------------------------------------------------------
// The state chunk hosts hold


/** Appends the entries of `next` that come after everything in `held`. */
export const mergeEvents = <T extends [number, number]>(
  held: readonly T[] | undefined,
  next: readonly T[] | undefined
): T[] => {
  const out = held ? held.slice() : [];
  const last = out.length ? out[out.length - 1][1] : -Infinity;
  for (const e of next ?? []) if (e[1] > last) out.push([e[0], e[1]] as T);
  return out;
};

export const mergeTown = (
  held: TownResponse | undefined,
  next: TownResponse
): TownResponse => {
  const out: TownResponse = emptyTown();
  for (const key of new Set([...Object.keys(held ?? {}), ...Object.keys(next)]))
    out[key] = mergeEvents(held?.[key], next[key]);
  return out;
};

/** A step series' value at `tick` (`fallback` before its first entry). */
export const valueAt = (
  series: readonly [number, number][] | undefined,
  tick: number,
  fallback = 0
) => {
  let v = fallback;
  if (series)
    for (const [value, at] of series) {
      if (at > tick) break;
      v = value;
    }
  return v;
};

export const responseState = (context: PlanningContext) => workerMeasures(context).state;

/** The context's world map, built on first lookup (workers have no other copy). */
export const theMap = (context: PlanningContext) => {
  const held = workerMeasures(context);
  return (held.map ??= worldMapOf(context));
};

/** The map place a chunk belongs to, or −1 (countryside). */
export const townOf = (cx: number, cy: number, context: PlanningContext) => placeAt(theMap(context), cx, cy);

/**
 * How far order has broken down in a town at a tick (0…1; unrest.ts sets it, else 0): the
 * enforced measures (closures, curfew, lockdown, checkpoints) hold only by (1 − defiance). Masks
 * are people's own choice and stay. Must be pure in (town, tick) and read only the shared series.
 */

export const defianceAt = (town: number, tick: number, context: PlanningContext) =>
  unrestOf(workerMeasures(context).state.towns[town], tick).defiance;
const borderAt = (town: number, tick: number, context: PlanningContext) => {
  const collapse = collapseOf(workerMeasures(context).state.towns[town], tick);
  return collapse.walled !== null ? 1 : collapse.border;
};
const enforced = (m: Measures, town: number, tick: number, context: PlanningContext): Measures => {
  const border = borderAt(town, tick, context);
  const d = m.level === 0 ? 0 : defianceAt(town, tick, context);
  if (d <= 0) return border > m.checkpoints ? { ...m, checkpoints: border } : m;
  const k = Math.max(0, 1 - d);
  return {
    ...m,
    closed: m.closed * k,
    curfew: m.curfew * k,
    lockdown: m.lockdown * k,
    checkpoints: Math.max(border, m.checkpoints * k),
  };
};

/** A chunk's town's measures at a tick (none in the countryside). */
export const measuresAt = (cx: number, cy: number, tick: number, context: PlanningContext): Measures => {
  const town = townOf(cx, cy, context);
  return town < 0
    ? NO_MEASURES
    : enforced(
        measuresOf(workerMeasures(context).state.towns[town]?.events, tick),
        town,
        tick,
        context
      );
};

/**
 * A town's response at a tick, for other systems (weather): read-only, pure in the tick.
 * `raw` skips defiance (for unrest itself, which must not read its own output).
 */
export const townResponse = (town: number, tick: number, context: PlanningContext, raw = false) => {
  const t = town >= 0 ? workerMeasures(context).state.towns[town] : undefined;
  const m = measuresOf(t?.events, tick);
  return {
    ...(raw ? m : enforced(m, town, tick, context)),
    awareness: valueAt(t?.aware, tick),
    hospitalLoad: valueAt(t?.hospital, tick),
  };
};

// ---------------------------------------------------------------------------------------------
// The configure message: traits and the response together

/** Traits plus the response (and the cast's directives, when there are any: domain/directive.ts), as the chunk hosts' configure bytes. */
/** What else a config may carry: the infection slot going round (LabStrain) and the simulation lab's roster (src/simlab/protocol.ts). */
export type ConfigExtras = { siege?: SiegeSnapshot; rts?: WorkerRtsOrder[]; strain?: number; lab?: LabRoster | null; made?: readonly (readonly [number, string])[]; held?: readonly number[] };

export const encodeConfig = (traitsJson: unknown, response: ResponseState, seed?: number, directives: readonly WorkerDirective[] = [], extras: ConfigExtras = {}) =>
  new TextEncoder().encode(JSON.stringify({
    traits: traitsJson, response, ...(seed === undefined ? {} : { seed }), ...(directives.length ? { directives } : {}),
    ...(extras.strain ? { strain: extras.strain } : {}), ...(extras.lab ? { lab: extras.lab } : {}),
    ...(extras.made?.length ? { made: extras.made } : {}), ...(extras.held?.length ? { held: extras.held } : {}),
    ...(extras.rts?.length ? { rts: extras.rts } : {}),
    ...(extras.siege?.structures.length ? { siege: extras.siege } : {}),
  }));

/** Splits configure bytes into traits (JSON object), the response, the run's seed (null: not sent), the directives, the infection slot, the lab's roster, who is made a super mutant (domain/mutants.ts) and who is held captive (domain/captives.ts); old bare-traits bytes still work. */
export const decodeConfig = (
  bytes: Uint8Array
): { traits: Record<string, unknown>; response: ResponseState | null; seed: number | null; directives: WorkerDirective[]; strain: number; lab: LabRoster | null; made: [number, string][]; held: number[]; rts: WorkerRtsOrder[]; siege: SiegeSnapshot } => {
  const v = JSON.parse(new TextDecoder().decode(bytes));
  if (v && typeof v === "object" && "traits" in v && "response" in v)
    return {
      rts: Array.isArray(v.rts) ? v.rts : [],
      siege: v.siege && Array.isArray(v.siege.structures) ? v.siege : { revision: 0, structures: [] },
      traits: v.traits, response: v.response, seed: typeof v.seed === "number" ? v.seed : null, directives: Array.isArray(v.directives) ? v.directives : [],
      strain: typeof v.strain === "number" ? v.strain : 0, lab: v.lab ?? null, made: Array.isArray(v.made) ? v.made : [], held: Array.isArray(v.held) ? v.held : [],
    };
  return { traits: v, response: null, seed: null, directives: [], strain: 0, lab: null, made: [], held: [], rts: [], siege: { revision: 0, structures: [] } };
};
