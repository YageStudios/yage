/** Authored civilian palette weighting and packed snapshot tint fields. */
import { CONTENT } from "../../content/runtime";
import { LOOK_VARIANTS } from "./sprites";

/** Palette slots per tint field. */
export const TINT_FIELDS: [number, number, number] = [8, 8, 4];
export const CIVILIAN_CLOTHES = 7;
export const FLAK = 7;
const HAIR_COLOURS = 8;
const SKIN_TONES = 4;

export const packTint = (clothes: number, hair: number, skin: number) => clothes + hair * 8 + skin * 64;
export const unpackTint = (tint: number) => ({ clothes: tint & 7, hair: (tint >> 3) & 7, skin: tint >> 6 });

/** A soldier's uniform: the same person, in flak. Never 255 (white-haired darkest skin isn't rolled). */
export const soldierTint = (tint: number) => (tint & ~7) | FLAK;

/**
 * Every civilian tint, weighted so hair goes with skin (darker skin rarely blonde or ginger), and
 * greys and whites are rarer. Built once; a roll picks one entry.
 */
const TINTS: number[] = (() => {
  const list: number[] = [];
  // Hair: black, dark brown, brown, auburn, ginger, blonde, grey, white.
  const light = CONTENT.looks.pawn.lightHairWeights;
  const dark = CONTENT.looks.pawn.darkHairWeights;
  for (let skin = 0; skin < SKIN_TONES; skin++) {
    const weights = skin < 2 ? light : dark;
    for (let hair = 0; hair < HAIR_COLOURS; hair++) {
      if (hair === 7 && skin === 3) continue;
      for (let clothes = 0; clothes < CIVILIAN_CLOTHES; clothes++) {
        for (let w = 0; w < weights[hair]; w++) list.push(packTint(clothes, hair, skin));
      }
    }
  }
  return list;
})();

/** A new person's look, from two draws of the generator (variant, then colours). */
export const rollLook = (next: () => number) => {
  const sprite = Math.min(LOOK_VARIANTS - 1, Math.floor(next() * LOOK_VARIANTS));
  const tint = TINTS[Math.min(TINTS.length - 1, Math.floor(next() * TINTS.length))];
  return { sprite, tint };
};

