export const enum Activity {
  Sleep = 0,
  Home = 1,
  Work = 2,
  Lunch = 3,
  Leisure = 4,
  School = 5,
  Play = 6,
  /** Walking the children to school. */
  Escort = 7,
  /** After dinner: out with friends, at a party, or home. */
  Evening = 8,
}

// Boundary flags: whose clock a boundary follows.
/** The household's: families leave for school and sit down to dinner together. */
export const FAM = 1;
export const WAKE = 2;
/** Work start / end. */
export const WS = 4;
export const WE = 8;
export const BED = 16;
/** [hour, activity, flags]; segment 0 continues the previous day's last segment. */
export type ScheduleEntry = [number, Activity, number];
export const SCHEDULES: ScheduleEntry[][] = [
  /* Worker */ [
    [0, Activity.Sleep, 0],
    [6.5, Activity.Home, WAKE],
    [7.5, Activity.Work, WS],
    [12, Activity.Lunch, 0],
    [13, Activity.Work, 0],
    [17.25, Activity.Leisure, WE],
    [18.5, Activity.Home, FAM],
    [19.75, Activity.Evening, 0],
    [22.5, Activity.Sleep, BED],
  ],
  /* Farmer */ [
    [0, Activity.Sleep, 0],
    [5.5, Activity.Home, WAKE],
    [6, Activity.Work, WS],
    [12, Activity.Home, 0],
    [13, Activity.Work, 0],
    [18.5, Activity.Home, FAM],
    [19.75, Activity.Evening, 0],
    [21.5, Activity.Sleep, BED],
  ],
  /* Night */ [
    [0, Activity.Work, 0],
    [1, Activity.Home, 0],
    [1.75, Activity.Sleep, 0],
    [9.5, Activity.Home, WAKE],
    [11.5, Activity.Leisure, 0],
    [14.5, Activity.Work, WS],
  ],
  /* Child */ [
    [0, Activity.Sleep, 0],
    [7, Activity.Home, WAKE],
    [7.6, Activity.School, FAM],
    [15, Activity.Play, 0],
    [18.5, Activity.Home, FAM],
    [20.25, Activity.Sleep, FAM],
  ],
  /* Elder */ [
    [0, Activity.Sleep, 0],
    [7.5, Activity.Home, WAKE],
    [9.5, Activity.Leisure, 0],
    [12, Activity.Home, 0],
    [14, Activity.Leisure, 0],
    [17, Activity.Home, 0],
    [19.75, Activity.Evening, 0],
    [21.5, Activity.Sleep, BED],
  ],
  /* Idle */ [
    [0, Activity.Sleep, 0],
    [7.5, Activity.Home, WAKE],
    [9.5, Activity.Leisure, 0],
    [12, Activity.Home, 0],
    [14, Activity.Leisure, 0],
    [17, Activity.Home, 0],
    [19.75, Activity.Evening, 0],
    [22, Activity.Sleep, BED],
  ],
  /* Parent */ [
    [0, Activity.Sleep, 0],
    [6.5, Activity.Home, WAKE],
    [7.6, Activity.Escort, FAM],
    [9, Activity.Work, 0],
    [12, Activity.Lunch, 0],
    [13, Activity.Work, 0],
    [17.25, Activity.Leisure, WE],
    [18.5, Activity.Home, FAM],
    [19.75, Activity.Evening, 0],
    [22.5, Activity.Sleep, BED],
  ],
  /* Infant */ [
    [0, Activity.Sleep, 0],
    [7, Activity.Home, FAM],
    [19.5, Activity.Sleep, FAM],
  ],
];
