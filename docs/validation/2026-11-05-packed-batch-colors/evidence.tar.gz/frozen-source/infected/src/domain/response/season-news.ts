import type { Season } from "../weather";

export const SEASON_NEWS: Record<Season, string> = {
  winter: "Winter sets in: people crowd indoors, and it spreads easier",
  spring: "Spring: the days lengthen and people get out again",
  summer: "Summer: windows open and evenings outdoors",
  autumn: "Autumn: the evenings draw in",
};
