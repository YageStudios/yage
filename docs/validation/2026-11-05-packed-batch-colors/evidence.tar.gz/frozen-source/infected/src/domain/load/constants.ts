import { CONTENT } from "../../content/runtime";
import type { LoadNumbers } from "../../content/schema/sim";
import { TICK_RATE } from "../world";

export const enum Emit {
  Cough = 0,
  Sneeze = 1,
  Vomit = 2,
  /** Blood dripped and splashed on the ground (a stain, no cloud). */
  Bleed = 3,
  /** A host dropping to the ground (a stain where they fall, no cloud). */
  Collapse = 4,
  /** A fungal spore burst: a big, slow, long-lived cloud. */
  Spore = 5,
  /** A soldier's shot: from the soldier (x, y) at the offset (vx, vy) to whoever they aimed at. */
  Shot = 6,
  /** A bloomed host's bite (HuntSystem): on whoever stands at (x, y), its slot, from the way `angle`. */
  Bite = 7,
}
/** Kinds that make a cloud (the rest are marks on the ground). */
export const isCloud = (kind: Emit) => kind === Emit.Cough || kind === Emit.Sneeze || kind === Emit.Spore;

const { spore, ...load } = CONTENT.load;

/** Tunable constants of the load model that cards don't touch (content/load.json5). */
export const LOAD: LoadNumbers = load;

/**
 * Clouds move in substeps of one tick (1 / TICK_RATE s), always counted from their birth, so a cloud's
 * state at any tick is a pure function of how it was born: stepping it tick by tick and jumping
 * straight to a tick land on the same place.
 */
export const CLOUD_STEP = 1 / TICK_RATE;

/** A spore burst's cloud, as multiples of a cough's (content/load.json5; see SYMPTOMS in symptoms.ts for the rest). */
export const SPORE: { load: number; size: number; life: number; corpses: number } = spore;

export enum Stain {
  Touch = 0,
  Vomit = 1,
  Body = 2,
  Blood = 3,
}

