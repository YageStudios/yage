/**
 * Surface materials: what a tile is made of, as distinct from what it is (its Tile id, which the
 * sim walks on). The world generator writes one MaterialId per tile (ChunkArt.materials, see
 * src/domain/art.ts); the ground painter looks each id up here for a pattern and two colours.
 * 0 means "the tile's default look".
 *
 * Ids are bytes and stable: append, never renumber. The materials themselves are a table,
 * content/materials.json5, numbered in file order.
 */
import { CONTENT } from "../content/runtime";

/** Shader pattern families (src/ground.ts draws each). Grouped by the tile class they decorate. */
export enum Pattern {
  Default = 0,
  // Carriageways and paving (Road class)
  Asphalt = 1,
  Cobble = 2,
  Setts = 3,
  Gravel = 4,
  Dirt = 5,
  Slabs = 6,
  Flags = 7,
  BrickPave = 8,
  Ruts = 9,
  // Floors
  Planks = 10,
  Tiles = 11,
  Checker = 12,
  Carpet = 13,
  Concrete = 14,
  Earth = 15,
  Parquet = 16,
  FlagFloor = 17,
  // Walls
  Brick = 20,
  Ashlar = 21,
  Rubble = 22,
  Timber = 23,
  Plaster = 24,
  Panel = 25,
  Glass = 26,
  Log = 27,
  Metal = 28,
  Adobe = 29,
  // Infrastructure
  Rail = 30,
  Platform = 31,
  Quay = 32,
  DeckStone = 33,
  DeckTimber = 34,
  DeckSteel = 35,
  /** One flat colour, no texture: a clean backdrop for art and shadow test sheets. */
  Flat = 36,
  /** Kept lawn: natural grass, greener and even (landscaped parks). */
  Lawn = 37,
}

export type MaterialKind = "road" | "paving" | "floor" | "wall" | "roof" | "infra";

export type Material = {
  id: number;
  key: string;
  kind: MaterialKind;
  pattern: Pattern;
  /** Main colour and the secondary one (mortar, beams, joints, markings), 0xRRGGBB. */
  base: number;
  accent: number;
  /** Pattern scale: courses/boards/slabs per tile (0 = the pattern's own). */
  scale?: number;
};

/** The materials in id order (content/materials.json5). */
const LIST: Omit<Material, "id">[] = CONTENT.materials.map(({ pattern, kind, ...m }) => {
  const id = Pattern[pattern as keyof typeof Pattern];
  if (id === undefined) throw new Error(`Material ${m.key}: unknown pattern ${pattern}`);
  return { ...m, kind: kind as MaterialKind, pattern: id };
});

export const MATERIALS: readonly Material[] = LIST.map((m, id) => ({ ...m, id }));
const BY_KEY = new Map(MATERIALS.map((m) => [m.key, m]));

/** A material's id by key; throws on an unknown key so typos fail in tests, not on screen. */
export const mat = (key: string): number => {
  const m = BY_KEY.get(key);
  if (!m) throw new Error(`Unknown material ${key}`);
  return m.id;
};
export const materialOf = (id: number): Material => MATERIALS[id] ?? MATERIALS[0];
export const hasMaterial = (key: string) => BY_KEY.has(key);
