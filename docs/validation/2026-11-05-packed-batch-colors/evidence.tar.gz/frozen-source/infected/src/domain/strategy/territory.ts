/** Settlement control is an observation of the real census, not a combat resolver. */
import type { ChunkCounts } from "../disease";
import { TICK_RATE } from "../world";
import type { WorldMap } from "../../worldmap/places";

export type TerritoryOwner = "none" | "human" | "infected";
export type TerritoryStatus = "unknown" | "human" | "infected" | "contested" | "securing" | "reclaiming" | "abandoned";
export type TerritoryCensus = { people: number; infected: number; humans: number; soldiers: number; reported: number; total: number };
export type Territory = TerritoryCensus & {
  place: number; owner: TerritoryOwner; status: TerritoryStatus;
  claimant: TerritoryOwner; progress: number; sampledAt: number; changedAt: number;
};
export type TerritoryEvent = { id: number; tick: number; place: number; owner: TerritoryOwner; status: TerritoryStatus; text: string };
export const TERRITORY_RULES = { holdTicks: 20 * TICK_RATE, events: 256 } as const;

/** A partial census must never turn missing chunks into cleared ground. */
export const territoryCensus = (map: WorldMap, place: number, counts: ReadonlyMap<number, ChunkCounts>): TerritoryCensus => {
  const chunks = [...new Set(map.places[place]?.chunks ?? [])];
  const result: TerritoryCensus = { people: 0, infected: 0, humans: 0, soldiers: 0, reported: 0, total: chunks.length };
  for (const key of chunks) {
    const row = counts.get(key);
    if (!row || ![row.people, row.infected, row.dead, row.soldiers].every((n) => Number.isFinite(n) && n >= 0)) continue;
    result.reported++;
    result.people += row.people;
    result.infected += row.infected;
    // Incubating people still belong to the human population. Soldiers are already in people.
    result.humans += Math.max(0, row.people - row.dead - row.infected);
    result.soldiers += row.soldiers;
  }
  return result;
};

/** Pure next observation. Repeated/backward ticks cannot advance capture; interruptions reset it. */
export const nextTerritory = (previous: Territory | undefined, census: TerritoryCensus, place: number, tick: number): Territory => {
  if (previous && tick <= previous.sampledAt) return previous;
  const next: Territory = {
    ...census, place, owner: previous?.owner ?? "none", status: "unknown", claimant: "none",
    progress: 0, sampledAt: tick, changedAt: previous?.changedAt ?? tick,
  };
  if (census.total > 0 && census.reported === census.total) {
    if (!census.infected && !census.humans && !census.soldiers) {
      next.owner = "none"; next.status = "abandoned";
    } else if (census.infected > 0 && (census.soldiers > 0 || census.infected < census.humans)) {
      next.status = "contested";
      // A first census with humans still resisting establishes their existing control, not a capture.
      if (!previous || previous.status === "unknown" && previous.owner === "none") next.owner = "human";
    } else {
      const candidate: TerritoryOwner = census.infected > 0 ? "infected" : "human";
      const initialHuman = candidate === "human" && (!previous || previous.status === "unknown" && previous.owner === "none");
      if (next.owner === candidate || initialHuman) {
        next.owner = candidate; next.status = candidate;
      } else {
        next.claimant = candidate;
        next.status = candidate === "infected" ? "securing" : "reclaiming";
        if (previous?.claimant === candidate && previous.reported === previous.total && previous.total > 0) {
          next.progress = Math.min(TERRITORY_RULES.holdTicks, previous.progress + tick - previous.sampledAt);
        }
        if (next.progress >= TERRITORY_RULES.holdTicks) {
          next.owner = candidate; next.status = candidate; next.claimant = "none"; next.progress = 0;
        }
      }
    }
  }
  if (!previous || previous.owner !== next.owner || previous.status !== next.status) next.changedAt = tick;
  return next;
};

export const territoryPercent = (territory: Pick<Territory, "progress">) => Math.floor(100 * territory.progress / TERRITORY_RULES.holdTicks);
export const territoryLabel = (territory: Territory | undefined): string => {
  if (!territory || territory.status === "unknown") return "Awaiting complete census";
  if (territory.claimant !== "none") return `${territory.status} ${territoryPercent(territory)}%`;
  return territory.status === "infected" ? "Infected control" : territory.status === "human" ? "Human control" : territory.status;
};

/** Operational contact lines are road links, not invented continuous territorial borders. */
export const territoryFronts = (map: WorldMap, territories: readonly Territory[]): number[] => {
  const byPlace = new Map(territories.map((t) => [t.place, t]));
  return map.links.flatMap((link, i) => {
    const a = byPlace.get(link.from), b = byPlace.get(link.to);
    if (!a || !b || a.status === "unknown" || b.status === "unknown") return [];
    const opposed = a.owner !== "none" && b.owner !== "none" && a.owner !== b.owner;
    const contested = a.status === "contested" || b.status === "contested";
    return opposed || contested ? [i] : [];
  });
};

/** Withdrawal prefers controlled roads; this changes route choice, never position or combat. */
export const withdrawalCosts = (map: WorldMap, territories: readonly Territory[]): number[] => {
  const byPlace = new Map(territories.map((t) => [t.place, t]));
  return map.places.map((_, i) => {
    const t = byPlace.get(i);
    if (!t || t.status === "unknown") return 2;
    if (t.status === "infected") return 1;
    if (t.status === "contested" || t.status === "reclaiming") return 5;
    return t.owner === "human" ? 8 : 2;
  });
};
