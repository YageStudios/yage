import type { RtsState } from "../../components/rts/RtsState";
import type { StrategyState } from "../../components/strategy/StrategyState";
import type { SiegeState } from "../../components/siege/SiegeState";
import type { Point } from "../rts/orders";
import type { Territory } from "./territory";
import { forceCentre } from "./operations";
import { State } from "../disease";
import { TICK_RATE } from "../world";

export type ForceMark = Point & { id: number; name: string; living: number; total: number; blocked: boolean };
export type RouteMark = { operation: number; blocked: boolean; points: Point[]; at: Point };
export type BreachMark = Point & { tick: number };
export type OperationalFrame = {
  tick: number; territories: Territory[]; forces: ForceMark[]; routes: RouteMark[]; breaches: BreachMark[];
};
/** Half an hour at five-second resolution. Retention is explicit; older scrubs have no force data. */
export const OPERATIONAL_HISTORY = { every: 5 * TICK_RATE, frames: 360, routePoints: 48 } as const;

/** Rendering history keeps original waypoints at a bounded resolution, not new simulated routes. */
const sampledRoute = (points: readonly Point[]): Point[] => {
  const stride = Math.max(1, Math.ceil((points.length - 1) / (OPERATIONAL_HISTORY.routePoints - 1)));
  return points.filter((_, i) => i % stride === 0 || i === points.length - 1).map((p) => ({ x: p.x, y: p.y }));
};

/** The units whose gid is listed, in `units` order (as filtering them would give), via a gid index. */
const indexUnits = <U extends { gid: number }>(units: readonly U[]) => {
  const at = new Map<number, number[]>();
  units.forEach((u, i) => { const list = at.get(u.gid); if (list) list.push(i); else at.set(u.gid, [i]); });
  return (gids: Iterable<number>) => {
    const found: number[] = [];
    for (const gid of new Set(gids)) for (const i of at.get(gid) ?? []) found.push(i);
    return found.sort((a, b) => a - b).map((i) => units[i]);
  };
};

/** A detached presentation snapshot of actual state. Never supplies input to the simulation. */
export const operationalSnapshot = (
  tick: number, forces: readonly RtsState[], strategies: readonly StrategyState[], sieges: readonly SiegeState[], territories: readonly Territory[],
): OperationalFrame => {
  const marks: ForceMark[] = [];
  for (const state of forces) {
    const membersOf = indexUnits(state.units);
    for (const horde of state.hordes) {
      const units = membersOf(horde.members);
      const at = forceCentre(units);
      if (!at) continue;
      marks.push({ ...at, id: horde.id, name: horde.name, living: units.filter((u) => u.state === State.Infected).length, total: horde.members.length, blocked: units.some((u) => u.state === State.Infected && (u.status === "blocked" || u.status === "lost")) });
    }
  }
  const routes: RouteMark[] = [], units = forces.flatMap((s) => s.units);
  let membersOf: ((gids: Iterable<number>) => typeof units) | null = null;
  for (const state of strategies) for (const op of state.operations) {
    if (!["active", "blocked", "holding"].includes(op.status)) continue;
    for (const task of op.tasks) {
      if (!["active", "blocked", "holding"].includes(task.status)) continue;
      membersOf ??= indexUnits(units);
      const at = forceCentre(membersOf(task.members).filter((u) => u.operation === op.id));
      if (!at || task.leg >= task.route.length) continue;
      routes.push({ operation: op.id, blocked: task.status === "blocked", points: sampledRoute([at, ...task.route.slice(task.leg)]), at: { ...op.at } });
    }
  }
  return {
    tick, territories: territories.map((t) => ({ ...t })), forces: marks, routes,
    breaches: sieges.flatMap((s) => s.events.filter((e) => e.kind === "breached" && e.tick <= tick && tick - e.tick <= 60 * TICK_RATE).map(({ x, y, tick }) => ({ x, y, tick }))),
  };
};

/** A scrub never falls forward to a future sample, or falls back to today's forces. */
export const operationalFrameAt = (frames: readonly OperationalFrame[], tick: number): OperationalFrame | null => {
  for (let i = frames.length - 1; i >= 0; i--) if (frames[i].tick <= tick) return frames[i];
  return null;
};
