/**
 * Unrest: how far a town's people have had enough. Lockdown fatigue (days kept in), shortages (shops
 * shut, hospitals overflowing, looting feeding on itself) and the dead push it up; it fades slowly
 * once life goes back to normal. Against it stands order: the soldiers a town has, against how many
 * are out on the streets. Where unrest is high and the soldiers are stretched, order breaks down.
 *
 * Page side (stepUnrest) it is two step series on each town's shared response (`unrest`, `order`),
 * like routes.ts, so everything a chunk does with it is a pure function of the tick:
 *
 * - protests by day as unrest builds: crowds in squares and streets (crowds spread the strain);
 * - looting: shops broken into, one by one (each shop has its own breaking point);
 * - fires: buildings set alight, burning for a few minutes, then a burnt-out shell for good;
 * - riots in the evening: rioters against a line of soldiers while order holds; once it doesn't,
 *   defiance (curfew and lockdown stop holding) and nobody stands in the way.
 */
import { CONTENT } from "../../content/runtime";
import { timeOfDay } from "../time";
import { hashUnit } from "../load/streams";
import { PlaceKind } from "../../worldgen/terrain/index";
import { planningLayout, type PlanningContext } from "../../worldgen/commute/context";
import { hash, TICK_RATE } from "../world";
import {
  responseState,
  townOf,
  type Series,
  type TownResponse,
} from "./measures";
import type { WorldResponse } from "./towns";

/** Owner-tunable unrest numbers; data in content/response.json5. */
const unrest = CONTENT.response.unrest;
const dayShare = ([from, to]: readonly [number, number]) =>
  [from / 24, to / 24] as const;
export const UNREST = {
  ...unrest,
  protestHours: dayShare(unrest.protestHours),
  riotHours: dayShare(unrest.riotHours),
};

export const ramp01 = (x: number, from: number, width = UNREST.ramp) => {
  const t = Math.min(1, Math.max(0, (x - from) / width));
  return t * t * (3 - 2 * t);
};

/** Order 0–1: the town's soldiers against those out on the streets at this unrest. */
export const orderOf = (unrest: number, people: number, soldiers: number) => {
  const street = unrest * people * UNREST.streetShare;
  if (street < 1) return 1;
  return Math.min(1, (soldiers * UNREST.perSoldier) / street);
};

/**
 * Advances every town's unrest to the response's tick (call right after stepWorldResponse, with that
 * step's dt in seconds and the same counts). Returns whether the shared state grew.
 */


// ---------------------------------------------------------------------------------------------
// What it means at a tick (pure; page and chunk hosts alike)

/** A step series' value at a tick (`fallback` before its first entry). */
const at = (s: Series | undefined, tick: number, fallback: number) => {
  let v = fallback;
  if (s)
    for (const [value, t] of s) {
      if (t > tick) break;
      v = value;
    }
  return v;
};

/** The first tick a series reached `level` (null if it never has by `tick`). */
export const firstReached = (
  s: Series | undefined,
  level: number,
  tick: number
) => {
  if (s)
    for (const [value, t] of s) {
      if (t > tick) break;
      if (value >= level) return t;
    }
  return null;
};

const inHours = (tod: number, [from, to]: readonly [number, number]) =>
  from <= to ? tod >= from && tod < to : tod >= from || tod < to;

export type Unrest = {
  unrest: number;
  order: number;
  /** 0–1 each: how far each phase has gone (whatever the hour). */
  protest: number;
  looting: number;
  riot: number;
  /** Out now: a protest crowd by day, rioters in the evening (0–1). */
  crowd: number;
  rioting: number;
  /** How far order has broken down: curfew and lockdown stop holding (0–1). */
  defiance: number;
};

export const CALM: Unrest = {
  unrest: 0,
  order: 1,
  protest: 0,
  looting: 0,
  riot: 0,
  crowd: 0,
  rioting: 0,
  defiance: 0,
};

/** A town's unrest at a tick. */
export const unrestOf = (
  town: TownResponse | undefined,
  tick: number
): Unrest => {
  const unrest = at(town?.unrest as Series | undefined, tick, 0);
  if (unrest <= 0) return CALM;
  const order = at(town?.order as Series | undefined, tick, 1);
  const protest = ramp01(unrest, UNREST.protestAt);
  const looting = ramp01(unrest, UNREST.lootAt);
  const riot = ramp01(unrest, UNREST.riotAt);
  const tod = timeOfDay(tick);
  const crowd = inHours(tod, UNREST.protestHours) ? protest : 0;
  const rioting = inHours(tod, UNREST.riotHours) ? riot : 0;
  return {
    unrest,
    order,
    protest,
    looting,
    riot,
    crowd,
    rioting,
    defiance: riot * (1 - order),
  };
};

/** A chunk's town's unrest (calm in the countryside). */
export const unrestAt = (cx: number, cy: number, tick: number, context: PlanningContext): Unrest => {
  const town = townOf(cx, cy, context);
  return town < 0 ? CALM : unrestOf(responseState(context).towns[town], tick);
};

/** Outdoor exposure multiplier in a chunk: crowds out protesting or rioting. */
export const crowdFactor = (u: Unrest) =>
  1 + UNREST.crowdSpread * Math.max(u.crowd, u.rioting);

/**
 * When a shop with hash `h` was broken into (tick), or null: each shop has its own breaking point
 * up the looting ramp, and only `shopsLooted` of them ever go. Once looted, it stays looted.
 */
export const lootedAt = (
  town: TownResponse | undefined,
  h: number,
  tick: number
) => {
  const k = hashUnit(h, 0x6c6f6f74, 7);
  if (k >= UNREST.shopsLooted) return null;
  return firstReached(
    town?.unrest as Series | undefined,
    UNREST.lootAt + (k / UNREST.shopsLooted) * (1 - UNREST.lootAt) * 0.8,
    tick
  );
};

/** A place's own seed for looting and fires: its hash with its chunk and index. */
export const placeSeed = (h: number, cx: number, cy: number, i: number) =>
  hash(h, cx, cy, i);

/** When a chunk's place `i` was looted (tick), or null: shops and taverns in a town only. */
export const placeLooted = (
  cx: number,
  cy: number,
  i: number,
  tick: number,
  context: PlanningContext
) => {
  const town = townOf(cx, cy, context);
  if (town < 0) return null;
  const p = planningLayout(context, cx, cy).places[i];
  if (!p || (p.kind !== PlaceKind.Shop && p.kind !== PlaceKind.Tavern))
    return null;
  return lootedAt(responseState(context).towns[town], placeSeed(p.h, cx, cy, i), tick);
};

/** A building's fire: null if it hasn't caught; else how long it has burned (s) and whether it's out. */
export const fireOf = (
  town: TownResponse | undefined,
  h: number,
  tick: number
) => {
  const k = hashUnit(h, 0x66697265, 8);
  if (k >= UNREST.buildingsBurnt) return null;
  const caught = firstReached(
    town?.unrest as Series | undefined,
    UNREST.lootAt +
      0.05 +
      (k / UNREST.buildingsBurnt) * (1 - UNREST.lootAt - 0.05) * 0.8,
    tick
  );
  if (caught === null) return null;
  const [lo, hi] = UNREST.burnSeconds;
  const burns = lo + hashUnit(h, 0x6275726e, 9) * (hi - lo);
  const seconds = (tick - caught) / TICK_RATE;
  return { seconds, burns, out: seconds >= burns, caught };
};
