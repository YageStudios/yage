const STATE_NAMES = ["Healthy", "Incubating", "Symptomatic", "Dead"];
export const stateName = (state: number) => STATE_NAMES[state] ?? "Unknown";

