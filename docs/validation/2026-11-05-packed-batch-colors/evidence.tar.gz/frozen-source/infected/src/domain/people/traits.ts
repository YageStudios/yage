import { CONTENT } from "../../content/runtime";
import { hash } from "../world";
export const unit = (h: number) => (h & 0xffff) / 65536;
// ---------------------------------------------------------------------------------------------
// Personality traits: two or three per person, from exclusive pairs and singles.
export const enum Trait {
  Sociable = 1 << 0,
  Homebody = 1 << 1,
  NightOwl = 1 << 2,
  EarlyBird = 1 << 3,
  Industrious = 1 << 4,
  Lazy = 1 << 5,
  Kind = 1 << 6,
  Abrasive = 1 << 7,
  Optimist = 1 << 8,
  Pessimist = 1 << 9,
  Gourmand = 1 << 10,
  Neat = 1 << 11,
  Nervous = 1 << 12,
  IronWilled = 1 << 13,
  GreenThumb = 1 << 14,
  Bookworm = 1 << 15
}
/** Exclusive pairs, by group (content/traits.json5 lists the traits pair by pair). */
const TRAIT_GROUPS: [
  number,
  number
][] = CONTENT.traits.map(([a, b]) => [a.bit, b.bit]);
/** [bit, name, description] per trait (content/traits.json5; `bit` is the Trait flag). */
export const TRAIT_INFO: [
  Trait,
  string,
  string
][] = CONTENT.traits.flat().map((t) => [t.bit as Trait, t.label, t.text]);
/** Trait bits for a person: two or three from different groups. */
export const traitsOf = (gid: number) => {
  const h = hash(gid, 61);
  const count = 2 + (h & 1);
  let bits = 0;
  let used = 0;
  for (let k = 0;k < count;k++) {
    let g = (h >>> (1 + k * 5)) % TRAIT_GROUPS.length;
    while (used & (1 << g))
      g = (g + 1) % TRAIT_GROUPS.length;
    used |= 1 << g;
    bits |= TRAIT_GROUPS[g][(h >>> (20 + k)) & 1];
  }
  return bits;
};
