/**
 * What the player can see into: the page's looked-into set (PrefabPresentation: the building the host
 * or a commanded unit is in, each faded in front of them or where they walk, each with a wall smashed
 * in), sent to every hot chunk as a command, "LOOK" (LookSync). A chunk unpacks a building's roster
 * only when one of these points lies on it (RosterSystem), and its building events surface only near
 * the view (BuildingEventsSystem). After the four magic bytes: the view's centre and half extents
 * (four f32 LE, world px), a u16 count, then that many points (f32 x, y each, world px).
 * The same on every thread.
 */

export type Look = {
  /** The view's centre (world px). */
  x: number;
  y: number;
  /** Half its width and height (world px). */
  rx: number;
  ry: number;
  /** World points, each on a building seen into. */
  points: number[];
};

/** What starts a look's bytes ("LOOK"): nothing else a chunk takes starts so. */
const MAGIC = [0x4c, 0x4f, 0x4f, 0x4b];
/** Points beyond this many are dropped (a view has a few dozen at most). */
const MAX_POINTS = 1024;

export const encodeLook = ({ x, y, rx, ry, points }: Look): Uint8Array => {
  const n = Math.min(MAX_POINTS, points.length >> 1);
  const bytes = new Uint8Array(4 + 16 + 2 + n * 8);
  bytes.set(MAGIC);
  const view = new DataView(bytes.buffer);
  view.setFloat32(4, x, true);
  view.setFloat32(8, y, true);
  view.setFloat32(12, rx, true);
  view.setFloat32(16, ry, true);
  view.setUint16(20, n, true);
  for (let i = 0;i < n * 2;i++) view.setFloat32(22 + i * 4, points[i], true);
  return bytes;
};

/** The look `bytes` say, or null for any other command. */
export const decodeLook = (bytes: Uint8Array): Look | null => {
  if (bytes.length < 22 || MAGIC.some((b, i) => bytes[i] !== b)) return null;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const n = view.getUint16(20, true);
  if (bytes.length !== 22 + n * 8) return null;
  const points: number[] = new Array(n * 2);
  for (let i = 0;i < n * 2;i++) points[i] = view.getFloat32(22 + i * 4, true);
  return { x: view.getFloat32(4, true), y: view.getFloat32(8, true), rx: view.getFloat32(12, true), ry: view.getFloat32(16, true), points };
};
