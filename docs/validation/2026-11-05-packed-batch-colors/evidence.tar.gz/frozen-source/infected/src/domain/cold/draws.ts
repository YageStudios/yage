/**
 * Cold draws: how many of n turn, each with chance p, hashed on the run's seed and what the draw is
 * for (never a stream, so a cold step's outcome is a pure function of its inputs). A few people are
 * drawn one by one; a crowd by Poisson when either side is rare, else normally (Irwin–Hall).
 */

/** One round of hash's mix (domain/world.ts), the same steps. */
const mix = (h: number, value: number) => {
  h = Math.imul(h ^ (value | 0), 0x01000193);
  h ^= h >>> 15;
  h = Math.imul(h, 0x2c1b3c6d);
  return h ^ (h >>> 12);
};

/** hash(seed, key, tick, purpose, i) / 2³², without the rest array (a crowd's draw asks it a dozen times). */
const unit = (seed: number, key: number, tick: number, purpose: number, i: number) => (mix(mix(mix(keyed(mix(0x811c9dc5, seed), key), tick), purpose), i) >>> 0) / 4294967296;
/** A key's low 32 bits, and its high bits when it has them (a chunk key is 38 bits: chunks 8192 apart share the low ones). */
const keyed = (h: number, key: number) => (key >= 4294967296 ? mix(mix(h, key), Math.floor(key / 4294967296)) : mix(h, key));

/** Poisson(mean) by inversion: one uniform, the cdf summed term by term. */
const poisson = (mean: number, u: number) => {
  let term = Math.exp(-mean);
  let cdf = term;
  let k = 0;
  while (u > cdf && k < 1000) {
    k++;
    term *= mean / k;
    cdf += term;
  }
  return k;
};

/** How many of `n` turn this step, each at chance `p`: a draw keyed on (seed, key, tick, purpose). */
export const binomial = (n: number, p: number, seed: number, key: number, tick: number, purpose: number) => {
  if (n <= 0 || p <= 0) return 0;
  if (p >= 1) return n;
  if (n <= 32) {
    let k = 0;
    for (let i = 0;i < n;i++) if (unit(seed, key, tick, purpose, i) < p) k++;
    return k;
  }
  const mean = n * p;
  if (mean < 12) return Math.min(n, poisson(mean, unit(seed, key, tick, purpose, 0)));
  if (n - mean < 12) return n - Math.min(n, poisson(n - mean, unit(seed, key, tick, purpose, 0)));
  let z = -6;
  for (let i = 0;i < 12;i++) z += unit(seed, key, tick, purpose, i);
  return Math.max(0, Math.min(n, Math.round(mean + z * Math.sqrt(mean * (1 - p)))));
};

/** One person's chance, keyed on them: whether a gid turns at chance `p`. */
export const chance = (p: number, seed: number, gid: number, tick: number, purpose: number) => p > 0 && unit(seed, gid, tick, purpose, 0) < p;

/** A uniform draw keyed on one person (their incubation, their life). */
export const unitOf = (seed: number, gid: number, tick: number, purpose: number) => unit(seed, gid, tick, purpose, 1);
