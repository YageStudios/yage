/**
 * District grammars (plan §9): street pattern parameters (content/streets.json5 and
 * content/grammars.json5). The generator in src/worldgen/district.ts reads these; profiles
 * override per district.
 */
import type { Grammar, RoadClass, Street } from "../atlas/model";
import { CONTENT } from "../content/runtime";

export type StreetSpec = { cls: RoadClass; width: number; surface: Street["surface"]; sidewalk: number };

/** Street types by name (content/streets.json5). */
export const STREETS: Record<string, StreetSpec> = CONTENT.streets;

export type GrammarSpec = {
  /** Street type along the grid axis, across it, and of connectors. */
  along: string;
  across: string;
  /** Probability a cross street is dropped between two long streets (T-junctions, cul-de-sacs). */
  drop: number;
};

/** Street patterns by grammar (content/grammars.json5). */
export const GRAMMARS: Partial<Record<Grammar, GrammarSpec>> = CONTENT.grammars;
