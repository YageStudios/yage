import type { ResponseMemory } from "../../components/response/ResponseMemory";
/** The region's own response memory; each town's lives on its `region:town` entity (components/response/Town*). */
export const createResponseMemory = (): ResponseMemory => ({
  borders: null,
  extremes: { closed: [], season: null },
});
