/**
 * Feral animals' bites (the beasts trait; systems/sim/BeastSystem.ts), timed by the clock alone:
 * a turned critter may bite once every BEAST.every seconds, when the bout (tick + id) / every turns
 * over. Pure, so the views can show the lunge on the same beat the chunk bites on.
 */
import { TICK_RATE, TILE } from "./world";

/** Feral animals at the living: how near (world px) one bites, and seconds between its bites. */
export const BEAST = { reach: TILE * 1.2, every: 20 };

/** Seconds since critter `id`'s last bite chance at (fractional) tick `tick`: 0 to BEAST.every. */
export const beastPhase = (id: number, tick: number) => {
  const every = BEAST.every * TICK_RATE;
  return ((((tick + id) % every) + every) % every) / TICK_RATE;
};

/** A feral critter's moment for drawing: `strike` 0–1 out and back as it bites (negative while it gathers for it), `aim` the angle at its prey. */
export type Feral = { strike: number; aim: number };

/** Seconds before its bite that a feral beast gathers itself; seconds its strike lasts after it. */
const GATHER = 0.35;
const STRIKE = 0.7;

/**
 * A feral beast's moment: on BeastSystem's beat (domain/beasts.ts beastPhase, the bite at phase 0)
 * it strikes, out and back over STRIKE seconds, having gathered itself for GATHER seconds before;
 * only with someone living near enough to bite, and aimed at them. Otherwise it just prowls.
 */
export const feralMoment = (id: number, tick: number, x: number, y: number, prey: readonly { x: number; y: number }[]): Feral => {
  let best: { x: number; y: number } | null = null;
  let bestD = (BEAST.reach * 1.4) ** 2;
  for (const p of prey) {
    const d = (p.x - x) ** 2 + (p.y - y) ** 2;
    if (d < bestD) {
      best = p;
      bestD = d;
    }
  }
  if (!best) return { strike: 0, aim: 0 };
  const aim = Math.atan2(best.y - y, best.x - x);
  const phase = beastPhase(id, tick);
  if (phase < STRIKE) return { strike: Math.sin((Math.PI * phase) / STRIKE), aim };
  if (phase > BEAST.every - GATHER) return { strike: -(phase - (BEAST.every - GATHER)) / GATHER, aim };
  return { strike: 0, aim };
};
