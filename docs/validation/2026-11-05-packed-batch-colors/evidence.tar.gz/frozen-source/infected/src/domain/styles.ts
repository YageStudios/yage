/**
 * Architecture styles (plan §11): how a district's lots become buildings. A style is independent
 * of the street grammar — the same grid can carry terraces, towers or warehouses — and of the
 * building's use, which the style's mix decides per lot. The styles are a table,
 * content/styles.json5; homesFor and jobsFor stay rules here.
 */
import type { BuildingUse } from "../atlas/model";
import { CONTENT } from "../content/runtime";

export type Style = {
  id: string;
  /** Lot frontage and building depth ranges, tiles. */
  lot: [number, number];
  depth: [number, number];
  /** Distance from the sidewalk/verge edge to the front wall. */
  setback: [number, number];
  /** Gap between neighbouring buildings (0 = continuous street wall). */
  gap: number;
  storeys: [number, number];
  /** Use mix by weight. */
  uses: readonly (readonly [BuildingUse, number])[];
  /** Share of lots left empty (gardens, gaps, vacant plots). */
  vacancy: number;
  /** Roof colour family for the preview and renderer. */
  roof: string;
};

/** District styles that read as town or city (no bare-earth patches on their open ground in objects mode; links through them get sidewalks). */
export const URBAN = new Set(CONTENT.styles.filter((s) => s.urban).map((s) => s.id));
/** Street-wall styles whose open ground is paved in objects mode: concrete yards and lots, no lawn (parks keep theirs). */
export const PAVED = new Set(CONTENT.styles.filter((s) => s.paved).map((s) => s.id));

export const STYLES: Record<string, Style> = Object.fromEntries(
  CONTENT.styles.map(({ urban: _urban, paved: _paved, look: _look, ...style }) => [style.id, style]),
);

/** Households a building of this use and size holds. */
export const homesFor = (use: BuildingUse, floorArea: number, storeys: number) => {
  switch (use) {
    case "house":
    case "farmhouse":
    case "terrace":
      return 1;
    case "apartment":
      return Math.max(2, Math.round((floorArea * storeys) / 70));
    case "tower":
      return Math.max(4, Math.round((floorArea * storeys) / 140));
    case "shop":
    case "tavern":
      return storeys > 1 ? 1 : 0;
    default:
      return 0;
  }
};

/** Jobs a building offers. */
export const jobsFor = (use: BuildingUse, floorArea: number, storeys: number) => {
  const area = floorArea * storeys;
  switch (use) {
    case "office":
    case "tower":
      return Math.round(area / (use === "tower" ? 30 : 20));
    case "shop":
      return Math.max(2, Math.round(floorArea / 25));
    case "workshop":
      return Math.max(2, Math.round(area / 40));
    case "warehouse":
      return Math.max(3, Math.round(area / 120));
    case "factory":
      return Math.max(5, Math.round(area / 50));
    case "school":
      return Math.max(6, Math.round(area / 40));
    case "hospital":
      return Math.max(20, Math.round(area / 25));
    case "clinic":
      return Math.max(3, Math.round(area / 30));
    case "university":
      return Math.max(15, Math.round(area / 35));
    case "tavern":
      return Math.max(2, Math.round(floorArea / 40));
    case "civic":
    case "church":
    case "mosque":
    case "station":
      return Math.max(2, Math.round(area / 60));
    case "barn":
    case "farmhouse":
      return 2;
    default:
      return 0;
  }
};
