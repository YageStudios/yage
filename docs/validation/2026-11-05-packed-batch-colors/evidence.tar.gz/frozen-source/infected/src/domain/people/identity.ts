import type { PersonAddressContext } from "../person-address";
import { WORLD_CHUNKS, WORLD_MIN } from "../world";
export const enum LifeRole {
  Worker = 0,
  Farmer = 1,
  /** Tavern staff: work evenings and into the night. */
  Night = 2,
  /** School-age (5–17). */
  Child = 3,
  Elder = 4,
  /** Adults at home: homemakers, between jobs. */
  Idle = 5,
  /** A worker who walks the household's children to school first. */
  Parent = 6,
  /** Under five: at home with the family. */
  Infant = 7
}
/** A person's place in their household. */
export const enum Kin {
  Head = 0,
  Partner = 1,
  Child = 2,
  Grandparent = 3
}
export const NONE = 65535;
export const HOME_CHUNK = 255;
/** No seat at work: out of view upstairs (or a commuter in a big building). */
export const NO_SEAT = 255;
// ---------------------------------------------------------------------------------------------
// Global ids
/** Home chunk and index of a gid (inverse of `gidFor`). */
export const gidChunkX = (gid: number, context?: PersonAddressContext) => {
  if (context?.source?.personAddresses) return context.source.personAddresses.home(gid)?.cx ?? NaN;
  return gid & 0x80000000 ? ((((gid >>> 21) & 1023) << 22) >> 22) : ((gid >>> 14) % WORLD_CHUNKS) + WORLD_MIN;
};
export const gidChunkY = (gid: number, context?: PersonAddressContext) => {
  if (context?.source?.personAddresses) return context.source.personAddresses.home(gid)?.cy ?? NaN;
  return gid & 0x80000000 ? ((((gid >>> 11) & 1023) << 22) >> 22) : Math.floor(((gid >>> 14) & 4095) / WORLD_CHUNKS) + WORLD_MIN;
};
export const gidIndex = (gid: number, context?: PersonAddressContext) => {
  if (context?.source?.personAddresses) return context.source.personAddresses.home(gid)?.index ?? -1;
  return gid & 0x80000000 ? gid & 2047 : gid & 16383;
};
/**
 * Drive-in commuters (domain/people/drive-in.ts): people from outside the loaded regions who work in
 * a loaded chunk. Their gids start here, above every resident identity a geographic source reserves
 * (identityCount stays below it), so only a source with person addresses has them; the legacy
 * world's off-world gids reach these values too.
 */
export const DRIVE_IN_BASE = 0xc0000000;
export const isDriveIn = (gid: number, context: PersonAddressContext) => gid >= DRIVE_IN_BASE && !!context.source?.personAddresses;
/** A drive-in's place once their shift is over: on their way out of the loaded world (routines.ts, walk.ts). */
export const AWAY = 65534;
/** Workplace codes from here up identify a far commute target. */
export const FAR_CODE = 4;
