/**
 * Captives (a story's `captive` beat, until `freed`, made a mutant or rescued): held where their
 * captor keeps them, out of the strain's reach in every tier, as the solver has them (solver/cast.ts
 * held stays). A gid set the authority keeps (HeldCaptives) and sends with the config; the lookup
 * is one set check, skipped while nobody is held.
 */
const HELD = new Set<number>();

export const setHeld = (held: readonly number[]) => {
  HELD.clear();
  for (const gid of held) HELD.add(gid >>> 0);
};

export const anyHeld = () => HELD.size > 0;

export const isHeld = (gid: number) => HELD.size > 0 && HELD.has(gid >>> 0);
