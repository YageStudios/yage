import { planningSettlement, type PlanningContext } from "../../worldgen/commute/context";
import { feederChunks } from "../../worldgen/commute/feeders";
import { linesOf, transitIndex } from "../../worldgen/commute/network";
import { zoneOf } from "../../worldgen/commute/zones";
import { planChunk, type ChunkPlan } from "../../worldgen/population/planner";
import { Kind, SIDE_DX, SIDE_DY } from "../../worldgen/terrain/kinds";
import { type TransitLine } from "../../worldgen/transit";
import { chunkKey, keyX, keyY } from "../commute";
import { inWorld } from "../world";
import { driveIns } from "./drive-in";
import { FAR_CODE, HOME_CHUNK } from "./identity";
// ---------------------------------------------------------------------------------------------
// Commuters (atlas only): jobs in reach by walking and the lines (src/commute.ts)
/**
 * `wdir` values from here up name a far work chunk: FAR_CODE + k is the k-th of the home chunk's
 * far targets (`zoneOf`), every one a chunk a line calls in. Below are the four sides; HOME_CHUNK
 * is the home chunk itself.
 */
/** The chunk someone with workplace code `wdir` works in, from their home chunk: [cx, cy]. */
export const workChunkOf = (cx: number, cy: number, wdir: number, out: number[] = [0, 0], context: PlanningContext) => {
  if (wdir === HOME_CHUNK) {
    out[0] = cx;
    out[1] = cy;
  }
  else if (wdir < FAR_CODE) {
    out[0] = cx + SIDE_DX[wdir];
    out[1] = cy + SIDE_DY[wdir];
  }
  else {
    const key = zoneOf(context, cx, cy).targets[wdir - FAR_CODE];
    out[0] = keyX(key);
    out[1] = keyY(key);
  }
  return out;
};
/** Someone's way to work as their commute was planned: the line and the stops to board and leave at, or null to walk. */
export const commuteRoute = (plan: ChunkPlan, i: number, context: PlanningContext): {
  line: TransitLine;
  board: number;
  alight: number;
} | null => {
  const ride = plan.ride[i];
  if (!ride)
    return null;
  const index = transitIndex(context, plan.cx, plan.cy);
  const line = index && linesOf(context, index)[ride - 1];
  return line ? { line, board: plan.board[i], alight: plan.alight[i] } : null;
};
/**
 * Everyone who works in a chunk from far away ([home cx, home cy, index] triples), for the chunk's
 * own reckonings of who is about: those who come by tram or train (transitInbound), then the
 * chunk's drive-ins (drive-in.ts), each [cx, cy, index] of this chunk past its residents. Empty in
 * the legacy world.
 */
export const farInbound = (cx: number, cy: number, context: PlanningContext): Int32Array => {
  const cache = context.inbound;
  const key = chunkKey(cx, cy);
  let list = cache.get(key);
  if (list)
    return list;
  const transit = transitInbound(cx, cy, context);
  const drive = context.source?.personAddresses ? driveIns(cx, cy, context) : null;
  if (!drive?.count)
    list = transit;
  else {
    list = new Int32Array(transit.length + drive.count * 3);
    list.set(transit);
    for (let k = 0, at = transit.length;k < drive.count;k++, at += 3) {
      list[at] = cx;
      list[at + 1] = cy;
      list[at + 2] = drive.first + k;
    }
  }
  if (cache.size > 1024)
    cache.clear();
  cache.set(key, list);
  return list;
};
/** Everyone who works in a chunk and comes by tram or train ([home cx, home cy, index] triples). Empty without lines. */
export const transitInbound = (cx: number, cy: number, context: PlanningContext): Int32Array => {
  const index = transitIndex(context, cx, cy);
  if (!index)
    return EMPTY;
  const key = chunkKey(cx, cy);
  // A far job is always a walk from a stop by it, so only the home chunks by the stops whose lines
  // lead to one (the stop tables, read backwards) can have anyone working here; a chunk with no
  // stop near has none. Planning them is cheap: their places come from the plan, their jobs from
  // the shared fields.
  const out: number[] = [];
  const at = [0, 0];
  for (const hkey of feederChunks(context, cx, cy)) {
    const hcx = keyX(hkey);
    const hcy = keyY(hkey);
    if ((!context.source?.personAddresses && !inWorld(hcx, hcy)) || planningSettlement(context, hcx, hcy).kind === Kind.Rural)
      continue;
    if (!zoneOf(context, hcx, hcy).targets.includes(key))
      continue;
    const plan = planChunk(hcx, hcy, context);
    for (let i = 0;i < plan.count;i++) {
      if (plan.wdir[i] === HOME_CHUNK || plan.wdir[i] < FAR_CODE)
        continue;
      workChunkOf(hcx, hcy, plan.wdir[i], at, context);
      if (at[0] === cx && at[1] === cy)
        out.push(hcx, hcy, i);
    }
  }
  return out.length ? Int32Array.from(out) : EMPTY;
};
const EMPTY = new Int32Array(0);
