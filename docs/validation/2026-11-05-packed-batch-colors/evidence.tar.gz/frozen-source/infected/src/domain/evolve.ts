/**
 * Evolution rules, page side: which cards are in the pool, offers with their forced-pick timer,
 * the passive tree's adjacency and allocation, and the traits all of it adds up to. Pure and
 * deterministic (randomness is passed in); the data lives in mutations.ts.
 */
import { BASE_TRAITS, RULES, type Stat, type Traits } from "./disease";
import { CARDS, PATHOGENS, PROGRESSION, TREE_EDGES, TREE_NODES } from "../content/mutations";
import { type Card, type Effects, type PassiveNode } from "./mutation-types";
import { cardLines } from "../traits";

export type Evolution = {
  pathogen: string;
  /** Cards it picked up on its own (viruses' drift), counted so far; they are also in `cards`. */
  drifted?: number;
  /** Cards picked, in order. */
  cards: string[];
  /** Allocated passive nodes (the start node always). */
  nodes: string[];
  /** Offers settled so far (picked by the player or forced). */
  offersResolved: number;
};

export const newEvolution = (pathogen: string): Evolution => ({ pathogen, cards: [], nodes: ["root"], offersResolved: 0 });

const cardIndex = new Map(CARDS.map((c) => [c.id, c]));
const nodeIndex = new Map(TREE_NODES.map((n) => [n.id, n]));
export const cardById = (id: string) => cardIndex.get(id);
export const nodeById = (id: string) => nodeIndex.get(id);
export const pathogenById = (id: string) => PATHOGENS.find((p) => p.id === id);

// ---------------------------------------------------------------------------------------------
// Traits

const STATS = Object.keys(BASE_TRAITS).filter((k) => typeof (BASE_TRAITS as any)[k] === "number" && k !== "start") as Stat[];

/** Base traits with every effect applied: (base + Σ add) × Π mul, then raised to any max. */
export const combine = (base: Traits, effects: readonly Effects[]): Traits => {
  const out = { ...base };
  for (const stat of STATS) {
    let add = 0;
    let mul = 1;
    let floor = -Infinity;
    for (const fx of effects) {
      add += fx.add?.[stat] ?? 0;
      mul *= fx.mul?.[stat] ?? 1;
      const m = fx.max?.[stat];
      if (m !== undefined && m > floor) floor = m;
    }
    out[stat] = Math.max((base[stat] + add) * mul, floor);
  }
  return out;
};

/** What the workers run with: base, pathogen, picked cards and allocated nodes. */
export const traitsFor = (evo: Evolution, start = -1): Traits => {
  const effects: Effects[] = [];
  const pathogen = pathogenById(evo.pathogen);
  if (pathogen) effects.push(pathogen.fx);
  for (const id of evo.cards) {
    const card = cardById(id);
    if (card) effects.push(card.fx);
  }
  for (const id of evo.nodes) {
    const node = nodeById(id);
    if (node) effects.push(node.fx);
  }
  const t = combine(BASE_TRAITS, effects);
  // Compounding (prions): every card picked multiplies spread.
  t.infectivity *= (1 + t.cascade) ** evo.cards.length;
  t.armor = Math.min(0.9, Math.max(0, t.armor));
  t.aggression = Math.min(1, Math.max(0, t.aggression));
  t.frenzy = Math.max(-0.5, t.frenzy);
  t.visibility = Math.max(0.05, t.visibility);
  t.reach = Math.min(2, Math.round(t.reach));
  t.pathogen = evo.pathogen;
  t.start = start;
  return t;
};

// ---------------------------------------------------------------------------------------------
// Milestones

/** Evolution points needed for the k-th card offer (0-based), before the pathogen's pickRate. */
export const pickThreshold = (k: number) => {
  const list = PROGRESSION.pickAt;
  return k < list.length ? list[k] : list[list.length - 1] + (k - list.length + 1) * PROGRESSION.pickStep;
};

/** Card offers earned with this many evolution points. */
export const offersEarned = (points: number, pickRate = 1) => {
  let k = 0;
  while (pickThreshold(k) * pickRate <= points) k++;
  return k;
};

/** Points at which the next card offer arrives, from points earned (not offers settled), or null when no cards are left. */
export const nextOfferAt = (evo: Evolution, points: number, pickRate = 1): number | null =>
  cardPool(evo).length ? Math.round(pickThreshold(offersEarned(points, pickRate)) * pickRate) : null;

/** Advanced unlock points earned with this many people absorbed. */
export const unlockPointsEarned = (absorbed: number) => PROGRESSION.startAp + PROGRESSION.apAt.filter((at) => at <= absorbed).length;

export const nodeCost = (node: PassiveNode) => PROGRESSION.nodeCost[node.kind];
export const unlockPointsSpent = (evo: Evolution) => evo.nodes.reduce((sum, id) => sum + (nodeById(id) ? nodeCost(nodeById(id)!) : 0), 0);
/** Unlock points earned and not yet spent on the passive tree. */
export const unlockPointsLeft = (absorbed: number, evo: Evolution) => unlockPointsEarned(absorbed) - unlockPointsSpent(evo);

// ---------------------------------------------------------------------------------------------
// Card pool

/** Whether a card can be offered: right pathogen, its tree node allocated, and one `after` group fully picked. */
export const isUnlocked = (card: Card, evo: Evolution) => {
  if (card.pathogen && card.pathogen !== evo.pathogen) return false;
  if (card.node && !evo.nodes.includes(card.node)) return false;
  if (!card.after) return true;
  return card.after.some((group) => group.every((id) => evo.cards.includes(id)));
};

/** Cards that could be offered now. */
export const cardPool = (evo: Evolution) => CARDS.filter((card) => !evo.cards.includes(card.id) && isUnlocked(card, evo));

/** Cards that list this one in an `after` group (what picking it leads to). */
export const followUps = (id: string) => CARDS.filter((card) => card.after?.some((group) => group.includes(id)));

/** Cards a passive node opens. */
export const cardsOpenedBy = (nodeId: string) => CARDS.filter((card) => card.node === nodeId);

// ---------------------------------------------------------------------------------------------
// Offers: a forced pick on a timer

export type Offer = {
  cards: string[];
  /** Seconds (page clock). */
  opened: number;
  deadline: number;
  /** From here the auto-pick is shown. */
  revealAt: number;
  /** Index into `cards` that will be picked if the player doesn't: rolled when the offer opens. */
  auto: number;
};


export const offerPhase = (offer: Offer, now: number): "open" | "reveal" | "due" =>
  now >= offer.deadline ? "due" : now >= offer.revealAt ? "reveal" : "open";

/** An offer's cards: up to `offerSize` distinct cards from the pool, weighted, and the pre-rolled auto-pick (OfferTimer opens it). */
export const drawOffer = (evo: Evolution, random: () => number, now: number): Offer | null => {
  const pool = cardPool(evo).map((card) => ({ card, weight: (card.weight ?? 1) * (card.after ? PROGRESSION.followUpWeight : 1) }));
  const cards: string[] = [];
  while (cards.length < PROGRESSION.offerSize && pool.length) {
    const total = pool.reduce((sum, entry) => sum + entry.weight, 0);
    let roll = random() * total;
    let i = 0;
    while (i < pool.length - 1 && roll >= pool[i].weight) roll -= pool[i++].weight;
    cards.push(pool[i].card.id);
    pool.splice(i, 1);
  }
  if (!cards.length) return null;
  const deadline = now + RULES.offerSeconds;
  return {
    cards,
    opened: now,
    deadline,
    revealAt: deadline - RULES.offerSeconds * RULES.revealShare,
    auto: Math.min(cards.length - 1, Math.floor(random() * cards.length)),
  };
};

/** The card an offer settles on: the player's choice if given (and in the offer), else the pre-rolled card once its deadline has passed; null while it stays open. */
export const offerPick = (offer: Offer, now: number, choice?: string): string | null => {
  if (choice !== undefined) return offer.cards.includes(choice) ? choice : null;
  return now >= offer.deadline ? offer.cards[offer.auto] : null;
};


// ---------------------------------------------------------------------------------------------
// Passive tree

const links = new Map<string, string[]>();
for (const edge of TREE_EDGES) {
  const [a, b] = edge.split("-");
  if (!links.has(a)) links.set(a, []);
  if (!links.has(b)) links.set(b, []);
  links.get(a)!.push(b);
  links.get(b)!.push(a);
}
export const neighbours = (id: string) => links.get(id) ?? [];

/** A node can be allocated when it touches an allocated node and the points cover it. */
export const canAllocate = (evo: Evolution, id: string, pointsLeft: number) => {
  const node = nodeById(id);
  if (!node || evo.nodes.includes(id)) return false;
  if (nodeCost(node) > pointsLeft) return false;
  return neighbours(id).some((n) => evo.nodes.includes(n));
};

/** Whether a node touches the allocated region (whatever the points). */
export const isReachable = (evo: Evolution, id: string) => !evo.nodes.includes(id) && neighbours(id).some((n) => evo.nodes.includes(n));


// ---------------------------------------------------------------------------------------------
// Plain-language effect lines for cards and nodes

/** One plain line per effect, with whether it helps the infection (each trait's class has its own: traits/). */
export const describeEffects = (fx: Effects): { text: string; good: boolean }[] => cardLines(fx);

/**
 * The symptoms a picked card shows off on the host right away, as `Showcase` bits (1 cough,
 * 2 sneeze, 4 vomit, 8 touch, 16 bleed, 32 spores): those the card changes that the strain now has.
 */
export const showcaseMask = (card: Card, traits: Traits) => {
  const touches = (stat: Stat) => !!(card.fx.add?.[stat] || card.fx.mul?.[stat] || card.fx.max?.[stat]) && traits[stat] > 0;
  return (touches("cough") ? 1 : 0) | (touches("sneeze") ? 2 : 0) | (touches("vomit") ? 4 : 0) | (touches("touch") ? 8 : 0) | (touches("bleed") ? 16 : 0) | (touches("spores") ? 32 : 0);
};

// ---------------------------------------------------------------------------------------------
// Drift: viruses mutate on their own

/** Drift mutations due by this many game seconds into the outbreak at `perDay` (traits.drift). */
export const driftsDue = (seconds: number, perDay: number, daySeconds: number) => (perDay > 0 ? Math.floor((Math.max(0, seconds) * perDay) / daySeconds) : 0);

/**
 * The k-th drift mutation: a card from the pool (symptoms and transmissions only; abilities are
 * the player's), picked by hashing k with the pathogen. Pure in the evolution and k.
 */
export const driftPick = (evo: Evolution, k: number): Card | null => {
  const pool = cardPool(evo).filter((c) => c.kind !== "ability");
  if (!pool.length) return null;
  let h = Math.imul(k + 1, 0x9e3779b1) ^ Math.imul(evo.pathogen.length + 7, 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 15), 0x2c1b3c6d);
  h ^= h >>> 13;
  return pool[(h >>> 0) % pool.length];
};
