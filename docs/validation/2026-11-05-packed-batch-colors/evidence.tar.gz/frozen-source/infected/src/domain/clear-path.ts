import { TILE } from "./world";

/** Whether a straight walk from one point to another stays on open ground (sampled, cheap). */
export const clearPath = (open: (x: number, y: number) => boolean, x0: number, y0: number, x1: number, y1: number) => {
  const steps = Math.min(24, Math.ceil(Math.hypot(x1 - x0, y1 - y0) / (TILE * 0.9)));
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    if (!open(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)) return false;
  }
  return true;
};
