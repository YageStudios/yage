import { chunkKey } from "yage/streaming";
import type { PlanningContext } from "../../worldgen/commute/context";
import { chunkCached, chunkCurrent } from "../../worldgen/commute/chunk-cache";
import { planChunk } from "../../worldgen/population/planner";
import { SIDE_DX, SIDE_DY } from "../../worldgen/terrain/kinds";
import { gidFor, hash, inWorld } from "../world";
import { gidIndex, isDriveIn, Kin } from "./identity";
import { type PersonRef, personOf } from "./person";
/**
 * Grown children who moved out: some households' heads (and partners) come from an elderly
 * household in the same chunk or a neighbouring one. Pure, so both sides of the link agree.
 */
export const parentsOf = (cx: number, cy: number, gid: number, context: PlanningContext): {
  cx: number;
  cy: number;
  hh: number;
} | null => {
  if (hash(gid, 90) % 100 >= 45 || isDriveIn(gid, context))
    return null;
  const side = hash(gid, 91) % 10;
  const ox = side < 6 ? cx : cx + SIDE_DX[side % 4];
  const oy = side < 6 ? cy : cy + SIDE_DY[side % 4];
  if (!context.source?.personAddresses && !inWorld(ox, oy))
    return null;
  const elders = elderHouseholds(ox, oy, context);
  if (!elders.length)
    return null;
  const hh = elders[hash(gid, 92) % elders.length];
  // Only when the ages work out (parents 18–45 years older); both directions of the link ask this.
  const mine = planChunk(cx, cy, context);
  const age = mine.age[gidIndex(gid, context)];
  const op = planChunk(ox, oy, context);
  let oldest = 0;
  for (let i = op.hhFirst[hh];i < op.hhFirst[hh] + op.hhSize[hh];i++)
    oldest = Math.max(oldest, op.age[i]);
  const gap = oldest - age;
  if (age >= 60 || gap < 18 || gap > 45)
    return null;
  return { cx: ox, cy: oy, hh };
};
/** Households of one or two people over 60 with nobody younger: parents whose children left. */
const elderHouseholds = (cx: number, cy: number, context: PlanningContext) => {
  const key = chunkKey(cx, cy);
  let list = context.elders.get(key);
  if (list && chunkCurrent(context, cx, cy, list))
    return list;
  const plan = planChunk(cx, cy, context);
  list = [];
  for (let hh = 0;hh < plan.hhSize.length;hh++) {
    const size = plan.hhSize[hh];
    if (!size || size > 2)
      continue;
    let old = true;
    for (let i = plan.hhFirst[hh];i < plan.hhFirst[hh] + size;i++)
      if (plan.age[i] < 60)
        old = false;
    if (old)
      list.push(hh);
  }
  if (context.elders.size > 64)
    context.elders.delete(context.elders.keys().next().value!);
  context.elders.set(key, chunkCached(context, cx, cy, list));
  return list;
};
const ref = (gid: number, relation: string, context: PlanningContext): PersonRef | null => {
  const p = personOf(gid, context);
  return p ? { gid, name: p.name, relation, cx: p.cx, cy: p.cy } : null;
};
const label = (sex: number, male: string, female: string) => (sex ? female : male);
/** Family: household members by relation, plus parents, siblings and grown children elsewhere. */
export const relativesOf = (gid: number, context: PlanningContext): PersonRef[] => {
  const me = personOf(gid, context);
  if (!me)
    return [];
  const { cx, cy, index } = me;
  const plan = planChunk(cx, cy, context);
  // A drive-in (drive-in.ts): their family is out of town.
  if (index >= plan.count)
    return [];
  const hh = plan.household[index];
  const kin = plan.kin[index] as Kin;
  const out: PersonRef[] = [];
  const add = (r: PersonRef | null) => r && r.gid !== gid && !out.some((o) => o.gid === r.gid) && out.push(r);
  const first = plan.hhFirst[hh];
  const size = plan.hhSize[hh];
  for (let i = first;i < first + size;i++) {
    if (i === index)
      continue;
    const other = gidFor(cx, cy, i, context);
    const k = plan.kin[i] as Kin;
    const sx = plan.sex[i];
    let relation = "housemate";
    if (kin === Kin.Head || kin === Kin.Partner) {
      if (k === Kin.Head || k === Kin.Partner)
        relation = label(sx, "husband", "wife");
      else if (k === Kin.Child)
        relation = label(sx, "son", "daughter");
      else
        relation = kin === Kin.Head ? label(sx, "father", "mother") : label(sx, "father-in-law", "mother-in-law");
    }
    else if (kin === Kin.Child) {
      if (k === Kin.Head || k === Kin.Partner)
        relation = label(sx, "father", "mother");
      else if (k === Kin.Child)
        relation = label(sx, "brother", "sister");
      else
        relation = label(sx, "grandfather", "grandmother");
    }
    else {
      if (k === Kin.Head)
        relation = label(sx, "son", "daughter");
      else if (k === Kin.Partner)
        relation = label(sx, "son-in-law", "daughter-in-law");
      else if (k === Kin.Child)
        relation = label(sx, "grandson", "granddaughter");
      else
        relation = label(sx, "husband", "wife");
    }
    add(ref(other, relation, context));
  }
  // Parents in another household, and siblings who also left that household.
  if (kin === Kin.Head || kin === Kin.Partner) {
    const origin = parentsOf(cx, cy, gid, context);
    if (origin) {
      const op = planChunk(origin.cx, origin.cy, context);
      for (let i = op.hhFirst[origin.hh];i < op.hhFirst[origin.hh] + op.hhSize[origin.hh];i++) {
        add(ref(gidFor(origin.cx, origin.cy, i, context), label(op.sex[i], "father", "mother"), context));
      }
      for (const child of childrenOf(origin.cx, origin.cy, origin.hh, context)) {
        const p = personOf(child, context);
        if (p)
          add(ref(child, p.sex === "female" ? "sister" : "brother", context));
      }
    }
  }
  // Grown children (and their children) living elsewhere.
  if (size <= 2 && elderHouseholds(cx, cy, context).includes(hh)) {
    for (const child of childrenOf(cx, cy, hh, context)) {
      const p = personOf(child, context);
      if (!p)
        continue;
      add(ref(child, p.sex === "female" ? "daughter" : "son", context));
      const cp = planChunk(p.cx, p.cy, context);
      const chh = cp.household[p.index];
      for (let i = cp.hhFirst[chh];i < cp.hhFirst[chh] + cp.hhSize[chh];i++) {
        if (cp.kin[i] === Kin.Child)
          add(ref(gidFor(p.cx, p.cy, i, context), label(cp.sex[i], "grandson", "granddaughter"), context));
      }
    }
  }
  return out;
};
/** Heads and partners in this chunk and its neighbours whose parents are household `hh`. */
const childrenOf = (cx: number, cy: number, hh: number, context: PlanningContext) => {
  const out: number[] = [];
  for (let d = -1;d < 4;d++) {
    const ox = d < 0 ? cx : cx + SIDE_DX[d];
    const oy = d < 0 ? cy : cy + SIDE_DY[d];
    if (!context.source?.personAddresses && !inWorld(ox, oy))
      continue;
    const plan = planChunk(ox, oy, context);
    for (let i = 0;i < plan.count;i++) {
      const k = plan.kin[i];
      if (k !== Kin.Head && k !== Kin.Partner)
        continue;
      const g = gidFor(ox, oy, i, context);
      const origin = parentsOf(ox, oy, g, context);
      if (origin && origin.cx === cx && origin.cy === cy && origin.hh === hh)
        out.push(g);
    }
  }
  return out;
};
