import { CONTENT } from "../../content/runtime";
import { type PlanningContext, planningLayout, planningSettlement } from "../../worldgen/commute/context";
import { type ChunkPlan, planChunk } from "../../worldgen/population/planner";
import { PlaceKind } from "../../worldgen/terrain/kinds";
import { placeKindNamed } from "../kinds";
import { gidFor, hash } from "../world";
import { type Culture, cultureOf } from "./culture";
import { driveIns } from "./drive-in";
import { gidChunkX, gidChunkY, gidIndex, HOME_CHUNK, Kin, LifeRole, NONE } from "./identity";
import { workChunkOf } from "./jobs";
import { parentsOf } from "./relatives";
import { TRAIT_INFO, traitsOf } from "./traits";
// ---------------------------------------------------------------------------------------------
// Names, occupations, relatives
const pick = <T>(list: T[], h: number) => list[h % list.length];
/** Worker occupations by workplace kind (content/occupations.json5 names the kinds). */
const OCCUPATIONS: Partial<Record<PlaceKind, string[]>> = Object.fromEntries(Object.entries(CONTENT.occupations.byPlace).map(([kind, names]) => [placeKindNamed(kind), names]));
const L = CONTENT.occupations.labels;
export type PersonRef = {
  gid: number;
  name: string;
  relation: string;
  cx: number;
  cy: number;
};
export type Person = {
  gid: number;
  cx: number;
  cy: number;
  index: number;
  first: string;
  surname: string;
  name: string;
  age: number;
  sex: "male" | "female";
  role: LifeRole;
  occupation: string;
  /** Where they work, learn or farm: chunk and place index, or null. */
  workplace: {
    cx: number;
    cy: number;
    place: number;
    kind: PlaceKind;
  } | null;
  /** Where they live: null for a drive-in, who lives out of the loaded world (drive-in.ts). */
  home: {
    cx: number;
    cy: number;
    place: number;
    kind: PlaceKind;
    storey: number;
  } | null;
  traits: string[];
  traitBits: number;
  culture: Culture;
  household: number;
};
/** Surname a household goes by: from the head's side. */
const householdSurname = (culture: Culture, plan: ChunkPlan, hh: number, context: PlanningContext): string => {
  // The head's family name: from their parents' household when it is known.
  const origin = plan.hhSize[hh] ? parentsOf(plan.cx, plan.cy, gidFor(plan.cx, plan.cy, plan.hhFirst[hh], context), context) : null;
  if (origin)
    return householdSurname(cultureOf(origin.cx, origin.cy, context), planChunk(origin.cx, origin.cy, context), origin.hh, context);
  return pick(culture.surnames, hash(plan.cx, plan.cy, hh, 81));
};
/** Everything about someone, from their gid alone. Null for gids nobody was generated with. */
export const personOf = (gid: number, context: PlanningContext): Person | null => {
  const cached = context.people.get(gid);
  if (cached)
    return cached;
  const cx = gidChunkX(gid, context);
  const cy = gidChunkY(gid, context);
  const index = gidIndex(gid, context);
  if (!Number.isInteger(cx) || !Number.isInteger(cy) || index < 0) return null;
  const plan = planChunk(cx, cy, context);
  // Past the chunk's residents: its drive-ins (drive-in.ts), each a household of their own from out of town.
  const drive = index >= plan.count ? driveIns(cx, cy, context) : null;
  const k = drive ? index - drive.first : -1;
  if ((drive && k >= drive.count) || gidFor(cx, cy, index, context) !== gid)
    return null;
  const culture = cultureOf(cx, cy, context);
  const layout = planningLayout(context, cx, cy);
  const hh = drive ? plan.hhSize.length + k : plan.household[index];
  const kin = drive ? Kin.Head : plan.kin[index] as Kin;
  const sex = drive ? drive.sex[k] : plan.sex[index];
  const age = drive ? drive.age[k] : plan.age[index];
  const first = pick(sex ? culture.female : culture.male, hash(gid, 82));
  // Partners and children take the household name; a grandparent keeps their own half the time.
  const surname = kin === Kin.Grandparent && hash(gid, 83) & 1 ? pick(culture.surnames, hash(gid, 84)) : householdSurname(culture, plan, hh, context);
  const role = drive ? LifeRole.Worker : plan.role[index] as LifeRole;
  const work = drive ? drive.work[k] : plan.work[index];
  const wdir = drive ? HOME_CHUNK : plan.wdir[index];
  const [wcx, wcy] = workChunkOf(cx, cy, wdir, [0, 0], context);
  const workPlace = work !== NONE ? planningLayout(context, wcx, wcy).places[work] : undefined;
  const homePlace = drive ? undefined : layout.places[plan.home[index]];
  const bits = traitsOf(gid);
  const person: Person = {
    gid,
    cx,
    cy,
    index,
    first,
    surname,
    name: `${first} ${surname}`,
    age,
    sex: sex ? "female" : "male",
    role,
    occupation: occupationOf(role, workPlace?.kind, age, planningSettlement(context, cx, cy).biome, gid, plan, hh),
    workplace: workPlace ? { cx: wcx, cy: wcy, place: work, kind: workPlace.kind } : null,
    home: homePlace ? { cx, cy, place: plan.home[index], kind: homePlace.kind, storey: Math.floor(plan.slot[index] / Math.max(1, homePlace.beds)) } : null,
    traits: TRAIT_INFO.filter(([bit]) => bits & bit).map(([, name]) => name),
    traitBits: bits,
    culture,
    household: hh,
  };
  if (context.people.size > 256)
    context.people.delete(context.people.keys().next().value!);
  context.people.set(gid, person);
  return person;
};
const occupationOf = (role: LifeRole, kind: PlaceKind | undefined, age: number, biome: number, gid: number, plan: ChunkPlan, hh: number) => {
  switch (role) {
    case LifeRole.Infant:
      return age < 2 ? L.baby : L.toddler;
    case LifeRole.Child:
      return kind === PlaceKind.School ? L.pupil : L.farmChild;
    case LifeRole.Elder:
      return L.retired;
    case LifeRole.Farmer:
      return pick(CONTENT.occupations.farm[biome === 1 || biome === 2 ? biome : 0], gid);
    case LifeRole.Idle: {
      let kids = false;
      for (let i = plan.hhFirst[hh];i < plan.hhFirst[hh] + plan.hhSize[hh];i++)
        if (plan.age[i] < 18)
          kids = true;
      return kids ? L.homemaker : L.betweenJobs;
    }
    default:
      return kind !== undefined && OCCUPATIONS[kind] ? pick(OCCUPATIONS[kind]!, hash(gid, 85)) : L.labourer;
  }
};
