/**
 * The cast: people a scenario follows by name (the solver's protagonist, everyone a beat names),
 * kept as records alongside the cold tier without making their chunks warm. A cast person in a cold
 * cell's counts is one of its cohort: each cold step the cohort's counts move exactly as they would
 * without them (domain/cold/step.ts, its `moves`), and the cast's own moves are a sample of the
 * cohort's, rank-coupled: of the c cast people in a stage that n people were in and k left, those
 * whose draw u (hashed on the seed, the person, the tick and the stage) is under k/n move on, the
 * lowest draws first, at least c - (n - k) and at most k of them. So the cast never holds more of
 * a stage than the cell does, and a run with a cast steps the same counts as one without.
 *
 * A stage is a bucket: the susceptible, the incubating by stage, the bloomed by stage, the dead
 * (and on from the dead, the first bloomed stage: a strain that breeds has young in their homes).
 */
import { State } from "../disease";
import { unitOf } from "./draws";
import { STAGES } from "./step";

/**
 * Who holds a cast person now: their cell's counts, a cell by name (an override), a warm chunk as a
 * person, or nobody's cells: walking cold on a directive (the directives' walkers, services/directives.ts).
 */
export const enum CastOwner {
  Cold = 0,
  Named = 1,
  Warm = 2,
  Walking = 3,
}

/** One person the scenario follows (components/cold/CastRecords.ts). */
export type CastRecord = {
  gid: number;
  /** Their home chunk's key. */
  home: number;
  /** State (domain/disease.ts), and the stage of it as the cold tier counts them. */
  state: number;
  stage: number;
  owner: CastOwner;
  /** The chunk's key where they are, as of `seen`. */
  at: number;
  /** The tick their state last changed (-1: as cast). */
  since: number;
  /** The tick `at` and `state` were last known. */
  seen: number;
};

export const BUCKETS = 2 + 2 * STAGES;
const DEAD = BUCKETS - 1;

/** A state and stage as a bucket: 0 susceptible, the incubating, the bloomed, then the dead. */
export const bucketOf = (state: number, stage: number) => {
  if (state === State.Incubating) return 1 + stage;
  if (state === State.Infected) return 1 + STAGES + stage;
  if (state === State.Dead) return DEAD;
  return 0;
};

/** A bucket as [state, stage]. */
export const stateOf = (bucket: number): [number, number] => {
  if (bucket === 0) return [State.Susceptible, 0];
  if (bucket === DEAD) return [State.Dead, 0];
  if (bucket <= STAGES) return [State.Incubating, bucket - 1];
  return [State.Infected, bucket - 1 - STAGES];
};

/** The cast pinned in `cell`'s counts (ColdInit pins): gid, state, stage triples, by gid. */
export const castPins = (records: readonly CastRecord[] | null, cell: { key: number }) => {
  const pins: number[] = [];
  for (const r of records ?? []) if (r.owner === CastOwner.Cold && r.home === cell.key) pins.push(r.gid, r.state, r.stage);
  return pins;
};

/** A cell's count in `bucket`. */
export const countIn = (cell: { s: number; e: readonly number[]; i: readonly number[]; d: number }, bucket: number) => {
  if (bucket === 0) return cell.s;
  if (bucket === DEAD) return cell.d;
  if (bucket <= STAGES) return cell.e[bucket - 1];
  return cell.i[bucket - 1 - STAGES];
};

/** What a cold step moved in one cell: `k` of the `n` in `from` on to the next bucket, in sub-step `sub`. */
export type Move = { sub: number; from: number; n: number; k: number };

const PURPOSE = 0x4000_0000;
const SPAN = 0x40;

/**
 * The cast people of one cell's counts (gid, bucket) after a step that made `moves` (in the order
 * the step drew them): each sub-step's moves are drawn from the buckets it began with, then taken.
 * Changes `members` in place; returns whether anyone moved.
 */
export const coupleMoves = (members: { gid: number; bucket: number }[], moves: readonly Move[], seed: number, tick: number) => {
  let moved = false;
  for (let m = 0;m < moves.length;) {
    const sub = moves[m].sub;
    const going: { gid: number; bucket: number }[] = [];
    for (;m < moves.length && moves[m].sub === sub;m++) {
      const { from, n, k } = moves[m];
      if (k <= 0 || n <= 0) continue;
      const here = members.filter((p) => p.bucket === from);
      if (!here.length) continue;
      const drawn = here.map((p) => ({ p, u: unitOf(seed, p.gid, tick, PURPOSE + sub * SPAN + from) })).sort((a, b) => a.u - b.u || a.p.gid - b.p.gid);
      const share = k / n;
      let count = drawn.filter((d) => d.u < share).length;
      count = Math.max(Math.max(0, here.length - (n - k)), Math.min(count, here.length, k));
      for (let q = 0;q < count;q++) going.push(drawn[q].p);
    }
    // The dead move on to the first bloomed stage (born into their homes: domain/cold/step.ts).
    for (const p of going) p.bucket = p.bucket === DEAD ? 1 + STAGES : p.bucket + 1;
    if (going.length) moved = true;
  }
  return moved;
};
