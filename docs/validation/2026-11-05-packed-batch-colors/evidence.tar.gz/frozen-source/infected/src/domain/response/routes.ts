/**
 * Animal and water routes, page side: each town's animal reservoir (`fauna`: the share of its
 * rats, birds, livestock, strays and mosquitoes that carry the strain, before the strain's per-kind level) and how
 * fouled its water supply is (`water`). Both follow the town's sick and dead, rise and fade with
 * closed-form relaxations, and go to the chunk hosts as extra series on mech1's town response
 * (measures.ts), so what a chunk does with them is a pure function of the tick.
 *
 * Birds also carry the reservoir between linked towns (roads, transit, the same links news takes),
 * which is how Bird II seeds towns no traveller has reached.
 */
import { CONTENT } from "../../content/runtime";
import type { Traits } from "../disease";
import { TICK_RATE } from "../world";
import { valueAt, type TownResponse } from "./measures";

/** The numbers are data (content/response.json5). */
export const ROUTES = CONTENT.response.routes;

/**
 * Advances the reservoirs and water to the response's tick (call right after stepWorldResponse,
 * with that step's dt in seconds). Returns whether the shared state grew.
 */

/** A town's animal reservoir and water fouling at a tick (0 when unknown). */
export const routesOf = (town: TownResponse | undefined, tick: number) => ({
  fauna: valueAt(town?.fauna as [number, number][] | undefined, tick),
  water: valueAt(town?.water as [number, number][] | undefined, tick),
  /** Its walls (0–1), which keep its feral animals out: the pond's, sent with the reservoir. */
  walls: valueAt(town?.walls as [number, number][] | undefined, tick),
});

/** Seconds between two ticks (for stepRoutes' dt). */
export const secondsBetween = (from: number, to: number) =>
  Math.max(0, (to - from) / TICK_RATE);

/** Integrates one town; the owning system controls phase order and iteration. */

export const routesActive = (
  traits: Pick<Traits, "rodent" | "bird" | "livestock" | "water"> &
    Partial<Pick<Traits, "dog" | "mosquito" | "beasts">>,
  towns: readonly { fauna: number; water: number }[]
) =>
  traits.rodent +
    traits.bird +
    traits.livestock +
    (traits.dog ?? 0) +
    (traits.mosquito ?? 0) +
    (traits.beasts ?? 0) +
    traits.water >
    0 ||
  towns.some((town) => town.fauna !== 0) ||
  towns.some((town) => town.water !== 0);
