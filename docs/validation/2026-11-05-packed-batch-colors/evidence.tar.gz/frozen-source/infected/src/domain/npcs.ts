/**
 * NPC archetypes (src/entities/npc.json5): one entity definition per LifeRole, each inheriting
 * `npc`, which carries every sim schema. The sim compiles one per archetype and spawns people by
 * their plan's role; per-person values are set procedurally after.
 */
import type { EntityDefinition, FlexibleEntityDefinition } from "yage/entity/definitions";
import { definition, RAW_DEFINITIONS } from "../content/definitions";
import type { LifeRole } from "./people/identity";
const ROLE_NAMES = ["worker", "farmer", "night", "child", "elder", "idle", "parent", "infant"] as const;
/** The archetype definition name for a role ("npc:worker", ...). */
export const archetypeName = (role: LifeRole): string => `npc:${ROLE_NAMES[role]}`;
/** Resolved archetypes, in LifeRole order. */
export const NPC_ARCHETYPES: EntityDefinition[] = ROLE_NAMES.map((_, role) => definition(archetypeName(role as LifeRole)));
/** The raw NPC definitions (base and archetypes), for a registry of their own (e.g. in a chunk worker). */
export const NPC_DEFINITIONS: FlexibleEntityDefinition[] = RAW_DEFINITIONS.filter((d) => d.name === "npc" || d.name.startsWith("npc:"));
