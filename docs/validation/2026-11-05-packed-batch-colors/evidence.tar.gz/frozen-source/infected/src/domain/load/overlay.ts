/** The snapshot overlay byte protocol; preserves the existing packet layout. */
import type { ViralEmission } from "../../components/sim/ViralEmission";
import { Emit, Stain } from "./constants";
import type { LabReport } from "../../simlab/protocol";
import type { BuildingMoment } from "../building-events";
export type Emission = ViralEmission;

export type Overlay = {
  people: { slot: number; load: number }[];
  surfaces: { tile: number; value: number; kind: Stain }[];
  emits: Emission[];
  /**
   * Objects mode: who is lying (pose 1) or sitting (pose 2), and which way (radians, clockwise from
   * +x: a sleeper's head-to-foot axis, a sitter's facing), from life.ts posesOf. Missing = all stand.
   */
  poses?: { slot: number; pose: number; angle: number }[];
  /** The simulation lab's report for this chunk (src/simlab/protocol.ts), when it has staged here. */
  lab?: LabReport;
  /** What buildings nobody sees into showed and sounded since the last snapshot (BuildingEventsSystem). */
  buildings?: BuildingMoment[];
};

const clampByte = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
const clampI8 = (v: number) => Math.max(-127, Math.min(127, Math.round(v)));
const angleByte = (a: number) => (Math.round((a / (Math.PI * 2)) * 256) % 256 + 256) % 256;

export const encodeOverlay = (overlay: Overlay) => {
  const poses = overlay.poses ?? [];
  // The lab's report goes last, as JSON with its length; the poses' count is written before it even when there are none.
  // Then the building events, after a lab length (0: no report) even when there is none.
  const lab = overlay.lab ? new TextEncoder().encode(JSON.stringify(overlay.lab)) : null;
  const buildings = overlay.buildings ?? [];
  const tail = buildings.length > 0;
  const size = 6 + overlay.people.length * 3 + overlay.surfaces.length * 4 + overlay.emits.length * 11 + (poses.length || lab || tail ? 2 + poses.length * 4 : 0) + (lab || tail ? 4 + (lab?.length ?? 0) : 0) + (tail ? 2 + buildings.length * 6 : 0);
  const bytes = new Uint8Array(size);
  const view = new DataView(bytes.buffer);
  let at = 0;
  view.setUint16(at, overlay.people.length, true);
  at += 2;
  for (const p of overlay.people) {
    view.setUint16(at, p.slot, true);
    bytes[at + 2] = clampByte(p.load * 255);
    at += 3;
  }
  view.setUint16(at, overlay.surfaces.length, true);
  at += 2;
  for (const s of overlay.surfaces) {
    view.setUint16(at, s.tile, true);
    bytes[at + 2] = clampByte(s.value * 255);
    bytes[at + 3] = s.kind;
    at += 4;
  }
  view.setUint16(at, overlay.emits.length, true);
  at += 2;
  for (const e of overlay.emits) {
    bytes[at] = e.kind;
    view.setUint16(at + 1, e.slot, true);
    view.setInt16(at + 3, Math.round(e.x), true);
    view.setInt16(at + 5, Math.round(e.y), true);
    view.setInt8(at + 7, clampI8(e.vx));
    view.setInt8(at + 8, clampI8(e.vy));
    bytes[at + 9] = angleByte(e.angle);
    bytes[at + 10] = clampByte(e.age);
    at += 11;
  }
  if (poses.length || lab || tail) {
    view.setUint16(at, poses.length, true);
    at += 2;
    for (const p of poses) {
      view.setUint16(at, p.slot, true);
      bytes[at + 2] = p.pose;
      bytes[at + 3] = angleByte(p.angle);
      at += 4;
    }
  }
  if (lab || tail) {
    view.setUint32(at, lab?.length ?? 0, true);
    if (lab) bytes.set(lab, at + 4);
    at += 4 + (lab?.length ?? 0);
  }
  if (tail) {
    view.setUint16(at, buildings.length, true);
    at += 2;
    for (const b of buildings) {
      bytes[at] = b.kind;
      view.setInt16(at + 1, Math.max(-32768, Math.min(32767, Math.round(b.x))), true);
      view.setInt16(at + 3, Math.max(-32768, Math.min(32767, Math.round(b.y))), true);
      bytes[at + 5] = clampByte(b.arg);
      at += 6;
    }
  }
  return bytes;
};

export const decodeOverlay = (bytes: Uint8Array): Overlay => {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let at = 0;
  const people: Overlay["people"] = [];
  const surfaces: Overlay["surfaces"] = [];
  const emits: Emission[] = [];
  const n = view.getUint16(at, true);
  at += 2;
  for (let i = 0; i < n; i++, at += 3) people.push({ slot: view.getUint16(at, true), load: bytes[at + 2] / 255 });
  const m = view.getUint16(at, true);
  at += 2;
  for (let i = 0; i < m; i++, at += 4) surfaces.push({ tile: view.getUint16(at, true), value: bytes[at + 2] / 255, kind: bytes[at + 3] as Stain });
  const k = view.getUint16(at, true);
  at += 2;
  for (let i = 0; i < k; i++, at += 11) {
    emits.push({
      kind: bytes[at] as Emit,
      slot: view.getUint16(at + 1, true),
      x: view.getInt16(at + 3, true),
      y: view.getInt16(at + 5, true),
      vx: view.getInt8(at + 7),
      vy: view.getInt8(at + 8),
      angle: (bytes[at + 9] / 256) * Math.PI * 2,
      age: bytes[at + 10],
    });
  }
  if (at + 2 > bytes.byteLength) return { people, surfaces, emits };
  const poses: NonNullable<Overlay["poses"]> = [];
  const q = view.getUint16(at, true);
  at += 2;
  for (let i = 0; i < q; i++, at += 4) poses.push({ slot: view.getUint16(at, true), pose: bytes[at + 2], angle: (bytes[at + 3] / 256) * Math.PI * 2 });
  if (at + 4 > bytes.byteLength) return { people, surfaces, emits, poses };
  const length = view.getUint32(at, true);
  const lab = length ? (JSON.parse(new TextDecoder().decode(bytes.subarray(at + 4, at + 4 + length))) as LabReport) : undefined;
  at += 4 + length;
  const out: Overlay = { people, surfaces, emits, poses };
  if (lab) out.lab = lab;
  if (at + 2 > bytes.byteLength) return out;
  const c = view.getUint16(at, true);
  at += 2;
  const buildings: BuildingMoment[] = [];
  for (let i = 0; i < c; i++, at += 6) buildings.push({ kind: bytes[at], x: view.getInt16(at + 1, true), y: view.getInt16(at + 3, true), arg: bytes[at + 5] });
  out.buildings = buildings;
  return out;
};

/**
 * Host input: [dx+1, dy+1, mask, pick tick as u32 LE], and where the page has walked the host
 * (HostBody), when it has: [world x as f32 LE, world y as f32 LE] from byte 7. The input is
 * re-applied every step, so the pick tick tells a fresh pick from one already played (mask 0: no
 * showcase). Two bytes alone are a direction (the AI's, a replay's of an old journal).
 */
export const showcaseBytes = (dx: number, dy: number, mask: number, tick: number, at?: { x: number; y: number } | null) => {
  const bytes = new Uint8Array(at ? 15 : 7);
  bytes[0] = dx + 1;
  bytes[1] = dy + 1;
  bytes[2] = mask;
  const view = new DataView(bytes.buffer);
  view.setUint32(3, Math.max(0, tick) >>> 0, true);
  if (at) {
    view.setFloat32(7, at.x, true);
    view.setFloat32(11, at.y, true);
  }
  return bytes;
};
export const showcaseOf = (bytes: Uint8Array) =>
  bytes.length >= 7 && bytes[2] ? { mask: bytes[2], tick: new DataView(bytes.buffer, bytes.byteOffset).getUint32(3, true) } : null;
/** Where the page has walked the host (world units), if the input says. */
export const hostAtOf = (bytes: Uint8Array) => {
  if (bytes.length < 15) return null;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  return { x: view.getFloat32(7, true), y: view.getFloat32(11, true) };
};
