import { chunkKey } from "yage/streaming";
import { CONTENT } from "../../content/runtime";
import { BLOCK } from "../../worldgen/terrain/kinds";
import { planningSettlement, type PlanningContext } from "../../worldgen/commute/context";
import { hash } from "../world";
import { gidChunkX, gidChunkY } from "./identity";
// ---------------------------------------------------------------------------------------------
// Cultures: one per settlement block, leaning on the block's biome.
export type Culture = {
  id: number;
  name: string;
  male: string[];
  female: string[];
  surnames: string[];
  /** Dress style hint for looks (index into DRESS_STYLES), and its description. */
  dress: number;
  dressText: string;
  /** Day of the 7-day week nobody works (0–6). */
  restDay: number;
  festival: {
    name: string;
    every: number;
    offset: number;
  };
  diet: string;
};
/** Dress styles, by index (content/dress.json5). */
export const DRESS_STYLES: string[] = CONTENT.dress;
/** Cultures, by id (content/cultures.json5). */
export const CULTURES: Culture[] = CONTENT.cultures;
/** The culture of a chunk: shared by its settlement block, two candidates per biome. */
export const cultureOf = (cx: number, cy: number, context: PlanningContext): Culture => {
  const bx = Math.floor(cx / BLOCK);
  const by = Math.floor(cy / BLOCK);
  const key = chunkKey(bx, by);
  let id = context.cultures.get(key);
  if (id === undefined) {
    const biome = planningSettlement(context, bx * BLOCK + 1, by * BLOCK + 1).biome;
    id = biome * 2 + (hash(bx, by, 97) & 1);
    // Biome 0 farmland → Vale/Riviere, 1 woods → Nordmark/Zemlya, 2 savanna → Sahel/Qasr.
    context.cultures.set(key, id);
  }
  return CULTURES[id];
};
export const isRestDay = (culture: Culture, day: number) => ((day % 7) + 7) % 7 === culture.restDay;
export const isFestival = (culture: Culture, day: number) => ((day % culture.festival.every) + culture.festival.every) % culture.festival.every === culture.festival.offset;
/** The dress style index for someone's looks (for the art's `rollLook`). */
export const dressOf = (gid: number, context: PlanningContext) => cultureOf(gidChunkX(gid, context), gidChunkY(gid, context), context).dress;
