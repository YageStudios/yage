/**
 * Pure helpers for the Outbreak tab: each town's status word, a sampled history for sparklines
 * that never grows past a fixed size (it halves its resolution instead), sparkline points, and the
 * strain's spread routes ranked by how strongly they carry it now.
 *
 * Once anyone has caught it, the routes are real shares: the sim tallies each new infection by the
 * route that gave the most load (services/tally.ts, `__infected.spreadTally`) and `routeShares` turns
 * that into each route's share. Before that, `spreadRoutes` ranks them off the strain's traits
 * (breath, coughs, surfaces, animal and water levels), the towns' animal reservoirs and water
 * fouling, and the jumps between settlements.
 */
import type { Traits } from "./disease";
import type { Collapse } from "./response/collapse";

export type Tone = "red" | "amber" | "green" | "dark" | "";
export type TownStatus = { label: string; tone: Tone };

const LEVEL_WORDS = ["", "masks", "closures", "curfew", "lockdown", "checkpoints"];

/** One word for where a town stands, the gravest first. */
export const townStatus = (level: number, c: Collapse, alert: number, reached: boolean): TownStatus => {
  if (c.firebombed !== null) return { label: "firebombed", tone: "dark" };
  if (c.walled !== null) return { label: "walled", tone: "dark" };
  if (c.evac !== null) return { label: "evac", tone: "red" };
  if (c.fallen !== null) return { label: "fallen", tone: "green" };
  if (c.border > 0) return { label: "sealed", tone: "red" };
  if (level > 0) return { label: LEVEL_WORDS[Math.min(level, LEVEL_WORDS.length - 1)], tone: level >= 4 ? "red" : "amber" };
  if (alert > 0) return { label: "alert", tone: "amber" };
  return reached ? { label: "spreading", tone: "green" } : { label: "quiet", tone: "" };
};

/** A bounded sample history: one value per `step` seconds; when full it drops every other sample and doubles the step. */
export type History = { values: number[]; step: number; at: number; cap: number };
export const newHistory = (cap = 64, step = 2): History => ({ values: [], step, at: -Infinity, cap });

export const pushSample = (h: History, value: number, seconds: number) => {
  if (seconds - h.at < h.step) return false;
  h.at = seconds;
  h.values.push(value);
  if (h.values.length >= h.cap) {
    h.values = h.values.filter((_, i) => i % 2 === 1);
    h.step *= 2;
  }
  return true;
};

/** SVG polyline points for values in a w×h box, scaled to their own peak (or `max`), baseline at the bottom. */
export const sparkPoints = (values: readonly number[], w: number, h: number, max?: number) => {
  if (values.length === 0) return "";
  const top = Math.max(max ?? 0, ...values, 1e-9);
  const n = values.length;
  const pad = 1;
  return values
    .map((v, i) => {
      const x = n === 1 ? w : (i / (n - 1)) * w;
      const y = h - pad - (Math.max(0, v) / top) * (h - 2 * pad);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
};

export type Route = { id: string; label: string; icon: string; strength: number; detail: string };

const clamp = (v: number) => Math.max(0, Math.min(1, v));

/**
 * The strain's routes, strongest first (routes with no strength left out).
 * @param fauna the worst town's animal reservoir (0–1) @param water the worst town's water fouling (0–1)
 */
export const spreadRoutes = (t: Traits, fauna: number, water: number, jumps: number, places: number): Route[] => {
  const animals = t.rodent + t.bird + t.livestock + (t.dog ?? 0) + (t.mosquito ?? 0);
  const kinds = (
    [
      ["rats", t.rodent],
      ["birds", t.bird],
      ["livestock", t.livestock],
      ["dogs", t.dog ?? 0],
      ["mosquitoes", t.mosquito ?? 0],
    ] as const
  )
    .filter(([, v]) => v > 0)
    .map(([k]) => k);
  const airborne = t.cough + t.sneeze + 2 * t.spores;
  const routes: Route[] = [
    { id: "contact", label: "Contact", icon: "people", strength: clamp(((t.breath * t.infectivity) / 0.12) * (1 + 0.5 * t.reach)), detail: t.reach > 0 ? "breath, wider reach" : "breath, face to face" },
    { id: "air", label: "Air", icon: "wind", strength: clamp((airborne * t.cloudLoad * t.infectivity) / 6), detail: `${+(t.cough + t.sneeze).toFixed(1)} coughs and sneezes a minute${t.spores > 0 ? ", spores" : ""}` },
    {
      id: "surfaces",
      label: "Surfaces",
      icon: "hand",
      strength: clamp(t.touch * 20 + (t.bleed + t.vomit) / 6 + t.corpses * 0.5),
      detail: [t.touch > 0 && "touch", t.bleed > 0 && "blood", t.vomit > 0 && "vomit", t.corpses > 0 && "corpses"].filter(Boolean).join(", ") || "none",
    },
    { id: "vectors", label: "Animals", icon: "rat", strength: animals > 0 ? clamp(0.15 + fauna) : 0, detail: kinds.length ? `${kinds.join(", ")} · reservoir up to ${Math.round(fauna * 100)}%` : "" },
    { id: "water", label: "Water", icon: "water", strength: t.water > 0 ? clamp(0.1 + water) : 0, detail: `supply fouled up to ${Math.round(water * 100)}%` },
    { id: "transit", label: "Between towns", icon: "route", strength: places > 1 ? clamp(jumps / Math.max(1, places - 1)) : 0, detail: `${jumps} jump${jumps === 1 ? "" : "s"} to new settlements` },
  ];
  return routes.filter((r) => r.strength > 0).sort((a, b) => b.strength - a.strength);
};

/** The tally's routes, in its order (services/tally.ts SPREAD_VIA). Transit there is cabins and platforms. */
const TALLY_ROUTES = ["contact", "air", "surfaces", "vectors", "water", "transit"] as const;
const TRANSIT: Route = { id: "transit", label: "Transit", icon: "route", strength: 0, detail: "cabins and platforms" };

/**
 * Each route's share of the infections so far (strength = share), largest first, from the tally
 * in TALLY_ROUTES order; details from `ranked` (spreadRoutes) where it has the route. Null when
 * nobody has caught it yet, so the panel keeps the ranking.
 */
export const routeShares = (tally: ArrayLike<number> | null | undefined, ranked: readonly Route[]): { routes: Route[]; total: number } | null => {
  if (!tally) return null;
  let total = 0;
  for (let i = 0; i < TALLY_ROUTES.length; i++) total += tally[i] ?? 0;
  if (total <= 0) return null;
  const routes = TALLY_ROUTES.map((id, i) => {
    const n = tally[i] ?? 0;
    const base = id === "transit" ? TRANSIT : ranked.find((r) => r.id === id) ?? { ...TRANSIT, id, label: id[0].toUpperCase() + id.slice(1), detail: "" };
    const share = n / total;
    return { ...base, strength: share, detail: `${Math.round(share * 100)}% · ${n.toLocaleString()} caught${base.detail ? ` · ${base.detail}` : ""}` };
  });
  return { routes: routes.filter((r) => r.strength > 0).sort((a, b) => b.strength - a.strength), total };
};
