/**
 * War and collapse: what happens to towns past the riots. Page side (stepCollapse, after
 * stepUnrest) it keeps three series on each town's shared response, append-only like the others,
 * so everything a chunk does with them is a pure function of the tick:
 *
 * - `fallen`: [[1, tick]] once the government falls: order broken for long enough, or too many
 *   dead. A fallen town does no more research, and its people fight over what's left.
 * - `border`: 1 while a standing town under lockdown has shut its border against a fallen or dying
 *   neighbour (its checkpoints hold whatever its own unrest: the army mans them).
 * - `evac`: [[to, tick]] when the army reaches a fallen town: convoys pull the healthy-looking out
 *   to the standing neighbour `to` (carriers among them) until the wall goes up.
 * - `cordon`: what the standing neighbours do about a fallen town: 1 walled off (nobody in or out),
 *   then 2 firebombed if it keeps dying (a share of its buildings burn down to shells).
 */
import { hashUnit } from "../load/streams";
import { TICK_RATE } from "../world";
import { type Series, type TownResponse } from "./measures";
import { firstReached } from "./unrest";
import type { WorldResponse } from "./towns";

/** Owner-tunable collapse numbers. */
export const COLLAPSE = {
  /** A government falls after about this many seconds of broken order (defiance over `fallDefiance`) or of mass death. */
  fallSeconds: 480,
  fallDefiance: 0.5,
  /** Share of a town dead that counts as mass death; and that a neighbour shuts its border against. */
  fallDead: 0.25,
  borderDead: 0.05,
  /** Seconds a border stays as it is before it can change again. */
  borderHold: 120,
  /** Seconds of evacuation (from the army's arrival) before the standing neighbours wall a fallen town off, and how long walled before they firebomb (if it's still dying). */
  wallDelay: 150,
  bombDelay: 240,
  bombDead: 0.35,
  /** Share of a firebombed town's buildings that burn, how long the bombing runs (s), and how long each burns. */
  bombBurnt: 0.45,
  bombSpread: 90,
  bombBurns: [120, 300] as const,
};

export const Cordon = { None: 0, Walled: 1, Firebombed: 2 } as const;

export const last = (s: Series | undefined, fallback: number) =>
  s?.length ? s[s.length - 1][0] : fallback;
export const lastTick = (s: Series | undefined) =>
  s?.length ? s[s.length - 1][1] : -Infinity;
export const push = (
  town: TownResponse,
  key: "fallen" | "border" | "cordon" | "evac",
  value: number,
  tick: number
) => {
  ((town[key] ??= []) as Series).push([value, tick]);
};

/** Share of a town dead (of the living and the dead), on at least a few hundred people. */
export const deadShare = (t: { people: number; dead: number }) =>
  t.dead / Math.max(300, t.people + t.dead);

/**
 * Advances the collapse to the response's tick (call after stepUnrest, with that step's dt in
 * seconds). Returns whether the shared state grew.
 */


// ---------------------------------------------------------------------------------------------
// What it means at a tick (pure; page and chunk hosts alike)

export type Collapse = {
  /** Tick the government fell, or null. */
  fallen: number | null;
  /** Its border shut (0/1). */
  border: number;
  /** When the evacuation began (tick) and the town the convoys take people to, or null. */
  evac: { at: number; to: number } | null;
  /** Ticks it was walled off and firebombed, or null. */
  walled: number | null;
  firebombed: number | null;
};

export const STANDING: Collapse = {
  fallen: null,
  border: 0,
  evac: null,
  walled: null,
  firebombed: null,
};

const valueAt = (s: Series | undefined, tick: number) => {
  let v = 0;
  if (s)
    for (const [value, t] of s) {
      if (t > tick) break;
      v = value;
    }
  return v;
};

const evacOf = (s: Series | undefined, tick: number) =>
  s?.length && s[0][1] <= tick ? { at: s[0][1], to: s[0][0] } : null;

export const collapseOf = (
  town: TownResponse | undefined,
  tick: number
): Collapse => {
  if (!town?.fallen?.length && !town?.border?.length) return STANDING;
  return {
    fallen: firstReached(town.fallen as Series | undefined, 1, tick),
    border: valueAt(town.border as Series | undefined, tick),
    evac: evacOf(town.evac as Series | undefined, tick),
    walled: firstReached(
      town.cordon as Series | undefined,
      Cordon.Walled,
      tick
    ),
    firebombed: firstReached(
      town.cordon as Series | undefined,
      Cordon.Firebombed,
      tick
    ),
  };
};

/** Research brake for stepWorldResponse: a fallen government researches nothing. */
export const fallenBrake = (town: TownResponse | undefined, tick: number) =>
  collapseOf(town, tick).fallen !== null ? 1 : 0;

/**
 * A building's fire in a firebombed town: null if it was spared or hasn't caught; else how long it
 * has burned (s), for how long it burns, and whether it's out. Caught one by one over the bombing.
 */
export const bombFireOf = (
  town: TownResponse | undefined,
  h: number,
  tick: number
) => {
  const bombed = firstReached(
    town?.cordon as Series | undefined,
    Cordon.Firebombed,
    tick
  );
  if (bombed === null) return null;
  const k = hashUnit(h, 0x626f6d62, 10);
  if (k >= COLLAPSE.bombBurnt) return null;
  const caught =
    bombed +
    Math.round((k / COLLAPSE.bombBurnt) * COLLAPSE.bombSpread * TICK_RATE);
  if (tick < caught) return null;
  const [lo, hi] = COLLAPSE.bombBurns;
  const burns = lo + hashUnit(h, 0x62726e64, 11) * (hi - lo);
  const seconds = (tick - caught) / TICK_RATE;
  return { seconds, burns, out: seconds >= burns, caught };
};
