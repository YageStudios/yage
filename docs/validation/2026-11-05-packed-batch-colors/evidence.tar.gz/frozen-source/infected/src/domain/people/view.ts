/** Scene-side projection of people and schedules into the HUD model. */
import { isFestival, isRestDay } from "./culture";
import { LifeRole, NONE } from "./identity";
import { personOf, type Person } from "./person";
import { relativesOf } from "./relatives";
import { planChunk } from "../../worldgen/population/planner";
import type { PlanningContext } from "../../worldgen/commute/context";
import { ACTIVITY_NAMES } from "../../services/life/basics";
import { segmentAt } from "../../services/life/schedule";
import { whoOf } from "../../services/life/who";
import { PlaceKind } from "../../worldgen/terrain/index";

const PLACE_NAMES: Record<number, string> = {
  [PlaceKind.Apartment]: "an apartment block",
  [PlaceKind.House]: "a house",
  [PlaceKind.Farmhouse]: "a farmhouse",
  [PlaceKind.Hut]: "a hut",
  [PlaceKind.Cabin]: "a cabin",
  [PlaceKind.Shop]: "a shop",
  [PlaceKind.Workshop]: "a workshop",
  [PlaceKind.Office]: "an office",
  [PlaceKind.School]: "the school",
  [PlaceKind.Tavern]: "the tavern",
  [PlaceKind.Park]: "the park",
  [PlaceKind.Plaza]: "the plaza",
  [PlaceKind.Field]: "the fields",
  [PlaceKind.Pasture]: "the pasture",
  [PlaceKind.Clearing]: "the clearing",
  [PlaceKind.Green]: "the green",
};

const ORDINAL = ["ground", "first", "second", "third"];
const storeyName = (n: number) => (n < ORDINAL.length ? `${ORDINAL[n]} floor` : `floor ${n}`);

/** What the panel shows for one person (plain data, built when they are opened). */
export type PersonView = {
  gid: number;
  name: string;
  sub: string;
  work: string;
  home: string;
  traits: readonly string[];
  kin: readonly { gid: number; name: string; relation: string }[];
  ways: string;
};

export const personView = (p: Person, planning: PlanningContext): PersonView => ({
  gid: p.gid,
  name: p.name,
  sub: `${p.age === 0 ? "Infant" : `${p.age}`}, ${p.sex} · ${p.culture.name}`,
  work: p.workplace ? `${p.occupation} at ${PLACE_NAMES[p.workplace.kind] ?? "work"}` : p.occupation,
  home: p.home ? `${PLACE_NAMES[p.home.kind] ?? "home"}${p.home.kind === PlaceKind.Apartment ? `, ${storeyName(p.home.storey)}` : ""}` : "out of town",
  traits: p.traits.slice(),
  kin: relativesOf(p.gid, planning).map((r) => ({ gid: r.gid, name: r.name, relation: `${r.relation}${r.cx !== p.cx || r.cy !== p.cy ? " · elsewhere" : ""}` })),
  ways: `Wears ${p.culture.dressText}; eats ${p.culture.diet}. Keeps ${p.culture.festival.name}.${p.role === LifeRole.Night ? " Works nights." : ""}`,
});

/** What they are doing at `t`, and whether today is a festival or rest day. */
export const nowOf = (p: Person, t: number, planning: PlanningContext) => {
  const plan = planChunk(p.cx, p.cy, planning);
  const who = p.home ? whoOf(p.gid, p.role, plan.home[p.index], plan.slot[p.index], undefined, planning) : whoOf(p.gid, p.role, NONE, 0, undefined, planning);
  const seg = segmentAt(who, t, undefined, planning);
  const notes: string[] = [];
  if (isFestival(p.culture, seg.day)) notes.push(`${p.culture.festival.name} today`);
  else if (isRestDay(p.culture, seg.day)) notes.push("rest day");
  return { act: ACTIVITY_NAMES[seg.act], notes: notes.length ? ` · ${notes.join(", ")}` : "" };
};


export type PersonState = { view: PersonView; now: ReturnType<typeof nowOf> };

export const personState = (gid: number, time: number, planning: PlanningContext): PersonState | null => {
  const person = personOf(gid >>> 0, planning);
  return person ? { view: personView(person, planning), now: nowOf(person, time, planning) } : null;
};

export const hostIdentity = (gid: number, planning: PlanningContext): { name: string; meta: string } | null => {
  const person = personOf(gid >>> 0, planning);
  return person ? {
    name: person.name,
    meta: `${person.age === 0 ? "Infant" : `${person.age}`}, ${person.sex} · ${person.occupation}`,
  } : null;
};
