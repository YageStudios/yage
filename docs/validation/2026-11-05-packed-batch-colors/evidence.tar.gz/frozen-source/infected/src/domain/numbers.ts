/** How the game writes counts and shares in its own text (objectives, the log): "12,345", "4.2%". */
export const fmt = (n: number) => Math.round(n).toLocaleString("en-US");
export const pct = (share: number) => (share >= 0.1 ? `${(share * 100).toFixed(0)}%` : share >= 0.001 ? `${(share * 100).toFixed(1)}%` : `${(share * 100).toFixed(2)}%`);
