/**
 * How a building looks, from three independent inputs: its architecture style (density and form,
 * src/domain/styles.ts), the culture of the people who built it (vernacular materials, palette and
 * furnishings, src/people.ts) and its use. A New York brownstone and an English village cottage
 * differ in all three.
 *
 * The world generator resolves `lookOf` once per building and writes the material ids into
 * ChunkArt.materials; the item placer picks furniture from `look.sets`. The vernaculars, use looks
 * and style looks are tables (content/{vernacular,use-looks,styles}.json5); the rules are here.
 */
import type { BuildingUse, RoadClass } from "../atlas/model";
import { mat } from "./materials";
import { CONTENT } from "../content/runtime";
import type { MaterialKeys, VernacularRow } from "../content/schema/places";

/** Culture ids: people.ts culture names, lowercased, plus the cities' own (content/vernacular.json5 keys, in order). */
export type CultureId = "valesfolk" | "rivierans" | "nordmarkers" | "zemlyans" | "sahelians" | "qasri" | "newyorker";
export const CULTURE_IDS = Object.keys(CONTENT.vernacular) as CultureId[];
export const cultureId = (name: string): CultureId => {
  const id = name.toLowerCase() as CultureId;
  return CULTURE_IDS.includes(id) ? id : "valesfolk";
};

type Keys = MaterialKeys;

/** Item sets (src/domain/items.ts set tags) a building of this culture furnishes from. */
export type Sets = { furniture: string; street: string; yard: string };

export type Look = { wall: number; floor: number; wet: number; roof: number; paving: number; road: number; culture: CultureId; sets: Sets };

/** Vernacular: what ordinary homes in each culture are built from. */
const VERNACULAR = CONTENT.vernacular as Record<CultureId, VernacularRow>;

/** Style overrides on the vernacular (form follows density: cities build in brick and stone). */
const STYLE: Record<string, Partial<Keys>> = Object.fromEntries(CONTENT.styles.map((s) => [s.id, s.look ?? {}]));

/** Use overrides: some buildings look like their job everywhere, refined by culture, then style. */
const USE = CONTENT.useLooks as Partial<Record<BuildingUse, (typeof CONTENT.useLooks)[string]>>;
const useLook = (use: BuildingUse, culture: CultureId, style: string): Partial<Keys> | undefined => {
  const u = USE[use];
  if (!u) return undefined;
  const { byCulture, byStyle, ...keys } = u;
  return { ...keys, ...byCulture?.[culture], ...byStyle?.[style] };
};

export const lookOf = (style: string, culture: string, use: BuildingUse): Look => {
  const c = cultureId(culture);
  const v = VERNACULAR[c];
  // Village and farm homes keep the countryside's look (thatch and timber in Vale country).
  const rural = v.rural && (style === "village" || style === "farmstead") && (use === "house" || use === "farmhouse") ? v.rural : {};
  const keys: Keys = { ...v, ...rural, ...STYLE[style], ...useLook(use, c, style) };
  // A culture's own vernacular wins over generic town styles outside its home (Sahel towns stay adobe),
  // though not over a real city's own (New York's, North America's postwar tract, a medina's).
  if (v.ownWalls && !style.startsWith("ny-") && !style.startsWith("us-") && !style.startsWith("medina-") && !USE[use]) {
    keys.wall = v.wall;
    keys.roof = v.roof;
  }
  return {
    wall: mat(keys.wall),
    floor: mat(keys.floor),
    wet: mat(keys.wet ?? keys.floor),
    roof: mat(keys.roof),
    paving: mat(keys.paving),
    road: mat(keys.road),
    culture: c,
    sets: v.sets,
  };
};

/** Road surface by class, for streets outside any district (and the class's default). */
export const roadMaterial = (cls: RoadClass, culture: string, urban: boolean): number => {
  const c = cultureId(culture);
  switch (cls) {
    case "arterial":
      return mat(c === "sahelians" ? "asphalt-worn" : "asphalt");
    case "collector":
      return mat(urban ? VERNACULAR[c].road : c === "sahelians" ? "red-laterite" : "asphalt-worn");
    case "local":
      return mat(urban ? VERNACULAR[c].road : "gravel");
    case "lane":
      return mat(c === "sahelians" ? "red-laterite" : "gravel");
    case "track":
      return mat(c === "sahelians" ? "red-laterite" : "farm-track");
    case "path":
      return mat("packed-earth");
  }
};
