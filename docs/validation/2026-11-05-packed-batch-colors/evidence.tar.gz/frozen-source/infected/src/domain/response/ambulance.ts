/**
 * Hospitals on the street (pure, no drawing): which buildings are a town's hospitals, which of their
 * beds hold patients, and the ambulances driving to people's homes and back along the roads.
 * Everything is a pure function of the plan, the town's response series and the game second, so
 * every viewer sees the same van at the same corner.
 *
 * The vans are a picture of the wards filling, not of particular people: crews go out as often as
 * the hospital is busy, each trip to a home near the hospital. (The carriers actually isolated are
 * out of sight in the ward; life.ts `inWard`.)
 */
import { CONTENT } from "../../content/runtime";
import type { Vec } from "../../atlas/model";
import type { BuildingInstance, Road } from "../../atlas/objects";
import { GridIndex } from "../../atlas/spatial-index";
import { hashUnit } from "../load/streams";
import { networkOf } from "../../worldgen/network/network-of";
import type { Plan } from "../../worldgen/plan";
import { planByKey } from "../../worldgen/prefabs/catalog";
import { responseProjections, type GenerationInput } from "../../worldgen/source/owner";
import { instancesOf } from "../../worldgen/prefabs/instances";
import { hospitalsOf } from "../../worldgen/services";
import { toWorld } from "../../atlas/objects";
import type { WorldMap } from "../../worldmap/places";
import { pathLength, pointAlong } from "./street";
import { TILE } from "../world";

/** The numbers are data (content/response.json5). */
export const AMBULANCE = CONTENT.response.ambulance;

// ---------------------------------------------------------------------------------------------
// Roads as a graph

export type AmbulanceGraph = {
  roads: Road[];
  lengths: number[];
  /** Node of each road's ends. */
  ends: [number, number][];
  /** Per node: [road, end] pairs. */
  at: [number, 0 | 1][][];
  /** Road segments by area (tiles): [road, segment]. */
  index: GridIndex<[number, number]>;
};

const DRIVABLE = new Set(["arterial", "collector", "local", "lane"]);

const graphOf = (plan: Plan, owner: GenerationInput): AmbulanceGraph => {
  const { roadGraphs } = responseProjections(owner);
  let g = roadGraphs.get(plan);
  if (g) return g;
  const roads = networkOf(plan, owner).roads.filter(
    (r) => DRIVABLE.has(r.cls) && r.points.length >= 2
  );
  const nodes = new Map<string, number>();
  const at: [number, 0 | 1][][] = [];
  const node = (p: Vec) => {
    const key = `${Math.round(p.x * 2)},${Math.round(p.y * 2)}`;
    let n = nodes.get(key);
    if (n === undefined) {
      nodes.set(key, (n = at.length));
      at.push([]);
    }
    return n;
  };
  const index = new GridIndex<[number, number]>(32);
  const ends: [number, number][] = [];
  roads.forEach((r, i) => {
    const a = node(r.points[0]);
    const b = node(r.points[r.points.length - 1]);
    ends.push([a, b]);
    at[a].push([i, 0]);
    at[b].push([i, 1]);
    for (let k = 0; k + 1 < r.points.length; k++) {
      const p = r.points[k];
      const q = r.points[k + 1];
      index.insert([i, k], {
        x0: Math.min(p.x, q.x),
        y0: Math.min(p.y, q.y),
        x1: Math.max(p.x, q.x),
        y1: Math.max(p.y, q.y),
      });
    }
  });
  g = {
    roads,
    lengths: roads.map((r) => pathLength(r.points)),
    ends,
    at,
    index,
  };
  roadGraphs.set(plan, g);
  return g;
};

/** The nearest point on a drivable road to p (tiles): road, distance along it, the point. */
const snapToRoad = (g: AmbulanceGraph, p: Vec) => {
  let best: { road: number; s: number; at: Vec; d: number } | null = null;
  for (let r = 8; r <= 64 && !best; r *= 2) {
    for (const [i, k] of g.index.query({
      x0: p.x - r,
      y0: p.y - r,
      x1: p.x + r,
      y1: p.y + r,
    })) {
      const pts = g.roads[i].points;
      const a = pts[k];
      const b = pts[k + 1];
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const L2 = dx * dx + dy * dy;
      const t =
        L2 > 0
          ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / L2))
          : 0;
      const q = { x: a.x + dx * t, y: a.y + dy * t };
      const d = Math.hypot(q.x - p.x, q.y - p.y);
      if (!best || d < best.d) {
        let s = 0;
        for (let j = 0; j < k; j++)
          s += Math.hypot(pts[j + 1].x - pts[j].x, pts[j + 1].y - pts[j].y);
        best = { road: i, s: s + Math.sqrt(L2) * t, at: q, d };
      }
    }
  }
  return best;
};

/** A road's points from distance s0 to s1 along it (either way). */
const piece = (points: readonly Vec[], s0: number, s1: number): Vec[] => {
  const forward = s1 >= s0;
  const L = pathLength(points);
  const pts = forward ? points : points.slice().reverse();
  const a = forward ? s0 : L - s0;
  const b = forward ? s1 : L - s1;
  const out: Vec[] = [pointAlong(pts, a)];
  let at = 0;
  for (let i = 0; i + 1 < pts.length; i++) {
    at += Math.hypot(pts[i + 1].x - pts[i].x, pts[i + 1].y - pts[i].y);
    if (at > a && at < b) out.push(pts[i + 1]);
  }
  out.push(pointAlong(pts, b));
  return out;
};

/**
 * The drive from one point to another along the roads (tiles): from the road nearest `from` to the
 * road nearest `to`, shortest way (Dijkstra over junctions). Null when either is off the roads or
 * they don't connect.
 */
export const routeBetween = (plan: Plan, from: Vec, to: Vec, owner: GenerationInput): Vec[] | null => {
  const g = graphOf(plan, owner);
  const a = snapToRoad(g, from);
  const b = snapToRoad(g, to);
  if (!a || !b) return null;
  if (a.road === b.road) return piece(g.roads[a.road].points, a.s, b.s);
  // Dijkstra from a's two ends (cost: the way along a to them).
  const N = g.at.length;
  const dist = new Float64Array(N).fill(Infinity);
  const prev = new Int32Array(N).fill(-1);
  const via = new Int32Array(N).fill(-1);
  const [a0, a1] = g.ends[a.road];
  dist[a0] = a.s;
  dist[a1] = Math.min(dist[a1], g.lengths[a.road] - a.s);
  const open: number[] = [a0, a1];
  const done = new Uint8Array(N);
  const [b0, b1] = g.ends[b.road];
  while (open.length) {
    let k = 0;
    for (let i = 1; i < open.length; i++)
      if (dist[open[i]] < dist[open[k]]) k = i;
    const n = open[k];
    open[k] = open[open.length - 1];
    open.pop();
    if (done[n]) continue;
    done[n] = 1;
    if (done[b0] && done[b1]) break;
    for (const [r, end] of g.at[n]) {
      const m = g.ends[r][end ? 0 : 1];
      const d = dist[n] + g.lengths[r];
      if (d < dist[m]) {
        dist[m] = d;
        prev[m] = n;
        via[m] = r;
        open.push(m);
      }
    }
  }
  const endCost0 = dist[b0] + b.s;
  const endCost1 = dist[b1] + (g.lengths[b.road] - b.s);
  if (!Number.isFinite(Math.min(endCost0, endCost1))) return null;
  const last = endCost0 <= endCost1 ? b0 : b1;
  // Walk back to a's end.
  const chain: number[] = [];
  for (let n = last; n !== -1; n = prev[n]) chain.push(n);
  chain.reverse();
  const first = chain[0];
  const out: Vec[] = [];
  const push = (pts: Vec[]) => {
    for (const p of pts)
      if (
        !out.length ||
        Math.hypot(out[out.length - 1].x - p.x, out[out.length - 1].y - p.y) >
          1e-6
      )
        out.push(p);
  };
  push(
    piece(g.roads[a.road].points, a.s, first === a0 ? 0 : g.lengths[a.road])
  );
  for (let i = 1; i < chain.length; i++) {
    const r = via[chain[i]];
    const forward = g.ends[r][0] === chain[i - 1];
    push(forward ? g.roads[r].points : g.roads[r].points.slice().reverse());
  }
  push(piece(g.roads[b.road].points, last === b0 ? 0 : g.lengths[b.road], b.s));
  return out;
};

// ---------------------------------------------------------------------------------------------
// Hospitals and their beds

export type Hospital = {
  inst: BuildingInstance;
  beds: { x: number; y: number; turn: number }[];
  homes: BuildingInstance[];
};

const HOMES = new Set(["house", "terrace", "apartment", "tower", "farmhouse"]);

/** A town's hospitals and clinics (objects mode), with their beds in world units and homes in reach. */
export const hospitalsOfTown = (
  map: WorldMap,
  town: number,
  plan: Plan | null,
  owner: GenerationInput
): Hospital[] => {
  const place = map.places[town];
  if (!plan || !place) return [];
  const { hospitals } = responseProjections(owner);
  let byTown = hospitals.get(plan);
  if (!byTown) hospitals.set(plan, (byTown = new Map()));
  let hit = byTown.get(town);
  if (hit) return hit;
  const inst = instancesOf(plan, owner);
  hit = [];
  for (const b of hospitalsOf(plan, place.id)) {
    const i = inst.byId.get(b.id);
    const p = i && planByKey(i.plan, owner);
    if (!i || !p) continue;
    const beds = p.beds.map(([x, y]) => {
      // As life.ts lies sleepers: on the bed, a shade toward its foot, turned with the building.
      const w = toWorld(i.frame, x + 0.5, y + 0.5 + 0.49);
      return { x: w.x * TILE, y: w.y * TILE, turn: i.frame.angle };
    });
    const R = AMBULANCE.reach;
    const o = i.outside;
    const homes = inst.list
      .filter(
        (h) =>
          HOMES.has(h.use) &&
          Math.abs(h.outside.x - o.x) < R &&
          Math.abs(h.outside.y - o.y) < R &&
          Math.hypot(h.outside.x - o.x, h.outside.y - o.y) > 12
      )
      .sort((h, k) => (h.id < k.id ? -1 : 1));
    hit.push({ inst: i, beds, homes });
  }
  byTown.set(town, hit);
  return hit;
};

/** Where someone stands `s` tiles out of a hospital's door (tiles): down its path, then along the
 * pavement to `side` (±1), a step out from the facade, clear of the eaves. */
export const queuePoint = (h: Hospital, s: number, side: number): Vec => {
  const d = h.inst.door;
  const o = h.inst.outside;
  const dx = o.x - d.x;
  const dy = o.y - d.y;
  const d1 = Math.hypot(dx, dy) || 1;
  if (s <= d1) return { x: d.x + (dx / d1) * s, y: d.y + (dy / d1) * s };
  const ax = (-dy / d1) * side;
  const ay = (dx / d1) * side;
  const out = 0.9;
  return {
    x: o.x + (dx / d1) * out + ax * (s - d1),
    y: o.y + (dy / d1) * out + ay * (s - d1),
  };
};

/** Which way a hospital's queue runs along the pavement (±1), fixed per building. */
export const queueSide = (h: Hospital) =>
  hashUnit(h.inst.seed, 0x71756575, 1) < 0.5 ? 1 : -1;

/** Spacing of a clinic queue (tiles). */
export const QUEUE_GAP = 0.85;

/**
 * Where the k-th person in the queue at a town's clinic door stands (world units; k = 0 is at the
 * front), or null if the town has no hospital or clinic. Its `hospital`-th door when it has several.
 * The same spots the care art draws its queue at.
 */
export const clinicSpot = (
  map: WorldMap,
  town: number,
  k: number,
  hospital = 0,
  plan: Plan | null,
  owner: GenerationInput
): Vec | null => {
  const hs = hospitalsOfTown(map, town, plan, owner);
  const h = hs[hospital % Math.max(1, hs.length)];
  if (!h) return null;
  const p = queuePoint(h, 0.6 + (k + 1) * QUEUE_GAP, queueSide(h));
  return { x: p.x * TILE, y: p.y * TILE };
};

/** Which beds hold patients at a hospital load (patients over beds): each bed by its own threshold. */
export const bedFilled = (hospital: number, bed: number, load: number) =>
  hashUnit(hospital + 1, bed, 0x77617264) < Math.min(1, load);

// ---------------------------------------------------------------------------------------------
// Ambulance runs

export type AmbulancePose = {
  /** World units; heading in radians. */
  x: number;
  y: number;
  angle: number;
  /** Lights flashing (driving out, or back with a patient). */
  siren: boolean;
  /** Stopped at a home with the crew out, 0–1 through the loading (−1: not loading). */
  loading: number;
  /** The home's door and the van's back (world units) while loading. */
  door?: Vec;
  /** The patient's seed (look) on this trip. */
  patient: number;
};

/** How many crews a hospital runs at a load, with this share of its staff still working (care.ts). */
export const crewsAt = (load: number, staff = 1) =>
  load <= 0
    ? 0
    : Math.max(
        1,
        Math.round(
          Math.min(AMBULANCE.crews, 1 + Math.floor(load * AMBULANCE.perLoad)) *
            Math.min(1, staff)
        )
      );

/** Smooth start and stop over a drive (0–1 → 0–1). */
const ease = (x: number) => x - Math.sin(2 * Math.PI * x) / (2 * Math.PI);

/** A crew's van at game second t (null: in the garage, or no route). */
export const ambulanceAt = (
  plan: Plan,
  h: Hospital,
  crew: number,
  t: number,
  owner: GenerationInput
): AmbulancePose | null => {
  const A = AMBULANCE;
  const offset = hashUnit(h.inst.seed, crew, 0x616d62) * A.round;
  const trip = Math.floor((t + offset) / A.round);
  const u = t + offset - trip * A.round;
  if (!h.homes.length) return null;
  const home =
    h.homes[
      Math.floor(
        hashUnit(h.inst.seed + crew * 7919, trip, 0x686f6d65) * h.homes.length
      )
    ];
  const key = `${h.inst.id}>${home.id}`;
  const { ambulanceRoutes } = responseProjections(owner);
  let routes = ambulanceRoutes.get(plan);
  if (!routes) ambulanceRoutes.set(plan, (routes = new Map()));
  let route = routes.get(key);
  if (route === undefined) {
    route = routeBetween(plan, h.inst.outside, home.outside, owner);
    if (routes.size > 512) {
      const oldest = routes.keys().next().value;
      if (oldest !== undefined) routes.delete(oldest);
    }
    routes.set(key, route);
  }
  const patient = (h.inst.seed * 31 + crew * 977 + trip * 131) >>> 0;
  // Parked at the kerb on the hospital's side, nose to tail with a gap, either side of the door.
  const park = (path: Vec[] | null, at: Vec): AmbulancePose => {
    const kerb = kerbPark(plan, h, crew, owner);
    if (kerb) return { ...kerb, siren: false, loading: -1, patient };
    const p = path ?? [at];
    const a = p.length > 1 ? Math.atan2(p[1].y - p[0].y, p[1].x - p[0].x) : 0;
    return lanePose(
      p,
      Math.min(crew * A.parkGap, pathLength(p)),
      a,
      false,
      -1,
      patient
    );
  };
  if (!route || route.length < 2) return park(null, h.inst.outside);
  const L = pathLength(route);
  const drive = L / A.speed;
  if (2 * drive + A.load + A.unload > A.round)
    return park(route, h.inst.outside);
  if (u < drive)
    return lanePose(route, L * ease(u / drive), 0, true, -1, patient);
  if (u < drive + A.load) {
    const pose = lanePose(route, L, 0, true, (u - drive) / A.load, patient);
    pose.door = { x: home.door.x * TILE, y: home.door.y * TILE };
    return pose;
  }
  if (u < 2 * drive + A.load) {
    const back = route.slice().reverse();
    return lanePose(
      back,
      L * ease((u - drive - A.load) / drive),
      0,
      true,
      -1,
      patient
    );
  }
  return park(route, h.inst.outside);
};

/** A parked van's spot (world units) and heading. */
export type KerbSpot = { x: number; y: number; angle: number };

/**
 * A crew's parking spot (world units): on the road nearest the hospital door, in at the kerb on the
 * door's side, crews spread either side of the door (0 just before it, 1 just past, 2 further on).
 */
export const kerbPark = (plan: Plan, h: Hospital, crew: number, owner: GenerationInput): KerbSpot | null => {
  const key = `${h.inst.id}#${crew}`;
  const { kerbs: byPlan } = responseProjections(owner);
  let kerbs = byPlan.get(plan);
  if (!kerbs) byPlan.set(plan, (kerbs = new Map()));
  const held = kerbs.get(key);
  if (held !== undefined) return held;
  const g = graphOf(plan, owner);
  const o = h.inst.outside;
  const snap = snapToRoad(g, o);
  let out: KerbSpot | null = null;
  if (snap) {
    const road = g.roads[snap.road];
    const L = g.lengths[snap.road];
    const slot = [-0.5, 0.5, 1.5][crew] ?? crew - 0.5;
    const s = Math.max(2, Math.min(L - 2, snap.s + slot * AMBULANCE.parkGap));
    const p = pointAlong(road.points, s);
    const a = pointAlong(road.points, Math.max(0, s - 1));
    const b = pointAlong(road.points, Math.min(L, s + 1));
    let angle = Math.atan2(b.y - a.y, b.x - a.x);
    let nx = -Math.sin(angle);
    let ny = Math.cos(angle);
    // Towards the door's side; facing so that side is the van's left (kerbside, nose on).
    const side = (o.x - snap.at.x) * nx + (o.y - snap.at.y) * ny >= 0 ? 1 : -1;
    if (side < 0) {
      angle += Math.PI;
      nx = -nx;
      ny = -ny;
    }
    const inset = Math.max(0, road.width / 2 - AMBULANCE.parkIn);
    out = { x: (p.x + nx * inset) * TILE, y: (p.y + ny * inset) * TILE, angle };
  }
  if (kerbs.size > 256) {
    const oldest = kerbs.keys().next().value;
    if (oldest !== undefined) kerbs.delete(oldest);
  }
  kerbs.set(key, out);
  return out;
};

/** A pose `s` along a route (tiles), kept to the right-hand lane; world units out. */
const lanePose = (
  route: readonly Vec[],
  s: number,
  fallback: number,
  siren: boolean,
  loading: number,
  patient: number
): AmbulancePose => {
  const L = pathLength(route);
  const p = pointAlong(route, s);
  const a = pointAlong(route, Math.max(0, s - 1.5));
  const b = pointAlong(route, Math.min(L, s + 1.5));
  const angle =
    Math.hypot(b.x - a.x, b.y - a.y) > 1e-6
      ? Math.atan2(b.y - a.y, b.x - a.x)
      : fallback;
  const nx = -Math.sin(angle);
  const ny = Math.cos(angle);
  return {
    x: (p.x + nx * AMBULANCE.lane) * TILE,
    y: (p.y + ny * AMBULANCE.lane) * TILE,
    angle,
    siren,
    loading,
    patient,
  };
};
