/**
 * Current goals for the Objectives panel: up to three at a time, each read off the live game (counts,
 * settlements reached, the response ladder, collapse, animal reservoirs, the cure race). Goals
 * appear when the state they talk about exists (a cure push once anyone researches, the roadblocks
 * once a town sets up checkpoints) and never by lesson or index; once met they stay met.
 *
 * Pure: a snapshot in, the goals to show and the ones just completed out. The HUD builds the
 * snapshot (live.ts) and draws the panel.
 */
import { DAY_SECONDS } from "./time";
import { fmt, pct } from "./numbers";

export type ObjectiveSnapshot = {
  started: boolean;
  /** Game seconds since the start of the run (tick / tick rate). */
  seconds: number;
  /** The town the outbreak began in (for wording), or "". */
  startTown: string;
  people: number;
  /** Everyone ever infected. */
  absorbed: number;
  /** Symptomatic hosts now. */
  bloomed: number;
  dead: number;
  /** Settlements the infection has reached, and the game seconds each was first reached. */
  reachedAt: number[];
  places: number;
  /** Highest infected share (0–1) of any reached settlement. */
  bestTownShare: number;
  cure: number;
  researching: number;
  /** Towns standing at checkpoints (the top rung). */
  checkpointTowns: number;
  /** Highest ladder level any town stands at. */
  maxLevel: number;
  fallen: number;
  /** Sum of the strain's animal routes (0 = it rides no animal), and the worst town reservoir (0–1). */
  animals: number;
  reservoir: number;
  victoryShare: number;
};

/** What the goals remember between snapshots: what's met, and when the state some goals count from first appeared. */
export type ObjectiveMemory = { done: Set<string>; cureFrom: number | null; checkpointsFrom: number | null };
export const newObjectiveMemory = (): ObjectiveMemory => ({ done: new Set(), cureFrom: null, checkpointsFrom: null });

export type ObjectiveView = { id: string; text: string; icon: string; value: number; target: number; fill: number; label: string };

type Unit = "count" | "share" | "days";
type Goal = {
  id: string;
  icon: string;
  text: (s: ObjectiveSnapshot) => string;
  /** Whether it can be worked on now (the state it is about exists). */
  when?: (s: ObjectiveSnapshot, m: ObjectiveMemory) => boolean;
  progress: (s: ObjectiveSnapshot, m: ObjectiveMemory) => [value: number, target: number];
  unit?: Unit;
};

const daysSince = (s: ObjectiveSnapshot, from: number | null) => (from === null ? 0 : Math.max(0, s.seconds - from) / DAY_SECONDS);

/** In priority order: the first three that apply and aren't met are shown. */
export const GOALS: readonly Goal[] = [
  { id: "infect", icon: "bio", text: (s) => (s.startTown ? `Infect 10 people in ${s.startTown}` : "Infect 10 people"), progress: (s) => [s.absorbed, 10] },
  { id: "bloom", icon: "spores", text: () => "Bloom 10 hosts", progress: (s) => [s.bloomed, 10] },
  { id: "reach", icon: "route", text: () => "Reach another settlement", when: (s) => s.places > 1, progress: (s) => [Math.max(0, s.reachedAt.length - 1), 1] },
  { id: "hundred", icon: "people", text: () => "Infect 100 people", progress: (s) => [s.absorbed, 100] },
  { id: "quarter", icon: "pin", text: () => "Take a quarter of a town", progress: (s) => [s.bestTownShare, 0.25], unit: "share" },
  {
    id: "cure",
    icon: "flask",
    text: () => "Survive the first cure push (3 days)",
    when: (s, m) => m.cureFrom !== null,
    progress: (s, m) => [daysSince(s, m.cureFrom), 3],
    unit: "days",
  },
  {
    id: "roadblocks",
    icon: "shield",
    text: () => "Evade the roadblocks: reach a new settlement",
    when: (s, m) => m.checkpointsFrom !== null && s.reachedAt.length < s.places,
    progress: (s, m) => [s.reachedAt.filter((at) => at > (m.checkpointsFrom ?? Infinity)).length, 1],
  },
  { id: "five", icon: "route", text: (s) => `Spread to ${Math.min(5, s.places)} settlements`, when: (s) => s.places > 2, progress: (s) => [s.reachedAt.length, Math.min(5, s.places)] },
  { id: "reservoir", icon: "rat", text: () => "Seed an animal reservoir", when: (s) => s.animals > 0, progress: (s) => [s.reservoir, 0.5], unit: "share" },
  { id: "topple", icon: "warning", text: () => "Topple a government", when: (s) => s.maxLevel >= 4 || s.fallen > 0, progress: (s) => [s.fallen, 1] },
  { id: "tenth", icon: "people", text: () => "Absorb 10% of the world", when: (s) => s.victoryShare > 0.1, progress: (s) => [s.people ? s.absorbed / s.people : 0, 0.1], unit: "share" },
  { id: "victory", icon: "star", text: (s) => `Absorb ${pct(s.victoryShare)} of the world`, progress: (s) => [s.people ? s.absorbed / s.people : 0, s.victoryShare], unit: "share" },
];

export const MAX_SHOWN = 3;

const label = (value: number, target: number, unit: Unit) =>
  unit === "share" ? `${pct(Math.min(value, target))} / ${pct(target)}` : unit === "days" ? `${Math.min(value, target).toFixed(1)} / ${target} d` : `${fmt(Math.min(value, target))} / ${fmt(target)}`;

/**
 * Advances the memory with a snapshot and returns the goals to show (up to MAX_SHOWN, in priority
 * order) and the ones met by this snapshot (for the toast).
 */
export const stepObjectives = (s: ObjectiveSnapshot, m: ObjectiveMemory): { shown: ObjectiveView[]; completed: ObjectiveView[] } => {
  if (!s.started) return { shown: [], completed: [] };
  if (m.cureFrom === null && (s.researching > 0 || s.cure > 0)) m.cureFrom = s.seconds;
  if (m.checkpointsFrom === null && s.checkpointTowns > 0) m.checkpointsFrom = s.seconds;
  const shown: ObjectiveView[] = [];
  const completed: ObjectiveView[] = [];
  for (const goal of GOALS) {
    if (m.done.has(goal.id)) continue;
    if (goal.when && !goal.when(s, m)) continue;
    const [value, target] = goal.progress(s, m);
    const view: ObjectiveView = {
      id: goal.id,
      text: goal.text(s),
      icon: goal.icon,
      value,
      target,
      fill: target > 0 ? Math.max(0, Math.min(1, value / target)) : 0,
      label: label(value, target, goal.unit ?? "count"),
    };
    // Only goals on show complete; one met while off the panel waits its turn (it then completes at once).
    if (shown.length < MAX_SHOWN && target > 0 && value >= target) {
      m.done.add(goal.id);
      completed.push(view);
      continue;
    }
    if (shown.length < MAX_SHOWN) shown.push(view);
  }
  return { shown, completed };
};

/** How many goals are met, of all there are (for the panel's head). */
export const objectiveCount = (m: ObjectiveMemory) => ({ done: m.done.size, total: GOALS.length });
