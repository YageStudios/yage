/** Scene readers carry their schema/source handles explicitly across render boundaries. */
import { SkyLightState } from "../../components/weather/SkyLightState";
import { ResponseExport, type ResponseView } from "../../components/response/ResponseExport";
import type { ReadOnlyGameModel } from "yage/game/GameModel";
import { RegionMap } from "../../components/response/RegionMap";
import type { PlanningContext } from "../../worldgen/commute/context";
import { placeAt, type WorldMap } from "../../worldmap/places";
import { collapseOf } from "./collapse";
import { measuresOf, valueAt } from "./measures";
import { unrestOf } from "./unrest";

export type ResponseRead = Readonly<{
  response: ResponseView;
  sky: SkyLightState;
  map: WorldMap;
  planning: PlanningContext;
}>;
/** The region's response export, the client's sky (its ground surface's) and the region's map and planning context. */
export const readResponse = (g: Pick<ReadOnlyGameModel, "single">): ResponseRead => {
  const { worldMap, planning } = g.single(RegionMap);
  return { response: g.single(ResponseExport).response!, sky: g.single(SkyLightState), map: worldMap, planning };
};
export const readTownOf = (read: ResponseRead, cx: number, cy: number) =>
  placeAt(read.map, cx, cy);
export const readTownResponse = (
  read: ResponseRead,
  town: number,
  tick: number,
  raw = false
) => {
  const state = read.response.shared.towns[town];
  const measures = measuresOf(state?.events, tick);
  const defiance = raw ? 0 : unrestOf(state, tick).defiance;
  const collapse = collapseOf(state, tick);
  const border = raw ? 0 : collapse.walled !== null ? 1 : collapse.border;
  const held = Math.max(0, 1 - defiance);
  return {
    ...measures,
    closed: measures.closed * held,
    curfew: measures.curfew * held,
    lockdown: measures.lockdown * held,
    checkpoints: Math.max(border, measures.checkpoints * held),
    awareness: valueAt(state?.aware, tick),
    hospitalLoad: valueAt(state?.hospital, tick),
  };
};
export const readMeasuresAt = (
  read: ResponseRead,
  cx: number,
  cy: number,
  tick: number
) => readTownResponse(read, readTownOf(read, cx, cy), tick);
