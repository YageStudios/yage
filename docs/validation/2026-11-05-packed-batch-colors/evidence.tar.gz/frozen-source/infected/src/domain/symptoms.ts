/**
 * What being sick looks like and does to a host, shared by the workers and the page. Pure: every
 * answer is a function of the strain, the host's gid, how far gone they are and the tick, so hot,
 * warm and late-loaded chunks agree.
 *
 * - Severity: how far through their life a bloomed host is (0 just bloomed, 1 about to die).
 * - Silence (prions): no outward sign at all until severity passes `traits.silent`; then the
 *   symptoms come on at full force. Silent hosts aren't counted as visible either.
 * - Actions: each cough, sneeze, vomit, bleed and collapse is a short action on the host with a
 *   pose (doubled over, or down on the ground) and the matching expulsion (load.ts).
 * - Sickness: the sick slow down, keep to home and sit down when they can (life.ts reads
 *   `sicknessOf`); parasites (`traits.steady`) keep their hosts on their feet.
 */
import { CONTENT } from "../content/runtime";
import type { Traits } from "./disease";
import { eventsBetween, hashUnit, Stream } from "./load/streams";
import { TICK_RATE } from "./world";

/** Tunable numbers of how sickness shows; data in content/disease.json5. */
export const SYMPTOMS = CONTENT.disease.symptoms;

/** Overlay pose codes beyond life.ts's (1 lie in bed, 2 sit): what render/poses.ts maps them to. */
export const enum SickPose {
  /** Down on the ground, uncovered; angle = head-to-foot axis. */
  Fallen = 3,
  /** Doubled over (cough, sneeze, vomit, clutching a wound); angle = the way they face. */
  Hunch = 4,
  /** On its knees eating a body (FeedSystem); angle = the way it faces. */
  Feed = 5,
}

/** How far through their life a bloomed host is, from their timer (life left, seconds at decay 1). */
export const severityOf = (timer: number, traits: Traits) => Math.min(1, Math.max(0, 1 - timer / Math.max(1e-6, traits.lifespan)));

/** Whether a bloomed host shows anything yet (prions hide until late). */
export const showing = (traits: Traits, severity: number) => severity >= traits.silent;

/**
 * How strongly a host shows its symptoms at this severity (0–1): 0 while silent, else 1. Kept a
 * step so the strains' tuned spread is unchanged outside the silent phase.
 */
export const intensity = (traits: Traits, severity: number) => (showing(traits, severity) ? 1 : 0);

/** Bleeds per minute at this severity (a trickle early, full late). */
export const bleedRate = (traits: Traits, severity: number) =>
  traits.bleed * intensity(traits, severity) * (SYMPTOMS.bleedFloor + (1 - SYMPTOMS.bleedFloor) * severity);

/** Collapses per minute at this severity (none before `collapseFrom`). */
export const collapseRate = (traits: Traits, severity: number) =>
  severity < SYMPTOMS.collapseFrom ? 0 : traits.collapse * intensity(traits, severity) * ((severity - SYMPTOMS.collapseFrom) / (1 - SYMPTOMS.collapseFrom) * 0.7 + 0.3);

export type Sickness = {
  /** Walking pace multiplier (≤ 1). */
  pace: number;
  /** Share of time away from home that the host spends at home instead. */
  home: number;
  /** Share of time outdoors spent sitting down. */
  sit: number;
};
const WELL: Sickness = { pace: 1, home: 0, sit: 0 };

/**
 * What the sickness does to how a bloomed host lives (life.ts): slower, more at home, sitting down.
 * Nothing while silent; parasites (`steady`) blunt it, so their hosts keep mixing.
 */
export const sicknessOf = (traits: Traits, severity: number): Sickness => {
  if (!showing(traits, severity)) return WELL;
  const s = severity * (1 - Math.min(1, Math.max(0, traits.steady)));
  if (s <= 0) return WELL;
  return { pace: 1 - (1 - SYMPTOMS.slowest) * s, home: SYMPTOMS.homeAtWorst * s * s, sit: SYMPTOMS.sitAtWorst * s };
};

/**
 * The tick a host last collapsed if they're still down at `tick`, else -1. The same hashed schedule
 * the load sim drops them on (Stream.Collapse at the current severity), so life.ts can hold them
 * still: a pure function of gid, strain, severity and tick, so late-loaded chunks agree.
 */
export const downSince = (traits: Traits, gid: number, severity: number, tick: number) => {
  let since = -1;
  eventsBetween(gid, Stream.Collapse, collapseRate(traits, severity), tick - SYMPTOMS.down * TICK_RATE, tick, (at) => (since = at));
  return since;
};

/** Whether a host spends this stretch (any integer: a schedule segment, an hour) at home for their sickness. */
export const staysHome = (traits: Traits, gid: number, severity: number, stretch: number) => hashUnit(gid, 0x51c4, stretch) < sicknessOf(traits, severity).home;

/** Whether a host sits down for this stretch while out. */
export const sitsDown = (traits: Traits, gid: number, severity: number, stretch: number) => hashUnit(gid, 0x5174, stretch) < sicknessOf(traits, severity).sit;
