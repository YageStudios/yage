/**
 * Borders and global travel. An atlas space is one region of a bigger world: its roads and its main
 * line run off the map's edge (the skeleton's "gate:" links and main railways), and later its
 * airport and harbour (the world agent's "airport" / "harbour" anchors) fly and sail further.
 * Each of those is a gate. Travellers leave through them every day, and carriers among them take
 * the strain to the world outside: the rest of the country, the other atlas spaces, abroad.
 *
 * As the world reacts, each gate goes open → screening (quarantine at the gate: the visibly sick
 * and some silent carriers are caught and held in a pen) → closed (only smugglers get through,
 * more as the town stops obeying). The outside reacts too: once it finds cases it screens and then
 * shuts its own side.
 *
 * Page side (stepBorders, after stepCollapse) like the other response systems: each gate's status
 * is an append-only step series and the outside is a few numbers stepped with the response's dt.
 * Nothing goes to the workers: the region's own people never leave the map; only the strain does.
 * Gate geometry is derived lazily, once per plan (no world-wide scans).
 */
import { CONTENT } from "../../content/runtime";
import type { Vec } from "../../atlas/model";
import type { Road } from "../../atlas/objects";
import { ALPHA } from "../worlds";
import { hashUnit } from "../load/streams";
import { DAY_SECONDS } from "../time";
import { networkOf } from "../../worldgen/network/network-of";
import type { Plan } from "../../worldgen/plan";
import { TILE } from "../world";
import type { WorldMap } from "../../worldmap/places";
import { collapseOf } from "./collapse";
import { Level, valueAt } from "./measures";
import { pathLength, pointAlong, subPath } from "./street";
import type { WorldResponse } from "./towns";

export type GateKind = "road" | "rail" | "air" | "sea";

export const enum GateStatus {
  Open = 0,
  /** Quarantine at the gate: travellers screened, the caught held. */
  Screening = 1,
  /** Shut: only smugglers get through. */
  Closed = 2,
}

export { BorderGate as Gate } from "../../components/response/BorderGate";
export { OutsideRegion as Outside } from "../../components/response/OutsideRegion";
import type { BorderGate as Gate } from "../../components/response/BorderGate";
import type { OutsideRegion as Outside } from "../../components/response/OutsideRegion";
import type { BorderGeometry } from "../../components/response/BorderGeometry";
import type { GenerationInput } from "../../worldgen/source/owner";
import type { ResponseView } from "../../components/response/ResponseExport";

/** Owner-tunable border numbers; data in content/response.json5. */
export const BORDERS = CONTENT.response.borders;

/** The people outside the map, whom travel links to it (content/response.json5). */
const OUTSIDE_PEOPLE = CONTENT.response.outsidePeople;

// ---------------------------------------------------------------------------------------------
// Geometry: the gates of the active plan.

const inside = (
  b: { x0: number; y0: number; x1: number; y1: number },
  p: Vec
) => p.x >= b.x0 && p.x <= b.x1 && p.y >= b.y0 && p.y <= b.y1;

/** Where a polyline (tiles) runs out of the bounds: the path from there inward, or null. */
const exitOf = (
  points: readonly Vec[],
  b: { x0: number; y0: number; x1: number; y1: number }
) => {
  if (points.length < 2) return null;
  // Walk it from whichever end lies outside (or nearest the edge).
  const edgeGap = (p: Vec) =>
    Math.min(p.x - b.x0, b.x1 - p.x, p.y - b.y0, b.y1 - p.y);
  const a = points[0];
  const z = points[points.length - 1];
  const path =
    edgeGap(a) <= edgeGap(z) ? points.slice() : points.slice().reverse();
  if (edgeGap(path[0]) > BORDERS.inset) return null;
  // The first point on the way in that is inside the bounds by `inset`.
  const L = pathLength(path);
  let s = 0;
  for (; s < L; s += 2)
    if (edgeGap(pointAlong(path, s)) >= BORDERS.inset) break;
  if (s >= L) return null;
  const edgeAt = (() => {
    for (let t = s; t >= 0; t -= 1)
      if (!inside(b, pointAlong(path, t))) return pointAlong(path, t);
    return path[0];
  })();
  return { path, s, L, edge: edgeAt };
};

/** Which side of the map a point near its edge is on. */
const compass = (
  p: Vec,
  b: { x0: number; y0: number; x1: number; y1: number }
) => {
  const sides: [number, string][] = [
    [p.y - b.y0, "North"],
    [b.y1 - p.y, "South"],
    [p.x - b.x0, "West"],
    [b.x1 - p.x, "East"],
  ];
  return sides.sort((u, v) => u[0] - v[0])[0][1];
};

/** Edge gap of a tile point: how far inside the bounds (negative outside). */
const gapOf = (p: Vec, b: { x0: number; y0: number; x1: number; y1: number }) =>
  Math.min(p.x - b.x0, b.x1 - p.x, p.y - b.y0, b.y1 - p.y);

/**
 * A link's road pieces chained from the one nearest the map's edge inward, until the chain is
 * inside by enough for the post and its queue. Null when none of them comes near the edge.
 */
const chainToEdge = (
  pieces: Road[],
  b: { x0: number; y0: number; x1: number; y1: number }
): { points: Vec[]; width: number } | null => {
  let start: Road | null = null;
  let gap = Infinity;
  let flip = false;
  for (const r of pieces) {
    const g0 = gapOf(r.points[0], b);
    const g1 = gapOf(r.points[r.points.length - 1], b);
    if (Math.min(g0, g1) < gap) {
      gap = Math.min(g0, g1);
      start = r;
      flip = g1 < g0;
    }
  }
  if (!start || gap > BORDERS.inset) return null;
  const points = flip ? start.points.slice().reverse() : start.points.slice();
  const used = new Set([start]);
  const want = BORDERS.inset + BORDERS.queueRoom + 8;
  for (let n = 0; n < 32 && gapOf(points[points.length - 1], b) < want; n++) {
    const tail = points[points.length - 1];
    const next = pieces.find(
      (r) =>
        !used.has(r) &&
        (Math.hypot(r.points[0].x - tail.x, r.points[0].y - tail.y) < 3 ||
          Math.hypot(
            r.points[r.points.length - 1].x - tail.x,
            r.points[r.points.length - 1].y - tail.y
          ) < 3)
    );
    if (!next) break;
    used.add(next);
    const fwd =
      Math.hypot(next.points[0].x - tail.x, next.points[0].y - tail.y) < 3;
    points.push(
      ...(fwd ? next.points.slice(1) : next.points.slice(0, -1).reverse())
    );
  }
  return { points, width: start.width };
};

const gateFrom = (
  id: string,
  kind: GateKind,
  name: string,
  town: number,
  points: readonly Vec[],
  width: number,
  b: { x0: number; y0: number; x1: number; y1: number }
): Gate | null => {
  const exit = exitOf(points, b);
  if (!exit) return null;
  const { path, s, L, edge } = exit;
  const at = pointAlong(path, s);
  const back = pointAlong(path, Math.max(0, s - 2));
  const inward = subPath(path, s, Math.min(BORDERS.queueRoom, L - s));
  return {
    id,
    kind,
    name,
    town,
    x: at.x * TILE,
    y: at.y * TILE,
    angle: Math.atan2(back.y - at.y, back.x - at.x),
    half: (width / 2) * TILE,
    inward: inward.map((p) => ({ x: p.x * TILE, y: p.y * TILE })),
    edge: { x: edge.x * TILE, y: edge.y * TILE },
    seed: Math.round(at.x * 131 + at.y * 977) >>> 0,
  };
};

/** The gates of a plan (world units). Pure in the plan and map. */
export const gatesOfPlan = (plan: Plan, map: WorldMap, owner: GenerationInput): Gate[] => {
  const sk = plan.skeleton;
  const b = sk.bounds;
  const town = (settlement: string) =>
    map.places.findIndex((p) => p.id === settlement);
  const out: Gate[] = [];
  let roads: Road[] | null = null;
  for (const link of sk.links) {
    const ends = [link.from, link.to];
    const gateEnd = ends.find((e) => e.startsWith("gate:"));
    if (!gateEnd) continue;
    const from = ends.find((e) => e !== gateEnd);
    if (!from) continue;
    roads ??= networkOf(plan, owner).roads;
    const chain = chainToEdge(
      roads.filter((r) => r.link === link.id && r.points.length >= 2),
      b
    );
    if (!chain) continue;
    // Named for the gateway anchor nearest where it leaves.
    const end = chain.points[0];
    let anchor: (typeof sk.anchors)[number] | undefined;
    let d = Infinity;
    for (const a of sk.anchors) {
      if (a.kind !== "gateway") continue;
      const e = Math.hypot(a.at.x - end.x, a.at.y - end.y);
      if (e < d) {
        d = e;
        anchor = a;
      }
    }
    const key = gateEnd.slice(5);
    const name = anchor && d < 200 ? anchor.name : `${compass(end, b)} Road`;
    const g = gateFrom(
      `road:${key}`,
      "road",
      name,
      town(from),
      chain.points,
      chain.width,
      b
    );
    if (g) out.push(g);
  }
  for (const rail of sk.railways ?? []) {
    if (rail.kind !== "main") continue;
    const first = rail.stops[0]?.settlement ?? "";
    const last = rail.stops[rail.stops.length - 1]?.settlement ?? "";
    // The stop nearest the end that runs off the map serves it.
    const exit = exitOf(rail.path, b);
    if (!exit) continue;
    const startEnd = exit.path[0] === rail.path[0];
    // The whole bed: the ballast of its widest piece and a shoulder either side.
    const ballast = plan.rails.reduce(
      (w, r) => (r.line === rail.id ? Math.max(w, r.width) : w),
      3
    );
    const g = gateFrom(
      `rail:${rail.id}`,
      "rail",
      `Main line ${compass(exit.path[0], b).toLowerCase()}`,
      town(startEnd ? first : last),
      rail.path,
      ballast + 3,
      b
    );
    if (g) out.push(g);
  }
  // Airports and harbours (world agent), when the skeleton has them: anchors of kind "terminal"
  // named for them. A terminal gate has no road to queue on: its post is at the anchor.
  for (const a of sk.anchors) {
    const kind: GateKind | null = /airport|airfield/i.test(a.name)
      ? "air"
      : /harbou?r|port|ferry|pier/i.test(a.name) && a.kind === "terminal"
      ? "sea"
      : null;
    if (!kind || a.kind !== "terminal") continue;
    let near = -1;
    let d = Infinity;
    map.places.forEach((p, i) => {
      const e = Math.hypot(p.x / TILE - a.at.x, p.y / TILE - a.at.y);
      if (e < d) {
        d = e;
        near = i;
      }
    });
    out.push({
      id: `${kind}:${a.id}`,
      kind,
      name: a.name,
      town: near,
      x: a.at.x * TILE,
      y: a.at.y * TILE,
      angle: 0,
      half: 2 * TILE,
      inward: [],
      edge: { x: a.at.x * TILE, y: a.at.y * TILE },
      seed: Math.round(a.at.x * 131 + a.at.y * 977) >>> 0,
    });
  }
  return out;
};

/** The active atlas's gates (none without an atlas). Cached per plan and map. */
export const createBorderGeometry = (): BorderGeometry => ({
  plan: null,
  map: null,
  gates: [],
});
export const gatesOf = (
  map: WorldMap,
  plan: Plan | null,
  geometry: BorderGeometry,
  owner: GenerationInput
): Gate[] => {
  if (geometry.plan === plan && geometry.map === map) return geometry.gates;
  geometry.plan = plan;
  geometry.map = map;
  geometry.gates = plan ? gatesOfPlan(plan, map, owner) : [];
  return geometry.gates;
};

/** The world outside the active space: the country, the other spaces, abroad. */
export const outsideOf = (plan: Plan | null): Outside[] => {
  const here = plan?.skeleton.space.key ?? "";
  return [
    {
      id: "country",
      name: "The rest of the country",
      population: OUTSIDE_PEOPLE.country,
      by: ["road", "rail"],
    },
    ...ALPHA.spaces
      .filter((s) => s.key !== here)
      .map(
        (s): Outside => ({
          id: s.key,
          name: s.name,
          population: OUTSIDE_PEOPLE.space * s.populationWeight,
          by: ["air", "sea"],
        })
      ),
    {
      id: "abroad",
      name: "Abroad",
      population: OUTSIDE_PEOPLE.abroad,
      by: ["air", "sea"],
    },
  ];
};

// ---------------------------------------------------------------------------------------------
// State, page side.

export { BordersState as Borders } from "../../components/response/BordersState";
import type { BordersState as Borders } from "../../components/response/BordersState";

/** Fresh borders over `gates`, every gate open (or `pinned`) and nothing yet out of the region. */
const newBorders = (gates: Borders["gates"], plan: Plan | null, pinned: GateStatus | null, tick: number): Borders => {
  const outside = outsideOf(plan);
return {
    gates,
    outside,
    million: outside.map(() => false),
    smuggled: gates.map(() => false),
    gate: gates.map(() => ({
      status: pinned === null ? [] : [[pinned, 0]],
      changed: pinned === null ? -Infinity : tick,
      caught: 0,
      held: pinned ? 9 : 0,
      out: 0,
      smuggled: pinned === GateStatus.Closed ? 1 : 0,
    })),
    world: outside.map(() => ({
      infected: 0,
      dead: 0,
      closure: 0,
      found: -1,
      arrived: 0,
      smuggled: 0,
    })),
    infectedSeries: outside.map(() => []),
    pinned,
    tick,
  };
};

/** The borders of a response, made on first use. */
export const bordersOf = (
  r: WorldResponse,
  map: WorldMap,
  plan: Plan | null,
  owner: GenerationInput
): Borders => {
  const b = r.memory.borders;
  const gates = gatesOf(map, plan, r.geometry, owner);
  if (b && b.gates === gates) return b;
  // Loaded borders are over the same gates, found again: they carry on over the found ones.
  if (b && b.gates.length === gates.length && b.gates.every((gate, i) => gate.id === gates[i].id)) return ((b.gates = gates), b);
  // A debug pin outlives the gates being found (the plan comes after the response).
  return (r.memory.borders = newBorders(gates, plan, b?.pinned ?? null, r.tick));
};

/** The borders as a reader of the export shows them: the export's, or before the response has made any, its gates all open (`geometry` is the reader's own cache of them). */
export const shownBorders = (
  view: Pick<ResponseView, "borders" | "tick">,
  map: WorldMap,
  plan: Plan | null,
  owner: GenerationInput,
  geometry: BorderGeometry
): Borders => view.borders ?? newBorders(gatesOf(map, plan, geometry, owner), plan, null, view.tick);

/** A gate's status at a tick. */
export const gateStatusAt = (
  b: Borders,
  gate: number,
  tick: number
): GateStatus =>
  valueAt(b.gate[gate]?.status, tick, GateStatus.Open) as GateStatus;

export type BorderNews = { text: string; kind: "good" | "bad" };

/** Which outside parts a gate reaches. */
export const reaches = (b: Borders, g: Gate) =>
  b.outside
    .map((o, i) => (o.by.includes(g.kind) ? i : -1))
    .filter((i) => i >= 0);

/** What the gate's own side wants, from its town's ladder, the region's, the town's shut border and the outside's closure. */
export const wanted = (
  r: WorldResponse,
  b: Borders,
  g: Gate,
  tick: number
): GateStatus => {
  const own = g.town >= 0 ? r.towns[g.town] : undefined;
  const level = own?.level ?? 0;
  const worst = r.towns.reduce((m, t) => Math.max(m, t.level), 0);
  const shut =
    g.town >= 0 && collapseOf(r.shared.towns[g.town], tick).border > 0;
  const far = reaches(b, g).reduce(
    (m, i) => Math.max(m, b.world[i].closure),
    0
  );
  // Airports and ports go first: the whole region at lockdown shuts them.
  const flying = g.kind === "air" || g.kind === "sea";
  if (
    level >= Level.Checkpoints ||
    shut ||
    far >= 0.8 ||
    (flying && worst >= Level.Lockdown)
  )
    return GateStatus.Closed;
  if (
    level >= Level.Curfew ||
    worst >= Level.Lockdown ||
    far >= 0.35 ||
    (flying && worst >= Level.Closures)
  )
    return GateStatus.Screening;
  return GateStatus.Open;
};

/**
 * Advances the gates and the outside to the response's tick (call after stepCollapse, with that
 * step's dt in seconds). Returns news for the page to toast.
 */


/** What the map, the HUD and the endgame read: gates with their status, the outside with its numbers. */
export const bordersView = (
  r: WorldResponse,
  map: WorldMap,
  tick: number,
  plan: Plan | null,
  owner: GenerationInput
) => {
  const b = bordersOf(r, map, plan, owner);
  return {
    gates: b.gates.map((g, i) => ({
      id: g.id,
      kind: g.kind,
      name: g.name,
      town: g.town,
      status: gateStatusAt(b, i, tick),
      held: Math.round(b.gate[i].held),
      caught: Math.round(b.gate[i].caught),
      out: Math.round(b.gate[i].out),
      smuggled: Math.round(b.gate[i].smuggled),
      x: g.x,
      y: g.y,
      edge: g.edge,
    })),
    outside: b.outside.map((o, i) => ({
      id: o.id,
      name: o.name,
      population: o.population,
      infected: Math.round(b.world[i].infected * o.population),
      dead: Math.round(b.world[i].dead * o.population),
      closure: b.world[i].closure,
      arrived: Math.round(b.world[i].arrived),
    })),
  };
};

/** Someone held in a gate's pen (k-th), stable for a while: a seed, or -1 if the pen holds fewer. */
export const heldAt = (
  b: Borders,
  gate: number,
  k: number,
  seconds: number
) => {
  const n = Math.min(12, Math.round(b.gate[gate]?.held ?? 0));
  if (k >= n) return -1;
  // People come and go: each slot's occupant changes every few hours, out of step with the others.
  const turn = Math.floor(
    seconds / (DAY_SECONDS / 6) + hashUnit(gate, k, 0x68656c64) * 3
  );
  return (b.gates[gate].seed * 31 + k * 977 + turn * 7919) >>> 0;
};
