/**
 * The cold tier: a chunk nobody simulates as people, held as its residents' counts by state
 * (components/cold/ColdCells.ts), stepped on the authority's steps. It is authoritative at its own
 * scale: who turns is drawn per cohort (draws.ts), hashed on the run's seed, the cell and the tick,
 * so the same steps give the same counts anywhere.
 *
 * Rate-matched to warm the way warm is to hot (services/load/rates.ts): a carrier gives each warm
 * cellmate `carrierRate` a second, and a warm person turns once their load reaches the dose. Here
 * each chunk's contagion per head, times the mean cellmates a person has (`crowd`, with the
 * neighbouring cells' reach), is the pressure on each of the people there, and a susceptible turns
 * at hazard pressure / dose. People are where the commute plan has them: commuters at their work
 * chunk in work hours (less lockdown), everyone else at home; a work chunk that isn't cold adds
 * its own people and contagion from the run's counts, unless it takes the commuters in as people
 * (`admits`: then they are there, out of the counts, and nobody goes there from them).
 *
 * The strain comes in only as its trait classes model it (traits/: effectsOf): the carriers' rates,
 * what passes, the dose, the stages' pace, and the bites, animals and water on top.
 *
 * Not modelled cold (yet): wards and home care, shunning, the vaccine, transit cabins, cures,
 * weather stress on the bloomed and the steered host (it is always somewhere warm).
 */
import { chunkX, chunkY } from "yage/streaming";
import { CONTENT } from "../../content/runtime";
import { beastHazard, bodiesOf, breedOf, sickShare, effectsOf, killsOf, lifeRateOf, lifeStretchOf, reachOf, risenShare, routeHazard, type TraitEffects, wildOf } from "../../traits";
import { RULES, State, type Traits } from "../disease";
import type { Move } from "./cast";
import { binomial, chance, unitOf } from "./draws";

export const COLD = CONTENT.sim.cold;

/** Stages the incubating and the bloomed pass through: their times are Erlang, not memoryless (warm's spread ±25%; eight stages, ±35%). */
export const STAGES = 8;

/** The most of a stage's people that move on in one draw: a step moves people stage by stage in sub-steps no coarser than this. */
const SUB_SHARE = 0.2;

/**
 * The chance a host moves on one stage in a sub-step of `tau` at stage rate `rate`. A sub-step moves a
 * host on at most one stage, so a stage lasts a whole number of sub-steps, geometric with this chance:
 * its mean is tau / chance. At rate·tau the mean is exactly 1 / rate, and eight stages' exactly the
 * strain's incubation (or life). The continuous 1 − e^(−rate·tau) undershoots it and ran every host's
 * stages ~10% long (22.1 s for a set 20 s). SUB_SHARE caps rate·tau, so the chance stays a share.
 */
const stagePass = (rate: number, tau: number) => Math.min(1, rate * tau);

/** The shape a cold cell has (components/cold/ColdCells.ts ColdCell). */
export type Cold = {
  key: number;
  cx: number;
  cy: number;
  s: number;
  e: number[];
  i: number[];
  d: number;
  soldiers: number;
  alert: number;
  overrides: number[];
  /** Residents who are people in a warm chunk (gids, ascending): not in the counts, not made again. */
  out: number[];
  flowTo: number[];
  flowN: number[];
};

/** A chunk that isn't cold, as the run counts it: its people and their contagion (load a second to each cellmate, summed). */
export type Outside = { people: number; rate: number };

export type ColdEnv = {
  seed: number;
  tick: number;
  /** Seconds this step covers. */
  dt: number;
  traits: Traits;
  /** What passes between people in a chunk now, on top of the traits' rates: infectivity, weather, masks both ways. */
  scale: (cx: number, cy: number) => number;
  /** The share of a chunk's commuters at their work now (work hours, less lockdown). */
  commuting: (cx: number, cy: number) => number;
  /** A chunk that isn't cold, now; null when the run knows nobody there. */
  outside: (key: number) => Outside | null;
  /** People in a cold cell from beyond the cells stepped (an anchor pond's other towns: src/anchors), on top of its own; none by default. */
  incoming?: (key: number) => Outside | null;
  /** How much of a flow to `key` gets through now (an anchor pond's closures: slower and fewer, src/anchors); all of it by default. */
  capacity?: (key: number) => number;
  /** Whether a chunk that isn't cold takes this tier's commuters in as people (they are there, not here): none go there in the counts. Default: none does. */
  admits?: (key: number) => boolean;
  /** Aggregate people still travelling along a surveyed flow after partial materialization. */
  commuters?: (cell: Cold, flow: number, away: number) => number;
  /** A cell's town's walls (0–1), which keep its feral animals out, as the pond's do; none by default. */
  walls?: (key: number) => number;
  /** Hears each cell's moves as they are drawn (bucket `from` to the next: domain/cold/cast.ts), for the cast to follow; it changes nothing. */
  moves?: (key: number, move: Move) => void;
};

/** What a cold step decided in one cell: a cohort's (gid NO_GID) or one known person's. */
export type ColdEvent = { kind: ColdKind; key: number; gid: number; count: number };
export const enum ColdKind {
  Infected = 1,
  Symptomatic = 2,
  Died = 3,
}
export const NO_GID = 0xffffffff;

const enum Purpose {
  Infect = 1,
  Person = 2,
  PersonTimer = 3,
  Bitten = 4,
  Killed = 5,
  Bred = 6,
  PersonBitten = 7,
  PersonKilled = 8,
  /** Each sub-step's stage draws: Incubate or Bloom, plus sub-step × Span, plus the stage. */
  Span = 0x40,
  Incubate = 0x1000_0000,
  Bloom = 0x2000_0000,
}

/** The dead's bucket as the cast counts them (domain/cold/cast.ts BUCKETS - 1): the young born into their homes move on from it to the first bloomed stage. */
const DEAD_BUCKET = 1 + 2 * STAGES;

const zeros = () => new Array<number>(STAGES).fill(0);

/**
 * The load a second on each person in a chunk with `people` there giving off `rate` between them:
 * its contagion per head, times the cellmates each has (COLD.crowd, with the neighbouring cells'
 * reach), times what passes between people there now (`scale`).
 */
export const coldPressure = (rate: number, people: number, fx: TraitEffects, scale: number) => {
  if (people <= 0) return 0;
  return (rate / people) * COLD.crowd * reachOf(fx) * scale;
};

/** Load a second one carrier in `state` gives each cellmate (the effects' rates). */
export const rateOf = (state: number, fx: TraitEffects) =>
  state === State.Incubating ? fx.rates.rE : state === State.Infected ? fx.rates.rI : state === State.Dead ? fx.rates.rD : 0;

/** Contagion `n` people in `state` give off (load a second to each cellmate, summed). */
export const contagionIn = (state: number, n: number, traits: Traits) => n * rateOf(state, effectsOf(traits));

/** Every resident a cell counts, known by name or not. */
export const residents = (c: Cold) => {
  let n = c.s + c.d + c.overrides.length / 3;
  for (let k = 0;k < STAGES;k++) n += c.e[k] + c.i[k];
  return n;
};

/** A cell's counts as a chunk row reports them (ChunkCounts). */
export const coldCounts = (c: Cold) => {
  let incubating = 0;
  let infected = 0;
  let dead = c.d;
  for (let k = 0;k < STAGES;k++) {
    incubating += c.e[k];
    infected += c.i[k];
  }
  for (let o = 0;o < c.overrides.length;o += 3) {
    const state = c.overrides[o + 1];
    if (state === State.Incubating) incubating++;
    else if (state === State.Infected) infected++;
    else if (state === State.Dead) dead++;
  }
  return { people: residents(c), incubating, infected, dead, soldiers: c.soldiers, alert: c.alert };
};

/** Contagion a cell's residents give off, summed (load a second to each cellmate). */
export const contagionOf = (c: Cold, fx: TraitEffects) => {
  const { rE, rI, rD } = fx.rates;
  let r = c.d * rD;
  for (let k = 0;k < STAGES;k++) r += c.e[k] * rE + c.i[k] * rI;
  for (let o = 0;o < c.overrides.length;o += 3) r += rateOf(c.overrides[o + 1], fx);
  return r;
};

/** A cell's bloomed, named or not. */
const bloomedIn = (c: Cold) => {
  let n = 0;
  for (let k = 0;k < STAGES;k++) n += c.i[k];
  for (let o = 0;o < c.overrides.length;o += 3) if (c.overrides[o + 1] === State.Infected) n++;
  return n;
};

/** A cell's share sick or dead (its animals and water follow it: traits/carriers.ts). */
/** A cell's dead, the named among them. */
const deadIn = (c: Cold) => {
  let dead = c.d;
  for (let o = 0;o < c.overrides.length;o += 3) if (c.overrides[o + 1] === State.Dead) dead++;
  return dead;
};

/** A cell's incubating, named or not. */
const incubatingIn = (c: Cold) => {
  let n = 0;
  for (let k = 0;k < STAGES;k++) n += c.e[k];
  for (let o = 0;o < c.overrides.length;o += 3) if (c.overrides[o + 1] === State.Incubating) n++;
  return n;
};

/** A cell's share feeding its animals and water: bloomed, dead and the incubating's part (sickShare, as RoutesSystem has it). */
const sickIn = (c: Cold, n: number) => sickShare(bloomedIn(c), deadIn(c), incubatingIn(c), n);

/** Chance over `dt` at hazard `h`. */
const within = (h: number, dt: number) => (h > 0 ? 1 - Math.exp(-h * dt) : 0);

/**
 * One cold step for someone known by name, the (gid, state, timer) triple at `q` of `o`, who would
 * catch it at `caught` this step: on their own timer, as warm and hot would have them. What turned, or 0.
 */
/** Where a named person is, for their own timer: the share of what catches them that bites, and how long the bloomed there live (lifeStretchOf). */
export type NamedPlace = { bitten: number; kills: number; stretch: number };

export const stepNamed = (o: number[], q: number, caught: number, seed: number, tick: number, dt: number, traits: Traits, place?: NamedPlace): ColdKind | 0 => {
  const gid = o[q];
  if (o[q + 1] === State.Susceptible) {
    if (!chance(caught, seed, gid, tick, Purpose.Person)) return 0;
    // Bitten (their share of what caught them), a raging bite kills: dead, or risen bloomed on the reanimated's longer life (BiteSystem).
    const fx = effectsOf(traits);
    if (place && place.bitten > 0 && place.kills > 0 && unitOf(seed, gid, tick, Purpose.PersonBitten) < place.bitten && unitOf(seed, gid, tick, Purpose.PersonKilled) < place.kills) {
      if (fx.rises > 0) {
        o[q + 1] = State.Infected;
        o[q + 2] = traits.lifespan * fx.riseLife;
        return ColdKind.Symptomatic;
      }
      o[q + 1] = State.Dead;
      o[q + 2] = 0;
      return ColdKind.Died;
    }
    o[q + 1] = State.Incubating;
    o[q + 2] = traits.incubation * (0.75 + unitOf(seed, gid, tick, Purpose.PersonTimer) * 0.5);
    return ColdKind.Infected;
  }
  if (o[q + 1] === State.Incubating) {
    o[q + 2] -= dt;
    if (o[q + 2] > 0) return 0;
    o[q + 1] = State.Infected;
    o[q + 2] = traits.lifespan * (1 + (unitOf(seed, gid, tick, Purpose.PersonTimer) * 2 - 1) * RULES.lifeJitter);
    return ColdKind.Symptomatic;
  }
  if (o[q + 1] === State.Infected) {
    // Their life runs down as the bloomed about them do: slower where they feed or forage (lifeStretchOf; DiseaseSystem, BiteSystem).
    o[q + 2] -= (traits.decay * dt) / (place?.stretch ?? 1);
    if (o[q + 2] > 0) return 0;
    o[q + 1] = State.Dead;
    o[q + 2] = 0;
    return ColdKind.Died;
  }
  return 0;
};

/**
 * The chance over `dt` that someone passing through cell `c` catches it from its residents, at
 * `scale` (coldStep's): its own people's contagion at home, its commuters' comings and goings aside.
 */
export const passingChance = (c: Cold, traits: Traits, scale: number, dt: number) => {
  const fx = effectsOf(traits);
  return within(coldPressure(contagionOf(c, fx), residents(c), fx, scale) / fx.dose, dt);
};

/** One cold step over `cells` (in key order): the counts move on in place; what turned, as events. */
export const coldStep = (cells: readonly Cold[], env: ColdEnv): ColdEvent[] => {
  const { traits, dt, seed, tick } = env;
  const fx = effectsOf(traits);
  const people = new Map<number, number>();
  const rate = new Map<number, number>();
  // The bloomed where they are (their bites), only where the strain bites.
  const biting = fx.bites > 0 ? new Map<number, number>() : null;
  // The living where they are (who the bites fall among: the pond's besides, the hunters, pass the dead by).
  const alive = biting ? new Map<number, number>() : null;
  const add = (key: number, p: number, r: number, b = 0, l = p) => {
    people.set(key, (people.get(key) ?? 0) + p);
    rate.set(key, (rate.get(key) ?? 0) + r);
    if (biting && b) biting.set(key, (biting.get(key) ?? 0) + b);
    if (alive && l) alive.set(key, (alive.get(key) ?? 0) + l);
  };
  const cold = new Set(cells.map((c) => c.key));
  const n = cells.map(residents);
  const r = cells.map((c) => contagionOf(c, fx));
  const b = biting ? cells.map(bloomedIn) : null;
  const living = cells.map((c, j) => n[j] - deadIn(c));
  const away = cells.map((c) => env.commuting(c.cx, c.cy));
  const admits = env.admits ?? (() => false);
  const capacity = env.capacity ?? (() => 1);
  // Where everyone is now: at home, or at work for the commuters in work hours.
  cells.forEach((c, j) => {
    if (!n[j]) return;
    let gone = 0;
    for (let f = 0;f < c.flowTo.length;f++) {
      if (!cold.has(c.flowTo[f]) && admits(c.flowTo[f])) continue;
      const share = ((env.commuters?.(c, f, away[j]) ?? away[j] * c.flowN[f]) * capacity(c.flowTo[f])) / n[j];
      gone += share;
      add(c.flowTo[f], n[j] * share, r[j] * share, b ? b[j] * share : 0, living[j] * share);
    }
    add(c.key, n[j] * (1 - gone), r[j] * (1 - gone), b ? b[j] * (1 - gone) : 0, living[j] * (1 - gone));
  });
  for (const key of [...people.keys()]) {
    if (cold.has(key)) continue;
    const there = env.outside(key);
    if (there) add(key, there.people, there.rate);
  }
  if (env.incoming)
    for (const c of cells) {
      const from = env.incoming(c.key);
      if (from) add(c.key, from.people, from.rate);
    }
  const pressure = new Map<number, number>();
  const at = (key: number, cx: number, cy: number) => {
    let p = pressure.get(key);
    if (p === undefined) {
      p = coldPressure(rate.get(key) ?? 0, people.get(key) ?? 0, fx, env.scale(cx, cy)) / fx.dose;
      pressure.set(key, p);
    }
    return p;
  };
  // The bites on each of the well where they are: the bloomed's bites over the living there.
  const bitesAt = (key: number) => {
    const there = biting ? (biting.get(key) ?? 0) : 0;
    return there > 0 ? (fx.bites * there) / Math.max(1, alive?.get(key) ?? 0) : 0;
  };
  const events: ColdEvent[] = [];
  const note = (kind: ColdKind, key: number, count: number, gid = NO_GID) => {
    if (count > 0) events.push({ kind, key, gid, count });
  };
  const incubateRate = STAGES / fx.incubation;
  // A bloomed host's pace through its stages, quickest where none are well to feed on.
  const lifeRate = lifeRateOf(fx, STAGES, 0);
  const subs = Math.max(1, Math.ceil((Math.max(incubateRate, lifeRate) * dt) / SUB_SHARE));
  const incubate = stagePass(incubateRate, dt / subs);
  const bloomAt = (prey: number, wild: number, risen: number, bodies: number) => stagePass(lifeRateOf(fx, STAGES, prey, wild, risen, bodies), dt / subs);
  const bloomAll = fx.feed > 0 || fx.forage > 0 || fx.rises > 0 || fx.scavenge > 0 ? -1 : bloomAt(0, 0, 0, 0);
  cells.forEach((c, j) => {
    let h = 0;
    let hb = 0;
    let beast = 0;
    if (n[j]) {
      let gone = 0;
      for (let f = 0;f < c.flowTo.length;f++) {
        if (!cold.has(c.flowTo[f]) && admits(c.flowTo[f])) continue;
        const share = ((env.commuters?.(c, f, away[j]) ?? away[j] * c.flowN[f]) * capacity(c.flowTo[f])) / n[j];
        gone += share;
        h += share * at(c.flowTo[f], chunkX(c.flowTo[f]), chunkY(c.flowTo[f]));
        if (biting) hb += share * bitesAt(c.flowTo[f]);
      }
      h += (1 - gone) * at(c.key, c.cx, c.cy);
      if (biting) hb += (1 - gone) * bitesAt(c.key);
      // Feral animals' bites, where they live: the reservoir following the cell's sick and dead.
      const sick = sickIn(c, n[j]);
      beast = beastHazard(fx, sick) * Math.max(0, 1 - (env.walls?.(c.key) ?? 0));
      hb += beast;
      h += hb + routeHazard(fx, sick);
    }
    const caught = within(h, dt);
    const prey = living[j] > 0 ? c.s / living[j] : 0;
    const wild = fx.forage > 0 ? wildOf(n[j]) : 0;
    // The share of the bitten the bites kill: the hosts' at their strength, the animals' at the bare kills.
    const kills = killsOf(fx, hb - beast, beast);
    // The dead to go round its bloomed, for hosts that eat them.
    const bodies = fx.scavenge > 0 ? bodiesOf(deadIn(c), bloomedIn(c)) : 0;
    const bloom = bloomAll >= 0 ? bloomAll : bloomAt(prey, wild, risenShare(fx, hb, h, kills), bodies);
    const named: NamedPlace | undefined = c.overrides.length ? { bitten: h > 0 ? hb / h : 0, kills, stretch: lifeStretchOf(fx, prey, wild, bodies) } : undefined;
    // Who catches it is drawn from the susceptible the step began with; the stages then move on
    // sub-step by sub-step, each sub-step's draws from the counts it began with.
    const infected = binomial(c.s, caught, seed, c.key, tick, Purpose.Infect);
    // Of them, the bitten (their share of the hazard), and of those a raging bite kills: dead, or risen bloomed.
    const killed = hb > 0 && kills > 0 && infected > 0 ? binomial(binomial(infected, hb / h, seed, c.key, tick, Purpose.Bitten), kills, seed, c.key, tick, Purpose.Killed) : 0;
    const risen = fx.rises > 0 ? killed : 0;
    let symptomatic = 0;
    let dead = 0;
    const bloomed = zeros();
    const died = zeros();
    for (let u = 0;u < subs;u++) {
      for (let k = 0;k < STAGES;k++) {
        bloomed[k] = binomial(c.e[k], incubate, seed, c.key, tick, Purpose.Incubate + u * Purpose.Span + k);
        died[k] = binomial(c.i[k], bloom, seed, c.key, tick, Purpose.Bloom + u * Purpose.Span + k);
      }
      if (env.moves) {
        for (let k = 0;k < STAGES;k++) {
          if (bloomed[k]) env.moves(c.key, { sub: u, from: 1 + k, n: c.e[k], k: bloomed[k] });
          if (died[k]) env.moves(c.key, { sub: u, from: 1 + STAGES + k, n: c.i[k], k: died[k] });
        }
      }
      for (let k = 0;k < STAGES;k++) {
        c.e[k] -= bloomed[k];
        if (k + 1 < STAGES) c.e[k + 1] += bloomed[k];
        else c.i[0] += bloomed[k];
        c.i[k] -= died[k];
        if (k + 1 < STAGES) c.i[k + 1] += died[k];
        else c.d += died[k];
      }
      symptomatic += bloomed[STAGES - 1];
      dead += died[STAGES - 1];
    }
    if (infected && env.moves) env.moves(c.key, { sub: subs, from: 0, n: c.s, k: infected });
    // Breeding: the bloomed's young, born bloomed into the dead's homes (breedOf), drawn from the bloomed the stages left.
    let born = 0;
    if (fx.breed > 0 && c.d > 0) {
      let bloomedNow = 0;
      for (let k = 0;k < STAGES;k++) bloomedNow += c.i[k];
      const all = residents(c);
      born = bloomedNow > 0 ? Math.min(c.d, binomial(bloomedNow, within(breedOf(fx, wildOf(all), c.d / all), dt), seed, c.key, tick, Purpose.Bred)) : 0;
      if (born && env.moves) env.moves(c.key, { sub: subs, from: DEAD_BUCKET, n: c.d, k: born });
    }
    c.s -= infected;
    c.e[0] += infected - killed;
    c.i[0] += risen + born;
    c.d += killed - risen - born;
    note(ColdKind.Infected, c.key, infected - killed + risen + born);
    note(ColdKind.Symptomatic, c.key, symptomatic + risen + born);
    note(ColdKind.Died, c.key, dead + killed - risen);
    // The people the run knows by name, each on their own timer, as warm and hot would have them.
    const o = c.overrides;
    for (let q = 0;q < o.length;q += 3) {
      const was = o[q + 1];
      const kind = stepNamed(o, q, caught, seed, tick, dt, traits, named);
      // Risen at once from a bite: caught and bloomed both, as the cohorts' risen are.
      if (kind === ColdKind.Symptomatic && was === State.Susceptible) note(ColdKind.Infected, c.key, 1, o[q]);
      if (kind) note(kind, c.key, 1, o[q]);
    }
  });
  return events;
};
