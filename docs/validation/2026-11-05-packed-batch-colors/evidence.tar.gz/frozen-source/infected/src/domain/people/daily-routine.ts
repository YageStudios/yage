import { hash } from "../world";
import { LifeRole } from "./identity";
import { Activity, BED, FAM, SCHEDULES, WAKE, WE, WS, type ScheduleEntry } from "./day-schedule";

export type DailyRoutineProfile = {
  id: string;
  /** Stable share following this regional pattern; other residents keep their occupation's baseline. */
  participation: number;
  schedules: Partial<Record<LifeRole, readonly ScheduleEntry[]>>;
  /** Local civil hour and relative activity, cyclic over midnight. Values are game tuning. */
  street: readonly (readonly [number, number])[];
  workplace: readonly (readonly [number, number])[];
};

/** A configurable gameplay preset requested for southern Spain, not a survey of all residents. */
export const SOUTHERN_SPAIN_ROUTINE: DailyRoutineProfile = {
  id: "southern-spain",
  participation: 0.65,
  schedules: {
    [LifeRole.Worker]: [
      [0, Activity.Evening, 0],
      [1.5, Activity.Sleep, BED],
      [8, Activity.Home, WAKE],
      [9, Activity.Work, WS],
      [14, Activity.Home, 0],
      [17, Activity.Work, 0],
      [20, Activity.Leisure, WE],
      [21, Activity.Home, FAM],
      [22, Activity.Evening, 0],
    ],
    [LifeRole.Parent]: [
      [0, Activity.Evening, 0],
      [1, Activity.Sleep, BED],
      [7, Activity.Home, WAKE],
      [7.6, Activity.Escort, FAM],
      [9, Activity.Work, WS],
      [14, Activity.Home, 0],
      [17, Activity.Work, 0],
      [20, Activity.Leisure, WE],
      [21, Activity.Home, FAM],
      [22, Activity.Evening, 0],
    ],
  },
  street: [
    [0, 0.7],
    [2, 0.12],
    [5, 0.05],
    [8, 0.65],
    [11, 0.8],
    [14, 0.3],
    [16, 0.18],
    [18, 0.7],
    [21, 0.9],
    [23, 1],
  ],
  workplace: [
    [0, 0.03],
    [7, 0.03],
    [9, 0.8],
    [13, 0.9],
    [14.5, 0.08],
    [16, 0.08],
    [17.5, 0.8],
    [19.5, 0.7],
    [21, 0.03],
  ],
};

export const regionalDailyRoutine = (country: string, latitude: number, longitude: number) =>
  country === "Spain" && latitude >= 36 && latitude <= 38.8 && longitude >= -7.6 && longitude <= -1.5
    ? SOUTHERN_SPAIN_ROUTINE
    : undefined;

export const scheduleFor = (person: { gid: number; role: number; routine?: DailyRoutineProfile }) => {
  const routine = person.routine;
  const custom = routine?.schedules[person.role as LifeRole];
  return custom && hash(person.gid, 0x726f7574) / 0x100000000 < Math.max(0, Math.min(1, routine!.participation))
    ? custom
    : SCHEDULES[person.role];
};

/** Interpolate regional activity at local civil time, including the midnight seam. */
const cycleAt = (curve: readonly (readonly [number, number])[], hour: number) => {
  if (!curve.length) return 0;
  const local = ((hour % 24) + 24) % 24;
  let left = curve[curve.length - 1],
    right = curve[0];
  let from = left[0] - 24,
    to = right[0];
  for (let i = 0; i < curve.length; i++) {
    if (local < curve[i][0]) break;
    left = curve[i];
    from = left[0];
    right = curve[(i + 1) % curve.length];
    to = right[0] + (i + 1 === curve.length ? 24 : 0);
  }
  const share = to === from ? 0 : (local - from) / (to - from);
  return Math.max(0, Math.min(1, left[1] + (right[1] - left[1]) * share));
};

export const dailyActivity = (routine: DailyRoutineProfile, localHour: number) => ({
  street: cycleAt(routine.street, localHour),
  workplace: cycleAt(routine.workplace, localHour),
});
