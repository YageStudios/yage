import type { LeanGameModel } from "yage/game/LeanGameModel";
import type { ReadOnlyGameModel } from "yage/game/GameModel";
import { RegionGates } from "../../components/response/RegionGates";
import { RegionMemory } from "../../components/response/RegionMemory";
import { RegionResponse } from "../../components/response/RegionResponse";
import { RegionTopology } from "../../components/response/RegionTopology";
import { RegionTowns } from "../../components/response/RegionTowns";
import { ResearchState } from "../../components/response/ResearchState";
import { TownResponse } from "../../components/response/TownResponse";
import type { WorldResponse } from "../../components/response/WorldResponse";
import { secondsBetween } from "./routes";
/** Reads of the region response pass (region:response; the response systems run on it and on its towns). */
export type Pass = ReadOnlyGameModel | LeanGameModel;
export const passOf = (g: Pass) => g.single(RegionResponse);
export const responding = (g: Pass) => {
  const rr = passOf(g);
  return rr.due && rr.respond ? rr : null;
};
export const span = (rr: RegionResponse) => secondsBetween(rr.before, rr.tick);
/** A per-town system's towns (its query's entities) in place order, each with its TownResponse. */
export const townsInOrder = (g: Pass, entities: readonly number[]) =>
  entities
    .map((eid) => ({ eid, town: g.getTypedUnsafe(TownResponse, eid) }))
    .sort((a, b) => a.town.index - b.town.index);
/**
 * The response systems' working view of the region's response, over its owners: the towns' own rows
 * in place order, the research, the links and the region's memory. Built where a system needs the
 * whole response and never stored; its scalars are copies (research is written to ResearchState).
 */
export const regionResponse = (g: Pass): WorldResponse => {
  const towns = g.single(RegionTowns).towns.map((eid) => g.getTypedUnsafe(TownResponse, eid));
  const research = g.single(ResearchState);
  return {
    towns: towns.map((town) => town.state),
    shared: { towns: towns.map((town) => town.series) },
    links: g.single(RegionTopology).links,
    cure: research.cure,
    reshuffles: research.reshuffles,
    tick: research.tick,
    memory: g.single(RegionMemory).memory,
    geometry: g.single(RegionGates).geometry,
  };
};
