/**
 * The item catalog: every placeable thing smaller than a building — furniture, street furniture,
 * yard and farm gear, clutter, parked vehicles. Pure data shared by three consumers:
 *
 * - the world generator places items (ChunkArt.items) by set, room and biome tags;
 * - the art draws each item's `art` sprite (src/render/items.ts; a test checks every key resolves);
 * - the sim can treat items as surfaces: `touch` says how often hands land on it, so viral load
 *   deposited on a table, door handle, bed or tram pole is attributable to that item.
 *
 * The data lives in src/entities/items/*.json5 as entity definitions; this module rebuilds the table.
 *
 * Footprints are in tiles (w along x, h along y) before rotation; `rot` quarter-turns swap them.
 */

import { componentOf, dataOf, definitionsOf } from "../content/definitions";

export type ItemCategory = "furniture" | "fixture" | "street" | "yard" | "farm" | "clutter" | "vehicle" | "infra";
export type RoomUse = "bedroom" | "living" | "kitchen" | "bath" | "shop" | "office" | "workshop" | "school" | "church" | "tavern" | "station" | "storage";
/** How often hands land on it: high = handles, tables, poles; low = shelves, bins. */
export type Touch = "high" | "medium" | "low" | "none";
/** Surface the load lands on: hard ones hold it longer than soft or porous ones. */
export type Surface = "hard" | "soft" | "porous" | "metal";

/**
 * How a piece is set in its room (render/prefabs.ts itemPose; test/world/orientation.test.ts):
 * - focal: what a room faces (altar, mihrab, minbar, bar, counter, fireplace): squared to the
 *   room exactly, backed against its wall, facing in, on the room's axis; never jittered;
 * - fixture: plumbed or set pieces (font, wudu, sink, stove, bath, shoe rack): squared, never jittered;
 * - ordered: rows (pews, prayer rows, school desks, ward beds): parallel, facing the focal piece;
 * - wall: shelves, dressers, wardrobes: square against a wall;
 * - table: a little jitter (about 6°), its chairs turned to it;
 * - loose: chairs, stools, rugs, plants, clutter: jitter allowed (chairs about 15°).
 * Street and yard pieces take their heading from the generator (ArtItem.angle) and are "fixture".
 */
export type Orient = "focal" | "fixture" | "ordered" | "wall" | "table" | "loose";

export type Item = {
  key: string;
  category: ItemCategory;
  orient: Orient;
  footprint: [number, number];
  /** Culture item sets (architecture.ts Sets) it belongs to; ["*"] = every culture. */
  sets: readonly string[];
  rooms?: readonly RoomUse[];
  /** Biomes it suits (BiomeId); absent = any. */
  biomes?: readonly string[];
  touch: Touch;
  surface: Surface;
  /** Blocks walking (the generator stamps it only where the template allows). */
  blocks: boolean;
  /** Seats or beds: people use it for a while (sit, sleep, ride). */
  seats?: number;
  /** Sprite key in src/render/items.ts. "ground:*" keys are drawn by the ground shader. */
  art: string;
  /** Drawn and in the catalog, but no room plan lays it out yet: itemsFor leaves it out. */
  unplaced?: true;
};

/** The catalog, in order, from src/entities/items/*.json5 (one `item:<key>` definition per item). */
export const ITEMS: readonly Item[] = definitionsOf("item:").map((def) => {
  const key = def.name.slice("item:".length);
  const item = dataOf<Omit<Item, "key" | "category" | "sets" | "rooms" | "biomes" | "art"> & { art?: string }>(def, "Item")!;
  const { category } = dataOf<{ category: ItemCategory }>(def, "ItemCategory")!;
  const place = dataOf<{ sets: string[]; rooms?: RoomUse[]; biomes?: string[] }>(def, "Placement")!;
  const out: Item = {
    key,
    category,
    orient: item.orient,
    footprint: item.footprint,
    sets: place.sets,
    ...(place.rooms && { rooms: place.rooms }),
    ...(place.biomes && { biomes: place.biomes }),
    touch: item.touch,
    surface: item.surface,
    blocks: item.blocks,
    ...(item.seats !== undefined && { seats: item.seats }),
    art: item.art ?? key,
    ...(componentOf(def, "Unplaced") && { unplaced: true as const }),
  };
  return out;
});

const BY_KEY = new Map(ITEMS.map((i) => [i.key, i]));
export const itemOf = (key: string): Item | undefined => BY_KEY.get(key);

/** Items of a culture set, optionally for a room or category. */
export const itemsFor = (set: string, filter: { room?: RoomUse; category?: ItemCategory; biome?: string } = {}) =>
  ITEMS.filter(
    (i) =>
      !i.unplaced &&
      (i.sets.includes("*") || i.sets.includes(set)) &&
      (!filter.room || i.rooms?.includes(filter.room)) &&
      (!filter.category || i.category === filter.category) &&
      (!filter.biome || !i.biomes || i.biomes.includes(filter.biome)),
  );
