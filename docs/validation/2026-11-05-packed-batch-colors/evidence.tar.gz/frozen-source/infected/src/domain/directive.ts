/**
 * Directives: what a scenario asks of someone it follows by name (the cast, domain/cold/cast.ts),
 * a journaled `direct` input. A directive is a goal the person pursues in the world as it is: the
 * authority works out where it takes them (services/directives.ts), the hosts walk them there on
 * their own legs when they are people (warm or hot), and the cold tier moves them cell by cell
 * when they are not. The world can refuse: the dead go nowhere, a walled-off town lets no one in,
 * a shut border or its checkpoints no one across. Then the directive fails, and that is all the
 * scenario learns.
 *
 * Goals:
 * - goTo {town, kind?}: a place of that kind (else the square, else somewhere to spend time) in
 *   the town's centre; a trip across a border is refused as travelTo's is.
 * - travelTo {town}: the town's centre, honouring its border, checkpoints and cordon.
 * - stay {where: home | here}: home, or where they are now.
 * - avoid {town}: wherever the day would take them in that town, home instead.
 * - meet {gid}: where another cast person is (followed as they move); done when both are in one chunk.
 *
 * Until `until` (by default a day, plus twice the walk for a trip) the person stays with it; then
 * they finish the part of the day they are in and go back to their schedule.
 */
import { CHUNK_SIZE, TICK_RATE } from "./world";
import { DAY_SECONDS } from "./time";

export type Goal =
  | { kind: "goTo"; town: number; place?: PlaceWant }
  | { kind: "travelTo"; town: number }
  | { kind: "stay"; where: "home" | "here" }
  | { kind: "avoid"; town: number }
  | { kind: "meet"; gid: number };

/** The kinds of place goTo can ask for (services/directives.ts finds one in the town). */
export type PlaceWant = "square" | "shop" | "eat" | "fun" | "ward" | "church";
export const PLACE_WANTS: readonly PlaceWant[] = ["square", "shop", "eat", "fun", "ward", "church"];

/** A journaled directive: `gid` (cast) pursues `goal` from the step that takes it until `until`. */
export type DirectCommand = { gid: number; goal: Goal; until?: number };

export const enum DirectiveStatus {
  /** Under way (or holding at the target). */
  Active = 0,
  /** Reached (goTo, travelTo, meet), or held to the end (stay, avoid). */
  Done = 1,
  Failed = 2,
}

/** Where a directive takes someone: a chunk and a place in it. */
export type Target = { cx: number; cy: number; place: number };

/** One directive (components/cold/Directives.ts). */
export type DirectiveRecord = {
  gid: number;
  goal: Goal;
  /** The step it was taken on, and the tick it lapses. */
  from: number;
  until: number;
  status: DirectiveStatus;
  /** Where it takes them (null: avoid, which has no one place). */
  target: Target | null;
  /** The tick it was done or failed (-1: neither yet). */
  ended: number;
  /** Ticks walked toward the next chunk while cold. */
  walked: number;
};

/** A directive's outcome, as the run tells it (S4's story events read these). */
export type DirectiveEvent = { tick: number; kind: "directive-done" | "directive-failed"; gid: number; goal: Goal["kind"]; reason?: string } | { tick: number; kind: "stage-failed"; stage: string; reason: string };

/** How the hosts hear of a directive (the config's `directives`): gid, mode, target chunk and place, from, until, avoided town. */
export type WorkerDirective = [gid: number, mode: number, cx: number, cy: number, place: number, from: number, until: number, town: number];
export const enum DirectiveMode {
  /** Spend the day at the target. */
  Go = 0,
  /** Wherever the day goes, never into `town`: home instead. */
  Avoid = 1,
}

const DAY_TICKS = DAY_SECONDS * TICK_RATE;
/** A cold walker's pace (world units a game second): the hosts' walkers do 26 to 40. */
export const COLD_PACE = 32;
/** Ticks a cold walker takes over one chunk. */
export const TICKS_PER_CHUNK = Math.round((CHUNK_SIZE / COLD_PACE) * TICK_RATE);
/** How long a directive holds when the input says nothing: a day, plus twice the walk (`chunks` across). */
export const defaultSpan = (chunks: number) => DAY_TICKS + 2 * chunks * TICKS_PER_CHUNK;

/** Whether the directive is in force on `tick`. */
export const inForce = (d: Pick<DirectiveRecord, "from" | "until" | "status">, tick: number) => d.status !== DirectiveStatus.Failed && tick >= d.from && tick < d.until;
