/** Farthest neighbouring chunk a routine can select: a funeral at a cemetery. */
export const CEMETERY_REACH = 3;
