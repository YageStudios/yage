/**
 * The nature layer's cells and bytes. A nature cell is CHUNK_SIZE / NATURE_CELLS a side; each
 * degraded chunk holds its NATURE_CHUNK_CELLS row by row (components/nature/NatureChunk.ts). On a
 * checkpoint the chunks are laid into one grid over the whole world, row by row from its top-left
 * cell, and run-length coded (pairs of a varint run and a value byte), so untouched land costs
 * almost nothing.
 */
import { CHUNK_SIZE, WORLD_CHUNKS, WORLD_MIN } from "./world";

/** Nature cells along a chunk's side, and in a chunk. */
export const NATURE_CELLS = 8;
export const NATURE_CHUNK_CELLS = NATURE_CELLS * NATURE_CELLS;
/** Nature cells along the world's side (the checkpoint's grid). */
export const NATURE_SIDE = WORLD_CHUNKS * NATURE_CELLS;
/** A nature cell's side in world units. */
export const NATURE_CELL = CHUNK_SIZE / NATURE_CELLS;

/** Degradation: a building burnt out on the cell, the ground scorched round one, a burn squad's ash. */
export const BURNT = 255;
export const SCORCHED = 96;
export const ASHED = 160;

const inWorld = (c: number) => c >= WORLD_MIN && c < WORLD_MIN + WORLD_CHUNKS;

/** The chunk and the cell in it at world point (x, y), or null outside the world. */
export const natureCellAt = (x: number, y: number): [cx: number, cy: number, cell: number] | null => {
  const cx = Math.floor(x / CHUNK_SIZE);
  const cy = Math.floor(y / CHUNK_SIZE);
  if (!inWorld(cx) || !inWorld(cy)) return null;
  const lx = Math.min(NATURE_CELLS - 1, Math.floor((x - cx * CHUNK_SIZE) / NATURE_CELL));
  const ly = Math.min(NATURE_CELLS - 1, Math.floor((y - cy * CHUNK_SIZE) / NATURE_CELL));
  return [cx, cy, ly * NATURE_CELLS + lx];
};

/** Cell `cell` of chunk (cx, cy)'s top-left world point. */
export const natureCellOrigin = (cx: number, cy: number, cell: number): [number, number] => [
  cx * CHUNK_SIZE + (cell % NATURE_CELLS) * NATURE_CELL,
  cy * CHUNK_SIZE + Math.floor(cell / NATURE_CELLS) * NATURE_CELL,
];

export type NatureCells = { cx: number; cy: number; cells: ArrayLike<number> };

/** Chunks' cells laid into the world's grid. */
export const natureGrid = (chunks: Iterable<NatureCells>) => {
  const grid = new Uint8Array(NATURE_SIDE * NATURE_SIDE);
  for (const { cx, cy, cells } of chunks) {
    if (!inWorld(cx) || !inWorld(cy)) throw new Error(`nature: chunk (${cx}, ${cy}) is outside the world`);
    for (let i = 0; i < NATURE_CHUNK_CELLS; i++) {
      const gx = (cx - WORLD_MIN) * NATURE_CELLS + (i % NATURE_CELLS);
      const gy = (cy - WORLD_MIN) * NATURE_CELLS + Math.floor(i / NATURE_CELLS);
      grid[gy * NATURE_SIDE + gx] = cells[i];
    }
  }
  return grid;
};

/** The world's grid as the chunks with any cell degraded, by row then column. */
export const natureChunksOf = (grid: Uint8Array) => {
  const out: { cx: number; cy: number; cells: Uint8Array }[] = [];
  for (let cy = WORLD_MIN; cy < WORLD_MIN + WORLD_CHUNKS; cy++)
    for (let cx = WORLD_MIN; cx < WORLD_MIN + WORLD_CHUNKS; cx++) {
      const cells = new Uint8Array(NATURE_CHUNK_CELLS);
      let any = false;
      for (let i = 0; i < NATURE_CHUNK_CELLS; i++) {
        const gx = (cx - WORLD_MIN) * NATURE_CELLS + (i % NATURE_CELLS);
        const gy = (cy - WORLD_MIN) * NATURE_CELLS + Math.floor(i / NATURE_CELLS);
        any = (cells[i] = grid[gy * NATURE_SIDE + gx]) > 0 || any;
      }
      if (any) out.push({ cx, cy, cells });
    }
  return out;
};

/** Degrades cell `cell` to at least `value`; whether it changed. Degradation never heals. */
export const degrade = (cells: Uint8Array, cell: number, value: number) => {
  if (cells[cell] >= value) return false;
  cells[cell] = value;
  return true;
};

/** `cells` run-length coded. */
export const encodeNature = (cells: Uint8Array) => {
  const out: number[] = [];
  for (let i = 0; i < cells.length; ) {
    const value = cells[i];
    let run = 1;
    while (i + run < cells.length && cells[i + run] === value) run++;
    for (let n = run; ; n = Math.floor(n / 128)) {
      if (n < 128) {
        out.push(n);
        break;
      }
      out.push((n % 128) | 128);
    }
    out.push(value);
    i += run;
  }
  return Uint8Array.from(out);
};

/** The cells `bytes` codes; throws unless they fill exactly `length` cells. */
export const decodeNature = (bytes: Uint8Array, length = NATURE_SIDE * NATURE_SIDE) => {
  const cells = new Uint8Array(length);
  let at = 0;
  for (let i = 0; i < bytes.length; ) {
    let run = 0;
    for (let scale = 1; ; scale *= 128) {
      if (i >= bytes.length) throw new Error("nature: truncated run");
      const b = bytes[i++];
      run += (b & 127) * scale;
      if (b < 128) break;
    }
    if (i >= bytes.length) throw new Error("nature: run without a value");
    if (at + run > length) throw new Error("nature: runs overflow the grid");
    cells.fill(bytes[i++], at, at + run);
    at += run;
  }
  if (at !== length) throw new Error(`nature: ${at} cells coded, ${length} expected`);
  return cells;
};

/** Bytes as base64 and back (the checkpoint's JSON carries the layer so). */
export const toBase64 = (bytes: Uint8Array) => {
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s);
};
export const fromBase64 = (text: string) => Uint8Array.from(atob(text), (c) => c.charCodeAt(0));
