/**
 * World clock shared by workers (schedules) and the page (lighting). Time is derived from the host
 * tick, so every chunk agrees on it and a chunk loaded after a gap knows how long it was away.
 */
import { TICK_RATE } from "./world";

/** Real seconds per in-game day. */
export const DAY_SECONDS = 720;
/** Game seconds per in-game hour. */
export const HOUR = DAY_SECONDS / 24;
/** The world starts at dawn so the first thing players see is people heading out. */
export const START_HOUR = 6.5;

/** Game seconds since midnight of day 0. Schedules run on this. */
export const clock = (tick: number) => tick / TICK_RATE + START_HOUR * HOUR;
export const worldSeconds = clock;
/** 0 at midnight, 0.5 at noon. */
export const timeOfDay = (tick: number) => (clock(tick) / DAY_SECONDS) % 1;
export const dayNumber = (tick: number) => Math.floor(clock(tick) / DAY_SECONDS);
/** 0 at night, 1 in full day, smooth through dawn (5–7h) and dusk (18.5–20.5h). */
export const daylight = (tick: number) => {
  const h = timeOfDay(tick) * 24;
  const ramp = (v: number) => Math.min(1, Math.max(0, v));
  return Math.min(ramp((h - 5) / 2), ramp((20.5 - h) / 2));
};
