import "../../components/siege/MutantSiege";
import { dataOf, definition } from "../../content/definitions";
import { mutantOf } from "../mutants";
import type { Structure } from "./types";
export type SiegeProfile = { name: string; damage: number; interval: number; reach: number; walls: boolean; splash: number };
export const siegeProfile = (gid: number, mutation: number): SiegeProfile =>
  dataOf<SiegeProfile>(definition(`mutant:${mutantOf(gid, mutation)?.id ?? "base"}`), "MutantSiege")!;
export const canBreach = (profile: SiegeProfile, structure: Structure) => structure.kind !== "wall" || profile.walls;
