/**
 * Drive-in commuters: people from outside the loaded regions who work in a loaded chunk. A city
 * centre's jobs are mostly held by people who live beyond what is loaded; without them a downtown
 * chunk with a thousand jobs and no homes stands empty all day. Each chunk with work places takes a
 * share of the jobs its own residents leave unfilled, worked by drive-ins: real people (a gid, a
 * name, a family, a job, traits) derived from the chunk's cell data alone, so every host and every
 * run gets the same ones whatever else is loaded.
 *
 * They are a source in the inbound path (jobs.ts farInbound): the world's sizing and the floor plans
 * count them with everyone else who works here. A drive-in comes in over one of the chunk's edges
 * as their shift starts (DriveInSystem), works and lunches here, and leaves by the nearest reachable edge
 * (routines.ts, walk.ts: their place out of hours is AWAY). A commute model that knows where they
 * live (flow fields) can replace this source; the people and the path stay.
 */
import { censusOf } from "../../worldgen/census/projection";
import type { PlanningContext } from "../../worldgen/commute/context";
import { chunkCached, chunkCurrent } from "../../worldgen/commute/chunk-cache";
import { planChunk, type ChunkPlan } from "../../worldgen/population/planner";
import { listsOf, pickWeighted } from "../../worldgen/population/workplaces";
import { isWork } from "../../worldgen/terrain/kinds";
import { chunkKey } from "../commute";
import { hash } from "../world";
import { HOME_CHUNK, isDriveIn, LifeRole, NO_SEAT, NONE } from "./identity";
import { unit } from "./traits";

/** The share of a chunk's unfilled jobs drive-ins work. */
export const DRIVE_SHARE = 0.2;
/** Most drive-ins one chunk takes (an identity's room is 1024: realworld/person-addresses.ts). */
export const DRIVE_CAP = 400;

/** A chunk's drive-ins: person `first + k` of the chunk is drive-in k. Every one is a Worker who works here. */
export type DrivePlan = {
  cx: number;
  cy: number;
  /** The chunk's residents: drive-in k has index first + k. */
  first: number;
  count: number;
  /** Per drive-in: their work place, a place of this chunk. Their home is out of the loaded world (NONE). */
  work: Uint16Array;
  age: Uint8Array;
  sex: Uint8Array;
};

const plans = new WeakMap<PlanningContext, Map<number, DrivePlan>>();
const none = (cx: number, cy: number, first: number): DrivePlan => ({ cx, cy, first, count: 0, work: new Uint16Array(0), age: new Uint8Array(0), sex: new Uint8Array(0) });

/** The staff a chunk's work places take (as the population plan weighs them: workplaces.ts) and the residents working there. */
export const staffing = (cx: number, cy: number, context: PlanningContext, plan: ChunkPlan = planChunk(cx, cy, context)) => {
  const census = censusOf(context, cx, cy);
  const lists = listsOf(census);
  const jobs = lists.workCum.length ? lists.workCum[lists.workCum.length - 1] : 0;
  let filled = 0;
  for (let i = 0; i < plan.count; i++) {
    const work = plan.work[i];
    if (plan.wdir[i] === HOME_CHUNK && work !== NONE && census.places[work] && isWork(census.places[work].kind)) filled++;
  }
  return { census, lists, jobs, filled };
};

/** Chunk (cx, cy)'s drive-ins: none without person addresses, without work places, or where the identities have no room. */
export const driveIns = (cx: number, cy: number, context: PlanningContext): DrivePlan => {
  let cache = plans.get(context);
  if (!cache) plans.set(context, (cache = new Map()));
  const key = chunkKey(cx, cy);
  const cached = cache.get(key);
  if (cached && chunkCurrent(context, cx, cy, cached)) return cached;
  const plan = planChunk(cx, cy, context);
  const addresses = context.source?.personAddresses;
  let out = none(cx, cy, plan.count);
  const room = addresses?.id({ cx, cy, index: plan.count });
  if (room != null && isDriveIn(room, context)) {
    const { census, lists, jobs, filled } = staffing(cx, cy, context, plan);
    const count = !lists.works.length ? 0 : Math.min(DRIVE_CAP, Math.round(Math.max(0, jobs - filled) * DRIVE_SHARE));
    if (count > 0) {
      out = { cx, cy, first: plan.count, count, work: new Uint16Array(count), age: new Uint8Array(count), sex: new Uint8Array(count) };
      for (let k = 0; k < count; k++) {
        out.work[k] = pickWeighted(lists.works, lists.workCum, unit(hash(cx, cy, k, 141)));
        out.age[k] = 20 + (hash(cx, cy, k, 142) % 45);
        out.sex[k] = hash(cx, cy, k, 143) & 1;
      }
    }
  }
  if (cache.size > 1024) cache.clear();
  cache.set(key, chunkCached(context, cx, cy, out));
  return out;
};

/** One person's plan row, a resident's or a drive-in's: what spawning and the floor plans read. */
export type PersonRow = { role: number; home: number; slot: number; wdir: number; work: number; seat: number };
/** Person `i` of chunk (cx, cy) into `out` (its plan's row, or past its residents its drive-ins'); false when there is none. */
export const personRow = (cx: number, cy: number, i: number, context: PlanningContext, out: PersonRow, plan: ChunkPlan = planChunk(cx, cy, context)): boolean => {
  if (i < plan.count) {
    out.role = plan.role[i];
    out.home = plan.home[i];
    out.slot = plan.slot[i];
    out.wdir = plan.wdir[i];
    out.work = plan.work[i];
    out.seat = plan.seat[i];
    return true;
  }
  const drive = driveIns(cx, cy, context);
  const k = i - drive.first;
  if (k < 0 || k >= drive.count) return false;
  out.role = LifeRole.Worker;
  out.home = NONE;
  out.slot = k % 200;
  out.wdir = HOME_CHUNK;
  out.work = drive.work[k];
  out.seat = NO_SEAT;
  return true;
};
export const blankRow = (): PersonRow => ({ role: 0, home: 0, slot: 0, wdir: HOME_CHUNK, work: NONE, seat: NO_SEAT });
