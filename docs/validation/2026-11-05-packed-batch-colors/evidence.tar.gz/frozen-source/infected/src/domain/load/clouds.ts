/** Cloud motion and exposure rules shared by the simulation and its renderer. */
import type { ViralCloud } from "../../components/sim/ViralCloud";
import type { Traits } from "../disease";
import { TILE } from "../world";
import { CLOUD_STEP, Emit, LOAD, SPORE } from "./constants";
export type Cloud = ViralCloud;

export const breathRadius = (traits: Traits) => TILE * (LOAD.breathRadius + LOAD.breathReach * traits.reach * traits.reachWeight);

/** Breath kernel: 1 face to face, falling to 0 at the breath radius. */
export const breathKernel = (distance: number, radius: number) => {
  if (distance >= radius) return 0;
  const k = 1 - distance / radius;
  return k * k;
};

/** A cloud born at `tick` from a host at (x, y) moving at (vx, vy), coughing towards `angle`. */
export const createCloud = (kind: Emit, slot: number, tick: number, x: number, y: number, angle: number, vx: number, vy: number, traits: Traits): Cloud => {
  const sneeze = kind === Emit.Sneeze;
  const spore = kind === Emit.Spore;
  const push = sneeze ? LOAD.sneezePush : spore ? LOAD.sporePush : LOAD.coughPush;
  const cvx = vx * LOAD.carry + Math.cos(angle) * push;
  const cvy = vy * LOAD.carry + Math.sin(angle) * push;
  return {
    kind,
    slot,
    born: tick,
    x0: x,
    y0: y,
    vx0: cvx,
    vy0: cvy,
    angle,
    hvx: vx,
    hvy: vy,
    load: traits.cloudLoad * (sneeze ? LOAD.sneezeLoad : spore ? SPORE.load : 1),
    size: TILE * traits.cloudSize * (sneeze ? LOAD.sneezeSize : spore ? SPORE.size : 1),
    life: traits.cloudLife * (spore ? SPORE.life : 1),
    steps: 0,
    x,
    y,
    vx: cvx,
    vy: cvy,
    px: x,
    py: y,
  };
};

/** Seconds since birth at a (possibly fractional) tick. */
export const cloudAge = (cloud: Cloud, tick: number) => Math.max(0, (tick - cloud.born) * CLOUD_STEP);
/** Load left in a cloud at `tick`, and its radius (units). */
export const cloudLoad = (cloud: Cloud, tick: number) => cloud.load * Math.exp(-cloudAge(cloud, tick) / cloud.life);
export const cloudRadius = (cloud: Cloud, tick: number) => {
  const start = TILE * LOAD.startSize;
  return start + (cloud.size - start) * (1 - Math.exp(-cloudAge(cloud, tick) / LOAD.grow));
};
/** Load per square tile at the cloud's centre (it thins towards the rim). */
export const cloudDensity = (cloud: Cloud, tick: number) => {
  const r = cloudRadius(cloud, tick) / TILE;
  return cloudLoad(cloud, tick) / (Math.PI * r * r * 0.5);
};
/** Concentration a person at distance `d` from the centre breathes. */
export const cloudAt = (cloud: Cloud, tick: number, d: number) => {
  const r = cloudRadius(cloud, tick);
  if (d >= r) return 0;
  return cloudDensity(cloud, tick) * (1 - (d * d) / (r * r));
};
/** Load a cloud hands out between two ticks, as a share of its load at birth. */
export const cloudShare = (cloud: Cloud, from: number, to: number) =>
  Math.exp(-cloudAge(cloud, from) / cloud.life) - Math.exp(-cloudAge(cloud, to) / cloud.life);
export const cloudGone = (cloud: Cloud, tick: number) => cloudLoad(cloud, tick) < LOAD.epsilon || cloudAge(cloud, tick) > cloud.life * 5;

/** One substep: drag, then slide along walls (each axis separately, so a cloud pushed at a wall
 * runs along it and out of the next opening, through doorways and round corners). */
const substep = (cloud: Cloud, open: (x: number, y: number) => boolean) => {
  const slow = Math.exp(-LOAD.drag * CLOUD_STEP);
  cloud.px = cloud.x;
  cloud.py = cloud.y;
  cloud.vx *= slow;
  cloud.vy *= slow;
  if (cloud.vx * cloud.vx + cloud.vy * cloud.vy < 0.01) {
    // Settled: it only spreads and thins from here.
    cloud.vx = 0;
    cloud.vy = 0;
  } else {
    const nx = cloud.x + cloud.vx * CLOUD_STEP;
    if (open(nx, cloud.y)) cloud.x = nx;
    else cloud.vx *= -0.25;
    const ny = cloud.y + cloud.vy * CLOUD_STEP;
    if (open(cloud.x, ny)) cloud.y = ny;
    else cloud.vy *= -0.25;
  }
  cloud.steps++;
};

/**
 * Puts the cloud where it is at `tick` (whole ticks; x/y then hold the position, px/py the one a
 * tick before). Pure in the tick: moving forward continues from the cache, going back replays
 * from birth.
 */
export const cloudTo = (cloud: Cloud, tick: number, open: (x: number, y: number) => boolean) => {
  const steps = Math.max(0, Math.floor(tick - cloud.born + 1e-6));
  if (steps < cloud.steps) {
    cloud.steps = 0;
    cloud.x = cloud.px = cloud.x0;
    cloud.y = cloud.py = cloud.y0;
    cloud.vx = cloud.vx0;
    cloud.vy = cloud.vy0;
  }
  while (cloud.steps < steps) substep(cloud, open);
  if (steps === 0) {
    cloud.px = cloud.x;
    cloud.py = cloud.y;
  }
  return cloud;
};

/** Where the cloud is at a fractional tick (for drawing), smoothed between substeps. */
export const cloudPosition = (cloud: Cloud, tick: number, open: (x: number, y: number) => boolean, out: { x: number; y: number }) => {
  const next = Math.max(0, Math.ceil(tick - cloud.born - 1e-6));
  cloudTo(cloud, cloud.born + next, open);
  const f = 1 - (cloud.born + next - tick);
  out.x = cloud.px + (cloud.x - cloud.px) * Math.min(1, Math.max(0, f));
  out.y = cloud.py + (cloud.y - cloud.py) * Math.min(1, Math.max(0, f));
  return out;
};

