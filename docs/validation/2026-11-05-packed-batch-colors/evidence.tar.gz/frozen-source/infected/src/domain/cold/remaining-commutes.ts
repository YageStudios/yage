import { chunkKey } from "yage/streaming";
import { gidChunkX, gidChunkY, gidIndex, HOME_CHUNK } from "../people/identity";
import { workChunkOf } from "../people/jobs";
import { coldCounts, type Cold } from "./step";
import type { PlanningContext } from "../../worldgen/commute/context";
import { planChunk } from "../../worldgen/population/planner";

/** Aggregate commuters exclude residents already materialized outside their home cell. */
export const remainingCommutes = (
  cell: Cold,
  away: number,
  context: PlanningContext
): number[] => {
  if (!Number.isFinite(away))
    throw new RangeError("Invalid aggregate commute share");
  const outside = new Map<number, number>();
  if (cell.out.length) {
    const plan = planChunk(cell.cx, cell.cy, context);
    for (const gid of new Set(cell.out)) {
      if (
        gidChunkX(gid, context) !== cell.cx ||
        gidChunkY(gid, context) !== cell.cy
      )
        continue;
      const index = gidIndex(gid, context);
      if (index < 0 || index >= plan.count || plan.wdir[index] === HOME_CHUNK)
        continue;
      const [cx, cy] = workChunkOf(
        cell.cx,
        cell.cy,
        plan.wdir[index],
        [0, 0],
        context
      );
      const key = chunkKey(cx, cy);
      outside.set(key, (outside.get(key) ?? 0) + 1);
    }
  }
  const share = Math.max(0, Math.min(1, away));
  const counts = cell.flowTo.map((key, flow) =>
    Math.max(0, share * cell.flowN[flow] - (outside.get(key) ?? 0))
  );
  const total = counts.reduce((sum, count) => sum + count, 0);
  const { people, dead } = coldCounts(cell);
  const living = Math.max(0, people - dead);
  // Known-away residents and mortality can leave fewer people than the original survey's flows.
  return total > living
    ? counts.map((count) => (count * living) / total)
    : counts;
};
