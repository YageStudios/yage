import { hasEntrance } from "../../worldgen/terrain/index";
/**
 * Building fronts under the response: where a place's door sits on its outer wall (rotated
 * buildings in objects mode, grid ones in the legacy world), the windows either side of it, and
 * which of them are lit at night or show a face by day. Pure in (place, time); the art draws it.
 */
import { inPoly } from "../../worldgen/geometry";
import { CONTENT } from "../../content/runtime";
import { toWorld } from "../../atlas/objects";
import { hashUnit } from "../load/streams";
import { isHome, PlaceKind, type Place } from "../../worldgen/terrain/index";

/** A door on its outer wall, chunk-local tiles: the face's midpoint, along the wall, and outward. */
export type Front = { x: number; y: number; ax: number; ay: number; ox: number; oy: number; left: number; right: number };

/** The numbers are data (content/response.json5). */
export const FRONTS = CONTENT.response.fronts;

/** Where a place's door meets the street, or null for open places. */
export const frontOf = (place: Place): Front | null => {
  if (!hasEntrance(place)) return null;
  if (place.frame && place.template) {
    const { angle } = place.frame;
    const [dx, dy] = place.template.door;
    const scale = place.frame.scale ?? 1;
    const footprint = place.template.footprint;
    if (footprint) {
      let nearest: { x: number; y: number; ax: number; ay: number; ox: number; oy: number; left: number; right: number } | null = null;
      let distance = Infinity;
      for (let i = 0; i < footprint.poly.length; i++) {
        const a = footprint.poly[i], b = footprint.poly[(i + 1) % footprint.poly.length];
        const vx = b.x - a.x, vy = b.y - a.y, length = Math.hypot(vx, vy);
        if (!length) continue;
        const along = Math.max(0, Math.min(length, ((dx + .5 - a.x) * vx + (dy + .5 - a.y) * vy) / length));
        const x = a.x + along * vx / length, y = a.y + along * vy / length;
        const d = (dx + .5 - x) ** 2 + (dy + .5 - y) ** 2;
        if (d >= distance) continue;
        const ax = vx / length, ay = vy / length;
        let ox = -ay, oy = ax;
        if (inPoly((a.x + b.x) / 2 + ox * .001, (a.y + b.y) / 2 + oy * .001, footprint.poly, footprint.holes)) { ox = -ox; oy = -oy; }
        nearest = { x, y, ax, ay, ox, oy, left: along, right: length - along }; distance = d;
      }
      if (!nearest) return null;
      const p = toWorld(place.frame, nearest.x, nearest.y), c = Math.cos(angle), s = Math.sin(angle);
      return { x: p.x, y: p.y, ax: (nearest.ax * c - nearest.ay * s) * scale, ay: (nearest.ax * s + nearest.ay * c) * scale,
        ox: (nearest.ox * c - nearest.oy * s) * scale, oy: (nearest.ox * s + nearest.oy * c) * scale, left: nearest.left, right: nearest.right };
    }
    const p = toWorld(place.frame, dx + 0.5, dy + 1);
    return { x: p.x, y: p.y, ax: Math.cos(angle) * scale, ay: Math.sin(angle) * scale, ox: -Math.sin(angle) * scale, oy: Math.cos(angle) * scale, left: dx + 0.5, right: place.template.w - dx - 0.5 };
  }
  const ox = -(place.inX ?? 0);
  const oy = -(place.inY ?? -1);
  const x = place.doorX + 0.5 + ox * 0.5;
  const y = place.doorY + 0.5 + oy * 0.5;
  // Along the wall: a quarter turn from outward (so +along is (−oy, ox)).
  const ax = -oy;
  const ay = ox;
  const lo = ax !== 0 ? (ax > 0 ? x - place.x0 : place.x1 + 1 - x) : ay > 0 ? y - place.y0 : place.y1 + 1 - y;
  const hi = ax !== 0 ? (ax > 0 ? place.x1 + 1 - x : x - place.x0) : ay > 0 ? place.y1 + 1 - y : y - place.y0;
  return { x, y, ax, ay, ox, oy, left: lo, right: hi };
};

/** Whether closures shutter this kind of place (schools, shops, taverns). */
export const shutterable = (kind: PlaceKind) => kind === PlaceKind.Shop || kind === PlaceKind.School || kind === PlaceKind.Tavern;

/** Offsets along the wall (tiles) of a home's front windows: either side of the door, where the wall reaches. */
export const windowsOf = (place: Place, f: Front): number[] => {
  if (!isHome(place.kind)) return [];
  const out: number[] = [];
  const w = FRONTS.window;
  if (f.left >= w + 0.6) out.push(-w);
  if (f.right >= w + 0.6) out.push(w);
  return out;
};

/** Whether window k of a home is lit tonight under curfew/lockdown strength `stay` (0…1), on day `day`. */
export const windowLit = (place: Place, k: number, day: number, stay: number) =>
  stay > 0 && hashUnit(place.h, k * 31 + day, 0x6c6974) < FRONTS.lit + (FRONTS.litMax - FRONTS.lit) * stay * stay;

/** Whether window k of a home shows a face at game second `seconds` under lockdown `lockdown` (0…1). */
export const faceAt = (place: Place, k: number, seconds: number, lockdown: number) => {
  if (lockdown <= 0) return false;
  const phase = hashUnit(place.h, k, 0x66616365);
  const slot = Math.floor(seconds / FRONTS.glance + phase * 7);
  return hashUnit(place.h, k * 977 + slot, 0x6c6f6f6b) < FRONTS.faces * lockdown;
};
