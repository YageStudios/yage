/** Snapshot sprite selection, independent of renderer resources. */
import { CONTENT } from "../../content/runtime";
import type { SpriteSet } from "../disease";
import { MUTANTS } from "../mutants";

export const enum Body {
  Tee = 0,
  Coat = 1,
  Dress = 2,
  Overalls = 3,
  Vest = 4,
}
export const enum Head {
  Crop = 0,
  Long = 1,
  Bun = 2,
  Bald = 3,
  Beard = 4,
  Afro = 5,
  FlatCap = 6,
  Bob = 7,
  StrawHat = 8,
  Beanie = 9,
}
export const BODIES = 5;
export const HEADS = 10;
export const LOOK_VARIANTS = BODIES * HEADS;
export const SPRITE_SETS = 5;

/**
 * How the sick are drawn for the player's pathogen type: pathogen-neutral by default, with a
 * small accent per type (PawnAtlasState.pathogen).
 */
export type PathogenLook = "neutral" | "virus" | "bacteria" | "fungus" | "parasite" | "prion";
export const PATHOGEN_LOOKS: PathogenLook[] = CONTENT.looks.pawn.pathogens;

export const spriteFor = (set: SpriteSet, variant: number) => (set as number) * LOOK_VARIANTS + variant;

/**
 * Super mutants (src/entities/mutants.json5) are drawn after the sprite sets: a row of the atlas
 * per kind (its index among domain/mutants.ts MUTANTS), MUTANT_VARIANTS looks each. They are
 * bloomed hosts, so `setOf` says Infected for them.
 */
export const MUTANT_SPRITES = SPRITE_SETS * LOOK_VARIANTS;
export const MUTANT_VARIANTS = HEADS;
/** A super mutant's sprite: kind `kind` (index into MUTANTS), look `variant` (any look variant; folded onto its row). */
export const mutantSprite = (kind: number, variant: number) => MUTANT_SPRITES + kind * MUTANT_VARIANTS + (variant % MUTANT_VARIANTS);
/**
 * The fallen who weren't plain people, after the super mutants' rows: a soldier dead in their kit (a
 * look per variant, as the Soldier set's), then a row per super-mutant kind, each lying as the Dead
 * set's civilians do. `setOf` says Dead for them.
 */
export const DEAD_SOLDIER_SPRITES = MUTANT_SPRITES + MUTANTS.length * MUTANT_VARIANTS;
export const DEAD_MUTANT_SPRITES = DEAD_SOLDIER_SPRITES + LOOK_VARIANTS;
/** Soldiers caught still in their kit, after the dead kinds' rows: incubating, then bloomed (a look per variant each). `setOf` says Incubating, Infected. */
export const KIT_INCUBATING_SPRITES = DEAD_MUTANT_SPRITES + MUTANTS.length * MUTANT_VARIANTS;
export const KIT_INFECTED_SPRITES = KIT_INCUBATING_SPRITES + LOOK_VARIANTS;
/**
 * What a corpse-eating host leaves of anyone (FeedSystem, services/death.ts bitesOf), after the kit rows: bones in
 * a stain, a row of REMAINS_VARIANTS strewings. `setOf` says Dead for them.
 */
export const REMAINS_SPRITES = KIT_INFECTED_SPRITES + LOOK_VARIANTS;
export const REMAINS_VARIANTS = HEADS;
/** The remains' sprite for look `variant` (folded onto their row). */
export const remainsSprite = (variant: number) => REMAINS_SPRITES + (variant % REMAINS_VARIANTS);
/** A soldier's sprite in the sprite set `set` stands for: in their kit whatever their state. */
export const kitSprite = (set: SpriteSet, variant: number) =>
  set === 3 /* Dead */ ? DEAD_SOLDIER_SPRITES + variant
  : set === 2 /* Infected */ ? KIT_INFECTED_SPRITES + variant
  : set === 1 /* Incubating */ ? KIT_INCUBATING_SPRITES + variant
  : spriteFor(4 /* SpriteSet.Soldier */ as SpriteSet, variant);
/** A dead super mutant's sprite: kind `kind` (index into MUTANTS), look `variant` (folded onto its row). */
export const deadMutantSprite = (kind: number, variant: number) => DEAD_MUTANT_SPRITES + kind * MUTANT_VARIANTS + (variant % MUTANT_VARIANTS);
/** The super-mutant kind (index into MUTANTS) a sprite draws, living or dead, or -1 for anyone else. */
export const mutantKindOf = (sprite: number) =>
  sprite >= KIT_INCUBATING_SPRITES ? -1
  : sprite >= DEAD_MUTANT_SPRITES ? Math.floor((sprite - DEAD_MUTANT_SPRITES) / MUTANT_VARIANTS)
  : sprite >= DEAD_SOLDIER_SPRITES ? -1
  : sprite >= MUTANT_SPRITES ? Math.floor((sprite - MUTANT_SPRITES) / MUTANT_VARIANTS)
  : -1;
/** Whether a sprite is a soldier in their kit, in any state. */
export const inKit = (sprite: number) =>
  (sprite >= KIT_INCUBATING_SPRITES && sprite < REMAINS_SPRITES) || (sprite >= DEAD_SOLDIER_SPRITES && sprite < DEAD_MUTANT_SPRITES) || (sprite >= 4 * LOOK_VARIANTS && sprite < MUTANT_SPRITES);
/** The sprite set an atlas sprite index belongs to (inverse of `spriteFor`): a super mutant's is Infected, a fallen soldier's or mutant's Dead, a soldier's in kit their state's. */
export const setOf = (sprite: number) =>
  (sprite >= REMAINS_SPRITES ? 3 /* Dead */
  : sprite >= KIT_INFECTED_SPRITES ? 2 /* Infected */
  : sprite >= KIT_INCUBATING_SPRITES ? 1 /* Incubating */
  : sprite >= DEAD_SOLDIER_SPRITES ? 3 /* Dead */
  : sprite >= MUTANT_SPRITES ? 2 /* Infected */
  : Math.floor(sprite / LOOK_VARIANTS)) as SpriteSet;
/** The look variant (body × head) of an atlas sprite index. */
export const variantOf = (sprite: number) =>
  (sprite - (sprite >= REMAINS_SPRITES ? REMAINS_SPRITES
    : sprite >= KIT_INFECTED_SPRITES ? KIT_INFECTED_SPRITES
    : sprite >= KIT_INCUBATING_SPRITES ? KIT_INCUBATING_SPRITES
    : sprite >= DEAD_MUTANT_SPRITES ? DEAD_MUTANT_SPRITES
    : sprite >= DEAD_SOLDIER_SPRITES ? DEAD_SOLDIER_SPRITES
    : 0)) % LOOK_VARIANTS;
export const bodyOf = (variant: number) => Math.floor(variant / HEADS) as Body;
export const headOf = (variant: number) => (variant % HEADS) as Head;

