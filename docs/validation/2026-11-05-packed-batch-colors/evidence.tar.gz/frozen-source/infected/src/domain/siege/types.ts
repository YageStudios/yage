import type { Point } from "../rts/orders";

/** One ground-floor tile or one physical field defense. Coordinates are global world pixels. */
export type Structure = Point & {
  id: string; kind: "door" | "wall" | "barricade" | "furniture"; angle: number; hw: number; hh: number;
  hp: number; maxHp: number; town: number; created: number; destroyed: number;
  /** Exact plan cell, when this is part of a freely rotated building. */
  building?: string; cellX?: number; cellY?: number;
  /** On the edge of that cell, not the cell: an inside wall or doorway on its west (1) or north (2) side. */
  edge?: number;
  /** The plan tile it stands on (furniture: which piece). */
  tile?: number;
};
export type SiegeEvent = Point & { tick: number; structure: string; gid: number; kind: "built" | "hit" | "breached"; text: string; /** Struck by a shot, not a blow: nobody swings at it. */ shot?: boolean };
export type SiegeAction = { kind: "siegeStrike"; at: Point };
export type SiegeRequest =
  | { kind: "register"; target: Structure }
  | { kind: "strike"; at: Point; command?: string }
  // The lab's hand (src/systems/scene/SimLabDriver.ts): a defense put as given, or taken back to how the world made it.
  | { kind: "set"; target: Structure }
  | { kind: "unset"; id: string }
  // A shot the page resolved into a dressing item (SimLabView): it takes `damage`, registered first if the record lacks it.
  | { kind: "shoot"; target: Structure; damage: number; gid: number };
export type SiegeSnapshot = { revision: number; structures: Structure[] };
export const SIEGE_LIMITS = { structures: 8192, events: 256, freshTicks: 120, fortifySeconds: 5 } as const;
export const structureContains = (s: Structure, x: number, y: number, pad = 0) => {
  const dx = x - s.x, dy = y - s.y, c = Math.cos(s.angle), n = Math.sin(s.angle);
  return Math.abs(dx * c + dy * n) < s.hw + pad && Math.abs(-dx * n + dy * c) < s.hh + pad;
};
export const structureDistance = (s: Structure, p: Point) => {
  const dx = p.x - s.x, dy = p.y - s.y, c = Math.cos(s.angle), n = Math.sin(s.angle);
  return Math.hypot(Math.max(0, Math.abs(dx * c + dy * n) - s.hw), Math.max(0, Math.abs(-dx * n + dy * c) - s.hh));
};
export const validSiegeAction = (a: SiegeAction) => !!a.at && Number.isFinite(a.at.x) && Number.isFinite(a.at.y) && Math.abs(a.at.x) < 67_000_000 && Math.abs(a.at.y) < 67_000_000;
