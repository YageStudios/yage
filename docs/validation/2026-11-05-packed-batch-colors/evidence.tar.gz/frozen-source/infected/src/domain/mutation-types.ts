import type { Stat } from "./disease";

export type Effects = {
  add?: Partial<Record<Stat, number>>;
  mul?: Partial<Record<Stat, number>>;
  max?: Partial<Record<Stat, number>>;
};

/** Plague Inc.'s three columns. */
export type CardKind = "transmission" | "symptom" | "ability";

export type Card = {
  id: string;
  name: string;
  kind: CardKind;
  /** Icon name (see ui/icons.ts). */
  icon: string;
  /** One line of flavour under the effects. */
  text: string;
  fx: Effects;
  /** A follow-up: enters the pool once any one group is fully picked. Absent = from the start. */
  after?: string[][];
  /** Exclusive to one pathogen. */
  pathogen?: string;
  /** Enters the pool only once this passive-tree node is allocated. */
  node?: string;
  /** Relative chance of being offered (default 1). */
  weight?: number;
};

export type Pathogen = {
  id: string;
  name: string;
  /** One line under the name. */
  tagline: string;
  /** Two sentences on how it plays. */
  text: string;
  icon: string;
  colour: string;
  /** Applied over BASE_TRAITS before any card or node. */
  fx: Effects;
};

export type NodeKind = "start" | "small" | "notable" | "keystone";
export type PassiveNode = { id: string; kind: NodeKind; name: string; x: number; y: number; fx: Effects };

// ---------------------------------------------------------------------------------------------
// The tables, from content/{progression,pathogens,cards,passive-tree}.json5.

export type Progression = {
  /** Evolution points (8·log2(1 + absorbed)) at which each card offer arrives, × pathogen pickRate. */
  pickAt: number[];
  /** After the list runs out, another offer every this many points. */
  pickStep: number;
  /** People absorbed at which each advanced unlock point arrives (the tree's currency). */
  apAt: number[];
  /** Unlock points to begin with. */
  startAp: number;
  /** Cards per offer. */
  offerSize: number;
  /** Unlock points per node. */
  nodeCost: Record<NodeKind, number>;
  /** Follow-ups (cards with `after`) are this much likelier to be offered: digging in pays. */
  followUpWeight: number;
};

