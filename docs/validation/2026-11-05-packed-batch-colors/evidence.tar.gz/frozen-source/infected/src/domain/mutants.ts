/**
 * Super mutants (the mutation trait): which bloomed hosts grow into one, and of what kind. Kinds
 * are entity objects (src/entities/mutants.json5, MutantDef), so a new one is data. Who mutates is
 * drawn by gid alone, a share RULES.mutantShare × mutation of everyone (more as the trait rises,
 * never fewer), and their kind by gid among the kinds' weights: the same in the full sim, the cold
 * tiers and the solver, and nothing to save.
 *
 * Besides, someone can be made one (a story's `mutate`, the lab's mutant cards): a made kind is a
 * record by gid (setMade; the authority keeps it in MadeMutants and the hosts get it with the
 * config), and it wins over the draw whatever the strain's mutation. It is one map lookup, skipped
 * outright while nobody is made.
 */
import "../components/strain/MutantDef";
import { dataOf, definitionsOf } from "../content/definitions";
import { RULES } from "./disease";
import { hash } from "./world";

export type MutantKind = { id: string; name: string; weight: number; speed: number; armor: number; strength: number };

/** Every kind (src/entities/mutants.json5), in file order; the base (no id) left out. */
export const MUTANTS: readonly MutantKind[] = definitionsOf("mutant:")
  .map((def) => dataOf<MutantKind>(def, "MutantDef"))
  .filter((d): d is MutantKind => !!d?.id)
  .map((d) => ({ id: d.id, name: d.name, weight: d.weight ?? 1, speed: d.speed ?? 1, armor: d.armor ?? 0, strength: d.strength ?? 1 }));

const TOTAL = MUTANTS.reduce((a, m) => a + m.weight, 0);
const unit = (h: number) => h / 4294967296;

/** The share of a strain's bloomed that are super mutants. */
export const mutantShare = (mutation: number) => Math.min(1, Math.max(0, mutation) * RULES.mutantShare);

/** The mutation a strain needs for `gid` to be a super mutant (above 1: none it can have). */
export const mutationFor = (gid: number) => unit(hash(gid >>> 0, 0x307a)) / RULES.mutantShare;

/** The kind `gid` grows into, should it mutate (by the kinds' weights). */
export const latentMutant = (gid: number): MutantKind | null => {
  if (!MUTANTS.length) return null;
  let at = unit(hash(gid >>> 0, 0x307b)) * TOTAL;
  for (const m of MUTANTS) if ((at -= m.weight) < 0) return m;
  return MUTANTS[MUTANTS.length - 1];
};

/** Who has been made into what (index into MUTANTS), by gid; empty for nearly every run. */
const MADE = new Map<number, number>();

/** Replaces the made record: [gid, kind id] each (unknown kinds passed over). */
export const setMade = (made: readonly (readonly [number, string])[]) => {
  MADE.clear();
  for (const [gid, id] of made) {
    const k = MUTANTS.findIndex((m) => m.id === id);
    if (k >= 0) MADE.set(gid >>> 0, k);
  }
};

/** Whether anyone is made (the strain's mutation gates nothing for them). */
export const anyMade = () => MADE.size > 0;

/** The kind `gid` was made into, or null. */
export const madeOf = (gid: number): MutantKind | null => {
  if (!MADE.size) return null;
  const k = MADE.get(gid >>> 0);
  return k === undefined ? null : MUTANTS[k];
};

/** The super mutant `gid` is once bloomed, at the strain's `mutation` (or as made); null for an ordinary host. */
export const mutantOf = (gid: number, mutation: number): MutantKind | null =>
  madeOf(gid) ?? (mutation > 0 && mutationFor(gid) < Math.max(0, mutation) ? latentMutant(gid) : null);

/** The kinds on average, by weight (what the coarse tiers fold in). */
export const MEAN_MUTANT = {
  speed: MUTANTS.reduce((a, m) => a + m.weight * m.speed, 0) / Math.max(1, TOTAL),
  armor: MUTANTS.reduce((a, m) => a + m.weight * m.armor, 0) / Math.max(1, TOTAL),
  strength: MUTANTS.reduce((a, m) => a + m.weight * m.strength, 0) / Math.max(1, TOTAL),
};

/** The share of shots a host shrugs off: the strain's armor and, a super mutant, its own besides. */
export const armorOf = (strain: number, gid: number, mutation: number) => {
  const m = mutantOf(gid, mutation);
  return m ? 1 - (1 - strain) * (1 - m.armor) : strain;
};
