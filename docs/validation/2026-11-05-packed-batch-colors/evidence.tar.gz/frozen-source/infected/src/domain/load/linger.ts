/**
 * Enclosure classes and how long effects last in each (game data). An effect's lifetime is a
 * multiple of the strain's own, so mutations still move it. Pure: page and workers alike.
 */
import { CONTENT } from "../../content/runtime";
import type { Weather } from "../weather";

export const enum Enclosure {
  Outdoors = 0,
  Room = 1,
  Cabin = 2,
  Subway = 3,
}

export const ENCLOSURE_NAMES = ["outdoors", "room", "cabin", "subway"] as const;

/**
 * Lifetime multipliers per class: air (clouds) and surfaces (decals), ordered by enclosure.
 * A room is the reference (1), so indoor life is as it has always been; the open air clears
 * sooner, and vehicles and the underground hold it for longer (content/linger.json5).
 */
export const LINGER: { air: readonly number[]; surface: readonly number[]; wind: number; wash: number } = CONTENT.linger;

/** Air lifetime multiplier for a class; outdoors it also takes the weather. */
export const airLinger = (where: Enclosure, w?: Weather) => {
  const base = LINGER.air[where];
  if (where !== Enclosure.Outdoors || !w) return base;
  return base * (1 - LINGER.wind * w.wind) * (1 - LINGER.wash * Math.max(w.rain, w.snow * 0.7));
};

/** Surface lifetime multiplier for a class; outdoors, rain washes decals away sooner. */
export const surfaceLinger = (where: Enclosure, w?: Weather) => {
  const base = LINGER.surface[where];
  if (where !== Enclosure.Outdoors || !w) return base;
  return base * (1 - LINGER.wash * Math.max(w.rain, w.snow * 0.7));
};

/** The class a transit cabin belongs to. */
export const cabinEnclosure = (kind?: string) => (kind === "subway" ? Enclosure.Subway : Enclosure.Cabin);
