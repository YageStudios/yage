import { Component, defaultValue, Schema, type } from "minecs";

/**
 * A super mutant's kind as an entity object (src/entities/mutants.json5): what a bloomed host grows
 * into under the mutation trait (domain/mutants.ts), drawn by its weight. speed: × the host's pace
 * hunting; armor: the share of shots it shrugs off on top of the strain's; strength: × its bite's
 * kill odds and its weight in a fight.
 */
@Component()
export class MutantDef extends Schema {
  @type("string") id: string;
  @type("string") name: string;
  @type("number") @defaultValue(1) weight: number;
  @type("number") @defaultValue(1) speed: number;
  @type("number") @defaultValue(0) armor: number;
  @type("number") @defaultValue(1) strength: number;
}
