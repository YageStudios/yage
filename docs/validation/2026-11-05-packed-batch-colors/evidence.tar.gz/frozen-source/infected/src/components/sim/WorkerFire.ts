import type { World } from "minecs";
import { Component, Schema, type } from "minecs";
import { OutingOdds } from "./OutingOdds";
@Component()
export class WorkerFire extends Schema {
  @type("object")
  fireLists: Map<number, {
    unrest: number;
    cordon: number;
    list: [
      number,
      number
    ][];
  }>;
  @type("object")
  clears: Map<number, Int32Array>;
  @type("object")
  hostLists: Map<number, number[]>;
  @type("object")
  camps: Map<number, {
    tick: number;
    camp: {
      place: number;
      households: number;
    } | null;
  }>;
  @type(OutingOdds)
  outingOdds: OutingOdds;
  @type("object")
  roads: Map<number, boolean>;
}
export const initializeWorkerFire = (world: World, entity: number) => {
  const fields = world(WorkerFire).store as unknown as Record<string, unknown[]>;
  fields.fireLists[entity] = new Map();
  fields.clears[entity] = new Map();
  fields.hostLists[entity] = new Map();
  fields.camps[entity] = new Map();
  world(WorkerFire, entity).outingOdds = { go: 1, indoor: 0, shut: 0 };
  fields.roads[entity] = new Map();
};
