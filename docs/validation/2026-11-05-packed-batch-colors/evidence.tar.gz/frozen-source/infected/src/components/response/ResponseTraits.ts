import { Schema, type } from "minecs";

export class ResponseTraits extends Schema {
  @type("number") visibility: number;
  @type("number") cureResist: number;
  @type("number") reshuffle: number;
  @type("number") evasion: number;
  @type("number") rodent: number;
  @type("number") bird: number;
  @type("number") livestock: number;
  @type("number") dog: number;
  @type("number") mosquito: number;
  @type("number") beasts: number;
  @type("number") water: number;
}
