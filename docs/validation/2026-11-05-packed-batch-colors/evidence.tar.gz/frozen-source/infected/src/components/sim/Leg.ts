import { Component, defaultValue, Schema, type } from "minecs";

/** The straight leg someone is on: from (ax, ay) at t0 to (bx, by) at t1, in game seconds. */
@Component()
export class Leg extends Schema {
  @type("float32") @defaultValue(0) ax: number;
  @type("float32") @defaultValue(0) ay: number;
  @type("float32") @defaultValue(0) bx: number;
  @type("float32") @defaultValue(0) by: number;
  @type("float32") @defaultValue(0) t0: number;
  @type("float32") @defaultValue(0) t1: number;
  /** Walking pace, units per second. */
  @type("uint8") @defaultValue(32) pace: number;
}
