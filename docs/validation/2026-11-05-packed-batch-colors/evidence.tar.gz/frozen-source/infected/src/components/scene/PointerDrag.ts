import { Schema, type } from "minecs";

export class PointerDrag extends Schema {
  @type("number")
  x: number;
  @type("number")
  y: number;
  @type("number")
  startX: number;
  @type("number")
  startY: number;
  @type("boolean")
  moved: boolean;
}
