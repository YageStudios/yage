import { Component, Schema, type } from "minecs";
import { ExtremesCar } from "./ExtremesCar";

/** The cars found in a chunk's streets, for the tiles they were found in: a view record (services/view/records) of the extremes. */
@Component()
export class ExtremesChunkCars extends Schema {
  @type("object") tiles: Uint8Array;
  @type([ExtremesCar]) cars: ExtremesCar[];
}
