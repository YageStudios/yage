import { Component, defaultValue, Schema, type } from "minecs";

/**
 * The infection going round (world:strain): an `infection:*` entity's id and slot, whose traits
 * TraitConfig lays over the evolution's and whose slot the newly caught carry ("" and 0: the run's
 * own strain, as in play).
 */
@Component()
export class InfectionRef extends Schema {
  @type("string") @defaultValue("") infection: string;
  @type("number") @defaultValue(0) slot: number;
}
