import { Schema, type } from "minecs";
export class LeaderState extends Schema {
  @type("number")
  eid: number;
  @type("number")
  x: number;
  @type("number")
  y: number;
  @type("number")
  tick: number;
  @type("number")
  cx: number;
  @type("number")
  cy: number;
}
