import { Component, defaultValue, Schema, type } from "minecs";

@Component()
export class Look extends Schema {
  @type("uint8")
  @defaultValue(0)
  sprite: number;

  @type("uint8")
  @defaultValue(0)
  tint: number;
}
