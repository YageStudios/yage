import { Schema, type } from "minecs";

export class ResponseCount extends Schema {
  @type("number") key: number;
  @type("number") people: number;
  @type("number") infected: number;
  @type("number") incubating: number;
  @type("number") dead: number;
  @type("number") soldiers: number;
}
