/** What the page asked one art-preview scene to show: fixture, place lookup, camera and display options. */
import { Component, Schema, defaultValue, type } from "minecs";

@Component()
export class ArtPreviewRequest extends Schema {
  /** "station" or "roads" draws that fixture chunk instead of the atlas; anything else is ignored. */
  @type("string") @defaultValue("") fixture: string;
  @type("string") @defaultValue("valesfolk") culture: string;
  @type("number") @defaultValue(0) x: number;
  @type("number") @defaultValue(0) y: number;
  @type("number") @defaultValue(0) dx: number;
  @type("number") @defaultValue(0) dy: number;
  /** An art feature kind to centre on (art-preview-features), its index, and the building use for "use". */
  @type("string") @defaultValue("") find: string;
  @type("number") @defaultValue(0) n: number;
  @type("string") @defaultValue("") use: string;
  @type("number") @defaultValue(2) zoom: number;
  @type("number") @defaultValue(12) hour: number;
  @type("number") @defaultValue(0) snow: number;
  @type("boolean") @defaultValue(false) people: boolean;
}
