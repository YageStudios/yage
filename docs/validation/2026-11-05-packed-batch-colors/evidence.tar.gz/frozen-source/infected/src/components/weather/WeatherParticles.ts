import { Component, Schema, type } from "minecs";
import { WeatherDrop } from "./WeatherDrop";
import { WeatherSplash } from "./WeatherSplash";
import { WeatherBank } from "./WeatherBank";
@Component()
export class WeatherParticles extends Schema {
  @type([WeatherDrop]) drops: WeatherDrop[];
  @type([WeatherSplash]) splashes: WeatherSplash[];
  @type([WeatherBank]) banks: WeatherBank[];
  /** How far each zoomed-out sheet has fallen, in tiles (wrapped to one; WeatherSheet). */
  @type(["number"]) sheetFall: number[];
  @type("object") openCache: Map<number, boolean>;
}
