import { Schema, type } from "minecs";

/** A building event's (domain/building-events.ts): a shriek inside, a fight, a door flung open. */
export type Moment = "cough" | "sneeze" | "retch" | "fall" | "spores" | "shot" | "bite" | "shriek" | "brawl" | "door";

export class SoundMoment extends Schema {
  @type("string") kind: Moment;
  @type("number") x: number;
  @type("number") y: number;
}
