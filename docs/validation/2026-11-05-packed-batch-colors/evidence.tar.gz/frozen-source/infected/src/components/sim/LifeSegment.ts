import { Schema, type } from "minecs";
export class LifeSegment extends Schema {
  @type("number")
  day: number;
  @type("number")
  index: number;
  @type("number")
  start: number;
  @type("number")
  end: number;
  @type("number")
  act: number;
}
