import type { World } from "minecs";
import { Component, Schema, defaultValue, type } from "minecs";
import type { Traits } from "../../domain/disease";
import type { LineKind } from "../../worldgen/transit";
export type CabinPool = {
  value: number;
  at: number;
};
export type RiderTally = {
  tick: number;
  running: number;
  prev: number;
};
export type CabinSources = {
  seats: number;
  riders: number[];
  air: number;
  deposit: number;
  kind?: LineKind;
};
/** Shared analytic pools and the event journal sent to other workers at stats time. */
@Component()
export class WorkerCabins extends Schema {
  @type("object")
  airs: Map<number, CabinPool>;
  @type("object")
  rails: Map<number, CabinPool>;
  @type("object")
  platformAirs: Map<number, CabinPool>;
  @type("object")
  platformRails: Map<number, CabinPool>;
  @type("object")
  tallies: Map<number, RiderTally>;
  @type("object")
  platformTallies: Map<number, RiderTally>;
  @type("object")
  cabins: Map<number, CabinSources>;
  @type("object")
  sheltered: Traits | null;
  @type("boolean")
  @defaultValue(false)
  sharing: boolean;
  @type(["number"])
  outbox: number[];
  /** Lockstep: this pass's riders and waiters, (platform, key, tick, count) each, for the post (RiderTallySystem). */
  @type(["number"])
  tallyOut: number[];
}
/** Empty pools, sharing on: every append is also queued for the other workers (cabin.ts). */
export const initializeWorkerCabins = (world: World, entity: number) => {
  Object.assign(world(WorkerCabins, entity), {
    airs: new Map(), rails: new Map(), platformAirs: new Map(), platformRails: new Map(),
    tallies: new Map(), platformTallies: new Map(), cabins: new Map(), sheltered: null, sharing: true, outbox: [], tallyOut: [],
  });
};
