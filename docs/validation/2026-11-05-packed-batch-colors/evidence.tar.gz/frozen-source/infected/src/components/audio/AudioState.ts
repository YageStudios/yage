import { Component, Schema, defaultValue, type } from "minecs";

/** The scene audio's lifecycle: the engine pause it follows, and whether the engine has loaded. */
@Component()
export class AudioState extends Schema {
  @type("boolean") @defaultValue(false) paused: boolean;
  @type("boolean") @defaultValue(false) loaded: boolean;
  @type("boolean") @defaultValue(false) disposed: boolean;
}
