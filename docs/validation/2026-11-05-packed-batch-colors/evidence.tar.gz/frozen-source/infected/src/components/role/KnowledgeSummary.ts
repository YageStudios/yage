import { Component, Schema, type } from "minecs";

/**
 * What a virus role knows now (role:knowledge), derived by RolePerceptionSystem: what the player
 * sees on the HUD, and all the AI may decide from. `at` is play seconds.
 */
@Component()
export class KnowledgeSummary extends Schema {
  @type("number") at: number;
  @type("boolean") started: boolean;
  @type("boolean") hostAlive: boolean;
  @type(["string"]) offer: string[];
  @type(["string"]) allocatable: string[];
}
