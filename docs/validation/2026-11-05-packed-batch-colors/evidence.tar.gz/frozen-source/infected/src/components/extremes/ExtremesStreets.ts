import { Component, Schema, type } from "minecs";

/** Street geometry the extremes read again and again, as view record entities: cars (ExtremesChunkCars) per "cx,cy" (oldest first, CAR_CHUNKS) and barrier crossings (ExtremesCrossing) per spot. */
@Component()
export class ExtremesStreets extends Schema {
  @type("object") cars: Map<string, number>;
  @type("object") crossings: Map<string, number>;
}
