import { Schema, type } from "minecs";
import { type Board, type StopNode, type Trip } from "../../services/travel/types";
import type { TransitIndex, TransitLine } from "../../worldgen/transit";
export class TravelNetwork extends Schema {
  @type("object")
  index: TransitIndex | null;
  @type("object")
  trips: Map<number, Trip | null>;
  @type("object")
  riders: Map<TransitLine, Int32Array>;
  @type("object")
  scans: Map<string, Map<number, Board>>;
  @type("object")
  stops: Map<TransitLine, StopNode[]>;
  @type("object")
  ents: Map<TransitLine, StopNode[][]>;
  @type("object")
  queues: Map<string, Float32Array>;
  @type("object")
  current: Map<number, {
    day: number;
    index: number;
    board: Board | null;
  }>;
}
