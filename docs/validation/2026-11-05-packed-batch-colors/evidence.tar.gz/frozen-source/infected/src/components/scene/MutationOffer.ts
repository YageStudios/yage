import { Schema, type } from "minecs";

export class MutationOffer extends Schema {
  @type(["string"])
  cards: string[];
  @type("number")
  opened: number;
  @type("number")
  deadline: number;
  @type("number")
  revealAt: number;
  @type("number")
  auto: number;
}
