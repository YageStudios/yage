import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
export class WeatherBank extends Schema {
  @type("object") sprite: PIXI.Sprite;
  @type("number") seed: number;
}
