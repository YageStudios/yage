import { Component, defaultValue, Schema, type } from "minecs";

/**
 * The simulation lab's people only: the infection they carry or last caught, its slot (an
 * `infection:*` entity's, InfectionDef.slot; 0: the run's own strain). Set while well to the one
 * going round, so it is the one they catch. Its own component, so a run's people (and its saves)
 * are as they were.
 */
@Component()
export class LabStrain extends Schema {
  @type("uint8") @defaultValue(0) strain: number;
}

/** Whether serialized world bytes register LabStrain: a world's bytes name its components near their start. */
export const namesLabStrain = (bytes: Uint8Array) => {
  const name = Array.from(LabStrain.type, (c) => c.charCodeAt(0)), end = Math.min(bytes.length, 4096) - name.length;
  outer: for (let i = 0; i <= end; i++) {
    for (let j = 0; j < name.length; j++) if (bytes[i + j] !== name[j]) continue outer;
    return true;
  }
  return false;
};
