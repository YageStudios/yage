import { Schema, type } from "minecs";
export class ViewBounds extends Schema {
  @type("number") minX: number;
  @type("number") minY: number;
  @type("number") maxX: number;
  @type("number") maxY: number;
}
