import { Schema, type } from "minecs";
import { TownCare } from "./TownCare";
export class TownResponseState extends Schema {
  @type("number") awareness: number;
  @type("number") heard: number;
  @type("number") level: number;
  @type("number") changed: number;
  @type("number") research: number;
  @type("number") people: number;
  @type("number") visible: number;
  @type("number") incubating: number;
  @type("number") dead: number;
  @type("number") hospital: number;
  @type("number") demand?: number;
  @type(TownCare) care?: TownCare;
  @type("number") pinned?: number;
  @type("number") pinnedLoad?: number;
}
