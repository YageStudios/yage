import { Schema, type } from "minecs";
import { nullable } from "minecs";
import { BorderGate } from "./BorderGate";
import { OutsideRegion } from "./OutsideRegion";
import { BorderGateState } from "./BorderGateState";
import { OutsideState } from "./OutsideState";
import { numberLists } from "./series";
import type { GateStatus } from "../../domain/response/borders";
export class BordersState extends Schema {
  @type([BorderGate]) gates: BorderGate[];
  @type([OutsideRegion]) outside: OutsideRegion[];
  @type([BorderGateState]) gate: BorderGateState[];
  @type([OutsideState]) world: OutsideState[];
  @numberLists(true, 3) infectedSeries: [number, number][][];
  @nullable() @type("number") pinned: GateStatus | null;
  @type("number") tick: number;
  @type(["boolean"]) million: boolean[];
  @type(["boolean"]) smuggled: boolean[];
}
