import { Component, defaultValue, nullable, Schema, type } from "minecs";
import { PointerDrag } from "./PointerDrag";
import { ScenePointerEvent } from "./ScenePointerEvent";

/** Platform events are data until the next scene input phase consumes them. */
@Component()
export class SceneInput extends Schema {
  @type([ScenePointerEvent]) pending: ScenePointerEvent[];
  @nullable() @type(PointerDrag) drag: PointerDrag | null;
  /** Where the pointer last rested over the canvas (client px), or -1 once it left (MapHoverWarm). */
  @type("number") @defaultValue(-1) hoverX: number;
  @type("number") @defaultValue(-1) hoverY: number;
  /** Browser subscriptions attached by SceneInputSystem and released with this entity. */
  @nullable() @type("object") release: (() => void) | null;
}
