import type * as PIXI from "pixi.js";
import type { BuildingPlan } from "../../atlas/objects";
import type { ArtPrefab } from "../../domain/art";

/** A static holder created during listing or culling, filled before this frame renders. */
export type PrefabRequest = {
  holder: PIXI.Container;
  plan: BuildingPlan;
  prefab: ArtPrefab;
  biome: string;
  /** The plan's origin in world tiles (its local (0, 0) before turning by the prefab's angle): where its broken walls fall (PrefabFloors). */
  origin?: [number, number];
  /** The building's heights for the sun's shadows (yage StaticParts.heights): what stands on its roof joins them once its top is placed. */
  heights?: PIXI.Container;
  /** Native polygon wall/roof depth pass, filled by the same queued roof owner. */
  tops?: PIXI.Container;
  /** Plain walls and roof shown while the building's top waits to be drawn (PrefabRoofs). */
  standIn?: PIXI.Container;
  /** The stand-in is the building's far look (drawFarFront), not plain walls and roof. */
  far?: boolean;
};
