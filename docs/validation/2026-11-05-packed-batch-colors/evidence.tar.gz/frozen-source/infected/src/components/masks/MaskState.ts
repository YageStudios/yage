import { Component, Schema, type } from "minecs";
import { MaskWearer } from "./MaskWearer";
@Component()
export class MaskState extends Schema {
  @type([MaskWearer])
  wearers: MaskWearer[] = [];
}
