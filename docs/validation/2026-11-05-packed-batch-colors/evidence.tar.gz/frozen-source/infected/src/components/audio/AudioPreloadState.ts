import { Component, defaultValue, Schema, type } from "minecs";

/** Whether this audio has asked for its sound to be brought in (AudioPreload, once, after the first paint). */
@Component()
export class AudioPreloadState extends Schema {
  @type("boolean") @defaultValue(false) requested: boolean;
}
