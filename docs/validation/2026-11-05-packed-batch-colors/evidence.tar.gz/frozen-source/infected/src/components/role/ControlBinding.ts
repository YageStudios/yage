import { Component, Schema, type } from "minecs";

/**
 * Which controller drives the role (ControllerIdentity.id): the sole source of truth, written only
 * by PossessionSystem. `epoch` goes up on every change, so intents stamped under an older binding
 * are rejected; `fallback` takes over on release or disconnect. `seen` is each controller's last
 * accepted source sequence (RoleIntentRouterSystem), so a replayed intent is a duplicate.
 */
@Component()
export class ControlBinding extends Schema {
  @type("string") controller: string;
  @type("number") epoch: number;
  @type("string") fallback: string;
  @type("object") seen: Record<string, number>;
}
