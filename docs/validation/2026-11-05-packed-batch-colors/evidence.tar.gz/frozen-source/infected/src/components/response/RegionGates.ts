import { Component, Schema, type } from "minecs";
import { BorderGeometry } from "./BorderGeometry";

/** The region's cache of its border gates (region:response), found from the plan and the map; never saved, found again after a load. */
@Component()
export class RegionGates extends Schema {
  @type(BorderGeometry) geometry: BorderGeometry;
}
