import { Schema, type } from "minecs";
export class PrefabChunk extends Schema {
  @type("number") cx: number;
  @type("number") cy: number;
}
