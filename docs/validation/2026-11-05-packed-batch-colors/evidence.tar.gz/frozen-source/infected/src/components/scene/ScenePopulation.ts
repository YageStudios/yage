import { Component, defaultValue, Schema, type } from "minecs";
import { ChunkPopulation } from "./ChunkPopulation";
import { InfectionJump } from "./InfectionJump";
import { PlaceTally } from "./PlaceTally";

@Component()
export class ScenePopulation extends Schema {
  @type(["number"]) spread: number[];
  @type([ChunkPopulation]) chunks: ChunkPopulation[];
  @type(["number"]) announced: number[];
  /** The people the announced in-map chunks were generated with, counted with `announced`. */
  @type("number") @defaultValue(0) generated: number;
  @type([PlaceTally]) places: PlaceTally[];
  @type([InfectionJump]) jumps: InfectionJump[];
}
