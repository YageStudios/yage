import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import type { DepthQuads } from "yage/streaming/depth-quads";
@Component()
export class MaskResources extends Schema {
  /** Every mask on screen, in the pawns' depth at its wearer's feet. */
  @type("object")
  quads: DepthQuads;
  /** Each mask kind's art, one under the next (MaskAssets.frame). */
  @type("object")
  atlas: PIXI.Texture;
}
