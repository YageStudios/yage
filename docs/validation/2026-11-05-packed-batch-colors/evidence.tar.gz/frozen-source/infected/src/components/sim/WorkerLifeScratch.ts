import type { World } from "minecs";
import { Component, Schema, type } from "minecs";
import { CONTENT } from "../../content/runtime";
import type { Who } from "../../services/life/who";
import { LifeWho } from "./LifeWho";
@Component()
export class WorkerLifeScratch extends Schema {
  @type(LifeWho)
  who: Who;
}
export const initializeWorkerLifeScratch = (world: World, entity: number) => {
  world(WorkerLifeScratch, entity).who = { gid: 0, role: 0, family: 0, rank: 0, traits: 0, culture: CONTENT.cultures[0], hcx: 0, hcy: 0, walk: 0 };
};
