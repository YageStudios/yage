import { Component, Schema, type } from "minecs";
import { SceneEvolution } from "../scene/SceneEvolution";

/** The strain's evolution (world:strain): its pathogen, picked cards and passive-tree nodes. OfferResolve and DriftSystem change it. */
@Component()
export class EvolutionState extends Schema {
  @type(SceneEvolution) evolution: SceneEvolution;
}
