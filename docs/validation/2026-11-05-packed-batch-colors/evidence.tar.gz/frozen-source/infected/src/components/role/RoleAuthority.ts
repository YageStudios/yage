import { Component, Schema, type } from "minecs";
import type { RoleAction } from "./RoleIntents";

/** The actions a role is granted (RoleAction kinds); RoleIntentRouterSystem rejects any other. */
@Component()
export class RoleAuthority extends Schema {
  @type(["string"]) actions: RoleAction["kind"][];
}
