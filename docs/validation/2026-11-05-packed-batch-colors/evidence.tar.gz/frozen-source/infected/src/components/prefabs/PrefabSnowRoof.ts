import { Schema, type, nullable } from "minecs";
import type * as PIXI from "pixi.js";
export class PrefabSnowRoof extends Schema {
  @type("string") topKey: string;
  @type("object") holder: PIXI.Container;
  @type(["number"]) at: [number, number];
  @nullable() @type("object") sheet: PIXI.Graphics | null;
}
