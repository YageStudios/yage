import { Component, Schema, nullable, type } from "minecs";
import type { InputManager } from "yage/inputs/InputManager";
import type { KeyboardListener } from "yage/inputs/KeyboardListener";
import type { PointerListener } from "yage/inputs/PointerListener";

/**
 * The page's keys for one scene: the InputManager its model carries (the spawner passes it) and the
 * keyboard, text-field filter and focus-loss release PageInputSetup attaches and removes, and the canvas pointer the
 * scene listens to (the page attaches it; PageInputSetup destroys it with its entity).
 */
@Component()
export class PageInput extends Schema {
  @type("object") input: InputManager;
  @nullable() @type("object") keyboard: KeyboardListener | null;
  @nullable() @type("object") release: (() => void) | null;
  @nullable() @type("object") pointer: PointerListener | null;
}
