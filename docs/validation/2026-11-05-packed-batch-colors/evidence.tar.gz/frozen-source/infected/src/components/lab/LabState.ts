/** Mutable state of one swap-on-death experiment. */
import { Component, Schema, defaultValue, nullable, type } from "minecs";
import { LabLeap } from "./LabLeap";
import { LabTrail } from "./LabTrail";

@Component()
export class LabState extends Schema {
  @type("number") @defaultValue(0) cx: number;
  @type("number") @defaultValue(0) cy: number;
  @type("string") @defaultValue("1") variantKey: string;
  @type("boolean") @defaultValue(true) slowmo: boolean;
  @type("number") @defaultValue(0) tick: number;
  @type("number") @defaultValue(-1) host: number;
  @type("number") @defaultValue(0) deaths: number;
  @type("number") @defaultValue(0) accumulator: number;
  @type("number") @defaultValue(0) now: number;
  @type("number") @defaultValue(0) x: number;
  @type("number") @defaultValue(0) y: number;
  @type("number") @defaultValue(2.2) zoom: number;
  @type(["string"]) swaps: string[];
  @nullable() @type(LabLeap) leap: LabLeap | null;
  @nullable() @type(LabTrail) trail: LabTrail | null;
}
