import { Component, Schema, type } from "minecs";

/** The strain a virus seat plays (role:virus); its routed actions reach only that strain and the seat's actor. */
@Component()
export class StrainRef extends Schema {
  @type("string") strain: string;
}
