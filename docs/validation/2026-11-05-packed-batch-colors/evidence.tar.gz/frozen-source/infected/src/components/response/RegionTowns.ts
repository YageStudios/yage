import { Component, Schema, type } from "minecs";

/** The region's `region:town` entities, in place order (services/response-export.ts seeds them). */
@Component()
export class RegionTowns extends Schema {
  @type(["number"]) towns: number[];
}
