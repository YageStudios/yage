import { Schema, type } from "minecs";
export class SceneLight extends Schema {
  @type("number") seconds: number;
  @type("number") night: number;
}
