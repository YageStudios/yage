import { Component, nullable, Schema, type } from "minecs";
import { MutationOffer } from "../scene/MutationOffer";

/** The strain's open mutation offer (world:strain): OfferTimer opens it, OfferResolve settles it. */
@Component()
export class MutationOfferState extends Schema {
  @nullable() @type(MutationOffer) offer: MutationOffer | null;
}
