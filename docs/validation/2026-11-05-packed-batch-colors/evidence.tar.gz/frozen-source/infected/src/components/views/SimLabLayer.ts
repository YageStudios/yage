import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";

/** The simulation lab's field overlay (SimLabView): its grid, markers and labels, and the group or building being dragged. */
@Component()
export class SimLabLayer extends Schema {
  @type("object") root: PIXI.Container | null;
  @type("object") lines: PIXI.Graphics | null;
  @type("object") labels: Map<string, PIXI.Text>;
  /** Pointer listeners on the canvas, taken off at cleanup. */
  @type("object") detach: (() => void) | null;
}
