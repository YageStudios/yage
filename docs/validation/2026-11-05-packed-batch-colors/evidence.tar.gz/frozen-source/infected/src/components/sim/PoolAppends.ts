import { Component } from "minecs";
import { Commands } from "yage/world/commands";
import type { Enclosure } from "../../domain/load/linger";
import type { PoolId } from "../../services/cabin";

/** One local append to a cabin or platform pool, as CabinLoadSystem or PlatformLoadSystem made it. */
export interface PoolAppend {
  id: PoolId;
  where: Enclosure;
  key: number;
  amount: number;
  tick: number;
}

/** This pass's local appends, in the order the load systems made them (PoolAppendSystem drains it). */
@Component()
export class PoolAppends extends Commands<PoolAppend> {}
