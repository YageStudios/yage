import { Component, Schema, type } from "minecs";
@Component()
export class PopulationPlan extends Schema {
  @type("number")
  cx: number;
  @type("number")
  cy: number;
  @type("number")
  count: number;
  @type("object")
  home: Uint16Array;
  @type("object")
  slot: Uint8Array | Uint32Array;
  @type("object")
  role: Uint8Array;
  @type("object")
  work: Uint16Array;
  @type("object")
  wdir: Uint8Array;
  @type("object")
  seat: Uint8Array;
  @type("object")
  age: Uint8Array;
  @type("object")
  sex: Uint8Array;
  @type("object")
  kin: Uint8Array;
  @type("object")
  household: Uint32Array;
  @type("object")
  hhFirst: Uint32Array;
  @type("object")
  hhSize: Uint8Array;
  @type("object")
  hhHome: Uint16Array;
  @type("object")
  hhFlat: Uint16Array | Uint32Array;
  @type("object")
  ride: Uint16Array;
  @type("object")
  board: Uint16Array;
  @type("object")
  alight: Uint16Array;
  @type("object")
  commute: Float32Array;
}
