import { Component, Schema, type, nullable } from "minecs";
import { FigurePose } from "../figures/FigurePose";
import { TransitFirst } from "./TransitFirst";
@Component()
export class TransitState extends Schema {
  @type([FigurePose]) figures: FigurePose[];
  @type("number") frameNo: number;
  @type("number") count: number;
  @nullable() @type(TransitFirst) first: TransitFirst | null;
}
