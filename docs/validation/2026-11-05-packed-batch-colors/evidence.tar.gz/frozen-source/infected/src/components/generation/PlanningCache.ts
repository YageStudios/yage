import { Component, Schema, type } from "minecs";
import type { Layout } from "../../worldgen/terrain/models";
import type { Plan } from "../../worldgen/plan";
import type { TransitIndex, TransitLine } from "../../worldgen/transit";
import type { Census } from "../../worldgen/census/projection";
import type { Net } from "../../worldgen/commute/types";
import type { Person } from "../../domain/people/person";
import type { ChunkPlan } from "../../worldgen/population/planner";
/** Transient projections belong to one source; they are never part of person-row saves. */
@Component()
export class PlanningCache extends Schema {
  @type("object") ages: Map<number,Uint8Array>;
  @type("object")
  cultures: Map<number, number>;
  @type("object")
  people: Map<number, Person>;
  @type("object")
  elders: Map<number, number[]>;
  @type("object")
  layouts: Map<number, Layout>;
  @type("object")
  populationPlans: Map<number, ChunkPlan>;
  @type("object")
  inbound: Map<number, Int32Array>;
  @type("object")
  plan: Plan | null | undefined;
  @type("object")
  census: Map<number, Census>;
  @type("object")
  lines: Map<TransitIndex, TransitLine[]>;
  @type("object")
  commuteNets: WeakMap<Plan, Net>;
}
