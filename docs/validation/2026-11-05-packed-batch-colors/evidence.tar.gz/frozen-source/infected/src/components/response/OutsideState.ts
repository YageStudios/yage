import { Schema, type } from "minecs";

export class OutsideState extends Schema {
  @type("number") infected: number;
  @type("number") dead: number;
  @type("number") closure: number;
  @type("number") found: number;
  @type("number") arrived: number;
  @type("number") smuggled: number;
}
