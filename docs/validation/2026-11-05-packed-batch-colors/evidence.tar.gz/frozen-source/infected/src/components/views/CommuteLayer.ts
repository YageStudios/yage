import { Component, Schema, type, defaultValue } from "minecs";
import type * as PIXI from "pixi.js";

@Component()
export class CommuteLayer extends Schema {
  @type("object") graphic: PIXI.Graphics;
  @type("number") @defaultValue(-1) drawn: number;
}
