import type { ScheduleEntry } from "../../domain/people/day-schedule";
import type { World } from "minecs";
import { Component, Schema, type } from "minecs";
import type { Segment } from "../../services/life/schedule";
import { LifeSegment } from "./LifeSegment";
const emptySegment = () => ({ day: 0, index: 0, start: 0, end: 0, act: 0 });
@Component()
export class WorkerSchedule extends Schema {
  @type(LifeSegment)
  scratch: Segment;
  @type("object")
  days: Float64Array[];
  @type("object")
  memoKey: Float64Array;
  @type("object")
  memoRole: Int32Array;
  @type("object")
  memoFamily: Float64Array;
  @type("object")
  memoDays: Float32Array;
  @type("object")
  memoSchedule: (readonly ScheduleEntry[] | undefined)[];
}
/** The schedule memo's sets (two days each; see dayBoundaries). */
export const MEMO_SET_BITS = 13;
const MEMO_SLOTS = 2 << MEMO_SET_BITS;
export const initializeWorkerSchedule = (world: World, entity: number) => {
  const fields = world(WorkerSchedule).store as unknown as Record<string, unknown[]>;
  world(WorkerSchedule, entity).scratch = emptySegment();
  fields.days[entity] = [new Float64Array(12), new Float64Array(12)];
  fields.memoKey[entity] = new Float64Array(MEMO_SLOTS).fill(NaN);
  fields.memoRole[entity] = new Int32Array(MEMO_SLOTS);
  fields.memoFamily[entity] = new Float64Array(MEMO_SLOTS);
  fields.memoSchedule[entity] = new Array(MEMO_SLOTS);
  fields.memoDays[entity] = new Float32Array(MEMO_SLOTS * 12);
};
