import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import type { Ctx } from "../../render/pawns/brush";
import type { PawnAtlasJob } from "../../render/pawns/atlas-off-page";

/** Every scene owns its canvas pair and GPU atlas textures. */
@Component()
export class PawnAtlasResources extends Schema {
  @type("object") art: HTMLCanvasElement;
  @type("object") mask: HTMLCanvasElement;
  @type("object") artContext: Ctx;
  @type("object") maskContext: Ctx;
  @type("object") atlas: PIXI.Texture;
  @type("object") tintMask: PIXI.Texture;
  /** The rigged sprites' parts (render/pawns/atlas.ts drawRigRows), canvases and GPU textures as the atlas's. */
  @type("object") rigArt: HTMLCanvasElement;
  @type("object") rigMask: HTMLCanvasElement;
  @type("object") rigArtContext: Ctx;
  @type("object") rigMaskContext: Ctx;
  @type("object") rigAtlas: PIXI.Texture;
  @type("object") rigTintMask: PIXI.Texture;
  /** The atlas being painted off the page (PawnAtlasAssets), until PawnAtlasPaint takes it. */
  @type("object") job: PawnAtlasJob | null;
}
