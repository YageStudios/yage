import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";

export class LoadParticle extends Schema {
  @type("number") x: number;
  @type("number") y: number;
  @type("number") vx: number;
  @type("number") vy: number;
  @type("number") z: number;
  @type("number") vz: number;
  @type("number") age: number;
  @type("number") life: number;
  @type("number") fade: number;
  @type("object") sprite: PIXI.Sprite;
}
