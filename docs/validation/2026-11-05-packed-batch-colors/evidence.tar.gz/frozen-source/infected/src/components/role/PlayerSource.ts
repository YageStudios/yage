import { Component, Schema, type } from "minecs";

/**
 * The player's driver: its next source sequence (PlayerIntentSystem) and the steering it last asked
 * for (PlayerSteerSystem), with the epoch it asked under, and where it last said the page has the
 * host and when (wall ms).
 */
@Component()
export class PlayerSource extends Schema {
  @type("number") sequence: number;
  @type("string") steer: string;
  @type("string") at: string;
  @type("number") atMs: number;
}
