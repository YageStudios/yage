import { Component, Schema, defaultValue, type } from "minecs";

/** A town's military (MilitarySystem): burn squads kept out whatever the dead (debug `&burn=1`). */
@Component()
export class TownMilitary extends Schema {
  @type("boolean") @defaultValue(false) burnPin: boolean;
}
