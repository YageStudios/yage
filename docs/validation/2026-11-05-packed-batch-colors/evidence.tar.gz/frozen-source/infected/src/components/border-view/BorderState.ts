import { Component, Schema, type } from "minecs";
import { FireSpot } from "../fire/FireSpot";
@Component()
export class BorderState extends Schema {
  @type([FireSpot])
  fires: FireSpot[] = [];
}
