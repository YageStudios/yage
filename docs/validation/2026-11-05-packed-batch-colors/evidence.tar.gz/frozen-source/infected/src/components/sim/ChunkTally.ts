import { Component, Schema, type } from "minecs";

/** Counts stay pending until the streaming host asks for stats, never drained by tick systems. */
@Component()
export class ChunkTally extends Schema {
  @type("object") pending: Uint32Array;
  /** Local events since the last stats, flat (services/events.ts). */
  @type("object") events: number[];
}
