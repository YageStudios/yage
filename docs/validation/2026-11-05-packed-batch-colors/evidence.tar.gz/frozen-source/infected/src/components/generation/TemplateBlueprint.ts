import { Component, Schema, type } from "minecs";
import type { Template } from "../../worldgen/terrain/models";
import { TemplateStairs } from "./TemplateStairs";
@Component()
export class TemplateBlueprint extends Schema {
  @type("number")
  w: number;
  @type("number")
  h: number;
  @type("object")
  door: Template["door"];
  @type("object")
  beds: Template["beds"];
  @type("object")
  furniture: Template["furniture"];
  @type("object")
  spots: Template["spots"];
  @type("number")
  floorCap: number;
  @type(TemplateStairs)
  stairs?: TemplateStairs;
}
