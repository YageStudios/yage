import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/** A request for the scene's sound: loading, player settings, or the engine's pause state. */
export type AudioCommand = { kind: "preload" } | { kind: "mute"; muted: boolean } | { kind: "volume"; volume: number } | { kind: "pause"; paused: boolean };

/** The scene's sound requests (HUD controls, preload and engine pause), drained by AudioControls. */
@Component()
export class AudioCommands extends Commands<AudioCommand> {}
