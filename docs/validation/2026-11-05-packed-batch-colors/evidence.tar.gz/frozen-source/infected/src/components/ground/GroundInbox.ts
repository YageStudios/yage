import { Component, Schema, type } from "minecs";

export const GROUND_TILES = 0;
export const GROUND_ADD = 1;

/** What the ground's owner streamed in since the last paint, in arrival order: chunk keys and their kinds (tiles arrived, or the chunk was added). */
@Component()
export class GroundInbox extends Schema {
  @type(["number"]) keys: number[];
  @type(["number"]) kinds: number[];
}
