import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/** A fresh chunk's residents to spawn (module generate pushes, PersonSpawnSystem drains in the "people" stack). */
/** `skip`: residents not spawned (ascending indices: people somewhere else now, services/cold/materialize.ts). */
export type SpawnRequest = { seed: number; cx: number; cy: number; people: number; skip?: readonly number[] };

@Component()
export class SpawnRequests extends Commands<SpawnRequest> {}
