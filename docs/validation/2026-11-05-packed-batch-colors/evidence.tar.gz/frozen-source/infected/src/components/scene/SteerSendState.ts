import { Component, Schema, type } from "minecs";


/**
 * The actor's steering as HostControl sends it: the direction its controller asked for
 * (steerBytes' [dx + 1, dy + 1]), where a player's page has walked the host ([x, y] world units,
 * HostBody; empty when it hasn't), and what was last sent and when (authority ms). A settled
 * card's showcase goes out with it (HostShowcase).
 */
@Component()
export class SteerSendState extends Schema {
  @type(["number"]) steer: number[];
  @type(["number"]) at: number[];
  @type("string") sent: string;
  @type("number") sentAt: number;
}
