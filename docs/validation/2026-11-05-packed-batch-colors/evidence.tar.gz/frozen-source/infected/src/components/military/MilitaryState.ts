import { Component, nullable, Schema, type } from "minecs";
import { FigurePose } from "../figures/FigurePose";
import { FireSpot } from "../fire/FireSpot";
import { MilitaryPile } from "./MilitaryPile";
@Component()
export class MilitaryState extends Schema {
  @type([FigurePose]) figures: FigurePose[];
  @type([FireSpot]) fires: FireSpot[];
  @type("number") patrols = 0;
  @type("number") cars = 0;
  @type("number") shots = 0;
  @type("number") convoys = 0;
  @type("number") piles = 0;
  @nullable() @type(MilitaryPile) pile: MilitaryPile | null = null;
}
