import { Schema, type } from "minecs";
import { nullable } from "minecs";
import type { Plan } from "../../worldgen/plan";
import type { WorldMap } from "../../worldmap/places";
import { BorderGate } from "./BorderGate";
export class BorderGeometry extends Schema {
  @nullable() @type("object") plan: Plan | null;
  @nullable() @type("object") map: WorldMap | null;
  @type([BorderGate]) gates: BorderGate[];
}
