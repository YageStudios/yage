import { Schema, type } from "minecs";

export class ChunkPopulation extends Schema {
  @type("number") key: number;
  @type("number") people: number;
  @type("number") incubating: number;
  @type("number") infected: number;
  @type("number") dead: number;
  @type("number") soldiers: number;
  @type("number") alert: number;
  /** The chunk's bloomed sample (services/bloomed.ts): a symptomatic person's gid (-1 or absent: nobody) and where they stood. */
  @type("number") bloomedGid?: number;
  @type("number") bloomedX?: number;
  @type("number") bloomedY?: number;
}
