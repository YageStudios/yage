import { Component, Schema, type } from "minecs";
import { BorderGeometry } from "../response/BorderGeometry";

/** The strategic map's own cache of the region's border gates, for the borders it shows before the response has made any (shownBorders). */
@Component()
export class WorldMapGates extends Schema {
  @type(BorderGeometry) geometry: BorderGeometry;
}
