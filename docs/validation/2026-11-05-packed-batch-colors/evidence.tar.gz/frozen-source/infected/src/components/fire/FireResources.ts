import { Component, nullable, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
@Component()
export class FireResources extends Schema {
  @nullable() @type("object") soft: PIXI.Texture | null = null;
  @type(["object"]) flames: PIXI.Texture[] = [];
}
