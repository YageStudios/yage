import { Component, Schema, type } from "minecs";
import type { Point } from "../../domain/rts/orders";
export type RtsPath = { order: number; goal: Point; points: Point[]; at: number; tick: number; x: number; y: number };
/** Rebuildable navigation memo, owned by the chunk and never part of a person transfer/save row. */
@Component()
export class RtsNavigation extends Schema {
  @type("number") geometryRevision: number;
  @type("object") paths: Map<number, RtsPath>;
}
