import { Schema, type } from "minecs";
export class ChunkStep extends Schema {
  @type("number")
  tick: number;
  @type("number")
  ticks: number;
  @type("number")
  dt: number;
  @type("number")
  space: number;
  @type("number")
  cx: number;
  @type("number")
  cy: number;
  @type("boolean")
  hot?: boolean;
}
