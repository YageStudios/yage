import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
@Component()
export class MarkerResources extends Schema {
  @type("object") root: PIXI.Container;
  @type("object") graphic: PIXI.Graphics;
}
