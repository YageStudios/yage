import { Component } from "minecs";
import { Commands } from "yage/world/commands";
import type { Pawn } from "../../domain/pawns";

/**
 * What the actor is asked (control:actor); HostTakeOver owns the queue. Routed role actions carry
 * their command id for the result; the seek comes from the actor's own HostControl.
 */
export type ActorOrder =
  /** Take over this pawn; `why` (if any) its clients say. */
  | { kind: "takeOver"; pawn: Pawn; why: string; command?: string }
  /** Pick and take over the next bloomed host (the AI's cycle). */
  | { kind: "cycle"; command?: string }
  /** Steer this way from now on. */
  | { kind: "steer"; dx: number; dy: number; x?: number; y?: number; command?: string }
  /** The host bit person `target` (its `n`th bite) where they were drawn, (x, y): the chunk there hears it. */
  | { kind: "bite"; target: number; n: number; x: number; y: number; command?: string }
  /** The controller changed: let go of the keys. */
  | { kind: "neutral" }
  /** Ride nobody (the lab's right-click on the ground): the host's worker is let go. */
  | { kind: "release" };

@Component()
export class ActorOrders extends Commands<ActorOrder> {}
