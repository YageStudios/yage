import { Component, Schema, type } from "minecs";
import { StartTownRow } from "../scene/StartTownRow";

/** The start screen's choices (region:response; SceneWorldSetup): the towns patient zero can start in. */
@Component()
export class ScenarioStartCatalog extends Schema {
  @type([StartTownRow]) towns: StartTownRow[];
}
