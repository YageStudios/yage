import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
export class TransitTemplate extends Schema {
  @type("string") id: string;
  @type("object") graphic: PIXI.Graphics;
}
