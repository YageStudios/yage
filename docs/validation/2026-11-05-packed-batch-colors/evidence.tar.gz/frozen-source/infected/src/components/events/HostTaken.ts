import { Component, defaultValue, Schema, type } from "minecs";

/**
 * A role's actor took over a host this frame ("world:host-taken", a transient HostTakeOver spawns):
 * the role, the host and where it stood, and why when the seek moved it (a client says so).
 */
@Component()
export class HostTaken extends Schema {
  @type("string") @defaultValue("") role: string;
  @type("number") @defaultValue(-1) gid: number;
  @type("number") @defaultValue(0) x: number;
  @type("number") @defaultValue(0) y: number;
  @type("string") @defaultValue("") why: string;
}
