import { Component, Schema, defaultValue, nullable, type } from "minecs";
import { Commands } from "yage/world/commands";
import type { SavedChunk } from "yage/streaming";
import type { Checkpoint } from "../../checkpoint/records";
import type { CheckpointSlots as Slots } from "../../persistence/checkpoint";

/** A checkpoint asked for: saved to `slot`, or loaded from it; `id` correlates it with its status in CheckpointState. */
export type CheckpointCommand = { kind: "save" | "load"; slot: string; id: number };

/**
 * The run's checkpoint requests (run:checkpoint). Gameplay and the debug hooks ask here and never
 * call the save or the load; CheckpointRequestSystem is the one drain.
 */
@Component()
export class CheckpointCommands extends Commands<CheckpointCommand> {}

/** A save under way (AuthoritySaveSystem): its records, then the hosts' chunks, then the slot written. */
export type SaveOperation = {
  id: number;
  slot: string;
  doc: Checkpoint;
  /** The hosts' answer: the chunk section and the tick it was taken at the start of. */
  taken?: { tick: number; chunks: SavedChunk[] };
  /** Set once the slot is written, or the save failed. */
  done?: { tick: number } | { error: string };
};

/** A load under way (AuthorityLoadSystem): the slot's text once read (null: an empty slot). */
export type LoadOperation = { id: number; slot: string; text?: string | null; error?: string };

/**
 * The run's checkpoint status (run:checkpoint): runtime correlation, never saved. Each phase has
 * its own fields: the request system stages, the save and load systems take what is staged for
 * them and report how it went.
 */
@Component()
export class CheckpointState extends Schema {
  /** Request: the save asked for, until AuthoritySaveSystem takes it on a step. */
  @nullable() @type("object") saveAsked: CheckpointCommand | null;
  /** Request: the load asked for, until AuthorityLoadSystem takes it. */
  @nullable() @type("object") loadAsked: CheckpointCommand | null;
  /** Request: the last request refused (another of its kind was under way), and why. */
  @type("number") @defaultValue(-1) refusedId: number;
  @type("string") @defaultValue("") refused: string;
  /** Save: the save under way. */
  @nullable() @type("object") saving: SaveOperation | null;
  /** Save: the last save finished: its id and the authority's tick it holds, or why it failed. */
  @type("number") @defaultValue(-1) savedId: number;
  @type("number") @defaultValue(-1) savedTick: number;
  @type("string") @defaultValue("") saveFailed: string;
  /** Load: the load under way. */
  @nullable() @type("object") loading: LoadOperation | null;
  /** Load: the last load finished: its id and the authority's tick it resumed at, or why it failed. */
  @type("number") @defaultValue(-1) loadedId: number;
  @type("number") @defaultValue(-1) loadedTick: number;
  @type("string") @defaultValue("") loadFailed: string;
}

/** Where the run's checkpoints are kept (run:checkpoint), as the run's composer gave them (services/run.ts): the page's browser slots, a test's own; null keeps none. */
@Component()
export class CheckpointStorage extends Schema {
  @nullable() @type("object") slots: Slots | null;
}

/** A complete checkpoint's digest (checkpoint/digest.ts) and the authority's tick it holds. */
export type AuthorityDigest = { tick: number; digest: string };

/**
 * The digest of every checkpoint the run has saved (run:checkpoint), in order: the authority's
 * whole state at those ticks, for a replay or a continuation to be compared by. Runtime, never saved.
 */
@Component()
export class AuthorityDigests extends Schema {
  @type(["object"]) @defaultValue([]) log: AuthorityDigest[];
}
