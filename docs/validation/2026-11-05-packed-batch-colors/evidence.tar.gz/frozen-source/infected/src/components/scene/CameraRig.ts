import { Component, Schema, type } from "minecs";
import type { ProjectedCamera } from "yage/systems/render/ProjectedCamera";

/** The camera's PIXI container on the stage: the chunk scene, the marker and the overlays draw into it; GroundView moves it to the SceneView (on the GPU: ProjectedCamera). */
@Component()
export class CameraRig extends Schema {
  @type("object") root: ProjectedCamera;
}
