import { Component, Schema, type } from "minecs";
/** Data on the existing mutant definitions; values are game seconds / tiles. */
@Component()
export class MutantSiege extends Schema {
  @type("string") name: string;
  @type("number") damage: number;
  @type("number") interval: number;
  @type("number") reach: number;
  @type("boolean") walls: boolean;
  @type("number") splash: number;
}
