import { Component, Schema, defaultValue, type } from "minecs";

/** The region's research (region:response): the cure's progress, the reshuffles it has paid for, and the tick the towns last stepped to (TownsResponseSystem writes the tick, TownResearchSystem the cure and reshuffles). */
@Component()
export class ResearchState extends Schema {
  @type("number") @defaultValue(0) cure: number;
  @type("number") @defaultValue(0) reshuffles: number;
  @type("number") @defaultValue(0) tick: number;
}
