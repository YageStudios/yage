import { Component, Schema, type } from "minecs";

/** The tier an office governs (role:governor, role:mayor): its TierIdentity.key. Every town at or under it is the office's, unless a nearer office holds it. */
@Component()
export class TierRef extends Schema {
  @type("string") key: string;
}
