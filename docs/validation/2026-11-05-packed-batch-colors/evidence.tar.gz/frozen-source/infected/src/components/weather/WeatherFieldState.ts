import { Component, Schema, defaultValue, type } from "minecs";
import { WeatherTarget } from "./WeatherTarget";
/**
 * The weather sampled over the view (GRID_X × GRID_Y). The grids are the entity's own arrays, made by
 * WeatherField.init: a fixed-length column would reserve them for every entity the page world can hold
 * (4096 × 3 × 70 floats, 3.4 MB) for the one weather entity.
 */
@Component()
export class WeatherFieldState extends Schema {
  @type("object") rain: Float32Array;
  @type("object") snow: Float32Array;
  @type("object") fog: Float32Array;
  @type("number") @defaultValue(-1) at: number;
  @type("number") @defaultValue(0) wind: number;
  @type("number") @defaultValue(0) windAngle: number;
  @type(WeatherTarget) target: WeatherTarget;
}
