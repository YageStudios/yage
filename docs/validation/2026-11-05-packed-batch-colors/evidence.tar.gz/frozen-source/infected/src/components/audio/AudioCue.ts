import { Component, Schema, type } from "minecs";
import type { VoiceOptions } from "yage/audio/types";

/** One sound asked for this frame (an "audio:cue" transient owned by its scene, or by none: every audio's); AudioVoices starts it on the owner's audio. */
@Component()
export class AudioCue extends Schema {
  @type("string")
  id: string;
  @type("object")
  opts: VoiceOptions;
}
