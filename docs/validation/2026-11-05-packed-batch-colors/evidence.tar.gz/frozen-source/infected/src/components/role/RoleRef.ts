import { Component, Schema, type } from "minecs";

/** The role (RoleIdentity.id) an actor, a controller's knowledge or a seat belongs to. */
@Component()
export class RoleRef extends Schema {
  @type("string") role: string;
}
