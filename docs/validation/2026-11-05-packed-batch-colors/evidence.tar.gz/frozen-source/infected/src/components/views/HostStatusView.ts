import { Component, defaultValue, Schema, type } from "minecs";

/** The controlled host as the HUD shows it (view:actor-status): alive, its life counted down between reports, and the dying warning. */
@Component()
export class HostStatusView extends Schema {
  @type("boolean") @defaultValue(false) alive: boolean;
  @type("boolean") @defaultValue(false) dying: boolean;
  /**
   * Seconds of life the host has left, counted down between reports; only meaningful while
   * `hasLife` (a number column can't hold null, so "no countdown" is the flag).
   */
  @type("boolean") @defaultValue(false) hasLife: boolean;
  @type("number") @defaultValue(0) hostLife: number;
  @type("number") @defaultValue(1) hostShare: number;
}
