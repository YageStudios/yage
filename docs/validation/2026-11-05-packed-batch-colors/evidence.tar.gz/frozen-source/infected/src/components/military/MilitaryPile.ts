import { Schema, type } from "minecs";
export class MilitaryPile extends Schema {
  @type("number") x: number;
  @type("number") y: number;
  @type("string") phase: string;
}
