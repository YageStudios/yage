import { Component, Schema, defaultValue, type } from "minecs";
import { CollapseNews } from "./CollapseNews";

/** What ResponseNewsSystem has announced of a town: its collapse, and its unrest phase (latched). */
@Component()
export class TownNews extends Schema {
  @type(CollapseNews) collapse: CollapseNews;
  @type("number") @defaultValue(0) unrest: number;
}
