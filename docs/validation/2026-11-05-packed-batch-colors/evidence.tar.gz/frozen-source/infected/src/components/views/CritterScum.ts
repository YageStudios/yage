import { Component, nullable, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";

/** A chunk's scum on fouled water (null when it has none), drawn for the tiles it was found in: a view record (services/view/records) of the critter view, which owns the graphic. */
@Component()
export class CritterScum extends Schema {
  @type("object") tiles: Uint8Array;
  @nullable() @type("object") graphic: PIXI.Graphics | null;
}
