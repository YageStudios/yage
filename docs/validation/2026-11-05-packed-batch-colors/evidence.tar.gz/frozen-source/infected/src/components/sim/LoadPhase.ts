import { Component, Schema, defaultValue, type } from "minecs";
import type { Ride } from "../../services/cabin";

/** Explicit buffers handed from sources through air/pools to uptake for one chunk world. */
@Component()
export class LoadPhase extends Schema {
  @type("object") rate: Float32Array;
  @type("object") nextSusceptible: Int32Array;
  @type("object") aboard: Uint8Array;
  /** 1 for someone on a building's roster this step (services/life/rosters.ts): the building's load, not a cell's (RosterLoadSystem). */
  @type("object") roster: Uint8Array;
  /** This step's roster members, in the world's order. */
  @type("object") rostered: number[];
  @type("object") care: Float32Array;
  @type("object") via: Float32Array;
  /** Per susceptible: the gid that gave the most of this step's load by name (breath, a cloud), or -1; and how much. */
  @type("object") src: Int32Array;
  @type("object") srcRate: Float32Array;
  /** Per cell, its carriers (chained by eid) and what each gives off: who a cell's infections are drawn from. */
  @type("object") carrierHead: Int32Array;
  @type("object") nextCarrier: Int32Array;
  @type("object") carrierRate: Float32Array;
  @type("object") riders: number[];
  @type("object") rides: Ride[];
  @type("object") waiters: number[];
  @type("object") stations: number[];
  @type("object") susceptibleHead: Int32Array;
  @type("object") cellRate: Float32Array;
  @type("object") pressure: Float32Array;
  @type("object") cellExtra: Float32Array;
  @type("boolean") @defaultValue(false) fresh: boolean;
  @type("boolean") @defaultValue(false) anyContagious: boolean;
  @type("number") @defaultValue(0) maxEid: number;
}
