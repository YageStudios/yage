import { Component, defaultValue, Schema, type } from "minecs";
import type { ChunkInfo } from "../../services/life/places";
import type { Spot3 } from "../../services/life/stores";
import type { Layout } from "../../worldgen/terrain/models";
@Component()
export class WorkerPlaces extends Schema {
  @type("number") @defaultValue(-1) regionRevision: number;
  @type("object")
  infos: Map<number, ChunkInfo>;
  @type("object")
  hops: Map<number, Int16Array>;
  @type("object")
  bridges: Map<number, number>;
  @type("object")
  doorNodes: Map<Layout, Uint8Array>;
  @type("object")
  laneRoom: Map<Layout, Float32Array>;
  @type("object")
  services: Map<number, {
    care: Spot3;
    lab: Spot3;
    worship: Spot3;
    mosque: Spot3;
    temple: Spot3;
  }>;
  @type("object")
  yards: Map<number, Spot3>;
}
