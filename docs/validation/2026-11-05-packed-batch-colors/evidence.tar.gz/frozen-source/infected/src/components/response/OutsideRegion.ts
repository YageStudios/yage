import { Schema, type } from "minecs";
import type { GateKind } from "../../domain/response/borders";
export class OutsideRegion extends Schema {
  @type("string") id: string;
  @type("string") name: string;
  @type("number") population: number;
  @type(["string"]) by: readonly GateKind[];
}
