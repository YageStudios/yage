import { Component, Schema, type } from "minecs";
import { FeedHost } from "./FeedHost";
/** Pending world generation is owned by the scene, independently of transport handles. */
@Component()
export class WorldFeedState extends Schema {
  @type([FeedHost]) hosts: FeedHost[];
  @type("number") left: number;
  @type("number") seed: number;
  @type("number") inFlight: number;
  @type("string") sortedFor: string;
}
