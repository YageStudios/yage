/**
 * The schemas a chunk world registers: one row per person, every field a flat numeric column so
 * rows can travel between chunks (yage/streaming hand-offs). Every person carries all of them.
 */
import { Pos } from "./sim/Pos";
import { Wander } from "./sim/Wander";
import { Gid } from "./sim/Gid";
import { Look } from "./sim/Look";
import { Role } from "./sim/Role";
import { Condition } from "./sim/Condition";
import { Life } from "./sim/Life";
import { Leg } from "./sim/Leg";
import { Exposure } from "./sim/Exposure";
// The person's body for hot chunks' contact (yage/physics/lean; src/systems/sim/HotContactSystem.ts).
import { LeanBody } from "yage/physics/lean";

export { Pos, Wander, Gid, Look, Role, Condition, Life, Leg, Exposure, LeanBody };

/** In row order (generation adds them in this order; hand-offs carry them in this order). */
export const SIM_SCHEMAS = [Pos, Wander, Gid, Look, Role, Condition, Life, Leg, Exposure, LeanBody];
