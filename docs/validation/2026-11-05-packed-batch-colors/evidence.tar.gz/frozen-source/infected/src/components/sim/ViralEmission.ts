import { Schema, type } from "minecs";
import type { Emit } from "../../domain/load/constants";

/** Typed symptom emission carried by a snapshot overlay. */
export class ViralEmission extends Schema {
  @type("number") kind: Emit;
  @type("number") slot: number;
  @type("number") x: number;
  @type("number") y: number;
  @type("number") vx: number;
  @type("number") vy: number;
  @type("number") angle: number;
  @type("number") age: number;
}
