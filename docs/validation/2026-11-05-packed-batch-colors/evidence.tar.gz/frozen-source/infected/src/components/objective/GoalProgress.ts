import { Component, defaultValue, Schema, type } from "minecs";

/**
 * The virus's objective (role:objective), evaluated by ObjectiveEvaluationSystem once the whole
 * region has reported: seconds with nobody carrying it, and the outcome once decided (lost to
 * extinction or a finished cure, won at the victory share).
 */
@Component()
export class GoalProgress extends Schema {
  @type("number") @defaultValue(0) extinctFor: number;
  @type("string") @defaultValue("") outcome: "" | "won" | "lost";
  @type("string") @defaultValue("") reason: "" | "extinct" | "share" | "cure";
}
