import type { DailyRoutineProfile } from "../../domain/people/daily-routine";
import { Schema, type } from "minecs";
import type { Culture } from "../../domain/people/culture";
export class LifeWho extends Schema {
  @type("object")
  routine?: DailyRoutineProfile;
  @type("number")
  gid: number;
  @type("number")
  role: number;
  @type("number")
  family: number;
  @type("number")
  rank: number;
  @type("number")
  traits: number;
  @type("number")
  hcx: number;
  @type("number")
  hcy: number;
  @type("number")
  walk: number;
  @type("object")
  culture: Culture;
}
