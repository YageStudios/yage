import { Component, defaultValue, Schema, type } from "minecs";

/** When TraitConfig last sent the hosts the strain's traits (world:strain), wall time. */
@Component()
export class TraitRevision extends Schema {
  @type("number") @defaultValue(0) configuredAt: number;
}
