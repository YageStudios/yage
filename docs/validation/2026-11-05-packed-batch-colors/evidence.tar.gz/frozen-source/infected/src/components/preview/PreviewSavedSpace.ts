/** Persisted seed and camera for one authoring space. */
import { Schema, type } from "minecs";

export class PreviewSavedSpace extends Schema {
  @type("string") key: string;
  @type("number") seed: number;
  @type("boolean") hasCamera: boolean;
  @type("number") x: number;
  @type("number") y: number;
  @type("number") scale: number;
}
