import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";

/** The chunk boundary debug layer (ChunkDebugView): its lines and a label per chunk, made when first shown. */
@Component()
export class ChunkDebugLayer extends Schema {
  @type("object") root: PIXI.Container | null;
  @type("object") lines: PIXI.Graphics | null;
  @type("object") labels: Map<number, PIXI.Text>;
}
