import { Schema, type } from "minecs";
import { LabCandidate } from "./LabCandidate";

/** The timed last-breath choice and its frozen target list. */
export class LabLeap extends Schema {
  @type("number") until: number;
  @type("number") x: number;
  @type("number") y: number;
  @type([LabCandidate]) targets: LabCandidate[];
}
