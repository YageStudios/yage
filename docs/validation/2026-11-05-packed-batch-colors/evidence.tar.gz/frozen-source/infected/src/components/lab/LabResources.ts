/** Browser and chunk resources owned by one lab scene. */
import { Component, Schema, type, type World } from "minecs";
import type * as PIXI from "pixi.js";
import type { ChunkScene } from "yage/streaming/layer";
import type { GroundHandle } from "../../services/ground/context";
import type { LabUI } from "../../ui/lab";

@Component()
export class LabResources extends Schema {
  @type("object") world: World;
  @type("object") app: PIXI.Application;
  @type("object") camera: PIXI.Container;
  @type("object") scene: ChunkScene;
  @type("object") ground: GroundHandle;
  @type("object") overlay: PIXI.Graphics;
  @type("object") ui: LabUI;
}
