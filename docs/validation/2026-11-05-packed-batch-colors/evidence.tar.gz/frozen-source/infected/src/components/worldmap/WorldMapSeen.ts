import { Component, Schema, defaultValue, type } from "minecs";

/** Page time (ms) each infection jump (by index into the track's jumps) was first drawn on the map, so jumps made while zoomed in play once you zoom out. */
@Component()
export class WorldMapSeen extends Schema {
  @type(["number"]) @defaultValue([]) jumps: number[];
}
