import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import type { CritterGround } from "../../render/critters/depth";

/** Layer handles and tile-derived geometry belong to this scene entity. */
@Component()
export class CritterLayer extends Schema {
  @type("object") ground: CritterGround;
  @type("object") air: PIXI.Graphics;
  @type("object") scum: PIXI.Container;
  /** Scum records (CritterScum entities) by "cx,cy", oldest first. */
  @type("object") scums: Map<string, number>;
}
