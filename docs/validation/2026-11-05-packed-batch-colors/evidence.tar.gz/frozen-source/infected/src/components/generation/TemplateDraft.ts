import { Component, Schema, type } from "minecs";
import type { TemplateKey } from "../../worldgen/templates/dimensions";
import type { Template } from "../../worldgen/terrain/models";
@Component()
export class TemplateDraft extends Schema {
  @type("string")
  key: TemplateKey;
  @type("number")
  w: number;
  @type("number")
  h: number;
  @type("number")
  doorX: number;
  @type("number")
  floorCap: number;
  @type("object")
  grid: Uint8Array;
  @type("object")
  beds: Template["beds"];
  @type("object")
  furniture: Template["furniture"];
  @type("object")
  spots: Template["spots"];
  @type("object")
  stairs: Template["stairs"] | null;
}
