import { Schema, type } from "minecs";
import type { GateKind } from "../../domain/response/borders";
import { ResponsePoint } from "./ResponsePoint";
export class BorderGate extends Schema {
  @type("string") id: string;
  @type("string") name: string;
  @type("string") kind: GateKind;
  @type("number") town: number;
  @type("number") x: number;
  @type("number") y: number;
  @type("number") angle: number;
  @type("number") half: number;
  @type("number") seed: number;
  @type([ResponsePoint]) inward: ResponsePoint[];
  @type(ResponsePoint) edge: ResponsePoint;
}
