import { Component, Schema, type } from "minecs";
import { SettlementState } from "./SettlementState";
/** Transient authored terrain-generation entity; every mutable draft column has a schema owner. */
@Component()
export class TerrainDraft extends Schema {
  @type("object")
  layouts: Map<number, import("../../worldgen/terrain/models").Layout>;
  @type("number")
  cx: number;
  @type("number")
  cy: number;
  @type(SettlementState)
  settlement: SettlementState;
  @type(["number"])
  placeIds: number[];
  @type(["number"])
  spotX: number[];
  @type(["number"])
  spotY: number[];
  @type(["number"])
  stamps: number[];
  @type(["number"])
  graphX: number[];
  @type(["number"])
  graphY: number[];
  @type(["number"])
  graphA: number[];
  @type(["number"])
  graphB: number[];
  @type(["number"])
  graphKind: number[];
  @type(["number"])
  portals: number[];
  @type(["number"])
  households: number[];
  @type("number")
  residents: number;
  @type("number")
  inflow: number;
}
