import { Component, Schema, defaultValue, type } from "minecs";
import { SEED } from "../../domain/world";

/**
 * The run's starting seed (world:outbreak): with the players' actions, all a replay needs. The
 * chunks are generated with it (their draws keyed on it), and the outbreak's start seeds every
 * game stream from it (the strain's offers, the AI controllers'). Presentation never draws from it.
 */
@Component()
export class RunSeed extends Schema {
  @type("number") @defaultValue(SEED) seed: number;
}
