import type { WorkerRtsOrder } from "../../domain/rts/orders";
import type { World } from "minecs";
import { Component, Schema, type } from "minecs";
import type { Ride } from "../../services/cabin";
import { PathogenTraits } from "../shared/PathogenTraits";
import { CONTENT } from "../../content/runtime";
import type { LabWorker } from "../../simlab/stage";
/** One planning context's configured strain and test overrides, shared by the chunk worlds bound to it. */
@Component()
export class WorkerInfection extends Schema {
  @type("object")
  rts: Map<number, WorkerRtsOrder>;
  @type(PathogenTraits)
  traits: PathogenTraits;
  /**
   * The host's lockstep lead (0: running free), as its steps and restores carry it (module.ts). While
   * it is set, what one chunk tells the others goes out as a post (src/sim/posts.ts) and lands on
   * every worker at once, instead of applying where it was made.
   */
  @type("number")
  lead: number;
  /** The run's seed, as the hosts' config carries it (-1 until configured): what a chunk restored from bytes draws with (chunkSeed). */
  @type("number")
  seed: number;
  /** Tests only: a stream the chunks' infection draws come from instead of their keyed hash (chunkDraws); null in play. */
  @type("object")
  random: (() => number) | null;
  /** Tests only: the same for free walking's draws. */
  @type("object")
  walkRandom: (() => number) | null;
  /** The simulation lab's roster as the config carries it (null outside the lab: src/simlab/stage.ts). */
  @type("object")
  lab: LabWorker | null;
  /** The infection slot whoever catches it now carries (LabStrain): the strain's active infection entity's (0: the run's own). */
  @type("number")
  strain: number;
  @type("object")
  rideLookup: ((world: World, eid: number) => Ride | null) | null;
  @type("object")
  platformLookup: ((world: World, eid: number) => number | null) | null;
}
/** A fresh strain from the content's defaults; lookups unset (the load systems use the life ones). */
export const initializeWorkerInfection = (world: World, entity: number) => {
  Object.assign(world(WorkerInfection, entity), {
    rts: new Map(), traits: { ...CONTENT.disease.traits }, lead: 0, seed: -1, lab: null, strain: 0, random: null, walkRandom: null, rideLookup: null, platformLookup: null,
  });
};
