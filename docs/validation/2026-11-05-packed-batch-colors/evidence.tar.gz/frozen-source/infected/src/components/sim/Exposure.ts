import { Component, defaultValue, Schema, type } from "minecs";

/**
 * Viral load (see load.ts): how much an uninfected person has taken in, and the tick it was last
 * updated (so a chunk back from storage can drain what they cleared while it was away).
 */
@Component()
export class Exposure extends Schema {
  @type("float32") @defaultValue(0) load: number;
  @type("uint32") @defaultValue(0) at: number;
}
