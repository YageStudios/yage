import { Component, defaultValue, Schema, type } from "minecs";

/** 0 civilian, 1 soldier. */
@Component()
export class Role extends Schema {
  @type("uint8")
  @defaultValue(0)
  kind: number;
}
