import { Schema, type } from "minecs";

export class ScenePointerEvent extends Schema {
  @type("string") kind: "down" | "move" | "up" | "cancel" | "wheel" | "follow" | "leave";
  @type("number") clientX: number;
  @type("number") clientY: number;
  @type("number") delta: number;
}
