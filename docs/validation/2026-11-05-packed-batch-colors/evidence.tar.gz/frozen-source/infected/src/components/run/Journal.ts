import { Component, defaultValue, nullable, Schema, type } from "minecs";
import { Commands } from "yage/world/commands";
import type { Anchor } from "../../anchors/types";
import type { CastCommand } from "../cold/CastRecords";
import type { StageCommand } from "../cold/Directives";
import type { DirectCommand } from "../../domain/directive";
import type { OutbreakCommand } from "../outbreak/OutbreakCommands";
import type { PlayerIntent } from "../role/PlayerIntents";
import type { PossessionCommand } from "../role/PossessionCommands";
import type { PlayClockCommand } from "../scene/PlayClockState";
import type { WatchCommand } from "./HotWatch";
import type { LookCommand } from "./LookWatch";

/**
 * Something a player did that the run plays on (services/journal.ts): an outbreak command, a play
 * clock change, a possession change or an intent for a role, a view to simulate closely,
 * someone to follow by name, a goal for someone followed, content staged into the world, or a
 * solved scenario's anchors (placed in the pond as they come due: services/cold/pond.ts).
 */
export type JournalInput =
  | { kind: "outbreak"; command: OutbreakCommand }
  | { kind: "clock"; command: PlayClockCommand }
  | { kind: "possession"; role: string; command: PossessionCommand }
  | { kind: "intent"; role: string; intent: PlayerIntent }
  | ({ kind: "watch" } & WatchCommand)
  | ({ kind: "look" } & LookCommand)
  | ({ kind: "cast" } & CastCommand)
  | ({ kind: "direct" } & DirectCommand)
  | ({ kind: "stage" } & StageCommand)
  | { kind: "scenario"; anchors: Anchor[]; until: number };

/** The inputs one frame took: the step at `step`, or a frame between steps while the next was `next`. */
export type JournalEntry = { at: { step: number } | { next: number }; inputs: JournalInput[] };

/** The players' inputs, waiting for the frame that takes them (CommandJournalSystem). */
@Component()
export class JournalCommands extends Commands<JournalInput> {}

/** run:journal: every input the run took, in order, by the frame that took it. The run is its seed and these. */
@Component()
export class CommandJournal extends Schema {
  @type(["object"]) entries: JournalEntry[];
}

/**
 * A replay's feed (JournalReplaySystem): the journal it plays, and the index of its next entry; no
 * source, a live run. While `pending` (the journal still being read, or a keyframe loading: `seek`,
 * the load's id) the run holds its steps and is fed nothing. A replay takes no input of its own.
 */
@Component()
export class JournalReplay extends Schema {
  @nullable() @type(["object"]) source: JournalEntry[] | null;
  @type("number") @defaultValue(0) next: number;
  @type("boolean") @defaultValue(false) pending: boolean;
  @type("number") @defaultValue(-1) seek: number;
}
