import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
export class PrefabFloor extends Schema {
  @type("string") key: string;
  @type("number") users: number;
  @type("object") geometry: PIXI.Geometry;
  @type("object") shader: PIXI.Shader;
  @type("object") textures: PIXI.Texture[];
}
