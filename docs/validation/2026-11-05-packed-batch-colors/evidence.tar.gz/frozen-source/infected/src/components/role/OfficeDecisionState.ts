import { Component, Schema, type } from "minecs";

/** An office AI's own state (controller:governor-ai, controller:mayor-ai), written only by OfficeDecisionSystem: its source sequence and the epoch it last drove under. */
@Component()
export class OfficeDecisionState extends Schema {
  @type("number") sequence: number;
  @type("number") epoch: number;
}
