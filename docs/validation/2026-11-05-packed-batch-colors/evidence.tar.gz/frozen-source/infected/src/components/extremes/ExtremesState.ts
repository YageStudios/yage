import { Component, Schema, type } from "minecs";
import { FigurePose } from "../figures/FigurePose";
import { FireSpot } from "../fire/FireSpot";

/** This frame's extreme-weather decisions (queues, braziers) and counts, and the veil's repaint time. */
@Component()
export class ExtremesState extends Schema {
  @type([FigurePose]) figures: FigurePose[] = [];
  @type([FireSpot]) fires: FireSpot[] = [];
  /** Flooded chunks shown, closed low points, open centres in view, lightning flash, sunk cars. */
  @type("number") flooded = 0;
  @type("number") barriers = 0;
  @type("number") queues = 0;
  @type("number") flash = 0;
  @type("number") sunk = 0;
  /** Whether the blowing-snow veil has been painted yet, and when it was last repainted (ms, view clock). */
  @type("boolean") veiled = false;
  @type("number") veilAt = 0;
}
