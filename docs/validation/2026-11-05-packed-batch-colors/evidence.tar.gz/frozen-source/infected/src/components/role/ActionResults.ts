import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/** A command's outcome: accepted (routed), applied (its owner did it) or rejected, with why. */
export type RoleResult = {
  command: string;
  controller: string;
  action: string;
  status: "accepted" | "applied" | "rejected";
  reason: string;
};

/** Outcomes from the router, PossessionSystem and the domain owners; RoleResultSystem drains them into the log. */
@Component()
export class ActionResults extends Commands<RoleResult> {}
