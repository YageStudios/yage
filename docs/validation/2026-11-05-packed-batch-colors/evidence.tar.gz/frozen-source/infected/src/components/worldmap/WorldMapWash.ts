import { Component, Schema, defaultValue, type } from "minecs";

/** Which weather wash is painted on WorldMapResources.wash: the game time and weather space it shows (repainted when the space changes or 4 s pass). */
@Component()
export class WorldMapWash extends Schema {
  @type("boolean") @defaultValue(false) painted: boolean;
  @type("number") @defaultValue(0) at: number;
  @type("number") @defaultValue(-1) space: number;
}
