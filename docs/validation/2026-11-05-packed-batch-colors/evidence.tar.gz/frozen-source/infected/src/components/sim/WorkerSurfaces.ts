import { Component, Schema, type, type World } from "minecs";
import type { Touch } from "../../services/load/surfaces";
import type { Anchors } from "../../services/surfaces";
@Component()
export class WorkerSurfaces extends Schema {
  @type("object")
  anchors: Map<string, Anchors>;
  @type("object")
  doorways: Map<string, Uint8Array>;
  @type("object")
  touches: WeakMap<Uint8Array, Touch>;
  @type("object")
  chunks: WeakMap<Uint8Array, {
    cx: number;
    cy: number;
  }>;
}
export const initializeWorkerSurfaces = (world: World, entity: number) => {
  const fields = world(WorkerSurfaces).store;
  fields.anchors[entity] = new Map();
  fields.doorways[entity] = new Map();
  fields.touches[entity] = new WeakMap();
  fields.chunks[entity] = new WeakMap();
};
