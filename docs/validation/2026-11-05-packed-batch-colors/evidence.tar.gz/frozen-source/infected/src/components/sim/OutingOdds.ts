import { Schema, type } from "minecs";
export class OutingOdds extends Schema {
  @type("number")
  go: number;
  @type("number")
  indoor: number;
  @type("number")
  shut: number;
}
