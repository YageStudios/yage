/** Camera and deterministic display options of one art screenshot scene. */
import { Component, Schema, defaultValue, type } from "minecs";

@Component()
export class ArtPreviewState extends Schema {
  @type("number") @defaultValue(0) x: number;
  @type("number") @defaultValue(0) y: number;
  @type("number") @defaultValue(2) zoom: number;
  @type("number") @defaultValue(12) hour: number;
  @type("number") @defaultValue(0) snow: number;
  @type("boolean") @defaultValue(false) people: boolean;
  @type("number") @defaultValue(0) frames: number;
  @type("boolean") @defaultValue(false) ready: boolean;
}
