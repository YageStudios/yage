import { Component, nullable, Schema, type } from "minecs";
import { HostLocation } from "./HostLocation";
import { HostPoint } from "./HostPoint";

@Component()
export class ControlledHost extends Schema {
  @type("number")
  gid: number;
  @type("number")
  state: number;
  @type("number")
  lifeLeft: number;
  @type("number")
  lifeAt: number;
  @type("number")
  warned: number;
  @type("number")
  slot: number;
  @type("number")
  lastSeek: number;
  @type(["number"])
  visited: number[];
  @nullable()
  @type(HostLocation)
  located: HostLocation | null;
  @nullable()
  @type(HostPoint)
  drawn: HostPoint | null;
  /** Where its stream slot last put it (drawn, less what the page leads it by): held while it is between chunks. */
  @nullable()
  @type(HostPoint)
  streamed: HostPoint | null;
}
