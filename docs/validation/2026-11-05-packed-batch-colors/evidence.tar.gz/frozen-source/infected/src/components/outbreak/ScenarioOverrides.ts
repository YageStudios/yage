import { Component, defaultValue, Schema, type } from "minecs";

/** Development overrides for this run (world:outbreak): `ladder` pins the response ladder (ResponseDebugPins; the page's `?ladder=`), -1 when unset. */
@Component()
export class ScenarioOverrides extends Schema {
  @type("number") @defaultValue(-1) ladder: number;
}
