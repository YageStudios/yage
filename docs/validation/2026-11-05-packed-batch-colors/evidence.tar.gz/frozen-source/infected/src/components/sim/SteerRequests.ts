import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/** The steered host's input: two bytes, steering direction + 1 on each axis. */
export type SteerRequest = { eid: number; bytes: Uint8Array };

/** Steering for this step, in arrival order (module input pushes, HostSteerSystem drains). */
@Component()
export class SteerRequests extends Commands<SteerRequest> {}
