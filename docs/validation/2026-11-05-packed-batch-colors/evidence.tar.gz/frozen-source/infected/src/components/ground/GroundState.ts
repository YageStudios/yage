import { Component, defaultValue, Schema, type } from "minecs";

/** Ground lifecycle values are owned by the render entity, independently of GPU handles. */
@Component()
export class GroundState extends Schema {
  @type(["number"]) announced: number[];
  @type(["number"]) queued: number[];
  @type("number") @defaultValue(0) snowStep: number;
  @type("boolean") @defaultValue(false) budgeted: boolean;
  @type("number") @defaultValue(0) paintBudget: number;
  @type("number") @defaultValue(1) zoom: number;
  @type("number") @defaultValue(0) focusX: number;
  @type("number") @defaultValue(0) focusY: number;
  /** Half the watched view's extent about the focus (world px; 0: none watched): GroundPaint paints its chunks from the plan before they are hot. */
  @type("number") @defaultValue(0) reachX: number;
  @type("number") @defaultValue(0) reachY: number;
  /** Where the host stands (world px): the building under them goes clear, those in front see-through. */
  @type(["number"]) insideX: number[];
  @type(["number"]) insideY: number[];
  /** Round the host and where they are walking to shortly: what stands in front there goes see-through ahead of them. */
  @type(["number"]) @defaultValue([]) aheadX: number[];
  @type(["number"]) @defaultValue([]) aheadY: number[];
  /** The host's drawn spot last frame and their smoothed walk (world px/s), for `ahead`. */
  @type("boolean") @defaultValue(false) hostSeen: boolean;
  @type("number") @defaultValue(0) hostX: number;
  @type("number") @defaultValue(0) hostY: number;
  @type("number") @defaultValue(0) hostVX: number;
  @type("number") @defaultValue(0) hostVY: number;
}
