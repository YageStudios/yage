import { Component, Schema, type } from "minecs";
import type { PawnSource } from "../../domain/pawns";

@Component()
export class LoadPass extends Schema {
  @type("number") ease: number;
  @type("number") far: number;
  @type("number") viewRadius: number;
  @type(["object"]) sources: PawnSource[];
}
