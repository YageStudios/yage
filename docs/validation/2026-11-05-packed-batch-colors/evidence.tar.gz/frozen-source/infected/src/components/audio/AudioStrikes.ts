import { Component, Schema, type } from "minecs";
import { AudioStrike } from "./AudioStrike";

/** Storm cells already heard, oldest first (at most 64). */
@Component()
export class AudioStrikes extends Schema {
  @type([AudioStrike]) heard: AudioStrike[];
}
