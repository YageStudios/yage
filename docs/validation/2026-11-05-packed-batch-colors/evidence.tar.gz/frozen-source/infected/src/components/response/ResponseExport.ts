import { Component, Schema, nullable, type } from "minecs";
import type { BordersState } from "./BordersState";
import type { ExtremeMemory } from "./ExtremeMemory";
import type { ResponseState } from "./ResponseState";
import type { TownResponseState } from "./TownResponseState";

/**
 * The region's response as the HUD, the views and the hosts' configure read it: a copy assembled
 * from the town entities and the region's research and memory (services/response-export.ts), in
 * place order. Derived, never a second truth: a reader that changes it changes nothing.
 */
export type ResponseView = Readonly<{
  towns: readonly TownResponseState[];
  /** The series the hosts hear of (the worker wire format: encodeConfig). */
  shared: ResponseState;
  links: readonly (readonly number[])[];
  cure: number;
  reshuffles: number;
  tick: number;
  borders: BordersState | null;
  extremes: ExtremeMemory;
}>;

/** world:response-export: the region's latest response export. */
@Component()
export class ResponseExport extends Schema {
  @nullable() @type("object") response: ResponseView | null;
}
