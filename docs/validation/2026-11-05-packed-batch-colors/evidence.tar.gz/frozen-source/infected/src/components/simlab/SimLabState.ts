/**
 * The simulation lab on the page (`?lab&field=<n>`, src/simlab): the setup being built (groups,
 * buildings, the infection going round), where each group's people stand and their gids, what is
 * waiting to go to the chunks, the chunks' latest reports, the round under way and its results.
 * SimLabDriver owns it; the lab panel (src/ui/simlab.ts), the field's overlay and `__lab` send
 * commands on its bus.
 */
import { Component, Schema, defaultValue, nullable, type } from "minecs";
import type { LabGroupReport, LabOutcome, LabReport, LabRoster, LabSpec, StrainCount } from "../../simlab/protocol";
import type { SimLabBus } from "../../ui/simlab";

export type SimLabPhase = "running" | "between" | "done";

/** A finished round: how long it ran (game seconds), how it ended, and its groups as they ended. */
export type SimLabResult = { round: number; seconds: number; outcome: LabOutcome; groups: LabGroupReport[]; shots: number; hits: number; kills: number };

/** A group as put out: its roster number and its people (gid, world x, y). */
export type SimLabPlaced = { n: number; people: [number, number, number][] };

@Component()
export class SimLabState extends Schema {
  @nullable() @type("object") spec: LabSpec | null;
  /** Each group's people as last put out, by group id. */
  @type("object") placed: Record<string, SimLabPlaced>;
  /** Groups to put out again (new, moved, changed) on the next frame. */
  @nullable() @type("object") dirty: Set<string>;
  /** The next roster group number. */
  @type("number") @defaultValue(0) nextGroup: number;
  /** Gids given so far, per chunk key (the next is gidFor(chunk, this)). */
  @nullable() @type("object") counters: Map<number, number>;
  /** The roster the workers were last configured with. */
  @nullable() @type("object") roster: LabRoster | null;
  /** Spawn commands waiting for their chunk (sent once the roster naming them has gone out, retried until the chunk takes them). */
  @type(["object"]) outbox: { cx: number; cy: number; bytes: Uint8Array; after: number }[];
  /** Infection slots by id (1 up), as their entities were spawned. */
  @nullable() @type("object") slots: Map<string, number>;
  @type("string") @defaultValue("running") phase: SimLabPhase;
  /** The round under way (rises for ever: a chunk's old report is never taken for a new round's). */
  @type("number") @defaultValue(1) round: number;
  /** Rounds run since the setup was loaded. */
  @type("number") @defaultValue(1) run: number;
  /** Each chunk's latest report and the tick it came on. */
  @nullable() @type("object") reports: Map<number, { tick: number; report: LabReport }>;
  /** The newest tick any report came on; the tick the round's first came on; the tick the pause between rounds ends. */
  @type("number") @defaultValue(-1) tick: number;
  @type("number") @defaultValue(-1) since: number;
  @type("number") @defaultValue(-1) until: number;
  /** The field's tallies, added up from the reports: per group, per infection slot, and the shots. */
  @type(["object"]) groups: LabGroupReport[];
  @type("object") strains: Record<number, StrainCount>;
  @type("object") shots: { shots: number; hits: number; kills: number };
  @type(["object"]) results: SimLabResult[];
  @type(["string"]) log: string[];
  /** The group or building picked in the panel ("" none). */
  @type("string") @defaultValue("") selected: string;
  /** The panel's model and the commands it, the overlay and `__lab` send (src/ui/simlab.ts). */
  @nullable() @type("object") bus: SimLabBus;
}
