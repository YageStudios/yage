import { Component, Schema, type } from "minecs";
import type { District } from "../../atlas/model";
import type { Layout, Settlement } from "../../worldgen/terrain/models";
@Component()
export class TerrainProjections extends Schema {
  @type("object")
  layouts: Map<string, Layout>;
  @type("object")
  settlements: Map<string, Settlement>;
  @type("object")
  districts: Map<string, (x: number, y: number) => District | null>;
  @type("object")
  placeIds: WeakMap<Layout, Map<string, number>>;
}
