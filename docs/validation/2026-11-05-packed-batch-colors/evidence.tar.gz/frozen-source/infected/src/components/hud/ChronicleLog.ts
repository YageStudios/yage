import { Component, Schema, defaultValue, type } from "minecs";
import type { Log, LogCursor } from "../../domain/chronicle";

/**
 * The event log: its entries, how far the scan has read the series, and the latest tick and place
 * names seen, which stamp and place the toasts that go in between scans.
 */
@Component()
export class ChronicleLog extends Schema {
  @type("object") log: Log;
  @type("object") cursor: LogCursor;
  @type("number") @defaultValue(0) tick: number;
  @type(["string"]) @defaultValue([]) names: string[];
}
