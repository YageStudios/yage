import { Component, Schema, type } from "minecs";
import { NATURE_CHUNK_CELLS } from "../../domain/nature";

/** One chunk's nature cells (nature:chunk): how degraded each is (0 untouched … 255 burnt out), row by row (domain/nature.ts). */
@Component()
export class NatureChunk extends Schema {
  @type("int32") cx: number;
  @type("int32") cy: number;
  @type(["uint8", NATURE_CHUNK_CELLS]) cells: Uint8Array;
}
