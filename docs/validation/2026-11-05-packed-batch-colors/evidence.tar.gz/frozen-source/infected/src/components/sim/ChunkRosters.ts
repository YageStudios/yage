import { Component, Schema, defaultValue, type } from "minecs";

/**
 * Who is shown inside which building this step (RosterSystem). Everyone else indoors is on their
 * building's roster: in stasis at its door, out of view (life.floor 1), no interior, no spots, no
 * pathing, their load the building's (RosterLoadSystem). A building is unpacked (its people placed in
 * its real interior) only in a hot chunk, and only while it is open: an open place (a park, a square),
 * or a building someone free walks in or the player's host stands at. Transient: rebuilt each step.
 */
@Component()
export class ChunkRosters extends Schema {
  /** Unpacked places this step, by rosterKey (the frame chunk and its eight neighbours). */
  @type("object") open: Set<number>;
  /** Last step's, to find the places that opened or closed. */
  @type("object") was: Set<number>;
  @type("boolean") @defaultValue(false) hot: boolean;
  /** Whether a step has set this (a fresh or restored world packs everyone on its first). */
  @type("boolean") @defaultValue(false) stepped: boolean;
  /**
   * Every place looked into, hot or warm: everyone indoors walked round the real interior, as before
   * rosters. For tools and tests that watch interiors (showInteriors); the game never sets it.
   */
  @type("boolean") @defaultValue(false) all: boolean;
  /** Last step's all, to unpack or pack everyone when it changes. */
  @type("boolean") @defaultValue(false) shown: boolean;
  /**
   * Whether the page has said what the player sees into (a LOOK command, domain/look.ts). Until it
   * has (headless runs, tests, the first moments of a chunk), the host's surroundings stand in.
   */
  @type("boolean") @defaultValue(false) looking: boolean;
  /** The page's see-into points (world px, x then y): a building with one on it is unpacked. */
  @type("object") looked: number[];
  /** The view's centre and half extents (world px), from the same command: building events surface inside it. */
  @type("number") @defaultValue(0) viewX: number;
  @type("number") @defaultValue(0) viewY: number;
  @type("number") @defaultValue(0) viewRX: number;
  @type("number") @defaultValue(0) viewRY: number;
  /** Building events for the next overlay (BuildingEventsSystem → LoadOverlaySystem): kind, x, y, arg each (domain/building-events.ts). */
  @type("object") events: number[];
  /** Last step's rostered people near the view: eid → their roster group and state (BuildingEventsSystem, to tell who died, caught it or left). */
  @type("object") seen: Map<number, number>;
  @type("number") @defaultValue(0) cx: number;
  @type("number") @defaultValue(0) cy: number;
}
