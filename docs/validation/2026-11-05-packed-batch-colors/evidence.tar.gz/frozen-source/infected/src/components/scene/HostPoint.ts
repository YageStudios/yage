import { Schema, type } from "minecs";

export class HostPoint extends Schema {
  @type("number")
  x: number;
  @type("number")
  y: number;
}
