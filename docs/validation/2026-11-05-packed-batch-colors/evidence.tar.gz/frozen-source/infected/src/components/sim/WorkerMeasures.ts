import { Component, Schema, type } from "minecs";
import type { World } from "minecs";
import { ResponseState } from "../response/ResponseState";
import type { WorldMap } from "../../worldmap/places";
import type { WorkerDirective } from "../../domain/directive";

/** The append-only response configuration a planning context received, plus its world map (built on first lookup) and the directives the config carries. */
@Component()
export class WorkerMeasures extends Schema {
  @type(ResponseState) state: ResponseState;
  @type("object") map: WorldMap | null;
  /** The cast's directives as the config last had them (domain/directive.ts), by gid. */
  @type("object") directives: Map<number, WorkerDirective>;
}

export const initializeWorkerMeasures = (world: World, entity: number) => {
  Object.assign(world(WorkerMeasures, entity), { state: { towns: [] }, map: null, directives: new Map() });
};
