import { Schema, type } from "minecs";

export class ResponseNotice extends Schema {
  @type("string") text: string;
  @type("string") kind: "good" | "bad";
  @type("number") town?: number;
}
