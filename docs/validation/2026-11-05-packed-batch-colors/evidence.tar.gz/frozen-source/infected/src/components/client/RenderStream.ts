import { Component, defaultValue, Schema, type } from "minecs";
import type { ChunkStreamer } from "yage/streaming";

/**
 * The streamer that keeps this client's view chunks hot over the run's transport (client:stream, once
 * the page has made it), and the view this client last asked the run to simulate closely: its ring
 * of chunks around the view, and what it sent (ChunkStreaming).
 */
@Component()
export class RenderStream extends Schema {
  @type("object") streamer: ChunkStreamer;
  @type("number") @defaultValue(1) ring: number;
  @type("string") @defaultValue("") sent: string;
}
