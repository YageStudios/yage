import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import type { TownSites } from "../../render/care/sites";
import type { FieldSite } from "../../render/field/site";
@Component()
export class CareResources extends Schema {
  @type("object")
  ground: PIXI.Graphics;
  @type("object")
  over: PIXI.Graphics;
  @type("object")
  sites: Map<number, TownSites>;
  @type("object")
  fields: Map<string, FieldSite | null>;
}
