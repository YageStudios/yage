import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/**
 * Asks TraitConfig to recompute the strain's traits from the evolution and configure the hosts
 * with them (and the response's measures); `track` then hands the pool the hosts to follow once
 * they run with the traits (the game's first host).
 */
export interface TraitRequest {
  track?: number[];
}

@Component()
export class TraitRequests extends Commands<TraitRequest> {}
