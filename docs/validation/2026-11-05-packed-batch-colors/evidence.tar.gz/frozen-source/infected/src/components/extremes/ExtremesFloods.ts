import { Component, Schema, type } from "minecs";

/** Flood chunk records (ExtremesFloodChunk entities) by "cx,cy", oldest first (evicted past FLOOD_CHUNKS). Their sprites are ExtremesResources'. */
@Component()
export class ExtremesFloods extends Schema {
  @type("object") chunks: Map<string, number>;
}
