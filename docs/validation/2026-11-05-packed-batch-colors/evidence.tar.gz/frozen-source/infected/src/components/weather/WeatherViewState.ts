import { Component, Schema, defaultValue, type } from "minecs";

@Component()
export class WeatherViewState extends Schema {
  @type("number") @defaultValue(0) seconds: number;
  @type("number") @defaultValue(0) dt: number;
  @type("number") @defaultValue(0) x: number;
  @type("number") @defaultValue(0) y: number;
  @type("number") @defaultValue(1) zoom: number;
  @type("number") @defaultValue(1) w: number;
  @type("number") @defaultValue(1) h: number;
  @type("number") @defaultValue(0) blend: number;
}
