import { Component, defaultValue, Schema, type } from "minecs";

/** When the region last ran a pass (region:response), wall time; RegionCadenceSystem runs one four times a second. */
@Component()
export class RegionCadence extends Schema {
  @type("number") @defaultValue(0) lastAt: number;
}
