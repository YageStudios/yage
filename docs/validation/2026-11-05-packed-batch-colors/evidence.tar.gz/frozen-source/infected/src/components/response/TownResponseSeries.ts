import { Schema } from "minecs";
import { numberLists } from "./series";
export class TownResponseSeries extends Schema {
  [key: string]: [number, number][] | undefined;
  @numberLists(true) events: [number, number][];
  @numberLists(true) aware: [number, number][];
  @numberLists(true) hospital: [number, number][];
  @numberLists(true) staff?: [number, number][];
  @numberLists(true) tents?: [number, number][];
  @numberLists(true) vax?: [number, number][];
  @numberLists(true) buried?: [number, number][];
  @numberLists(true) fauna?: [number, number][];
  @numberLists(true) water?: [number, number][];
  @numberLists(true) unrest?: [number, number][];
  @numberLists(true) order?: [number, number][];
  @numberLists(true) fallen?: [number, number][];
  @numberLists(true) border?: [number, number][];
  @numberLists(true) evac?: [number, number][];
  @numberLists(true) cordon?: [number, number][];
  @numberLists(true) burn?: [number, number][];
}
