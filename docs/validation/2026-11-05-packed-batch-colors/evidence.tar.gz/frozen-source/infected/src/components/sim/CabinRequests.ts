import { Component } from "minecs";
import { Commands } from "yage/world/commands";
import type { Traits } from "../../domain/disease";

/**
 * What the outside asks of planning:cabins, in arrival order (CabinPoolsSystem drains it at the
 * top of the planning stack): another worker's pool events, with the strain the pools faded by
 * when they arrived; sharing turned on or off; or forgetting every pool (tests, a new game).
 */
export type CabinRequest =
  | { kind: "events"; bytes: Uint8Array; sheltered: Traits | null }
  | { kind: "share"; on: boolean }
  | { kind: "reset" };

@Component()
export class CabinRequests extends Commands<CabinRequest> {}
