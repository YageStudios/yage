import { Component, Schema, defaultValue, type } from "minecs";

/** This frame's world → screen mapping for the strategic map: camera centre (world px), zoom and screen size (worldmap/draw/transform MapTransform). */
@Component()
export class WorldMapTransform extends Schema {
  @type("number") @defaultValue(0) x: number;
  @type("number") @defaultValue(0) y: number;
  @type("number") @defaultValue(1) scale: number;
  @type("number") @defaultValue(1) width: number;
  @type("number") @defaultValue(1) height: number;
}
