import { Component, Schema, type } from "minecs";

/** What a travel row asks of the systems after the schedule's triage. */
export const enum TravelRow {
  /** Nothing more this step (gone free, or sitting out a dwell). */
  None = 0,
  /** A bloomed host on its schedule: RageTargetSystem decides whether it breaks off. */
  Rage = 1,
  /** The leg ended: LegTransitionSystem plays the events due, then TransitMotionSystem places them. */
  Due = 2,
  /** Under way: TransitMotionSystem places them along the leg. */
  Moving = 3,
  /** A free walker who got there: RejoinSystem takes them back to their day. */
  Rejoin = 4,
}

/**
 * This step's travel rows on the chunk's context entity: the schedule's people in the world's order
 * (ScheduleSystem's triage), the free walkers held up by a wall or water (FreeWalkSystem, for
 * SidestepSystem), and the free walkers who arrived (FreeWalkSystem), each with what it
 * still needs (TravelRow). The systems after them walk the rows in order, so every person is moved,
 * turned and rejoined as when the schedule did it all person by person. Cleared by the triage.
 */
@Component()
export class TravelRows extends Schema {
  @type("object") eid: number[];
  @type("object") kind: TravelRow[];
  @type("object") held: number[];
  @type("object") arrived: number[];
  @type("object") arrivedKind: TravelRow[];
}

/** Empty rows (the chunk context's init, and each step's triage). */
export const clearTravelRows = (rows: TravelRows) => {
  rows.eid = [];
  rows.kind = [];
  rows.held = [];
  rows.arrived = [];
  rows.arrivedKind = [];
};
