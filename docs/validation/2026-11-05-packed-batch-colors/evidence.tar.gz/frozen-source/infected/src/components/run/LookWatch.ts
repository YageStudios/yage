import { Component, defaultValue, nullable, Schema, type } from "minecs";
import { Commands } from "yage/world/commands";
import type { Look } from "../../domain/look";

/** A viewer's see-into set as it tells the run (domain/look.ts), or null when it goes. */
export type LookCommand = { viewer: string; look: Look | null };

/** What the run's viewers see into (each client's LookSync, through the journal); LookWatchSystem drains them on its steps. */
@Component()
export class LookCommands extends Commands<LookCommand> {}

/**
 * What the run's hot chunks are told the players see into (run:hot, LookWatchSystem): every viewer's
 * last look, the one they make together (sent as LOOK bytes), and the hot chunks that have it, each
 * with the pool's state for it when told (a chunk's context is transient: one that moved host, was
 * made again or came back from a load has forgotten). Runtime only: a load tells every hot chunk
 * again (`loaded`, the checkpoint load it last saw).
 */
@Component()
export class LookWatch extends Schema {
  @type("object") views: Map<string, Look>;
  @type("object") told: Map<number, { state: object; host: number }>;
  @nullable() @type("object") merged: Look | null;
  @type("number") @defaultValue(-1) loaded: number;
}
