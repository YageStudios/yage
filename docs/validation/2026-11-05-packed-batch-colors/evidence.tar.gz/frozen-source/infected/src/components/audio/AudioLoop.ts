import { Schema, type } from "minecs";

/** A loop the audio keeps running while it is wanted: its preset, eased level and parameters. */
export class AudioLoop extends Schema {
  @type("string") id: string;
  /** Last faded-to level; -1 before the first fade of a (re)started voice. */
  @type("number") level: number;
  /** Last quantised parameters sent to the voice. */
  @type("object") params: Record<string, number>;
  /** performance.now() when it went quiet; 0 while it is wanted. */
  @type("number") quietSince: number;
}
