import { Component, nullable, Schema, type } from "minecs";
import { FigurePose } from "../figures/FigurePose";
import { FireSpot } from "../fire/FireSpot";
import { HostPoint } from "../scene/HostPoint";
import { ResponseSign } from "./ResponseSign";
@Component()
export class ResponseViewState extends Schema {
  @type([FigurePose]) figures: FigurePose[] = [];
  @type([FireSpot]) braziers: FireSpot[] = [];
  @type([ResponseSign]) signs: ResponseSign[] = [];
  @type("boolean") rideEnabled = false;
  @nullable() @type(HostPoint) ride: HostPoint | null = null;
}
