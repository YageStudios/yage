import { Component } from "minecs";
import { Commands } from "yage/world/commands";
import type { PrefabRequest } from "./PrefabRequest";

/** Lazy prefab tops; only PrefabRoofs drains this queue. */
@Component()
export class PrefabRoofRequests extends Commands<PrefabRequest> {}
