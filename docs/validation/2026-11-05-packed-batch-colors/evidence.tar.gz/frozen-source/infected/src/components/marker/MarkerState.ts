import { Component, Schema, defaultValue, type } from "minecs";
@Component()
export class MarkerState extends Schema {
  @type("number") @defaultValue(0) x: number;
  @type("boolean") @defaultValue(false) visible: boolean;
  @type("number") @defaultValue(0) y: number;
  @type("number") @defaultValue(1) zoom: number;
  @type("number") @defaultValue(0) dt: number;
  @type("number") @defaultValue(0) phase: number;
  @type("boolean") @defaultValue(false) dying: boolean;
}
