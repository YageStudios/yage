/**
 * One scene's continuous play clock; simulation speed changes preserve elapsed game time. Game time
 * is `speed` × wall time, standing still while paused. PlayClock owns the state and changes it
 * from PlayClockCommands; everyone else reads it with the functions below.
 */
import { Component, Schema, defaultValue, type } from "minecs";
import { Commands } from "yage/world/commands";

/** The speeds the HUD offers, slowest first. */
export const SPEEDS = [1, 2, 4] as const;

@Component()
export class PlayClockState extends Schema {
  @type("number") @defaultValue(0) baseMs: number;
  @type("number") @defaultValue(0) changedAt: number;
  @type("number") @defaultValue(1) speed: number;
  @type("boolean") @defaultValue(false) paused: boolean;
}

export type PlayClockRead = Pick<PlayClockState, "baseMs" | "changedAt" | "speed" | "paused">;

/** The clock rate the hosts run at (0 while paused). */
export const playRate = (state: PlayClockRead) => (state.paused ? 0 : state.speed);

/** Game ms at wall time `wall` (performance.now()). */
export const playMs = (state: PlayClockRead, wall: number) => state.baseMs + (wall - state.changedAt) * playRate(state);

/** Game seconds at wall time `wall`. */
export const playSeconds = (state: PlayClockRead, wall: number) => playMs(state, wall) / 1000;

/** One step along SPEEDS from `speed` (−1 slower, +1 faster). */
export const steppedSpeed = (speed: number, by: number) => {
  const i = SPEEDS.indexOf(speed as (typeof SPEEDS)[number]);
  return SPEEDS[Math.max(0, Math.min(SPEEDS.length - 1, (i < 0 ? 0 : i) + by))];
};

/** A change to the play clock; `wall` (performance.now()) defaults to when PlayClock applies it. */
export type PlayClockCommand =
  | { kind: "speed"; speed: number; wall?: number }
  | { kind: "pause"; paused: boolean; wall?: number }
  | { kind: "toggle"; wall?: number }
  | { kind: "step"; by: number; wall?: number };

/** The scene's play clock requests (HUD speed controls), drained by PlayClock. */
@Component()
export class PlayClockCommands extends Commands<PlayClockCommand> {}
