import type { Schema } from "minecs";
import { type } from "minecs";

/** Variable numeric lists, preserving the append-only worker wire format. */
export const numberLists =
  (pair = false, depth = 2) =>
  (target: Schema, key: string) => {
    type(["object"])(target, key);
    const schema = (target.constructor as typeof Schema).schema.properties[key];
    let items: Record<string, unknown> = {
      type: "array",
      items: { type: "number" },
      ...(pair ? { minItems: 2, maxItems: 2 } : {}),
    };
    for (let level = 2; level < depth; level++)
      items = { type: "array", items };
    schema.items = items;
  };
