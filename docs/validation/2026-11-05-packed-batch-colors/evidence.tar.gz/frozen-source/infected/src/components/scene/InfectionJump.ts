import { Schema, type } from "minecs";

export class InfectionJump extends Schema {
  @type("number") from: number;
  @type("number") to: number;
  @type("number") at: number;
}
