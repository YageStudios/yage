import { Component, defaultValue, Schema, type } from "minecs";

/** The transport's startup and byte counters (run:transport), written by PoolIngress. */
@Component()
export class StreamMetrics extends Schema {
  @type("number") @defaultValue(0) startedAt: number;
  @type("number") @defaultValue(0) readyAt: number;
  /** Region chunks ready. */
  @type("number") @defaultValue(0) ready: number;
  /** Snapshot message bytes as received (their byteLength) since the readout last took them, and per second. */
  @type("number") @defaultValue(0) snapshotBytes: number;
  @type("number") @defaultValue(0) snapshotRate: number;
  /** Overlay message bytes (events, tile changes) likewise, apart from snapshots. */
  @type("number") @defaultValue(0) overlayBytes: number;
  @type("number") @defaultValue(0) overlayRate: number;
}
