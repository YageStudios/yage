import { Schema, type } from "minecs";

export type Source = "fire" | "siren" | "gunfire" | "crowd" | "riot";

export class SoundSource extends Schema {
  @type("string") kind: Source;
  @type("number") x: number;
  @type("number") y: number;
  @type("number") level: number;
}
