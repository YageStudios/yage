/** The region's response pass: its bookkeeping and its ordered announcements. The response itself
 * is its towns' (region:town), its research (ResearchState) and its memory (RegionMemory).
 * Response systems run after RegionScheduleSystem marks a pass due, in the declared phase order.
 */
import { Component, Schema, defaultValue, type } from "minecs";
import { ResponseNotice } from "./ResponseNotice";
export { CollapseNews } from "./CollapseNews";

@Component()
export class RegionResponse extends Schema {
  @type([ResponseNotice]) notices: ResponseNotice[];

  /** A pass is due this frame (the four-times-a-second UI beat), at this tick. */
  @type("boolean")
  @defaultValue(false)
  due: boolean;
  @type("number")
  @defaultValue(0)
  tick: number;
  /** The response steps in this pass (the outbreak is seeded and the game not over); the drift steps whenever a pass is due. */
  @type("boolean")
  @defaultValue(false)
  respond: boolean;

  /** This pass: the response tick it started from and whether a shared series grew (each town keeps its own level and hospital before it: TownResponse). */
  @type("number")
  @defaultValue(0)
  before: number;
  @type("boolean")
  @defaultValue(false)
  grew: boolean;

  /** A series grew since the hosts were last configured: they hear of it once five seconds have passed. */
  @type("boolean")
  @defaultValue(false)
  pending: boolean;
}
