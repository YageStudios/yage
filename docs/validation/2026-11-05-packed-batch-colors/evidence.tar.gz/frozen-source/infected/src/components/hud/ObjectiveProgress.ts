import { Component, Schema, type } from "minecs";
import type { ObjectiveMemory } from "../../domain/objectives";

/** The objectives met so far and the lines they started counting from (LeftColumnPanels steps it). */
@Component()
export class ObjectiveProgress extends Schema {
  @type("object") memory: ObjectiveMemory;
}
