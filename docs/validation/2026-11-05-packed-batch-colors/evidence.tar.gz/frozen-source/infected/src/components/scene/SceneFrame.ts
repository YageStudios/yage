import { Component, Schema, defaultValue, type } from "minecs";
import { SceneLight } from "./SceneLight";
import { ViewBounds } from "./ViewBounds";

/** This frame's shared render values; its chunk scene and ground are ChunkSceneResources, its pool AuthorityTransport and its streamer RenderStream. */
@Component()
export class SceneFrame extends Schema {
  @type(SceneLight) light: SceneLight;
  @type(ViewBounds) bounds: ViewBounds;
  /** How far ahead (world px) the moving camera will be in a moment, and where it was last frame (lastZoom 0: nowhere yet). */
  @type("number") @defaultValue(0) leadX: number;
  @type("number") @defaultValue(0) leadY: number;
  @type("number") @defaultValue(0) lastX: number;
  @type("number") @defaultValue(0) lastY: number;
  @type("number") @defaultValue(0) lastZoom: number;
}
