import { Component, defaultValue, Schema, type } from "minecs";

/**
 * The outbreak's lifecycle (world:outbreak): begun (OfferResolve, on the begin command) with its first
 * host, and seeded once anyone has caught it (OutbreakLifecycleSystem), at that tick.
 */
@Component()
export class OutbreakState extends Schema {
  @type("boolean") @defaultValue(false) started: boolean;
  @type("boolean") @defaultValue(false) seeded: boolean;
  @type("number") @defaultValue(-1) startGid: number;
  @type("number") @defaultValue(-1) seededTick: number;
}
