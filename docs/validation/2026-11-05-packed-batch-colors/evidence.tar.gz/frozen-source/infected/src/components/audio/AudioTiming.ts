import { Component, Schema, defaultValue, type } from "minecs";

/** When the next crowd grumble and police siren may sound (performance.now() ms). */
@Component()
export class AudioTiming extends Schema {
  @type("number") @defaultValue(0) nextGrumble: number;
  @type("number") @defaultValue(0) nextPolice: number;
}
