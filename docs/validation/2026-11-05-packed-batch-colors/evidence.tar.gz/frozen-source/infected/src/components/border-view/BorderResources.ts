import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
@Component()
export class BorderResources extends Schema {
  @type("object")
  ground: PIXI.Graphics;
  @type("object")
  over: PIXI.Graphics;
  @type("object")
  flames: PIXI.Graphics;
  @type("object")
  glow: PIXI.Graphics;
}
