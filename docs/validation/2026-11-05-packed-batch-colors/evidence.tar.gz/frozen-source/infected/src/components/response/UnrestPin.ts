import { Schema, nullable, type } from "minecs";

export class UnrestPin extends Schema {
  @type("boolean") pinned: boolean;
  @type("number") unrest: number;
  @nullable() @type("number") order: number | null;
}
