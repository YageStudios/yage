import { Component, defaultValue, Schema, type } from "minecs";

/**
 * An infection as an entity object (src/entities/infections.json5, or one the lab saved): its
 * pathogen, the cards it has picked up and the traits it sets outright over them. Its slot is what
 * its children carry (LabStrain): given when it is spawned, 1 up (0 is the run's own strain).
 */
@Component()
export class InfectionDef extends Schema {
  @type("string") id: string;
  @type("string") name: string;
  @type("number") @defaultValue(0) slot: number;
  @type("string") pathogen: string;
  @type(["string"]) cards: string[];
  @type("object") traits: Record<string, number>;
}
