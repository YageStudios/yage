import { Component, Schema, type, nullable } from "minecs";
import type * as PIXI from "pixi.js";
import { FigureResources } from "../figures/FigureResources";
import type { EntranceStream } from "../../render/transit/entrance-streams";
import type { Board } from "../../services/travel/types";
import type { TransitLine } from "../../worldgen/transit";
import type { planningPlan } from "../../worldgen/commute/context";
import type { PlanningContext } from "../../worldgen/commute/context";
import { TransitVehicle } from "./TransitVehicle";
import { TransitTemplate } from "./TransitTemplate";
@Component()
export class TransitResources extends Schema {
  @type(FigureResources) figures: FigureResources;
  @type("object") entranceLines: Map<TransitLine, Board[]>;
  @type(["object"]) entranceDemand: EntranceStream[];
  @nullable() @type("object") entrancePlanning: PlanningContext | null;
  @nullable() @type("object") entrancePlan: ReturnType<typeof planningPlan>;
  @type("number") entranceRevision: number;
  @type("number") entranceDay: number;
  @type("object") root: PIXI.Container;
  @type([TransitVehicle]) drawn: TransitVehicle[];
  @type([TransitTemplate]) templates: TransitTemplate[];
}
