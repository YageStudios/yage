import { Component, Schema, type } from "minecs";
import type { PlanningContext } from "../../worldgen/commute/context";
import type { WorldMap } from "../../worldmap/places";

/** The region's geography: the planning context the page's world is built from, and the world map of its places over it. */
@Component()
export class RegionMap extends Schema {
  @type("object") planning: PlanningContext;
  @type("object") worldMap: WorldMap;
}
