import { Component, defaultValue, Schema, type } from "minecs";
@Component()
export class PrefabState extends Schema {
  @type("number") last: number;
  @type("number") marketShown: number;
  @type("number") snowShown: number;
  @type("number") nightShown: number;
  /** What the player sees into this frame (world px, x then y): where the host and commanded units stand, each building faded or cleared (its middle) and each breach. LookSync sends it to the hot chunks. */
  @type(["number"]) @defaultValue([]) looked: number[];
}
