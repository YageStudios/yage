import { Schema, type } from "minecs";
import { nullable } from "minecs";
import type { Season } from "../../domain/weather";
export class ExtremeMemory extends Schema {
  @type(["number"]) closed: number[];
  @nullable() @type("string") season: Season | null;
}
