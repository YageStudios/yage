import { Component, defaultValue, Schema, type } from "minecs";

/**
 * A card in the sim lab's spawn menu (src/entities/simlab.json5 `labkind:*`; src/simlab/kinds.ts
 * adds one per super mutant kind): what a group put down from it is. side: the lab side its people
 * stand on; count: how many a new group has; weapon / gear: their kit (content/arms.json5);
 * mutant: a MutantDef id, every one of them grown into that kind once bloomed; needs: trait
 * minimums the infection going round is raised to so they show; components: any person
 * component's values, as a group's `components` (src/simlab/protocol.ts LabGroup).
 */
@Component()
export class LabKind extends Schema {
  @type("string") id: string;
  @type("string") name: string;
  @type("string") @defaultValue("") hint: string;
  @type("string") @defaultValue("civilian") side: string;
  @type("number") @defaultValue(10) count: number;
  @type("string") @defaultValue("") weapon: string;
  @type("string") @defaultValue("") gear: string;
  @type("string") @defaultValue("") mutant: string;
  @type("object") needs: Record<string, number>;
  @type("object") components: Record<string, Record<string, number>>;
}
