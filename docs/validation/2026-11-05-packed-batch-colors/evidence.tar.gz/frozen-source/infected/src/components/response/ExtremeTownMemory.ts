import { Component, Schema, type } from "minecs";

/** What ExtremesSystem has announced of a town's weather (latched until it eases). */
@Component()
export class ExtremeTownMemory extends Schema {
  @type("boolean") storm: boolean;
  @type("boolean") blizzard: boolean;
  @type("boolean") heat: boolean;
  @type("boolean") cold: boolean;
  @type("boolean") flood: boolean;
}
