import { Component, Schema, type } from "minecs";

/**
 * A place in the world's hierarchy, top down: world organizations, countries, states, counties,
 * cities and towns. `key` is its stable id ("state:home", "town:<place id>"), the same on every
 * load of the same seed; `parent` is the key of the tier it sits in, which need not be an entity
 * yet (the home state's country is still the abstract outside). Offices name what they govern by
 * key (TierRef), never by entity or index.
 */
@Component()
export class TierIdentity extends Schema {
  @type("string") tier: string;
  @type("string") key: string;
  @type("string") parent: string;
}
