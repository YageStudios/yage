import { Schema, type } from "minecs";
import type { Biome, Kind } from "../../worldgen/terrain/kinds";
export class SettlementState extends Schema {
  @type("number")
  kind: Kind;
  @type("number")
  size: number;
  @type("number")
  biome: Biome;
  @type("number")
  town: number;
}
