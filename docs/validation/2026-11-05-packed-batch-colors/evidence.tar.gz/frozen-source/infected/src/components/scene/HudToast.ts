import { Component, defaultValue, Schema, type } from "minecs";
import type { ToastKind } from "../../ui/chrome";

/** One toast asked for this frame (a "hud:toast" transient owned by its scene); HudToasts shows it, or notes rate-limited news. */
@Component()
export class HudToast extends Schema {
  @type("string")
  @defaultValue("")
  text: string;
  @type("string")
  @defaultValue("bad")
  kind: ToastKind;
  /** When it was asked for (performance.now ms): the rate limit counts from here. */
  @type("number")
  @defaultValue(0)
  at: number;
  /** News: at most one toast every 2.5 s, the rest go to the notes. Otherwise it is shown as is, for `ms`. */
  @type("boolean")
  @defaultValue(true)
  limited: boolean;
  /** How long an unlimited toast shows (ms). */
  @type("number")
  @defaultValue(4000)
  ms: number;
}
