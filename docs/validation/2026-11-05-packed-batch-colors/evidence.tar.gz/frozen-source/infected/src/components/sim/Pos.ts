import { Component, defaultValue, Schema, type } from "minecs";

@Component()
export class Pos extends Schema {
  @type("float32")
  @defaultValue(0)
  x: number;

  @type("float32")
  @defaultValue(0)
  y: number;
}
