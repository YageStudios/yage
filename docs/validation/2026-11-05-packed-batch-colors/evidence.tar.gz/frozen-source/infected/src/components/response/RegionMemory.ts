import { Component, Schema, type } from "minecs";
import { ResponseMemory } from "./ResponseMemory";

/** The region's own response memory (region:response): its borders, their geometry and the weather's news; each town's lives on its town entity. */
@Component()
export class RegionMemory extends Schema {
  @type(ResponseMemory) memory: ResponseMemory;
}
