import { Component, Schema, type } from "minecs";

/** A client's external subscriptions (client:session): runtime release handles, released once by RuntimeRelease. */
@Component()
export class RuntimeLifetime extends Schema {
  @type("boolean") disposed: boolean;
  @type("object") releases: Set<() => void>;
}
