import type { World } from "minecs";
import { Component, Schema, type } from "minecs";
import type { Segment } from "../../services/life/schedule";
import { LifeSegment } from "./LifeSegment";
const emptySegment = () => ({ day: 0, index: 0, start: 0, end: 0, act: 0 });
@Component()
export class WorkerReactionScratch extends Schema {
  @type("object")
  dest: number[];
  @type(LifeSegment)
  segment: Segment;
}
export const initializeWorkerReactionScratch = (world: World, entity: number) => {
  const fields = world(WorkerReactionScratch).store as unknown as Record<string, unknown[]>;
  fields.dest[entity] = [0, 0, 0];
  world(WorkerReactionScratch, entity).segment = emptySegment();
};
