import { Component, Schema, type } from "minecs";
import type { PlaceFrame } from "../../worldmap/timeline";

/** The places' tallies as the run went (SpreadSystem, every TIMELINE_EVERY ticks): what a replay's scrub shows on the world view. */
@Component()
export class PlaceTimeline extends Schema {
  @type(["object"]) frames: PlaceFrame[];
}
