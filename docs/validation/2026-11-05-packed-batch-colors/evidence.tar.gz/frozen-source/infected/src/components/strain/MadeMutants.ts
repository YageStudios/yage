import { Component, Schema, type } from "minecs";

/**
 * Who has been made into a super mutant, whatever the strain's mutation (a story's `mutate`
 * anchor, services/mutants.ts makeMutants): kind id by gid (src/entities/mutants.json5).
 * TraitConfig hands it to domain/mutants.ts setMade here and to the hosts with the config.
 */
@Component()
export class MadeMutants extends Schema {
  @type("object") made: Record<string, string>;
}
