import { Component, Schema, defaultValue, nullable, type } from "minecs";
import type { Emit } from "../../domain/load/constants";
import type { Weather } from "../../domain/weather";
import type { ObjectsNav } from "../../worldgen/terrain/models";
import { ViralCloud } from "./ViralCloud";
import { ViralEmission } from "./ViralEmission";
import { WeatherSample } from "./WeatherSample";
/** Hot effects are transient and rebuilt from person rows when a stored chunk returns. */
@Component()
export class LoadEffects extends Schema {
  @type("boolean")
  @defaultValue(false)
  present: boolean;
  @type([ViralCloud])
  clouds: ViralCloud[];
  @type("object")
  cloudOpens: WeakMap<(x: number, y: number) => boolean, (x: number, y: number) => boolean>;
  @type("object")
  surface: Float32Array;
  @type("object")
  at: Uint32Array;
  @type("object")
  kind: Uint8Array;
  @type("object")
  where: Uint8Array;
  @type("object")
  active: number[];
  @type("object")
  isActive: Uint8Array;
  @type([ViralEmission])
  emits: ViralEmission[];
  @type("object")
  recoil: Map<number, [
    number,
    number
  ]>;
  @type("object")
  actions: Map<number, {
    kind: Emit;
    at: number;
    angle: number;
  }>;
  @type("object")
  px: Float32Array;
  @type("object")
  py: Float32Array;
  @type("object")
  vx: Float32Array;
  @type("object")
  vy: Float32Array;
  @type("number")
  @defaultValue(-1)
  hotTick: number;
  @type("object")
  groundTiles: Uint8Array | null;
  @type("object")
  groundObjects: ObjectsNav | null;
  @type("number")
  @defaultValue(0)
  groundCx: number;
  @type("number")
  @defaultValue(0)
  groundCy: number;
  @nullable()
  @type(WeatherSample)
  groundWeather: Weather | null;
}
