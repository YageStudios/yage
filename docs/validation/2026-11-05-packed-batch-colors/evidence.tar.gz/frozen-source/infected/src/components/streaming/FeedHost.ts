import { Schema, type } from "minecs";
import { FeedChunk } from "./FeedChunk";
export class FeedHost extends Schema {
  @type("number") host: number;
  @type([FeedChunk]) queued: FeedChunk[];
  /** Surveys asked of this host and not yet answered. */
  @type("number") surveying: number;
}
