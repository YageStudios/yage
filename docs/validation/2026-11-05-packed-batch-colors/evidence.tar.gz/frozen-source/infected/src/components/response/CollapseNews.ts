import { Schema, type } from "minecs";

export class CollapseNews extends Schema {
  @type("boolean") fallen: boolean;
  @type("number") border: number;
  @type("boolean") evac: boolean;
  @type("boolean") walled: boolean;
  @type("boolean") firebombed: boolean;
}
