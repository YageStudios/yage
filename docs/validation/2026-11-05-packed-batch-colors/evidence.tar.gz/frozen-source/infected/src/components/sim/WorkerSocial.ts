import { Component, Schema, type, type World } from "minecs";

/**
 * Family observations across a worker's chunk worlds (person rows remain transferable): the homes
 * with someone visibly sick, who has been mourned, and the social records world (made with the
 * first death seen; sim/host-state's socialRecords) whose entities are the funerals and the
 * households' losses, indexed by the dead's home chunk and by household.
 */
@Component()
export class WorkerSocial extends Schema {
  @type("object")
  sickHomes: Map<number, number>;
  /** Funeral entities by the home chunk (chunkKey) of whoever died, by day then gid. */
  @type("object")
  funerals: Map<number, number[]>;
  @type("object")
  mourned: Set<number>;
  /** FamilyLoss entities by household (familyKey), oldest first, at most four. */
  @type("object")
  losses: Map<number, number[]>;
  /** Lockstep: what this worker's chunks saw since the last post (services/life/observe's events). */
  @type("object")
  outbox: number[];
  /** The funerals' and losses' world, or null before anyone's death is seen. */
  @type("object")
  records: World | null;
}
