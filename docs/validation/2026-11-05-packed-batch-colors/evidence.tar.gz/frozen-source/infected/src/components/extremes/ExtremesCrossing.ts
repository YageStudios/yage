import { Component, Schema, type } from "minecs";

/** Where a closed road's barrier spans the carriageway (world units): a view record of the extremes, per barrier spot. */
@Component()
export class ExtremesCrossing extends Schema {
  @type("number") x: number;
  @type("number") y: number;
  @type("number") half: number;
}
