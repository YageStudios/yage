import { Component, Schema, defaultValue, type } from "minecs";

/**
 * A household's loss, an entity in a planning context's social records (WorkerSocial.records): who
 * died (gid), on which day, their place in the family (kin), and their grave (where the funeral
 * was: chunk and place). Laid with the funeral; the household mourns through it (griefOf).
 */
@Component()
export class FamilyLoss extends Schema {
  @type("float64") @defaultValue(0) gid: number;
  @type("float64") @defaultValue(0) day: number;
  @type("float64") @defaultValue(0) kin: number;
  @type("float64") @defaultValue(0) cx: number;
  @type("float64") @defaultValue(0) cy: number;
  @type("float64") @defaultValue(0) place: number;
}
