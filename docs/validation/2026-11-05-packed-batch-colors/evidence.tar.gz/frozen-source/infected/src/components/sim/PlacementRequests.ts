import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/** Who to place where their day has them, in the order asked (SnapshotPlacementSystem drains in the "people" stack). */
export type PlacementRequest =
  /** Just spawned (PersonSpawnSystem): placed at t, midnight on day one. */
  | { kind: "born"; eids: number[]; cx: number; cy: number; t: number }
  /** A chunk loaded at t (module restored): everyone on their schedule when it is fresh, else those more than two hours behind. */
  | { kind: "catchUp"; cx: number; cy: number; t: number; all: boolean };

@Component()
export class PlacementRequests extends Commands<PlacementRequest> {}
