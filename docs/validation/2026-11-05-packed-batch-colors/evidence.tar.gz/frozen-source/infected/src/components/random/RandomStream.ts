import { Component, Schema, type } from "minecs";

/**
 * An entity's own deterministic random stream (mulberry32 state), saved with it: a controller's
 * choices, the strain's offers. Each owner draws only from its own, so none shifts another's draws.
 */
@Component()
export class RandomStream extends Schema {
  @type("number") state: number;
}

/** The next draw in [0, 1) of `random`'s stream. */
export const nextRandom = (random: RandomStream) => {
  let t = (random.state = (random.state + 0x6d2b79f5) | 0);
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

/** `random`'s stream as a draw function, for domain code that takes one. */
export const streamRandom = (random: RandomStream) => () => nextRandom(random);

/** Restarts `random`'s stream from `key` (FNV-1a), so the same key always draws the same sequence. */
export const seedRandom = (random: RandomStream, key: string) => {
  let h = 0x811c9dc5;
  for (let i = 0; i < key.length; i++) h = Math.imul(h ^ key.charCodeAt(i), 0x01000193);
  random.state = h | 0;
};
