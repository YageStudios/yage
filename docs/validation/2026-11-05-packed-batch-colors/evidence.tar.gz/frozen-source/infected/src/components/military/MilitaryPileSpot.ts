import { Component, nullable, Schema, type } from "minecs";

/** Where a burn cell's pile stands (chunk-local), or null when it has no open ground, for the tiles it was found in: a view record (services/view/records) of the military view. */
@Component()
export class MilitaryPileSpot extends Schema {
  @type("object") tiles: Uint8Array;
  @nullable() @type("object") spot: { x: number; y: number } | null;
}
