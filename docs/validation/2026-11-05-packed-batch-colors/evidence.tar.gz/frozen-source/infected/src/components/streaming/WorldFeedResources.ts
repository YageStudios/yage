import { Component, Schema, type } from "minecs";
export type FeedPool = {
  hosts: readonly { index: number }[];
  chunks: ReadonlyMap<number, { host: number; ready: boolean }>;
  placement: (cx: number, cy: number, pool: any, space: number) => number;
  generate(cx: number, cy: number, seed: number): unknown;
  survey(cx: number, cy: number, seed: number): Promise<Uint8Array>;
};
@Component()
export class WorldFeedResources extends Schema {
  @type("object") pool: FeedPool;
  /** Where surveyed chunks' answers go (services/cold/survey.ts). */
  @type("object") answers: { surveyed(cx: number, cy: number, bytes: Uint8Array): void };
}
