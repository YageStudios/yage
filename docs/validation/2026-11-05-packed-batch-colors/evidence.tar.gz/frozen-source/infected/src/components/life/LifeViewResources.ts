/** The life viewer's loaded life and its UI, owned by its entity. */
import { Component, Schema, type } from "minecs";
import type { LifeFile } from "../../life/model";
import type { LifeViewUI } from "../../ui/life";

@Component()
export class LifeViewResources extends Schema {
  @type("object") file: LifeFile;
  @type("object") ui: LifeViewUI;
}
