import { Component, Schema, defaultValue, type } from "minecs";

/** world:response-export: how many times the export was assembled, and the response tick of the latest. */
@Component()
export class ExportRevision extends Schema {
  @type("number") @defaultValue(0) revision: number;
  @type("number") @defaultValue(0) tick: number;
}
