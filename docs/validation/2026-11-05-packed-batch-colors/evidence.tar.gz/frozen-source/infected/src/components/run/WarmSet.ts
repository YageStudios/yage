import { Component, defaultValue, Schema, type } from "minecs";

/**
 * Which in-map chunks the run simulates as people (run:hot, WarmSetSystem): the rest are cold cells
 * (ColdCells). `warm` is set on the first step from the chunks the boot generated; `leaving` maps a
 * chunk being unloaded to the tick it unloads at, until its absorb applies on the step that covers it.
 */
@Component()
export class WarmSet extends Schema {
  @type("boolean") @defaultValue(false) started: boolean;
  @type("object") warm: Set<number>;
  @type("object") leaving: Map<number, number>;
}
