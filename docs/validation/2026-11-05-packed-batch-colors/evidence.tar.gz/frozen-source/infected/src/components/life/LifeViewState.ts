/** The life viewer's clock, playback and camera. */
import { Component, Schema, defaultValue, type } from "minecs";

@Component()
export class LifeViewState extends Schema {
  @type("number") @defaultValue(0) tick: number;
  @type("number") @defaultValue(0) endTick: number;
  @type("boolean") @defaultValue(false) playing: boolean;
  /** Days a second while playing. */
  @type("number") @defaultValue(1) speed: number;
  /** The camera keeps them in view. */
  @type("boolean") @defaultValue(true) follow: boolean;
  @type("number") @defaultValue(0) x: number;
  @type("number") @defaultValue(0) y: number;
  @type("number") @defaultValue(4) scale: number;
  @type("number") @defaultValue(1) width: number;
  @type("number") @defaultValue(1) height: number;
  @type("number") @defaultValue(1) dpr: number;
  @type("boolean") @defaultValue(true) dirty: boolean;
  @type("boolean") @defaultValue(false) dragging: boolean;
  @type("number") @defaultValue(0) pointerX: number;
  @type("number") @defaultValue(0) pointerY: number;
}
