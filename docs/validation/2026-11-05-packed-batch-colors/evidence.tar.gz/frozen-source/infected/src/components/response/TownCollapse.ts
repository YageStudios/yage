import { Component, Schema, defaultValue, type } from "minecs";

/** A town's collapse (CollapseSystem): strain towards its fall, and whether and when its border last changed. */
@Component()
export class TownCollapse extends Schema {
  @type("number") @defaultValue(0) strain: number;
  @type("boolean") @defaultValue(false) bordered: boolean;
  @type("number") @defaultValue(0) borderChanged: number;
}
