import { type } from "minecs";
import { HostPoint } from "./HostPoint";

export class HostLocation extends HostPoint {
  @type("number")
  cx: number;
  @type("number")
  cy: number;
  @type("number")
  at: number;
}
