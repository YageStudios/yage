import { Component, Schema, type } from "minecs";
import type { ChunkNav } from "../../worldgen/objects-nav";
@Component()
export class NavigationProjections extends Schema {
  @type("object")
  chunks: Map<number, Map<number, ChunkNav>>;
  @type("object")
  lastKeys: Map<number, number>;
  @type("object")
  lasts: Map<number, ChunkNav>;
}
