import { Component, Schema, nullable, type } from "minecs";
import type { GameAudio, Handle } from "yage/audio/engine";
import type { PresetRegistrar } from "yage/audio/types";
import type { SettingsStore } from "../../persistence/settings";
import type { HudBus } from "../../ui/model";
import type { AudioLoopName } from "./AudioLoops";

/** Handles outside ECS storage: this scene's own GameAudio, its voices and its page subscriptions. */
@Component()
export class AudioResources extends Schema {
  /** Where the unlocking gestures are heard (the window in the page). */
  @type("object") target: EventTarget;
  /** The HUD model the settings are published to. */
  @nullable() @type("object") bus: HudBus | null;
  /** Aborted at teardown: removes the gesture listeners and cancels a late preload. */
  @type("object") abort: AbortController;
  @type("object") releasePause: () => void;
  /** The saved settings, opened at init and closed at teardown. */
  @type("object") settings: SettingsStore;
  /** The engine and presets, once their lazy imports resolve. */
  @nullable() @type("object") engine: typeof GameAudio | null;
  @nullable() @type("object") presets: PresetRegistrar | null;
  @nullable() @type("object") loading: Promise<void> | null;
  /** This scene's audio context, created from the first gesture after loading. */
  @nullable() @type("object") audio: GameAudio | null;
  @type("object") voices: Set<Handle>;
  @type("object") loops: Record<AudioLoopName, Handle | null>;
  /** The one ambulance siren pass sounding. */
  @nullable() @type("object") siren: Handle | null;
}
