import { Component, Schema, type } from "minecs";

/**
 * The virus AI's own state (controller:virus-ai), written only by VirusDecisionSystem: its next
 * decision and next host cycle (play seconds), its source sequence, and the epoch it last drove
 * under (a new epoch clears its plans).
 */
@Component()
export class VirusDecisionState extends Schema {
  @type("number") next: number;
  @type("number") cycleAt: number;
  @type("number") sequence: number;
  @type("number") epoch: number;
}
