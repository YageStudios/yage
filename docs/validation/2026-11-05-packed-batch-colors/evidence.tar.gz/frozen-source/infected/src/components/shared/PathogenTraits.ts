import { Schema, type } from "minecs";
import type { Traits } from "../../domain/disease";

export class PathogenTraits extends Schema implements Traits {
  @type("string")
  pathogen: string;

  @type("number")
  start: number;

  @type("number")
  infectivity: number;

  @type("number")
  dose: number;

  @type("number")
  clearance: number;

  @type("number")
  breath: number;

  @type("number")
  cough: number;

  @type("number")
  sneeze: number;

  @type("number")
  vomit: number;

  @type("number")
  cloudLoad: number;

  @type("number")
  cloudSize: number;

  @type("number")
  cloudLife: number;

  @type("number")
  touch: number;

  @type("number")
  persistence: number;

  @type("number")
  stagger: number;

  @type("number")
  incubation: number;

  @type("number")
  lifespan: number;

  @type("number")
  decay: number;

  @type("number")
  reach: number;

  @type("number")
  reachWeight: number;

  @type("number")
  corpses: number;

  @type("number")
  aggression: number;

  @type("number")
  frenzy: number;

  @type("number")
  bite: number;

  @type("number")
  reanimate: number;

  @type("number")
  scavenge: number;

  @type("number")
  metabolism: number;

  @type("number")
  breed: number;

  @type("number")
  beasts: number;

  @type("number")
  mutation: number;

  @type("number")
  visibility: number;

  @type("number")
  armor: number;

  @type("number")
  cold: number;

  @type("number")
  heat: number;

  @type("number")
  pickRate: number;

  @type("number")
  cascade: number;

  @type("number")
  cureResist: number;

  @type("number")
  reshuffle: number;

  @type("number")
  evasion: number;

  @type("number")
  rodent: number;

  @type("number")
  bird: number;

  @type("number")
  livestock: number;

  @type("number")
  water: number;

  @type("number")
  dog: number;

  @type("number")
  mosquito: number;

  @type("number")
  bleed: number;

  @type("number")
  collapse: number;

  @type("number")
  spores: number;

  @type("number")
  silent: number;

  @type("number")
  steady: number;

  @type("number")
  drift: number;
}
