import { Component, defaultValue, Schema, type } from "minecs";

/**
 * Where the outbreak's offers and unlock points stand, written each frame by OfferClockUpdate for
 * whoever shows them (HudAfter's evolution panel).
 */
@Component()
export class OfferClock extends Schema {
  /** Unlock points earned and not yet spent on the passive tree. */
  @type("number") @defaultValue(0) pointsLeft: number;
  /** The line about the next forced mutation. */
  @type("string") @defaultValue("") offerLine: string;
  /** The line about the next unlock point. */
  @type("string") @defaultValue("") pointLine: string;
}
