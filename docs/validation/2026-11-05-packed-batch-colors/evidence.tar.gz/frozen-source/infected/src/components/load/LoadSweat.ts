import { Schema, type } from "minecs";

export class LoadSweat extends Schema {
  @type("number") gid: number;
  @type("number") next: number;
}
