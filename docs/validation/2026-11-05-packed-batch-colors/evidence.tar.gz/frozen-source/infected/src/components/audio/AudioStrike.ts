import { Schema, type } from "minecs";

/** The six-second window a storm cell last thundered in. */
export class AudioStrike extends Schema {
  @type("number") key: number;
  @type("number") win: number;
}
