import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import { FigureResources } from "../figures/FigureResources";
export type CrowdSpace = { x: number; y: number; room: number; face: number } | null;
@Component()
export class UnrestResources extends Schema {
  @type("object") ground: PIXI.Graphics;
  @type("object") held: PIXI.Graphics;
  @type("object") top: PIXI.Graphics;
  @type("object") glow: PIXI.Graphics;
  @type("object") flames: PIXI.Graphics;
  @type(FigureResources) figures: FigureResources;
  /** Crowd spot records (UnrestSpot entities) by "cx,cy". */
  @type("object") spots: Map<string, number>;
}
