import { Component, Schema, type } from "minecs";
import type { OutbreakHistory } from "../../ui/left-state";

/** The Outbreak tab's sparkline samples, for the world and town by town (LeftColumnPanels pushes them). */
@Component()
export class OutbreakSamples extends Schema {
  @type("object") history: OutbreakHistory;
}
