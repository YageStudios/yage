import { Component, defaultValue, Schema, type } from "minecs";
import type { Traits } from "../../domain/disease";
import type { Emission, Overlay } from "../../domain/load/overlay";
import { Commands } from "yage/world/commands";

/**
 * One load phase's effect rows for this step (docs/LOAD.md): the clouds, puddles, blood and falls
 * its source system found, person by person, as columns on the chunk's context entity. The effect
 * systems after it walk the rows; soil entries and emissions are applied in row order, so the
 * stains, the emissions and their wire order come out as if each event were applied when found.
 * Reset after the phase's emits go out.
 */
export class LoadRowTable extends Schema {
  /** Row: what the row asks for (LoadRow). */
  @type("object") kind: number[];
  /** Cloud rows: the Emit kind. */
  @type("object") emit: number[];
  @type("object") eid: number[];
  /** The tick the event happened at. */
  @type("object") at: number[];
  @type("object") x: number[];
  @type("object") y: number[];
  @type("object") angle: number[];
  @type("object") vx: number[];
  @type("object") vy: number[];
  /** Cloud rows: the mouth, and how long the air there holds a cloud (fixed when it is coughed). */
  @type("object") mx: number[];
  @type("object") my: number[];
  @type("object") linger: number[];
  /** Each row's emission for the page, once its effect system has made it. */
  @type("object") emission: (Emission | null)[];
  /** Soil entries: the row they come at (direct soils take the next row's index), tile, amount and stain. */
  @type("object") soilRow: number[];
  @type("object") soilTile: number[];
  @type("object") soilAmount: number[];
  @type("object") soilStain: number[];
  /** The first synthesis row when synthesis ran this step (rows before it are a showcase's), else -1. */
  @type("number") @defaultValue(-1) synthFrom: number;
  /** Synthesis: the clouds already about when its rows began (born * 65536 + slot), made by LoadClouds. */
  @type("object") known: Set<number> | null;
}

/** The table's per-row and per-soil columns (all plain arrays). */
export const ROW_COLUMNS = ["kind", "emit", "eid", "at", "x", "y", "angle", "vx", "vy", "mx", "my", "linger", "emission", "soilRow", "soilTile", "soilAmount", "soilStain"] as const;

/** Empty columns for a fresh table (the chunk context's init). */
export const initRows = (rows: LoadRowTable) => {
  for (const column of ROW_COLUMNS) (rows as any)[column] = [];
  rows.synthFrom = -1;
  rows.known = null;
};

/** Showcase and synthesis rows: applied before the hot step's motion and prune. */
@Component()
export class SynthesisRows extends LoadRowTable {}

/** The hot step's rows: applied after prune, before inhaling. */
@Component()
export class HotRows extends LoadRowTable {}

export type ShowcaseRequest = {
  eid: number;
  /** Showcase bits of the picked card. */
  mask: number;
  /** The pick's tick: seeds which way the host faces. */
  seed: number;
};

/** Picked cards to play on their hosts this step (module input pushes, LoadShowcase drains). */
@Component()
export class ShowcaseRequests extends Commands<ShowcaseRequest> {}

/** A chunk back from storage at `tick`: loads to bring up to date (the "restore" stack drains). */
@Component()
export class RestoreRequests extends Commands<{ tick: number }> {}

/** The overlay asked for with a snapshot (the "present" stack encodes it into `bytes`). */
@Component()
export class LoadOverlay extends Schema {
  @type("object") traits: Traits | null;
  @type("number") @defaultValue(0) tick: number;
  @type("object") poses: Overlay["poses"];
  @type("object") bytes: Uint8Array | null;
}
