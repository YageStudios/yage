import { Component, Schema, nullable, type } from "minecs";
import type { createHud } from "../../ui/hud";
import type { HudBus } from "../../ui/model";

/** The HUD's model (the bus the scene patches and drains) and, once the page has built it over that bus, the HUD itself. */
@Component()
export class HudResources extends Schema {
  @type("object") bus: HudBus;
  @nullable() @type("object") hud: ReturnType<typeof createHud> | null;
}
