import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import type { Stain } from "../../domain/load/constants";

export class LoadStain extends Schema {
  @type("number") tile: number;
  @type("number") target: number;
  @type("number") shown: number;
  @type("number") seed: number;
  @type("number") since: number;
  @type("number") kind: Stain;
  @type("object") sprite: PIXI.Sprite;
  @type("object") glint: PIXI.Sprite;
}
