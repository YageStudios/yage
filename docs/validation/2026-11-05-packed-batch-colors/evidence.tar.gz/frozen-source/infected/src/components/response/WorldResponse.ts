import { Schema, type } from "minecs";
import { TownResponseState } from "./TownResponseState";
import { ResponseState } from "./ResponseState";
import { ResponseMemory } from "./ResponseMemory";
import { BorderGeometry } from "./BorderGeometry";
import { numberLists } from "./series";
export class WorldResponse extends Schema {
  @type([TownResponseState]) towns: TownResponseState[];
  @type(ResponseState) shared: ResponseState;
  @numberLists() links: number[][];
  @type("number") cure: number;
  @type("number") reshuffles: number;
  @type("number") tick: number;
  @type(ResponseMemory) memory: ResponseMemory;
  /** The border gates found from the plan and the map: a cache, not memory. */
  @type(BorderGeometry) geometry: BorderGeometry;
}
