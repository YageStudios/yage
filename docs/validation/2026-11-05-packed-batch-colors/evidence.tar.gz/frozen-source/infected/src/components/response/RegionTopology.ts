import { Component, Schema, type } from "minecs";
import { numberLists } from "./series";

/** The populated region the run generates up front (region:response). */
@Component()
export class RegionTopology extends Schema {
  /** Chunks in the world map's bounds: generation is done when this many are ready. */
  @type("number") total: number;
  /** Each town's neighbours the news travels to (by place index). */
  @numberLists() links: number[][];
}
