import { Component, Schema, defaultValue, type } from "minecs";

/** What has sounded (debugging and probes). */
@Component()
export class AudioCounters extends Schema {
  @type("number") @defaultValue(0) moments: number;
  @type("number") @defaultValue(0) shots: number;
  @type("number") @defaultValue(0) errors: number;
}
