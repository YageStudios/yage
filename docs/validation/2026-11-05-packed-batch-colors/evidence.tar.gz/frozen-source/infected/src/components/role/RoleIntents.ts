import type { SiegeAction } from "../../domain/siege/types";
import type { StrategyAction } from "../../domain/strategy/operations";
import type { RtsAction } from "../../domain/rts/orders";
import { Component } from "minecs";
import { Commands } from "yage/world/commands";
import type { Pawn } from "../../domain/pawns";

/** What any controller of a role may ask: the same union for the player and the AI (each role is granted its own kinds: RoleAuthority). */
export type RoleAction =
  | RtsAction | SiegeAction | StrategyAction
  /** Pick this card of the open mutation offer. */
  | { kind: "pick"; card: string }
  /** Buy this passive-tree node with unlock points. */
  | { kind: "allocate"; node: string }
  /** Take over this bloomed pawn. */
  | { kind: "takeOver"; pawn: Pawn }
  /** The next bloomed host (Tab). */
  | { kind: "cycle" }
  /** Steer the host: steerBytes' [dx + 1, dy + 1], and where the player's page has walked it (world units, HostBody), if it has. */
  | { kind: "steer"; dx: number; dy: number; x?: number; y?: number }
  /** The host bit person `target` (its `n`th bite), drawn at (x, y) world units when it landed: the page saw it (domain/bite.ts). */
  | { kind: "bite"; target: number; n: number; x: number; y: number }
  /** An office: put a town's response ladder at this level (0, none, to the top). `town` is the town's tier key; a town's own office always orders its own town. */
  | { kind: "setLevel"; level: number; town?: string }
  /** An office: send a town's burn squads out, or call them back. */
  | { kind: "burn"; on: boolean; town?: string };

/** One controller's request, stamped with the binding epoch it saw and its own sequence. */
export type RoleIntent = {
  controller: string;
  epoch: number;
  sequence: number;
  action: RoleAction;
};

/** The role's inbound intents (player adapter, AI decision); RoleIntentRouterSystem drains them. */
@Component()
export class RoleIntents extends Commands<RoleIntent> {}

/** A command's id in results: its controller and source sequence. */
export const commandId = (intent: Pick<RoleIntent, "controller" | "sequence">) => `${intent.controller}:${intent.sequence}`;
