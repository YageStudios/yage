import { Component, Schema, type } from "minecs";
import { FigurePose } from "../figures/FigurePose";
import { FireSpot } from "../fire/FireSpot";
import { CrowdSpot } from "./CrowdSpot";
@Component()
export class UnrestState extends Schema {
  @type([FigurePose]) figures: FigurePose[];
  @type([FireSpot]) fires: FireSpot[];
  @type([CrowdSpot]) crowds: CrowdSpot[];
}
