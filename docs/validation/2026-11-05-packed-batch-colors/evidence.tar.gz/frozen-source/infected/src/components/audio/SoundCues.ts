import { Component, defaultValue, Schema, type } from "minecs";
import { SoundMoment, type Moment } from "./SoundMoment";
import { SoundSource, type Source } from "./SoundSource";

/**
 * This scene's transient sound reports, queued by the views as they draw (soundAt, sourceAt) and
 * consumed by AudioEffects after them. Bounded, and dropped while the scene isn't listening.
 */
@Component()
export class SoundCues extends Schema {
  @type("boolean") @defaultValue(false) listening: boolean;
  @type([SoundMoment]) moments: SoundMoment[];
  @type([SoundSource]) sources: SoundSource[];
}

const MAX_MOMENTS = 64;
const MAX_SOURCES = 256;

/** A moment heard at (x, y) this frame: a cough, a fall… */
export const soundAt = (cues: SoundCues, kind: Moment, x: number, y: number) => {
  if (!cues.listening || cues.moments.length >= MAX_MOMENTS) return;
  cues.moments.push({ kind, x, y });
};

/** A source sounding at (x, y) this frame at `level`: a fire, a siren, gunfire, a crowd. */
export const sourceAt = (cues: SoundCues, kind: Source, x: number, y: number, level = 1) => {
  if (!cues.listening || level <= 0 || cues.sources.filter((source) => source.kind === kind).length >= MAX_SOURCES) return;
  cues.sources.push({ kind, x, y, level });
};
