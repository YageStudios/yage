import { Component, Schema, type } from "minecs";
import type { PathogenLook } from "../../domain/look/sprites";

@Component()
export class PawnAtlasState extends Schema {
  @type("string") pathogen: PathogenLook;
  @type("string") drawn: PathogenLook;
}
