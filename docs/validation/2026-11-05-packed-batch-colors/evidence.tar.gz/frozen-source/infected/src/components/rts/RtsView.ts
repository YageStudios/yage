import { Component, defaultValue, Schema, type, nullable } from "minecs";
import { Commands } from "yage/world/commands";
import type { Graphics } from "pixi.js";
import type { Objective } from "../../domain/strategy/operations";
import type { Point } from "../../domain/rts/orders";
export type RtsViewEvent = { kind: "key"; key: string; shift: boolean; ctrl: boolean } | { kind: "down" | "move" | "up" | "cancel" | "leave"; x: number; y: number; button: number; shift: boolean };
@Component()
export class RtsView extends Schema {
  @type(["number"]) selected: number[];
  /** The infected host the player walks (-1 none): the group forms on it and WASD leads it. */
  @type("number") @defaultValue(-1) leader: number;
  /** Whether the steer keys were held last frame: pressing them sends the group after the leader. */
  @type("boolean") steering: boolean;
  /** The press under way (screen px), and whether the group took it (a click then orders, not the scene). */
  @nullable() @type("object") press: { x: number; y: number; button: number; shift: boolean; group: boolean } | null;
  /** A Shift-drag selection box under way (screen px). */
  /** The defense the ridden host was sent at (right click): it walks into reach and strikes until it falls (null none). */
  @nullable() @type("object") breaching: { id: string; x: number; y: number; next: number } | null;
  /** A regional objective chosen in the panel, waiting for a settlement click (null none). */
  @nullable() @type("string") strategic: Objective | null;
  @nullable() @type("object") drag: { start: Point; last: Point; button: number; shift: boolean } | null;
  @type("object") release: (() => void) | null;
  @nullable() @type("object") lines: Graphics | null;
  @type("string") signature: string;
  @type("string") message: string;
  /** Where orders were just given (performance.now() ms), drawn as a fading ring. */
  @type("object") pings: { x: number; y: number; attack: boolean; born: number }[];
}
@Component()
export class RtsViewEvents extends Commands<RtsViewEvent> {}
