import { Component, Schema, type } from "minecs";
import { Commands } from "yage/world/commands";
import type { CastRecord } from "../../domain/cold/cast";

/** Someone for the run to follow by name from now on (a journaled `cast` input). */
export type CastCommand = { gid: number };

/** The cast asked for (services/journal.ts), drained on the authority's steps (CastSystem). */
@Component()
export class CastCommands extends Commands<CastCommand> {}

/**
 * The people the run follows by name (domain/cold/cast.ts), in gid order: where each is and how
 * they fare, kept through the cold tier (rank-coupled to their cell's counts), a cell's names, or a
 * warm chunk (its host's locate reports), and handed between them as the tiers hand them on.
 */
@Component()
export class CastRecords extends Schema {
  @type(["object"]) cast: CastRecord[];
}
