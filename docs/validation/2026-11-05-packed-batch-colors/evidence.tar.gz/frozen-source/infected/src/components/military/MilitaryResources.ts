import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import { FigureResources } from "../figures/FigureResources";
@Component()
export class MilitaryResources extends Schema {
  @type("object") ground: PIXI.Graphics;
  @type("object") held: PIXI.Graphics;
  @type("object") flames: PIXI.Graphics;
  @type("object") glow: PIXI.Graphics;
  @type(FigureResources) figures: FigureResources;
  /** Pile spot records (MilitaryPileSpot entities) by burn cell "gx,gy", oldest first. */
  @type("object") pileSpots: Map<string, number>;
}
