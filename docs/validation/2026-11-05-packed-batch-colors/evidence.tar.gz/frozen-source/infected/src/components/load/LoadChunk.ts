import { Schema, type } from "minecs";
import { LoadCloud } from "./LoadCloud";
import { LoadEmission } from "./LoadEmission";
import { LoadPerson } from "./LoadPerson";
import { LoadStain } from "./LoadStain";

export class LoadChunk extends Schema {
  @type("number") cx: number;
  @type("number") cy: number;
  @type("number") tick: number;
  @type([LoadCloud]) clouds: LoadCloud[];
  @type([LoadStain]) stains: LoadStain[];
  @type([LoadPerson]) people: LoadPerson[];
  @type([LoadEmission]) pending: LoadEmission[];
}
