import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/** Asks to change who drives the role; PossessionSystem drains them. */
export type PossessionCommand =
  /** `controller` takes the role, if the binding is still at `epoch`. */
  | { kind: "acquire"; controller: string; epoch: number }
  /** `controller` lets go: the fallback takes over. */
  | { kind: "release"; controller: string }
  /** `controller`'s connection is gone: the fallback takes over whatever the epoch. */
  | { kind: "disconnect"; controller: string };

@Component()
export class PossessionCommands extends Commands<PossessionCommand> {}
