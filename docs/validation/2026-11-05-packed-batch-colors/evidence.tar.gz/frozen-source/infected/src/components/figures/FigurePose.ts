import { Schema, type } from "minecs";
import type { PoseKind } from "yage/streaming/layer";

/** A decided street figure pose; scene systems own the list, rendering only uploads it. */
export class FigurePose extends Schema {
  @type("number") x: number;
  @type("number") y: number;
  @type("number") sprite: number;
  @type("number") tint: number;
  @type("number") pose?: PoseKind;
  @type("number") turn?: number;
}
