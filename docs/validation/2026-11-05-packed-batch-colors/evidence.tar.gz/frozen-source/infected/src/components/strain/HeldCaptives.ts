import { Component, Schema, type } from "minecs";

/**
 * Who is held captive (a story's `capture`, until its `free` or `mutate`: services/mutants.ts
 * holdCaptives): the town they're held in, by gid. TraitConfig hands the gids to
 * domain/captives.ts setHeld here and to the hosts with the config.
 */
@Component()
export class HeldCaptives extends Schema {
  @type("object") held: Record<string, number>;
}
