import { Schema, type } from "minecs";

export class WeatherTarget extends Schema {
  @type("number") cloud: number;
  @type("number") fog: number;
  @type("number") snow: number;
  @type("number") rain: number;
  @type("number") wet: number;
  @type("number") cover: number;
  @type("number") windX: number;
  @type("number") windY: number;
}
