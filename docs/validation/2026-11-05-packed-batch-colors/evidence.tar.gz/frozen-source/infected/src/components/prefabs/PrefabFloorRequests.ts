import { Component } from "minecs";
import { Commands } from "yage/world/commands";
import type { PrefabRequest } from "./PrefabRequest";

/** Lazy prefab floors; only PrefabFloors drains this queue. */
@Component()
export class PrefabFloorRequests extends Commands<PrefabRequest> {}
