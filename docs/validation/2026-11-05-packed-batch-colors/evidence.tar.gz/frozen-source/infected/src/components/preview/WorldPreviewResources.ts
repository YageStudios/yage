/** Non-serializable authoring-viewer resources, owned by its entity. */
import { Component, Schema, type } from "minecs";
import type { Plan } from "../../worldgen/plan";
import type { CompiledChunk } from "../../worldgen/compile/chunk";
import type { WorldPreviewUI } from "../../ui/world-preview";
import type { GenerationOwner } from "../../worldgen/source/owner";

@Component()
export class WorldPreviewResources extends Schema {
  @type("object") plan: Plan;
  @type("object") cache: Map<string, { chunk: CompiledChunk; image: HTMLCanvasElement }>;
  @type("object") ui: WorldPreviewUI;
  @type("object") params: URLSearchParams;
  /** The viewer's own generation source: plans, templates and chunk projections it compiles. */
  @type("object") generation: GenerationOwner;
}
