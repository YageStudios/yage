import { Schema, type } from "minecs";
export class MaskWearer extends Schema {
  @type("number")
  x: number;
  @type("number")
  y: number;
  @type("number")
  gid: number;
  @type("number")
  pose: number;
  @type("number")
  turn: number;
}
