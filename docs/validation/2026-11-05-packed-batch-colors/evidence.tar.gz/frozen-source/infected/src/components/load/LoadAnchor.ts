import { Schema, type } from "minecs";

export class LoadAnchor extends Schema {
  @type("number") key: number;
  @type("number") slot: number;
  @type("number") gid: number;
}
