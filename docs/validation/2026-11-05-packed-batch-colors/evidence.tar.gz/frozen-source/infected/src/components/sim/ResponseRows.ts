import { Component, Schema, type } from "minecs";

/**
 * This step's armed-response rows on the chunk's context entity, laid by DraftSystem once the
 * draft is done and only when someone is visibly sick: the susceptible soldiers in the world's
 * order (SoldiersSystem hunts and shoots), then, in an alerted chunk, the susceptible civilians in
 * the world's order (FleeSystem runs them from the sick still standing).
 */
@Component()
export class ResponseRows extends Schema {
  @type("object") soldiers: number[];
  @type("object") civilians: number[];
}
