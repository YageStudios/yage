import { Component, Schema, defaultValue, type } from "minecs";

/** Eased sky and surface conditions owned by one scene. */
@Component()
export class SkyLightState extends Schema {
  @type("number") @defaultValue(0) cloud: number;
  @type("number") @defaultValue(0) fog: number;
  @type("number") @defaultValue(0) snow: number;
  @type("number") @defaultValue(0) rain: number;
  @type("number") @defaultValue(0) wet: number;
  @type("number") @defaultValue(0) cover: number;
  @type("number") @defaultValue(0) windX: number;
  @type("number") @defaultValue(0) windY: number;
}
