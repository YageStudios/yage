import { Component, defaultValue, Schema, type } from "minecs";

/**
 * The seat's host as the page walks it (view:host-body, HostBody): where it is now, in realtime on
 * the player's keys, and how it moves past walking (the simulation lab's own pace, a run, a roll).
 * The hosts' copy follows it (HostControl sends where it is). Presentation and the page's own.
 */
@Component()
export class HostBodyView extends Schema {
  /** The host walked (-1 none). */
  @type("number") @defaultValue(-1) gid: number;
  /** Where it is (world units), if it is drawn (`drawn`). */
  @type("number") @defaultValue(0) x: number;
  @type("number") @defaultValue(0) y: number;
  @type("boolean") @defaultValue(false) drawn: boolean;
  /** Whether the page walks it (a player holds the seat's role, it lives, not a replay); else it is where the stream draws it. */
  @type("boolean") @defaultValue(false) driving: boolean;
  /** How long (ms) the stream has drawn the host far from it: past a while, the run moved it (a shove, a hand-off) and it goes there. */
  @type("number") @defaultValue(0) apart: number;
  /** Its walking pace (units/s, before the clock's rate), 0 for the rules' host speed; and what a run multiplies it by. */
  @type("number") @defaultValue(0) walk: number;
  @type("number") @defaultValue(1) run: number;
  /** A roll under way: its way (a unit vector) and how far through it is (0 … 1; 1 none). */
  @type("number") @defaultValue(0) rollX: number;
  @type("number") @defaultValue(0) rollY: number;
  @type("number") @defaultValue(1) rollT: number;
  /** The way it last moved (a unit vector; 0, 0 none yet): where it faces. */
  @type("number") @defaultValue(0) faceX: number;
  @type("number") @defaultValue(0) faceY: number;
  /** A lunge under way (a bite): its way (a unit vector) and how far through it is (0 … 1; 1 none). */
  @type("number") @defaultValue(0) lungeX: number;
  @type("number") @defaultValue(0) lungeY: number;
  @type("number") @defaultValue(1) lungeT: number;
  /** A click's walk (RtsInputSystem): where to (world units), while `goal`; whom to run down and bite (-1 none). The keys take it back. */
  @type("number") @defaultValue(0) goalX: number;
  @type("number") @defaultValue(0) goalY: number;
  @type("boolean") @defaultValue(false) goal: boolean;
  @type("number") @defaultValue(-1) chase: number;
  /** The page's bites so far (each one's number), and the wall ms the next may come (HostBite). */
  @type("number") @defaultValue(0) bites: number;
  @type("number") @defaultValue(0) biteReady: number;
  /** The last frame's wall ms (-1 none). */
  @type("number") @defaultValue(-1) at: number;
}
