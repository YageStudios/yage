import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
export class PrefabStall extends Schema {
  @type("number") market: number;
  @type("object") layer: PIXI.Container;
}
