import { Schema, type } from "minecs";
export class WeatherSample extends Schema {
  @type("number")
  temperature: number;
  @type("number")
  rain: number;
  @type("number")
  snow: number;
  @type("number")
  fog: number;
  @type("number")
  cloud: number;
  @type("number")
  heat: number;
  @type("number")
  cold: number;
  @type("number")
  windAngle: number;
  @type("number")
  wind: number;
  @type("number")
  wetness: number;
  @type("number")
  snowCover: number;
  @type("number")
  storm: number;
}
