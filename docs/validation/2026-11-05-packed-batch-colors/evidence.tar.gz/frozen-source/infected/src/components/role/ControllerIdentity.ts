import { Component, Schema, type } from "minecs";

/** A driver of a role (controller:player, controller:virus-ai): its stable id, its kind and its role. */
@Component()
export class ControllerIdentity extends Schema {
  @type("string") id: string;
  @type("string") kind: "player" | "ai";
  @type("string") role: string;
}
