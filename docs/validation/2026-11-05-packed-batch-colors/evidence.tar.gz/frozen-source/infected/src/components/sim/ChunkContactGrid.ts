import { Component, Schema, defaultValue, type } from "minecs";

/**
 * Per-step contact grid shared by infection and response: cells of 4×4 tiles. The census belongs
 * to a chunk world; an interleaved world must never replace its chains.
 */
@Component()
export class ChunkContactGrid extends Schema {
  @type("number") cells: number;
  @type("number") cellSize: number;
  @type("object") cellOf: (x: number, y: number) => number;
  /** First visible (symptomatic) infected per cell, -1 for none; `nextVisible[eid]` chains them. */
  @type("object") visibleHead: Int32Array;
  @type("object") nextVisible: Int32Array;
  /** One susceptible person per cell, -1 for none. */
  @type("object") susceptible: Int32Array;
  @type("number") @defaultValue(0) visibleTotal: number;
  /** Uninfected soldiers in the chunk. */
  @type("number") @defaultValue(0) soldiers: number;
  /** Living people in the chunk. */
  @type("number") @defaultValue(0) alive: number;
  @type("number") @defaultValue(-1) chunk: number;
  @type("number") @defaultValue(-1) tick: number;
}
