import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/** A chunk back from storage, seen at `tick` (module restored pushes, RestoreObserveSystem drains in the "restore" stack). */
export type ObserveRequest = { tick: number };

@Component()
export class ObserveRequests extends Commands<ObserveRequest> {}
