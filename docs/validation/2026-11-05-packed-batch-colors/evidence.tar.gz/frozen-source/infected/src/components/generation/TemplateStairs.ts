import { Schema, type } from "minecs";
export class TemplateStairs extends Schema {
  @type("object")
  tiles: [
    number,
    number
  ][];
  @type("number")
  up: number;
}
