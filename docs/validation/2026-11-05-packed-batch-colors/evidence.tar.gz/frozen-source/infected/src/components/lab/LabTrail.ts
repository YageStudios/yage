import { Schema, type } from "minecs";

/** A transfer's world-space animation endpoints and start time. */
export class LabTrail extends Schema {
  @type("number") x0: number;
  @type("number") y0: number;
  @type("number") x1: number;
  @type("number") y1: number;
  @type("number") at: number;
}
