import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
export class WeatherSplash extends Schema {
  @type("object") sprite: PIXI.Sprite;
  @type("number") age: number;
}
