import { Component, Schema, type } from "minecs";

/** A chunk's flood geometry: distance from the water over its tiles, and the levels it was painted at. A view record of the extremes. */
@Component()
export class ExtremesFloodChunk extends Schema {
  @type("number") cx: number;
  @type("number") cy: number;
  /** The tiles it was built from (a new tile array rebuilds it). */
  @type("object") tiles: Uint8Array;
  /** Breadth-first steps from the water (255 = beyond reach). */
  @type("object") dist: Uint8Array;
  /** The flood grid it was last painted at (joined), and that grid's furthest reach (tiles). */
  @type("string") painted: string;
  @type("number") reach: number;
  /** Tiles carrying a ripple or flotsam. */
  @type(["number"]) ripples: number[];
}
