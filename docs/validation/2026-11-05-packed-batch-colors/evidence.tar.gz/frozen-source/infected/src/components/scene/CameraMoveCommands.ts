import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/** HUD navigation, applied by Camera after the host and input phases in the same frame. */
export type CameraMoveCommand =
  | { kind: "place"; place: number }
  | { kind: "point"; x: number; y: number; zoom?: number }
  | { kind: "look"; x: number; y: number }
  | { kind: "follow" };

@Component()
export class CameraMoveCommands extends Commands<CameraMoveCommand> {}
