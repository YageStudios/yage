import { Component, Schema, type } from "minecs";

/** The town's standing security policy (region:town): whether its burn squads are ordered out. MilitarySystem alone writes it, from SecurityOrders. */
@Component()
export class TownSecurity extends Schema {
  @type("boolean") burn: boolean;
}
