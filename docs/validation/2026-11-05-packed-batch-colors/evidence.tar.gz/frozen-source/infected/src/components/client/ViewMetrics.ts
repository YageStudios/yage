import { Component, defaultValue, Schema, type } from "minecs";

/** A client's render counters (client:metrics): what it drew, its frame rate and frame time. */
@Component()
export class ViewMetrics extends Schema {
  @type("number") @defaultValue(0) drawn: number;
  @type("number") @defaultValue(0) fps: number;
  @type("number") @defaultValue(0) frameMs: number;
  /** Frames since `lastSecond`, when the frame rate was last sampled. */
  @type("number") @defaultValue(0) frames: number;
  @type("number") @defaultValue(0) lastSecond: number;
}
