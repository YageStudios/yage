import { Component, Schema, nullable, type } from "minecs";
import type * as PIXI from "pixi.js";

/** The viewport outlives scene resources and owns the caller-supplied Pixi application and, once the viewport system has made it, its stage. */
@Component()
export class ScenePlatform extends Schema {
  @type("object") app: PIXI.Application;
  @nullable() @type("object") stage: PIXI.Container | null;
}
