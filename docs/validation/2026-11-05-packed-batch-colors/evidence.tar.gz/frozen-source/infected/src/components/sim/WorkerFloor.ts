import type { World } from "minecs";
import { Component, Schema, type } from "minecs";
import { CONTENT } from "../../content/runtime";
import type { Floor, SlotPlan } from "../../services/life/floor";
import type { Segment } from "../../services/life/schedule";
import type { Who } from "../../services/life/who";
import type { Place } from "../../worldgen/terrain/models";
import { LifeSegment } from "./LifeSegment";
import { LifeWho } from "./LifeWho";
const emptySegment = () => ({ day: 0, index: 0, start: 0, end: 0, act: 0 });
@Component()
export class WorkerFloor extends Schema {
  @type("number")
  useSeat: number;
  @type("object")
  floors: Map<object, Floor>;
  @type("object")
  openFloors: Map<Place, [
    Float32Array,
    Float32Array
  ]>;
  @type("object")
  slotPlans: Map<string, SlotPlan>;
  @type("object")
  commuters: Map<number, Int32Array[]>;
  @type(LifeWho)
  scanWho: Who;
  @type(LifeSegment)
  scanSeg: Segment;
  @type("object")
  scanOut: number[];
  @type("boolean")
  queued: boolean;
  @type("object")
  standOut: number[];
  @type("object")
  spotOut: number[];
  @type("object")
  stairOut: number[];
  @type("boolean")
  upstairs: boolean;
}
export const initializeWorkerFloor = (world: World, entity: number) => {
  const fields = world(WorkerFloor).store as unknown as Record<string, unknown[]>;
  fields.useSeat[entity] = 0;
  fields.floors[entity] = new Map();
  fields.openFloors[entity] = new Map();
  fields.slotPlans[entity] = new Map();
  fields.commuters[entity] = new Map();
  world(WorkerFloor, entity).scanWho = { gid: 0, role: 0, family: 0, rank: 0, traits: 0, culture: CONTENT.cultures[0], hcx: 0, hcy: 0, walk: 0 };
  world(WorkerFloor, entity).scanSeg = emptySegment();
  fields.scanOut[entity] = [0, 0, 0];
  fields.queued[entity] = false;
  fields.standOut[entity] = [0, 0];
  fields.spotOut[entity] = [0, 0];
  fields.stairOut[entity] = [0, 0];
  fields.upstairs[entity] = false;
};
