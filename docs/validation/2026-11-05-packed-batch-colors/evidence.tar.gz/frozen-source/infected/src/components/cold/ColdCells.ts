import { Component, Schema, type } from "minecs";

/**
 * A cold chunk (domain/cold): its residents as counts by state, the incubating and the bloomed in
 * STAGES stages each (so their times spread like the people's own), plus anyone the run has known
 * by name since (overrides: gid, state, timer triples: the role's hosts, and visitors who were here
 * when it went cold), its residents who were people somewhere else then (out, by gid) and where its
 * commuters work (the plan's work chunks, by key, and how many work at each).
 */
export class ColdCell extends Schema {
  @type("number") key: number;
  @type("number") cx: number;
  @type("number") cy: number;
  @type("number") s: number;
  @type(["number"]) e: number[];
  @type(["number"]) i: number[];
  @type("number") d: number;
  @type("number") soldiers: number;
  @type("number") alert: number;
  @type(["number"]) overrides: number[];
  @type(["number"]) out: number[];
  @type(["number"]) flowTo: number[];
  @type(["number"]) flowN: number[];
}

/** world:cold: every in-map chunk the run holds as counts, not people, in key order. */
@Component()
export class ColdCells extends Schema {
  @type([ColdCell]) cells: ColdCell[];
}
