import { Schema, type } from "minecs";

export class SceneTotals extends Schema {
  @type("number")
  people: number;
  @type("number")
  incubating: number;
  @type("number")
  infected: number;
  @type("number")
  dead: number;
  @type("number")
  soldiers: number;
  @type("number")
  alerted: number;
  @type("number")
  chunks: number;
}
