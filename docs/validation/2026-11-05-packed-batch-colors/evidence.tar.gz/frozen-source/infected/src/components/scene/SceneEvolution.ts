import { Schema, type } from "minecs";

export class SceneEvolution extends Schema {
  @type("string")
  pathogen: string;
  @type(["string"])
  cards: string[];
  @type(["string"])
  nodes: string[];
  @type("number")
  drifted?: number;
  @type("number")
  offersResolved: number;
}
