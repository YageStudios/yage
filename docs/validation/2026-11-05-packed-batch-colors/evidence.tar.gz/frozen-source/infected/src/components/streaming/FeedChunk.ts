import { Schema, type } from "minecs";
export class FeedChunk extends Schema {
  @type("number") cx: number;
  @type("number") cy: number;
  /** Surveyed (planned on its host, not made: the region's cold cells), not generated. */
  @type("boolean") survey: boolean;
}
