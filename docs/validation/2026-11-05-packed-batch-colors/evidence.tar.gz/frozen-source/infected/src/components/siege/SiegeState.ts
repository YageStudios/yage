import { Component, Schema, type } from "minecs";
import { Commands } from "yage/world/commands";
import type { SiegeEvent, SiegeRequest, Structure } from "../../domain/siege/types";
/** SiegeSystem is the sole owner; the hosts receive immutable collision projections. */
@Component()
export class SiegeState extends Schema {
  @type("number") revision: number;
  @type(["object"]) structures: Structure[];
  @type("object") cooldowns: Record<string, number>;
  @type(["object"]) events: SiegeEvent[];
  @type("number") fortifiedAt: number;
}
@Component()
export class SiegeOrders extends Commands<SiegeRequest> {}
