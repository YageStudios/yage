import { Component, Schema, type } from "minecs";

/** The run's hash (services/run-hash.ts) every HASH_EVERY ticks, as this client saw it on those steps (RunHashSystem): tick → hash. */
@Component()
export class RunHashes extends Schema {
  @type("object") byTick: Map<number, string>;
}
