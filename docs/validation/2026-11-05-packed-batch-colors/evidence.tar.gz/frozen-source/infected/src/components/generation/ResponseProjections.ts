import { Component, Schema, type } from "minecs";
import type { Vec } from "../../atlas/model";
import type { AmbulanceGraph, Hospital, KerbSpot } from "../../domain/response/ambulance";
import type { LowPoint } from "../../domain/response/extremes";
import type { Checkpoint } from "../../domain/response/street";
import type { Plan } from "../../worldgen/plan";
import type { TransitLine } from "../../worldgen/transit";
import type { Point, WorldMap } from "../../worldmap/places";

/**
 * Response geometry derived from a source's plans and maps (domain/response): pure in its keys,
 * owned by the generation owner so a second context's caches outlive another owner's disposal.
 */
@Component()
export class ResponseProjections extends Schema {
  /** Drivable roads as a graph, per plan (ambulance.ts). */
  @type("object")
  roadGraphs: WeakMap<Plan, AmbulanceGraph>;
  /** A town's hospitals and clinics with beds and homes in reach, per plan by town. */
  @type("object")
  hospitals: WeakMap<Plan, Map<number, Hospital[]>>;
  /** Ambulance routes hospital → home (tiles), per plan; bounded. */
  @type("object")
  ambulanceRoutes: WeakMap<Plan, Map<string, Vec[] | null>>;
  /** Crews' kerbside parking spots (world units), per plan; bounded. */
  @type("object")
  kerbs: WeakMap<Plan, Map<string, KerbSpot | null>>;
  /** A town's checkpoints, per plan and map. */
  @type("object")
  checkpoints: WeakMap<Plan, WeakMap<WorldMap, Map<number, Checkpoint[]>>>;
  /** Patrol routes town → checkpoint (world units), per plan. */
  @type("object")
  patrolRoutes: WeakMap<Plan, Map<string, Vec[] | null>>;
  /** Convoy routes town → town (world units), per plan. */
  @type("object")
  convoyRoutes: WeakMap<Plan, Map<string, Vec[] | null>>;
  /** Each regional link's bridges and riverside stretches, per map (extremes.ts). */
  @type("object")
  lowPoints: WeakMap<WorldMap, LowPoint[][]>;
  /** Transit line paths in world units (extremes.ts lineClosures). */
  @type("object")
  linePaths: WeakMap<TransitLine, Point[]>;
}
