import type { Rect } from "../../atlas/model";
/**
 * The page's scene (main thread): the camera over the world and what this frame's systems pass
 * each other (src/systems/Flow, Camera, SceneWorld, audio/AudioEffects, Hud). One entity carries it, next to
 * yage's PixiViewport. World units are pixels (TILE px a tile); zoom is screen px per world px.
 */
import { Component, Schema, defaultValue, nullable, type } from "minecs";

@Component()
export class SceneView extends Schema {
  /** Geographic extent in game coordinates; null for bounded lab and authored fixtures. */
  @nullable() @type("object") geographicBounds: Rect | null;
  /** Camera centre (world px) and zoom. */
  @type("number")
  @defaultValue(0)
  x: number;
  @type("number")
  @defaultValue(0)
  y: number;
  @type("number")
  @defaultValue(2)
  zoom: number;
  /** Out far enough to see the whole map: the camera never zooms out past it. */
  @type("number")
  @defaultValue(0)
  minZoom: number;

  /** The camera follows the host (free look and flights turn it off). */
  @type("boolean")
  @defaultValue(true)
  following: boolean;
  /** A dive from the world view: easing towards (diveX, diveY) at diveZoom. */
  @type("boolean")
  @defaultValue(false)
  diving: boolean;
  @type("number")
  @defaultValue(0)
  diveX: number;
  @type("number")
  @defaultValue(0)
  diveY: number;
  @type("number")
  @defaultValue(1)
  diveZoom: number;

  /** Page time (ms) and step (s) of this frame. */
  @type("number")
  @defaultValue(0)
  now: number;
  @type("number")
  @defaultValue(0)
  dt: number;

  /** The host as drawn this frame (feet, world px), when it is alive. */
  @type("boolean")
  @defaultValue(false)
  hasHost: boolean;
  @type("number")
  @defaultValue(0)
  hostX: number;
  @type("number")
  @defaultValue(0)
  hostY: number;
  /** The host is about to die (the red vignette, the marker's pulse). */
  @type("boolean")
  @defaultValue(false)
  dying: boolean;

  /** What the views saw: game clock (s), night 0-1, and how far into the world map (0-1). */
  @type("number")
  @defaultValue(0)
  seconds: number;
  @type("number")
  @defaultValue(0)
  night: number;
  @type("number")
  @defaultValue(0)
  blend: number;
  /** The newest sim tick drawn. */
  @type("number")
  @defaultValue(0)
  tick: number;
  /** Town life round the camera, 0-1: the living and well against a busy town (the ambience thins with it). */
  @type("number")
  @defaultValue(0)
  life: number;
}
