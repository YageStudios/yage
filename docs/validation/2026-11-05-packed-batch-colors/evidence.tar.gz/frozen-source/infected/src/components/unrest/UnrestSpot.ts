import { Component, nullable, Schema, type } from "minecs";
import type { CrowdSpace } from "./UnrestResources";

/** Where a chunk's crowd gathers (or null), for the tiles it was found in: a view record (services/view/records) of the unrest view. */
@Component()
export class UnrestSpot extends Schema {
  @type("object") tiles: Uint8Array;
  @nullable() @type("object") spot: CrowdSpace;
}
