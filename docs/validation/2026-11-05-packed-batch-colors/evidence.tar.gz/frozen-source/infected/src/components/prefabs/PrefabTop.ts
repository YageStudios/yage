import { Schema, type, nullable } from "minecs";
import type * as PIXI from "pixi.js";
import { PrefabFace } from "./PrefabFace";
import { PrefabRoofLook } from "./PrefabRoofLook";
import type { FrontCut } from "../../render/front-breaks";
import type { PlanDoor } from "../../render/doors";
import type { WindowLight } from "yage/streaming/window-light";

export class PrefabTop extends Schema {
  @type("string") key: string;
  @type("number") users: number;
  @type("object") roof: PIXI.Graphics;
  @type([PrefabFace]) faces: PrefabFace[];
  @nullable() @type("object") snow: PIXI.Graphics | null;
  @type(PrefabRoofLook) look: PrefabRoofLook;
  @type(["number"]) size: [number, number];
  /** Textures its roof and snow drew with that are its own (render/roof-textures.ts snowFill), freed with it. */
  @type(["object"]) textures: PIXI.Texture[];
  /** What stands up off its roof (drawRoof's `cast`), six numbers each: x, y, w, h, height above the roof, round (1) or not (0). */
  @type(["number"]) casters: number[];
  /** Its graphics not tessellated yet (PrefabRoofs does one at a time, on the frame budget); placed once empty. */
  @type(["object"]) untessellated: PIXI.Graphics[];
  /** Draws face i's windows as shapes into `g` and `lit` (its sharp look), and gives their light on the ground (yage window-light), if any, and their lit glass (PrefabFace.sharpGlass). */
  @type("object") drawSharp: (i: number, g: PIXI.Graphics, lit: PIXI.Graphics) => { ground: PIXI.Geometry | null; lights: WindowLight[]; glass: number[] };
  /** What the breaks in `broken` (brokenIds) cut in face i (render/front-breaks.ts), what its door shows (planDoor: its opening and leaf, or its boards; the room in through it, and its lamp light, if not `seen` into), with the face's size and tones for the cut. */
  @type("object") cutsOf: (i: number, broken: Map<number, string>, door: PlanDoor | null, seen: boolean, lean: number) => { cuts: FrontCut[]; dress: ((g: PIXI.Graphics) => void)[]; room: ((g: PIXI.Graphics) => void)[]; glow: ((g: PIXI.Graphics) => void)[]; len: number; depth: number; wall: number; wood: number };
  /** Its sharp faces' graphics not tessellated yet; swapped in once empty. */
  @type(["object"]) sharpening: PIXI.Graphics[];
}
