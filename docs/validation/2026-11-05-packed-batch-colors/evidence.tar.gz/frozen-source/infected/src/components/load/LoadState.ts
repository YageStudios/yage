import { Component, Schema, type } from "minecs";
import { PathogenTraits } from "../shared/PathogenTraits";
import { LoadAttachment } from "./LoadAttachment";
import { LoadChunk } from "./LoadChunk";
import { LoadParticle } from "./LoadParticle";
import { LoadPulse } from "./LoadPulse";
import { LoadSweat } from "./LoadSweat";
import type { BuildingMoment } from "../../domain/building-events";

@Component()
export class LoadState extends Schema {
  @type("number") clock: number;
  @type("string") pathogen: string;
  @type([LoadChunk]) chunks: LoadChunk[];
  @type([LoadParticle]) particles: LoadParticle[];
  @type([LoadAttachment]) attached: LoadAttachment[];
  @type([LoadPulse]) pulses: LoadPulse[];
  @type([LoadSweat]) sweat: LoadSweat[];
  @type(PathogenTraits) traits: PathogenTraits;
  /** Soldiers aiming, by gid: where their last shot went and until when (clock) they hold it there. */
  @type("object") aims: Map<number, { angle: number; until: number }>;
  /** Soldiers holding something other than the rifle, by gid (a weapon id: "pistol" draws the sidearm). Set by the lab's ridden fighter. */
  @type("object") arms: Map<number, string>;
  /** Each soldier's rifle as drawn (radians), turned towards its aim a little each frame. */
  @type("object") gunAngles: Map<number, number>;
  /** Building events come in on overlays (LoadIngress, world px), for BuildingEventsView to draw and sound. */
  @type("object") buildings: BuildingMoment[];
  /** Soldiers turned to face their aim (LOOK, held in the pawn layer's facings until the aim lapses), by gid. */
  @type("object") faced: Map<number, number>;
}
