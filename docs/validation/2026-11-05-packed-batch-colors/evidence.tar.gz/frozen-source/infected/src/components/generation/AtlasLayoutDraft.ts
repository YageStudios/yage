import { Component, Schema, type } from "minecs";
import type { OpenSpace } from "../../atlas/model";
import type { ChunkGraph } from "../../worldgen/atlas-layout/chunk-graph";
import type { EdgePortal } from "../../worldgen/atlas-layout/portals";
import type { ObjectsNavigator } from "../../worldgen/objects-nav";
import type { Plan } from "../../worldgen/plan";
import type { Instances } from "../../worldgen/prefabs/instances";
import type { ChunkPlace } from "../../worldgen/runtime";
import type { GenerationOwner } from "../../worldgen/source/owner";
import type { Layout, Place, Settlement } from "../../worldgen/terrain/models";
/**
 * Transient atlas chunk-layout generation entity (AtlasTerrain.layout): the chunk's source inputs,
 * then the walking graph, places, spots and households the generation systems build in order.
 */
@Component()
export class AtlasLayoutDraft extends Schema {
  // Inputs, set by AtlasTerrain before the generation world steps.
  @type("object")
  plan: Plan;
  @type("object")
  generation: GenerationOwner;
  @type("number")
  cx: number;
  @type("number")
  cy: number;
  @type("object")
  settlement: Settlement;
  /** Whether the chunk lies inside the space (outside it has no open places). */
  @type("boolean")
  inside: boolean;
  /** The chunk's compiled ground tiles. */
  @type("object")
  tiles: Uint8Array;
  @type("object")
  chunkPlaces: ChunkPlace[];
  /** Objects mode's navigator (and its solid test in world units); absent on the legacy tiles. */
  @type("object")
  nav: ObjectsNavigator | undefined;
  @type("object")
  solid: ((x: number, y: number) => boolean) | undefined;
  @type("number")
  inflow: number;
  // Built by the generation systems.
  @type("object")
  graph: ChunkGraph;
  /** East, west, south and north edge crossings, and their graph nodes. */
  @type("object")
  sides: EdgePortal[];
  @type("object")
  portals: number[];
  @type("object")
  instances: Instances | null;
  @type("object")
  places: Place[];
  @type("object")
  spotX: number[];
  @type("object")
  spotY: number[];
  @type("object")
  households: number[];
  @type("object")
  opens: OpenSpace[];
  @type("object")
  usedOpen: Set<OpenSpace>;
  /** Objects mode: each building's place index by id (open places absent). */
  @type("object")
  ids: Map<string, number>;
  @type("object")
  exits: number[];
  @type("object")
  layout: Layout | null;
}
