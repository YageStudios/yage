import { Component, Schema, type } from "minecs";
import type { PlaceKind } from "../../worldgen/terrain/kinds";
/** A generated home, workplace or open area, instantiated from its authored place entity. */
@Component()
export class GeneratedPlace extends Schema {
  @type("number")
  kind: PlaceKind;
  @type("number")
  x0: number;
  @type("number")
  y0: number;
  @type("number")
  x1: number;
  @type("number")
  y1: number;
  @type("number")
  doorX: number;
  @type("number")
  doorY: number;
  @type("number")
  node: number;
  @type("number")
  beds: number;
  @type("number")
  storeys: number;
  @type("number")
  floorCap: number;
  @type("number")
  capacity: number;
  @type("number")
  residents: number;
  @type("number")
  hh0: number;
  @type("number")
  households: number;
  @type("number")
  spot0: number;
  @type("number")
  spots: number;
  @type("number")
  h: number;
}
