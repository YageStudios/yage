import type { World } from "minecs";
import { Component, Schema, type } from "minecs";
import { CONTENT } from "../../content/runtime";
import type { Segment } from "../../services/life/schedule";
import type { Who } from "../../services/life/who";
import { type Board, type Net } from "../../services/travel/types";
import { LifeSegment } from "./LifeSegment";
import { LifeWho } from "./LifeWho";
import { TravelNetwork } from "./TravelNetwork";
const emptySegment = () => ({ day: 0, index: 0, start: 0, end: 0, act: 0 });
@Component()
export class WorkerTravel extends Schema {
  @type("object")
  lineSalts: Map<string, number>;
  @type(TravelNetwork)
  network: Net;
  @type("boolean")
  ready: boolean;
  @type("object")
  homeTile: number[];
  @type("object")
  workTile: number[];
  @type(LifeSegment)
  scanA: Segment;
  @type(LifeSegment)
  scanB: Segment;
  @type("object")
  fromOut: number[];
  @type("object")
  toOut: number[];
  @type("object")
  loadsOf: WeakMap<Map<number, Board>, Map<number, Uint16Array>>;
  @type(LifeSegment)
  boardSeg: Segment;
  @type("object")
  boardDest: number[];
  @type(LifeWho)
  rideWho: Who;
  @type("object")
  queueOut: number[];
  @type("object")
  tmp3: number[];
}
export const initializeWorkerTravel = (world: World, entity: number) => {
  const fields = world(WorkerTravel).store as unknown as Record<string, unknown[]>;
  fields.lineSalts[entity] = new Map();
  fields.ready[entity] = false;
  world(WorkerTravel, entity).network = { index: null, trips: new Map(), riders: new Map(), scans: new Map(), stops: new Map(), ents: new Map(), queues: new Map(), current: new Map() };
  fields.homeTile[entity] = [0, 0];
  fields.workTile[entity] = [0, 0];
  world(WorkerTravel, entity).scanA = emptySegment();
  world(WorkerTravel, entity).scanB = emptySegment();
  fields.fromOut[entity] = [0, 0, 0];
  fields.toOut[entity] = [0, 0, 0];
  fields.loadsOf[entity] = new WeakMap();
  world(WorkerTravel, entity).boardSeg = emptySegment();
  fields.boardDest[entity] = [0, 0, 0];
  world(WorkerTravel, entity).rideWho = { gid: 0, role: 0, family: 0, rank: 0, traits: 0, culture: CONTENT.cultures[0], hcx: 0, hcy: 0, walk: 0 };
  fields.queueOut[entity] = [0, 0];
  fields.tmp3[entity] = [0, 0, 0];
};
