import { Component, Schema, defaultValue, type } from "minecs";
import type { TownResponseSeries } from "./TownResponseSeries";
import type { TownResponseState } from "./TownResponseState";

/**
 * A town of the region's response (one `region:town` entity per world-map place, in place order).
 * The town owns its rows: `state` and `series` are no one else's (the HUD, the views and the hosts'
 * configure read a copy: ResponseExport), and the systems that step a town query TownResponse with
 * that system's own per-town state.
 */
@Component()
export class TownResponse extends Schema {
  /** The town's place index (its row in the export and on the world map). */
  @type("number") @defaultValue(-1) index: number;
  /** The page's own view of the town (awareness, ladder, hospital, research...). */
  @type("object") state: TownResponseState;
  /** The append-only series the hosts hear of. */
  @type("object") series: TownResponseSeries;
  /** This pass, before the towns stepped: its level and whether its hospital was full (for the news). */
  @type("number") @defaultValue(0) levelBefore: number;
  @type("boolean") @defaultValue(false) fullBefore: boolean;
}
