import { Component, Schema, type } from "minecs";
import type { PlanningContext } from "../../worldgen/commute/context";
@Component()
export class PopulationRequest extends Schema {
  @type("number")
  cx: number;
  @type("number")
  cy: number;
  @type("object")
  context: PlanningContext;
}
