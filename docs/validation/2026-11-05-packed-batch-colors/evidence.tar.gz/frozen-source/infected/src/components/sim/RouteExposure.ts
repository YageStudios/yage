import { Schema, type } from "minecs";
export class RouteExposure extends Schema {
  @type("object")
  cells: Float32Array | null;
  @type("number")
  water: number;
  @type("number")
  level: number;
  @type("number")
  day: number;
  @type("number")
  t: number;
}
