import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/** Put the town's response ladder at `level`, asked by `role`'s command; TownPolicySystem drains them on the region's pass. */
export type TownPolicyOrder = { kind: "level"; level: number; role: string; command: string };

@Component()
export class TownPolicyOrders extends Commands<TownPolicyOrder> {}
