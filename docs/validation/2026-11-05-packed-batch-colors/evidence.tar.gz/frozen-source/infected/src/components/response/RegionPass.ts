import { Component, nullable, Schema, type } from "minecs";
import { RegionPassRow } from "./RegionPassRow";

/** The region's pass this frame (region:response), set by RegionCadenceSystem on pass frames and cleared on the next frame. */
@Component()
export class RegionPass extends Schema {
  @nullable() @type(RegionPassRow) pass: RegionPassRow | null;
  /** The HUD's refresh this frame, four times a second by the frame clock (the pass itself, running free). */
  @nullable() @type(RegionPassRow) shown: RegionPassRow | null;
}
