import { Component, Schema, type } from "minecs";
import type { RoleResult } from "./ActionResults";

/** The role's latest results, oldest first (bounded); `next` counts every result ever logged, so readers keep their own cursor. */
@Component()
export class RoleResultLog extends Schema {
  @type(["object"]) results: RoleResult[];
  @type("number") next: number;
}
