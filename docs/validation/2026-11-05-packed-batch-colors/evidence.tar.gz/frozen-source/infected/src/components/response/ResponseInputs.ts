import { Component, Schema, type } from "minecs";
import type { WorldMap } from "../../worldmap/places";
import { ResponseCount } from "./ResponseCount";
import { ResponseTraits } from "./ResponseTraits";
import type { PlanningContext } from "../../worldgen/commute/context";
@Component()
export class ResponseInputs extends Schema {
  @type("object") planning: PlanningContext;
  @type("object") map: WorldMap;
  @type([ResponseCount]) counts: ResponseCount[];
  @type(ResponseTraits) traits: ResponseTraits;
}
