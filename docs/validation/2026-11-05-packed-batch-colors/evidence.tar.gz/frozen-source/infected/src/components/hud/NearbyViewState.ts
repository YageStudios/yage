import { Component, Schema, type } from "minecs";
import { NearbySpotRow } from "../scene/NearbySpotRow";

/** The Nearby panel's notable places (hud:nearby), found once the active atlas can plan them. */
@Component()
export class NearbyViewState extends Schema {
  @type("boolean") found: boolean;
  @type([NearbySpotRow]) spots: NearbySpotRow[];
}
