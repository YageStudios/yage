import { Component } from "minecs";
import { Commands } from "yage/world/commands";
import type { RoleAction } from "./RoleIntents";

/** What the player's input asked, with the binding epoch the client saw; PlayerIntentSystem drains them into the role's intents. */
export type PlayerIntent = { action: RoleAction; epoch: number };

@Component()
export class PlayerIntents extends Commands<PlayerIntent> {}
