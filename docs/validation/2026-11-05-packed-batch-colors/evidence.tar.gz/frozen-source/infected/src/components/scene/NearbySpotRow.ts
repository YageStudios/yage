import { Schema, type } from "minecs";
import type { NearbyKind } from "../../ui/nearby";

/** A notable place for the Nearby panel (tiles). */
export class NearbySpotRow extends Schema {
  @type("string") kind: NearbyKind;
  @type("string") label: string;
  @type("string") name: string;
  @type("string") icon: string;
  @type("number") x: number;
  @type("number") y: number;
  @type("number") r: number;
}
