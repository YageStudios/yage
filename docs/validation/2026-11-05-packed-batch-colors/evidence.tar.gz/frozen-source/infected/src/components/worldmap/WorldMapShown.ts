import type { OperationalFrame } from "../../domain/strategy/history";
import { Component, nullable, Schema, type } from "minecs";
import type { Track } from "../../worldmap/track";

/** The track the world view draws instead of the run's own (a replay's scrub: ReplayViewSystem); none, the run's. */
@Component()
export class WorldMapShown extends Schema {
  @type("number") tick: number = -1;
  @nullable() @type("object") track: Track | null;
  @nullable() @type("object") operations: OperationalFrame | null;
}
