import { Component, nullable, Schema, type } from "minecs";
import type { ChunkPool } from "yage/streaming";

/**
 * The pool the run's hosts report through and take commands from (run:transport); TransportCleanup
 * destroys it. `cold` holds the bytes of chunks that went cold: the run's, so they outlive any
 * client's streamer (a client streams with it, services/run.ts), and a checkpoint keeps them.
 */
@Component()
export class AuthorityTransport extends Schema {
  @type("object") pool: ChunkPool;
  /** Geographic NPC slots held by loaded, pending and retiring chunks. */
  @nullable() @type("object") populationReservations: Map<number, number> | null;
  @type("object") cold: Map<number, Uint8Array>;
}
