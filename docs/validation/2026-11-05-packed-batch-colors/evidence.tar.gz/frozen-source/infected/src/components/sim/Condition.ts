import { Component, defaultValue, Schema, type } from "minecs";

/**
 * Disease state (see `State` in disease.ts) and seconds left in it. Registered as "Condition", not
 * "Health": yage has its own Health schema, and minecs aliases @Components that share a name.
 */
@Component("Condition")
export class Condition extends Schema {
  @type("uint8")
  @defaultValue(0)
  state: number;

  @type("float32")
  @defaultValue(0)
  timer: number;
}
