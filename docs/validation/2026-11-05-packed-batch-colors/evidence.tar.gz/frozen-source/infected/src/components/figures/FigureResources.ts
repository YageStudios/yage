import { Schema, type } from "minecs";
import type { ChunkLayer, ChunkScene } from "yage/streaming/layer";

/** Per-layer GPU instances share their parent scene's pawn assets. */
export class FigureResources extends Schema {
  @type("object") scene: ChunkScene;
  @type("object") layers: Map<number, ChunkLayer>;
}
