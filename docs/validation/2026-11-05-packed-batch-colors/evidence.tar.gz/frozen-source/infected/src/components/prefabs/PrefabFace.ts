import { Schema, type, nullable } from "minecs";
import type * as PIXI from "pixi.js";
import type { WindowLight, WindowLightMesh } from "yage/streaming/window-light";
export class PrefabFace extends Schema {
  @type("object") g: PIXI.Graphics;
  @type("object") lit: PIXI.Graphics;
  /** The light out of its lit street-level windows onto the ground (yage window-light), if any. */
  @type("object") ground: PIXI.Geometry | null;
  @type(["number"]) at: [number, number, number];
  /** The face with its windows drawn as shapes rather than from the baked sheet (PrefabRoofs draws it zoomed in, frees it zoomed out). */
  @nullable() @type("object") sharp: PIXI.Graphics | null;
  @nullable() @type("object") sharpLit: PIXI.Graphics | null;
  /** Its sharp look's light on the ground: its shapes pick their own lit windows. */
  @nullable() @type("object") sharpGround: PIXI.Geometry | null;
  /** Its sharp look's lit windows' open glass (face px), six numbers each: x0, y0, x1, y1, storey, its floor (face y); where someone in the room shows against the light. */
  @nullable() @type(["number"]) sharpGlass: number[] | null;
  /** Its sharp look's street-level lit openings (yage window-light), for that light again with people in the way. */
  @nullable() @type(["object"]) sharpLights: WindowLight[] | null;
  /** The buildings' fronts drawn with it (each a front, its lit windows and their light on the ground), swapped between the two as the zoom changes. */
  @type(["object"]) placed: { front: PIXI.Graphics; lit: PIXI.Graphics; ground: WindowLightMesh; sharp: boolean }[];
}
