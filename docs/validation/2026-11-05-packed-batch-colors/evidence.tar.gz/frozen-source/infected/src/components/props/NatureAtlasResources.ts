import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import type { ChunkLayerStyle } from "yage/streaming/layer";
@Component()
export class NatureAtlasResources extends Schema {
  @type("object") art: HTMLCanvasElement;
  @type("object") mask: HTMLCanvasElement;
  @type("object") textures: Set<PIXI.Texture>;
  @type("object") style: ChunkLayerStyle;
}
