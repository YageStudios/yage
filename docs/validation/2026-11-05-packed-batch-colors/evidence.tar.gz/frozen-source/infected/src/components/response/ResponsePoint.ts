import { Schema, type } from "minecs";

export class ResponsePoint extends Schema {
  @type("number") x: number;
  @type("number") y: number;
}
