import { Component, defaultValue, Schema, type } from "minecs";

/** The strain's points (world:strain): everyone it has ever infected and the evolution points that earned. EvolutionProgressSystem accrues them. */
@Component()
export class EvolutionBudget extends Schema {
  @type("number") @defaultValue(0) absorbed: number;
  @type("number") @defaultValue(0) earned: number;
}
