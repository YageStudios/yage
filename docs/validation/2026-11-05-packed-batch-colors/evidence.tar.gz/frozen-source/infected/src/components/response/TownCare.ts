import { Schema, type } from "minecs";

export class TownCare extends Schema {
  @type("number") staff: number;
  @type("number") tents: number;
  @type("number") vax: number;
}
