import type { RegionLoader } from "../../realworld/region-loader";
import type { TransitIndex } from "../../worldgen/transit";
import { Component, Schema, type } from "minecs";
import type { AtlasTerrain } from "../../worldgen/layout";
import type { Plan } from "../../worldgen/plan";
import type { ChunkContent } from "../../worldgen/runtime";
@Component()
export class SourcePlans extends Schema {
  @type("object")
  regionLoader: RegionLoader | null;
  @type("object")
  terrains: Map<number, AtlasTerrain>;
  @type("object")
  plans: Map<number, Plan>;
  @type("object")
  geographic: Map<number, Plan>;
  @type("object")
  geographicTransit: TransitIndex | null;
  @type("object")
  chunks: Map<string, ChunkContent>;
}
