import { Component, defaultValue, Schema, type } from "minecs";

/**
 * A host report held for the step that covers its tick: a chunk's counts, (kind "locate") where a
 * role's host was, (kind "absorb") a chunk's world as it went cold (WarmSetSystem), or (kind "exit")
 * people who walked into a cold chunk (ColdCrossingSystem), after its absorb. Applied in
 * (tick, key, kind) order. Its chunk, kind and bytes go into a checkpoint taken while it waits.
 */
export type HeldReport = { tick: number; key: number; cx: number; cy: number; bytes: Uint8Array; kind?: "locate" | "absorb" | "exit"; /** An exit's: the chunk it left. */ from?: number; apply: () => void };

const RANK = { locate: 1, absorb: 2, exit: 3 } as const;

/** The order held reports apply in: by tick, then chunk, a chunk's counts, then its located hosts, then its absorb, then the exits into it by the chunk they left. */
export const heldOrder = (p: Pick<HeldReport, "tick" | "key" | "kind" | "from">, q: Pick<HeldReport, "tick" | "key" | "kind" | "from">) =>
  p.tick - q.tick || p.key - q.key || (p.kind ? RANK[p.kind] : 0) - (q.kind ? RANK[q.kind] : 0) || (p.from ?? 0) - (q.from ?? 0);

/**
 * The authority's step (run:clock). In lockstep the authority acts on sim ticks, not frames: the
 * step at `tick` runs on the first frame after the pool has committed it, every STEP_TICKS ticks,
 * with what the hosts reported for the ticks before it, and nothing it sends lands before the tick
 * the step fixes (services/authority-time.ts). Running free (a remote server), every frame is a
 * step, at the newest tick the hosts reported.
 */
@Component()
export class AuthorityStep extends Schema {
  @type("boolean") @defaultValue(false) geographicLoading: boolean;
  /** This frame's step tick; -1 when this frame isn't one. */
  @type("number") @defaultValue(-1) tick: number;
  /** The latest step's tick (the authority's time between steps). */
  @type("number") @defaultValue(0) last: number;
  /** In lockstep, the next step's tick. */
  @type("number") @defaultValue(0) next: number;
  /** In lockstep, host reports waiting for their step (PoolIngress). */
  @type("object") held: HeldReport[];
  /** A replay holds the step for a frame while it applies the commands recorded between steps. */
  @type("boolean") @defaultValue(false) hold: boolean;
}
