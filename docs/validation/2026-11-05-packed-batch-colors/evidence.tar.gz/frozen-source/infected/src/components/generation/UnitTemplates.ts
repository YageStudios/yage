import { Component, Schema, type } from "minecs";
import type { BuildingPlan } from "../../atlas/objects";
import type { Template } from "../../worldgen/terrain/models";
import type { NativeUnit } from "../../worldgen/native-floor";
@Component()
export class UnitTemplates extends Schema {
  /** Upright templates by key/w/h, as makeTemplate built them. */
  @type("object")
  built: Map<string, Template>;
  @type("object")
  turned: Map<string, Template>;
  @type("object")
  plans: Map<string, BuildingPlan>;
  /** Measured buildings' floor specs by plan key: planByKey builds (and briefly keeps) their plans. */
  @type("object")
  natives: Map<string, NativeUnit>;
  /** Built native plans, least recently used first, at most NATIVE_PLANS (prefabs/catalog.ts). */
  @type("object")
  nativePlans: Map<string, BuildingPlan>;
}
