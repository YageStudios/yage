import { Schema, type } from "minecs";
import type { Climate } from "../../domain/disease";

/** A town patient zero can start in (chunk coordinates, the world map's name for it). */
export class StartTownRow extends Schema {
  @type("number") cx: number;
  @type("number") cy: number;
  @type("string") name: string;
  @type("string") climate: Climate;
  @type("boolean") city: boolean;
  @type("number") size: number;
}
