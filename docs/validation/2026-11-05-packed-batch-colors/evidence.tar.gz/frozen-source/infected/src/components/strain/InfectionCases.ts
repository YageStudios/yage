import { Component, defaultValue, Schema, type } from "minecs";

/** An infection's children where the page can see them (the hot chunks' reports, added up): incubating, sick, dead. */
@Component()
export class InfectionCases extends Schema {
  @type("number") @defaultValue(0) incubating: number;
  @type("number") @defaultValue(0) sick: number;
  @type("number") @defaultValue(0) dead: number;
}
