import { Component, Schema, type } from "minecs";
import type { District, Rect } from "../../atlas/model";
import type { RoadNetwork } from "../../worldgen/network/model";
import type { Plan } from "../../worldgen/plan";
import type { CemeteryLayout } from "../../worldgen/cemetery";
import type { OpenSpace } from "../../atlas/model";
import type { FrontPaths } from "../../worldgen/prefabs/front-paths";
import type { Instances } from "../../worldgen/prefabs/instances";
@Component()
export class PlanProjections extends Schema {
  @type("object")
  networks: WeakMap<Plan, RoadNetwork>;
  @type("object")
  districts: WeakMap<Plan, {
    d: District;
    box: Rect;
  }[]>;
  @type("object")
  instances: WeakMap<Plan, Instances>;
  @type("object")
  paths: WeakMap<Plan, FrontPaths>;
  /** District lookups the chunk art reads. */
  @type("object")
  lookups: WeakMap<Plan, (x: number, y: number) => District | null>;
  /** Cemetery layouts in this source's culture (wall and trees). */
  @type("object")
  cemeteries: WeakMap<OpenSpace, CemeteryLayout>;
}
