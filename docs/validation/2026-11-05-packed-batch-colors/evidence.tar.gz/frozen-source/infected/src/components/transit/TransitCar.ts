import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
export class TransitCar extends Schema {
  @type("object") root: PIXI.Container;
  @type("object") body: PIXI.Graphics;
  @type("object") shadow: PIXI.Graphics;
  @type("object") lit: PIXI.Graphics;
}
