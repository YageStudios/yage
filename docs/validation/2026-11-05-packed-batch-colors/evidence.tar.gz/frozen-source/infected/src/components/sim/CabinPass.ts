import { Component, Schema, type } from "minecs";
import type { Traits } from "../../domain/disease";
import type { Ride } from "../../services/cabin";
import { PathogenTraits } from "../shared/PathogenTraits";
/** One chunk's riders and source columns, handed explicitly to the worker's pool systems. */
@Component()
export class CabinPass extends Schema {
  @type("object")
  riders: readonly number[];
  @type("object")
  rides: readonly Ride[];
  @type("object")
  waiters: readonly number[];
  @type("object")
  stations: readonly number[];
  @type("object")
  states: ArrayLike<number>;
  @type("number")
  tick: number;
  @type("number")
  ticks: number;
  @type("number")
  dt: number;
  @type(PathogenTraits)
  traits: Traits;
  @type("object")
  rate: Float32Array;
  @type("number")
  rats: number;
  /** The host's lockstep lead (0: running free): while set, appends and tallies only go out in the post. */
  @type("number")
  lead: number;
}
