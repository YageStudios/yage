import { Component } from "minecs";
import { Commands } from "yage/world/commands";
import type { LogTone } from "../../domain/chronicle";

/** Signals waiting for LeftColumnPanels to stamp and append to its chronicle. */
export type LeftColumnCommand = { text: string; kind: LogTone };

@Component()
export class LeftColumnCommands extends Commands<LeftColumnCommand> {}
