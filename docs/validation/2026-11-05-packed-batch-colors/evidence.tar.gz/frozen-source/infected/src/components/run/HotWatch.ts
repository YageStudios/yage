import type { GeographicWatchState } from "../../services/geographic-watch";
import { Component, Schema, type, nullable } from "minecs";
import type { HotFocus, HotSet } from "yage/streaming";
import { Commands } from "yage/world/commands";

/** A viewer's view as it asks the run to simulate it closely (in chunks), or null when it goes. */
export type WatchCommand = { viewer: string; view: HotFocus | null };

/** What the run's viewers ask to watch closely (each client's ChunkStreaming); HotWatchSystem drains them on its steps. */
@Component()
export class HotWatchCommands extends Commands<WatchCommand> {}

/**
 * Which chunks the run simulates closely (run:hot): every viewer's last view, and the hot set they
 * make together (yage HotSet), as stamped on the hosts. Any number of viewers, each its own hot area.
 */
@Component()
export class HotWatch extends Schema {
  @nullable() @type("object") geographic: GeographicWatchState | null;
  @type("object") views: Map<string, HotFocus>;
  @type("object") hot: HotSet;
}
