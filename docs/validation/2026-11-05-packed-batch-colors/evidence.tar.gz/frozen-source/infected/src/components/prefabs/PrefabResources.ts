import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import type { StaticInstance } from "yage/streaming/statics";
import { PrefabFloor } from "./PrefabFloor";
import { PrefabTop } from "./PrefabTop";
import { PrefabSnowRoof } from "./PrefabSnowRoof";
import { PrefabStall } from "./PrefabStall";
import { PrefabChunk } from "./PrefabChunk";
import type { PrefabInterior } from "./PrefabInterior";
import type { Swing } from "../../render/doors";
/** A building's fade: from one alpha to another, started `at` (ms); `wanted` is when it was last asked to be faded. */
/** A bullet hole in a building's wall: where (its frame, px, already lifted up the face) and its seed for how it chipped. */
export type PrefabHole = { x: number; y: number; seed: number };
export type PrefabFade = { from: number; to: number; at: number; wanted: number };
@Component()
export class PrefabResources extends Schema {
  @type("object") textures: Set<PIXI.Texture>;
  @type("object") geometries: Set<PIXI.Geometry>;
  @type("object") shaders: Set<PIXI.Shader>;
  @type("object") graphics: Set<PIXI.Graphics>;
  @type("object") program: PIXI.Program;
  @type([PrefabFloor]) floors: PrefabFloor[];
  @type([PrefabTop]) tops: PrefabTop[];
  @type([PrefabSnowRoof]) snowRoofs: PrefabSnowRoof[];
  @type([PrefabStall]) stalls: PrefabStall[];
  @type([PrefabChunk]) chunks: PrefabChunk[];
  @type("object") litWindows: Set<PIXI.Container>;
  /** Buildings fading (PrefabPresentation), each with where its fade runs from and to. */
  @type("object") fading: Map<StaticInstance, PrefabFade>;
  /** Each building's inside, by its over part (the holder PrefabRoofs places the roof in). */
  @type("object") interiors: Map<PIXI.Container, PrefabInterior>;
  /** Each front door swung open with the traffic through it (PrefabFloors), by render/doors.ts swingKey; its front shows it open too (PrefabRoofs). */
  @type("object") swings: Map<string, Swing>;
  /** The bullet holes in each building's walls (its own frame, px), by prefab id: kept while it unloads and redrawn when it comes back. */
  @type("object") holes: Map<string, PrefabHole[]>;
  /** Each building's over part while built, by prefab id: where its holes draw. */
  @type("object") overs: Map<string, PIXI.Container>;
}
