import type { World } from "minecs";
import { Component, Schema, type } from "minecs";
import type { Template } from "../../worldgen/terrain/models";
@Component()
export class WorkerGeometry extends Schema {
  @type("object")
  blockedTiles: Map<Template, Uint8Array>;
  @type("object")
  wayOut: number[];
  /** Row setters copy typed arrays; a private owner object lets large interiors grow them. */
  @type("object")
  routing: { dist: Int32Array; bfsQueue: Int32Array };
}
export const initializeWorkerGeometry = (world: World, entity: number) => {
  const fields = world(WorkerGeometry).store as unknown as Record<string, unknown[]>;
  fields.blockedTiles[entity] = new Map();
  fields.wayOut[entity] = [0, 0];
  fields.routing[entity] = { dist: new Int32Array(4096), bfsQueue: new Int32Array(4096) };
};
