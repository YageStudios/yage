import { Component, defaultValue, Schema, type } from "minecs";

/** Clock interpolation and derived light belong to this scene, never a module singleton. */
@Component()
export class GroundLighting extends Schema {
  @type("number") @defaultValue(-1) tick: number;
  /** A debug time of day (0..1) pins the clock; a typed column can't hold null, so the flag says whether it is set. */
  @type("boolean") @defaultValue(false) timePinned: boolean;
  @type("number") @defaultValue(0) debugTime: number;
  @type("number") base: number;
  @type("number") since: number;
  @type("number") shown: number;
  @type("number") last: number;
  @type("number") time: number;
  @type("number") night: number;
  @type("number") tint: number;
  @type("number") seconds: number;
}
