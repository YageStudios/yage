import { Schema, type } from "minecs";
import { TownResponseSeries } from "./TownResponseSeries";
export class ResponseState extends Schema {
  @type([TownResponseSeries]) towns: TownResponseSeries[];
}
