import type { World } from "minecs";
import { Component, Schema, type } from "minecs";
@Component()
export class WorkerRoutineScratch extends Schema {
  @type("object")
  routineOut: [
    number,
    number,
    number
  ];
  @type("object")
  workAt: number[];
}
export const initializeWorkerRoutineScratch = (world: World, entity: number) => {
  const fields = world(WorkerRoutineScratch).store as unknown as Record<string, unknown[]>;
  fields.routineOut[entity] = [0, 0, 0];
  fields.workAt[entity] = [0, 0];
};
