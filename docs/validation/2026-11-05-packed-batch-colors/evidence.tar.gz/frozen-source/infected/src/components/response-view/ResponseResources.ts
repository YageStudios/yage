import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import { FigureResources } from "../figures/FigureResources";
@Component()
export class ResponseResources extends Schema {
  @type("object")
  street: PIXI.Graphics;
  @type("object")
  vans: PIXI.Graphics;
  @type("object")
  lights: PIXI.Graphics;
  @type("object")
  fronts: PIXI.Graphics;
  @type("object")
  flames: PIXI.Graphics;
  @type("object")
  signs: PIXI.Container;
  @type(["object"])
  signPool: PIXI.Text[] = [];
  @type(FigureResources)
  figures: FigureResources;
}
