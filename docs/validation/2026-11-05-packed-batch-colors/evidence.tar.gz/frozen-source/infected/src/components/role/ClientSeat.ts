import { Component, Schema, type } from "minecs";

/** The role this client plays or watches (client:session): its camera, HUD and input follow that role's actor. `seen` is how far it has read the role's results (RoleResultToasts). */
@Component()
export class ClientSeat extends Schema {
  @type("string") role: string;
  @type("number") seen: number;
}
