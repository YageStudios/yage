import { Schema, type } from "minecs";
import { ViralEmission } from "../sim/ViralEmission";

export class LoadEmission extends Schema {
  @type(ViralEmission) emission: ViralEmission;
  @type("number") born: number;
}
