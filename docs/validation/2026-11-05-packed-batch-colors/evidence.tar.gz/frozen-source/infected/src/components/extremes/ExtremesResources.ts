import { Component, nullable, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import { FigureResources } from "../figures/FigureResources";

/**
 * The scene's extreme-weather GPU and canvas handles. Each is recorded the moment it is made, so
 * cleanup releases exactly what exists (also after a failed init) and nothing of another scene.
 */
@Component()
export class ExtremesResources extends Schema {
  /** Flood sprites under everything that stands, and the ripples over them. */
  @nullable() @type("object") floodRoot: PIXI.Container | null = null;
  @nullable() @type("object") ripples: PIXI.Graphics | null = null;
  /** Barriers and signs under the pawns; banners, lamps and sunk cars over them. */
  @nullable() @type("object") ground: PIXI.Graphics | null = null;
  @nullable() @type("object") over: PIXI.Graphics | null = null;
  @nullable() @type("object") flames: PIXI.Graphics | null = null;
  @nullable() @type("object") glow: PIXI.Graphics | null = null;
  @nullable() @type(FigureResources) figures: FigureResources | null = null;
  @nullable() @type("object") labelRoot: PIXI.Container | null = null;
  /** Centre banner labels by text. */
  @type("object") labels: Map<string, PIXI.Text>;
  /** Screen space: the blowing-snow veil (canvas, its texture and sprite), then haze and lightning. */
  @nullable() @type("object") veilCanvas: HTMLCanvasElement | null = null;
  @nullable() @type("object") veilContext: CanvasRenderingContext2D | null = null;
  @nullable() @type("object") veilTexture: PIXI.Texture | null = null;
  @nullable() @type("object") veil: PIXI.Sprite | null = null;
  @nullable() @type("object") screen: PIXI.Graphics | null = null;
  /** Painted flood sprites by "cx,cy" (each owns its canvas texture). */
  @type("object") floodSprites: Map<string, PIXI.Sprite>;
}
