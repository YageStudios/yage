import { Schema, type } from "minecs";
import { numberLists } from "./series";
export class BorderGateState extends Schema {
  @numberLists(true) status: [number, number][];
  @type("number") changed: number;
  @type("number") caught: number;
  @type("number") held: number;
  @type("number") out: number;
  @type("number") smuggled: number;
}
