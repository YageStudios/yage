import { nullable, Schema, type } from "minecs";

/** A car in a chunk's streets (chunk-local tiles); `body` set for one drawn here, stalled in the flood. */
export class ExtremesCar extends Schema {
  @type("number") x: number;
  @type("number") y: number;
  @type("number") w: number;
  @type("number") h: number;
  @nullable() @type("number") body?: number;
}
