import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import { ViralCloud } from "../sim/ViralCloud";

export class LoadCloud extends Schema {
  @type(ViralCloud) motion: ViralCloud;
  @type("number") seed: number;
  @type(["object"]) sprites: PIXI.Sprite[];
}
