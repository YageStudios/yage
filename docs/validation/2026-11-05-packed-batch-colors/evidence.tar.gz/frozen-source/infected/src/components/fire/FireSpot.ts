import { Schema, nullable, type } from "minecs";
import type { FireKind } from "../../render/fire";
export class FireSpot extends Schema {
  @type("string") kind: FireKind;
  @type("number") x: number;
  @type("number") y: number;
  @nullable() @type(["number"]) corners?: number[] | null;
  @type("number") size: number;
  @type("number") heat: number;
  @type("number") smoke: number;
  @type("number") seed: number;
}
