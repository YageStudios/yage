import { Component, Schema, defaultValue, type } from "minecs";

/** The player's sound settings (persisted through src/persistence/settings.ts). */
@Component()
export class AudioSettings extends Schema {
  @type("boolean") @defaultValue(false) muted: boolean;
  @type("number") @defaultValue(1) volume: number;
}
