import { Component, Schema, type } from "minecs";
import type { ChunkScene } from "yage/streaming/layer";
import type { GroundHandle } from "../../services/ground/context";

/**
 * The chunk view's drawing (view:chunks): the chunk scene that draws its chunks and the ground handle under them.
 * ChunkViews destroys the chunk scene with its entity.
 */
@Component()
export class ChunkSceneResources extends Schema {
  @type("object") scene: ChunkScene;
  @type("object") ground: GroundHandle;
}
