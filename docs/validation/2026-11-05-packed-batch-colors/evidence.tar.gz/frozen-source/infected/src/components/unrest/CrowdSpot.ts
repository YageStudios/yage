import { Schema, type } from "minecs";
export class CrowdSpot extends Schema {
  @type("number") x: number;
  @type("number") y: number;
  @type("boolean") riot: boolean;
}
