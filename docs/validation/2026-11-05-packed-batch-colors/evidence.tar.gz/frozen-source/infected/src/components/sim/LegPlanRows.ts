import { Component, Schema, type } from "minecs";
import type { Segment } from "../../services/life/schedule";

/** The leg a rejoining walker starts on (RejoinSystem decides, LegPlanSystem writes it). */
export const enum LegPlan {
  /** Inside their destination: on to their spot there. */
  Spot = 0,
  /** Inside another place: out of it (`at` is the place's index in this chunk). */
  Leave = 1,
  /** Nowhere to head for: stay put until `at` (the segment's end). */
  Dwell = 2,
  /** To the graph node `at` in this chunk, and along the graph from there. */
  Join = 3,
}

/** Rejoin's plan rows this step, in the order it made them. */
@Component()
export class LegPlanRows extends Schema {
  @type("object") eid: number[];
  @type("object") plan: LegPlan[];
  @type("object") at: number[];
  /** Spot rows: the segment as Rejoin had it when it chose (the spot is picked for it). */
  @type("object") segment: (Segment | null)[];
}

export const clearLegPlanRows = (rows: LegPlanRows) => {
  rows.eid = [];
  rows.plan = [];
  rows.at = [];
  rows.segment = [];
};
