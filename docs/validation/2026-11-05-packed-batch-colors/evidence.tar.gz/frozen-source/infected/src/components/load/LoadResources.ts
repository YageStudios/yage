import { Component, Schema, type } from "minecs";
import type { DepthQuads } from "yage/streaming/depth-quads";
import type * as PIXI from "pixi.js";
import type { PawnSource } from "../../domain/pawns";
import type { RingTextures } from "../../render/load/ring-textures";
import type { Anchors } from "../../services/surfaces";

@Component()
export class LoadResources extends Schema {
  @type("object") floor: PIXI.Container;
  /** People's load rings: pooled sprites (LoadRings shows this frame's, hides the rest). */
  @type("object") rings: PIXI.Container;
  @type(["object"]) ringSprites: PIXI.Sprite[];
  /** Ring textures by line-width tier (render/load/ring-textures.ts), built as zooms ask for them. */
  @type("object") ringTextures: Map<number, RingTextures>;
  @type("object") furniture: PIXI.Container;
  @type("object") air: PIXI.Container;
  @type("object") puff: PIXI.Texture;
  @type("object") glint: PIXI.Texture;
  @type("object") drop: PIXI.Texture;
  /** Soldiers' rifles and the hands on them (LoadGuns): in the pawns' depth, each at its soldier's feet. */
  @type("object") guns: PIXI.Container;
  @type("object") rifles: DepthQuads;
  @type("object") pistols: DepthQuads;
  @type("object") pistol: PIXI.Texture;
  @type("object") hands: DepthQuads;
  @type("object") gun: PIXI.Texture;
  @type("object") hand: PIXI.Texture;
  @type(["object"]) stains: PIXI.Texture[];
  @type(["object"]) sheens: PIXI.Texture[];
  @type(["object"]) bloods: PIXI.Texture[];
  @type(["object"]) splats: PIXI.Texture[];
  @type("object") tiles: Map<number, Uint8Array>;
  @type("object") anchors: Map<number, Anchors | null>;
  @type("object") bySource: Map<number, PawnSource>;
}
