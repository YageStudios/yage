import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/** Where the player's shots met a wall (world px), the way they flew, and a seed for how high the hole sits; only PrefabStatics drains this queue. */
export type PrefabHoleRequest = { x: number; y: number; ux: number; uy: number; seed: number };

@Component()
export class PrefabHoleRequests extends Commands<PrefabHoleRequest> {}
