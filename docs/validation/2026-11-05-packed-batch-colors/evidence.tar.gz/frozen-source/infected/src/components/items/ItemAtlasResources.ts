import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import type { ChunkLayerStyle } from "yage/streaming/layer";
/** External CPU/GPU handles belong to one scene and are released with it. */
@Component()
export class ItemAtlasResources extends Schema {
  @type("object") atlases: Set<PIXI.Texture>;
  @type("object") styles: ChunkLayerStyle[];
  @type("object") textures: Map<string, PIXI.Texture | null>;
  @type("object") standalone: Set<PIXI.Texture>;
}
