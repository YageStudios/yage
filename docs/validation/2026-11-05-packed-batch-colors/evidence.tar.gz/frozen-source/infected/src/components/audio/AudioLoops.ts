import { Component, Schema, type } from "minecs";
import { AudioLoop } from "./AudioLoop";

/** The scene's beds (town, rain, wind) and one loop per kind of placed source. */
@Component()
export class AudioLoops extends Schema {
  @type(AudioLoop) town: AudioLoop;
  @type(AudioLoop) rain: AudioLoop;
  @type(AudioLoop) wind: AudioLoop;
  @type(AudioLoop) fire: AudioLoop;
  @type(AudioLoop) gunfire: AudioLoop;
  @type(AudioLoop) crowd: AudioLoop;
}

export type AudioLoopName = "town" | "rain" | "wind" | "fire" | "gunfire" | "crowd";
export const AUDIO_LOOP_NAMES: readonly AudioLoopName[] = ["town", "rain", "wind", "fire", "gunfire", "crowd"];
