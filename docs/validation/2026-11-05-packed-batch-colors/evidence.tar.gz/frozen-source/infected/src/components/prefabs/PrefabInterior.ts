import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
/**
 * A building's inside (floor and furniture), kept out of the scene until someone looks in: built
 * the first time its roof fades, and hidden whenever its roof stands whole over it.
 */
export class PrefabInterior extends Schema {
  /** Holds the floor and furniture; under the building's shadow-free under part. */
  @type("object") layer: PIXI.Container;
  /** Builds the floor and furniture into `layer`; null once done. */
  @type("object") furnish: (() => void) | null;
  /** The building's roof and fronts are placed (PrefabRoofs), so they cover the inside. */
  @type("boolean") roofed: boolean;
}
