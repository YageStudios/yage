import { Component, defaultValue, Schema, type } from "minecs";

/**
 * Everyday life (src/services/life.ts): where someone lives and works, and where they are in their day.
 * Places are indices into `chunkLayout(cx, cy).places`. The home chunk comes from the gid; other
 * chunks are stored as small offsets from it. Who they are (name, family, traits) is derived from
 * the gid by people.ts and not stored.
 */
@Component()
export class Life extends Schema {
  /** Home place, and bed slot in it (flat × 3 + member in apartments). */
  @type("uint16") @defaultValue(0) home: number;
  @type("uint8") @defaultValue(0) slot: number;
  /** Side of the home chunk the workplace chunk lies on, 255 for the home chunk itself. */
  @type("uint8") @defaultValue(255) wdir: number;
  /** Workplace, school or field; 65535 for none. */
  @type("uint16") @defaultValue(65535) work: number;
  /** Rank among the staff or pupils there (who sits at the desks in view); 255 for none. */
  @type("uint8") @defaultValue(255) seat: number;
  /** LifeRole: whose schedule they follow. */
  @type("uint8") @defaultValue(0) role: number;
  /** 1 while out of sight upstairs (don't draw); 0 on the ground floor or outside. */
  @type("uint8") @defaultValue(0) floor: number;
  /** 0 following the schedule, 1 free (hive, soldiers, fleeing: Wander drives them). */
  @type("uint8") @defaultValue(0) mode: number;
  /** Stage of the current leg (Stage in life.ts). 0 = dwelling at a spot. */
  @type("uint8") @defaultValue(0) stage: number;
  /** 1 when a hand-off bounced this segment: stay in the current chunk until the next one. */
  @type("uint8") @defaultValue(0) stuck: number;
  /** Current schedule segment: day and index. */
  @type("uint16") @defaultValue(0) legDay: number;
  @type("uint8") @defaultValue(0) leg: number;
  /** Where the current segment is spent: chunk offset from home, and place. */
  @type("int8") @defaultValue(0) ddx: number;
  @type("int8") @defaultValue(0) ddy: number;
  @type("uint16") @defaultValue(0) dst: number;
  /** Graph node the current leg heads for (or last reached): chunk offset from home, and node. */
  @type("int8") @defaultValue(0) ndx: number;
  @type("int8") @defaultValue(0) ndy: number;
  @type("uint16") @defaultValue(0) node: number;
}
