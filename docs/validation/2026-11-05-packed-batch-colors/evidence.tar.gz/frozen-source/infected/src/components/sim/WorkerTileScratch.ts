import type { World } from "minecs";
import { Component, Schema, type } from "minecs";
@Component()
export class WorkerTileScratch extends Schema {
  @type("object")
  localOut: number[];
  @type("object")
  facings: Map<object, Float32Array>;
}
export const initializeWorkerTileScratch = (world: World, entity: number) => {
  const fields = world(WorkerTileScratch).store as unknown as Record<string, unknown[]>;
  fields.localOut[entity] = [0, 0];
  fields.facings[entity] = new Map();
};
