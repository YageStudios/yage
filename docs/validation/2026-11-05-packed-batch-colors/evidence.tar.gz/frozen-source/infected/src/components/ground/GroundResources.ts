import type { PlanningContext } from "../../worldgen/commute/context";
import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import type { ChunkScene } from "yage/streaming/layer";
import type { ChunkArt } from "../../domain/art";
import type { PlacedItem } from "../../render/dress";
import type { Snapshot } from "yage/streaming";
import type { AheadSource, ChunkWork } from "../../services/ground/ahead";
import type { chunkProps } from "../../render/props";
import type { GroundTextures } from "../../render/textures";

/** `natured`, `dressed`: false while the chunk's props wait to be laid (GroundProps); `dressing`, its dressing items as dressChunk laid them (chunkDressing), smashed ones and all. Lamp placements share this painted chunk's lifetime with its art and tiles; prop and static consumers do not place them again. */
export type PaintedGround = { mesh?: PIXI.Mesh<PIXI.Shader>; tiles: Uint8Array; art: ChunkArt; core: Uint8Array; ids: PIXI.Texture; blend: PIXI.Texture; fx: PIXI.Texture; mat: PIXI.Texture; shader: PIXI.Shader; natured?: boolean; dressed?: boolean; dressing?: PlacedItem[]; nature?: Snapshot; lampItems?: ChunkWork["lampItems"] };
/**
 * `ahead` makes where chunks are worked out ahead off the page's thread (GroundAhead, and queued chunks for GroundPaint); without one it works out only chunks whose tiles it holds, on the page.
 * `paintFloor` is the least a paint run takes while chunks wait, whatever the frame's shared budget has left (ms).
 */
/**
 * A queued chunk's work so far: its art, material core, then its texture data, worked out beside
 * the eight painted neighbours `around` (null where none was); one of them painted or repainted
 * since leaves the chunk to refresh its border once it paints.
 */
export type PreparedGround = Omit<ChunkWork, "tiles"> & { data?: { ids: Uint8Array; blend: Uint8Array; fx: Uint8Array; mat: Uint8Array; around: (PaintedGround | undefined)[] } };
export type GroundOptions = { art?: (cx: number, cy: number, tiles: Uint8Array) => ChunkArt | null; paintBudget?: number; paintFloor?: number; planning: PlanningContext; ahead?: () => AheadSource | null };

/** Texture/mesh handles and reproducible terrain caches are runtime resources. */
@Component()
export class GroundResources extends Schema {
  @type("object") planning: PlanningContext;
  @type("object") scene: ChunkScene;
  @type("object") options: GroundOptions;
  @type("object") tileCache: Map<number, Uint8Array>;
  @type("object") textures: GroundTextures;
  @type("object") materialTextures: Set<PIXI.Texture>;
  @type("object") materialBases: Set<PIXI.BaseTexture>;
  @type("object") shared: PIXI.UniformGroup;
  @type("object") program: PIXI.Program;
  @type("object") roadProgram: PIXI.Program;
  /** How lit the street lamps are (0 by day, 1 at night), shared by every chunk's lamp light (GroundLight sets it). */
  @type("object") lampLevel: { value: number };
  @type("object") quad: PIXI.Geometry;
  @type("object") palette: PIXI.Texture;
  @type("object") painted: Map<number, PaintedGround>;
  /** Painted chunks a neighbour has painted next to since, for GroundPaint to refresh once each on its budget. */
  @type("object") stale: Set<number>;
  /** Queued chunks' art, material core and texture data, worked out a step per budget slice before they paint (GroundPaint). */
  @type("object") prepared: Map<number, PreparedGround>;
  /** Chunks of a town hovered on the world map, worked out ahead from the plan's own tiles (GroundAhead); GroundPaint takes one when the tiles it is sent match. */
  @type("object") ahead: Map<number, ChunkWork>;
  /** The ahead worker (options.ahead, started at boot, taken the first time a town is hovered); `asked` is what it has been sent and not yet answered. */
  @type("object") aheadSource: AheadSource | null;
  @type("object") asked: Set<number>;
  /** Chunks GroundPaint gave a view to paint from the plan before they were hot (it removes them once out of view, unless they went hot). */
  @type("object") previewed: Set<number>;
  /** Chunks GroundFar has given a far picture (yage ChunkScene.setFar), with whether its ground part is still up. */
  @type("object") farPictured: Map<number, boolean>;
  /** When (ms) zooming in hid the far pictures; they go FAR_WARM_MS after (GroundFar). */
  @type("number") farHiddenAt: number;
  /** Chunks whose buildings GroundFar listed from the plan ahead of their paint (until painted or gone). */
  @type("object") planListed: Set<number>;
  @type("object") nature: Map<number, ReturnType<typeof chunkProps>>;
}
