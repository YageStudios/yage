import { Component, defaultValue, Schema, type } from "minecs";

@Component()
export class Gid extends Schema {
  @type("uint32")
  @defaultValue(0)
  id: number;
}
