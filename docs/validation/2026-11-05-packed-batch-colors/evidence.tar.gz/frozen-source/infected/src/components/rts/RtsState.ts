import { Component, defaultValue, Schema, type } from "minecs";
import { Commands } from "yage/world/commands";
import type { RtsAction, RtsContact, RtsHorde, RtsNotice, RtsUnit } from "../../domain/rts/orders";

/** Durable command state on the virus actor, independent of camera and selection. */
@Component()
export class RtsState extends Schema {
  @type("boolean") @defaultValue(false) commanding: boolean;
  @type("number") @defaultValue(1) nextOrder: number;
  @type("number") @defaultValue(1) nextHorde: number;
  @type(["object"]) units: RtsUnit[];
  @type(["object"]) hordes: RtsHorde[];
  @type(["object"]) contacts: RtsContact[];
  @type(["object"]) history: RtsNotice[];
}
@Component()
export class RtsOrders extends Commands<{ action: RtsAction; command?: string; operation?: number; expectedOperation?: number }> {}
/** Existing tracked-person reports, queued by PoolIngress and drained only by RtsCommandSystem. */
@Component()
export class RtsReports extends Commands<RtsContact> {}
