/** Browser/rendering resources and loaded chunks owned by an art-preview scene. */
import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import type { ChunkScene } from "yage/streaming/layer";
import type { activeAtlas } from "../../atlas/install";
import type { GroundHandle } from "../../services/ground/context";
import type { Fixture } from "../../render/fixtures";
import type { createArtPreviewUI } from "../../ui/art-preview";

@Component()
export class ArtPreviewResources extends Schema {
  @type("object") app: PIXI.Application;
  @type("object") camera: PIXI.Container;
  @type("object") scene: ChunkScene;
  @type("object") ground: GroundHandle;
  @type("object") atlas: ReturnType<typeof activeAtlas>;
  @type("object") fixtures: Map<string, Fixture>;
  @type("object") loaded: Set<string>;
  @type("object") ui: ReturnType<typeof createArtPreviewUI>;
}
