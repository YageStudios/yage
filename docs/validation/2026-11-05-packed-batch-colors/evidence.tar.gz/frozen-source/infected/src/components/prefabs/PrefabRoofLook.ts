import { Schema, type } from "minecs";
import type { RoofKind } from "../../atlas/objects";
export class PrefabRoofLook extends Schema {
  @type("string") kind: RoofKind;
  @type("number") ridge: 0 | 1;
  @type("number") roof: number;
  @type("number") wall: number;
  @type("string") culture: string;
  @type("string") use: string;
  @type("number") storeys: number;
  @type("number") variant: number;
  @type("number") hue: number;
  @type("number") wallTone: number;
  @type("boolean") snow: boolean;
}
