import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/** Send the town's burn squads out (or call them back), asked by `role`'s command; MilitarySystem drains them on the region's pass. */
export type SecurityOrder = { kind: "burn"; on: boolean; role: string; command: string };

@Component()
export class SecurityOrders extends Commands<SecurityOrder> {}
