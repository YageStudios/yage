import { Component, Schema, type } from "minecs";
import { Commands } from "yage/world/commands";
import type { Operation, OperationEvent, StrategyAction } from "../../domain/strategy/operations";
@Component()
export class StrategyState extends Schema {
  @type("number") nextOperation: number;
  @type("number") nextEvent: number;
  @type(["object"]) operations: Operation[];
  @type(["object"]) events: OperationEvent[];
}
@Component()
export class StrategyOrders extends Commands<{ action: StrategyAction; command?: string }> {}
