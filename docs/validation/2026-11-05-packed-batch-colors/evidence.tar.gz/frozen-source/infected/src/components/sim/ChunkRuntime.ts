import { Component, Schema, defaultValue, nullable, type } from "minecs";
import { LeaderState } from "./LeaderState";
@Component()
export class ChunkRuntime extends Schema {
  @type("boolean")
  @defaultValue(false)
  alerted: boolean;
  @type("number")
  @defaultValue(-1)
  showcased: number;
  /** The run's seed, as the chunk was generated with it: every draw in the chunk is keyed on it (chunkDraws). */
  @type("number")
  @defaultValue(0)
  seed: number;
  /** Game seconds of this world's last step DriveInSystem saw (-1: none yet), for the drive-ins due since. */
  @type("number")
  @defaultValue(-1)
  driveSeen: number;
  @nullable()
  @type(LeaderState)
  leader: LeaderState | null;
}
