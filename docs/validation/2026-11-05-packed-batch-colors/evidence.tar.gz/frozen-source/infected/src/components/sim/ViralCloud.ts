import { Schema, type } from "minecs";
import type { Emit } from "../../domain/load/constants";

/** Typed cloud state, including its deterministic trajectory cache. */
export class ViralCloud extends Schema {
  @type("number") kind: Emit;
  @type("number") slot: number;
  @type("number") born: number;
  @type("number") x0: number;
  @type("number") y0: number;
  @type("number") vx0: number;
  @type("number") vy0: number;
  @type("number") angle: number;
  @type("number") hvx: number;
  @type("number") hvy: number;
  @type("number") load: number;
  @type("number") size: number;
  @type("number") life: number;
  @type("number") steps: number;
  @type("number") x: number;
  @type("number") y: number;
  @type("number") vx: number;
  @type("number") vy: number;
  @type("number") px: number;
  @type("number") py: number;
}
