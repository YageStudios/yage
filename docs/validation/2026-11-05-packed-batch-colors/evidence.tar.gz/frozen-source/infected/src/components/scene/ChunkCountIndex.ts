import { Component, Schema, type } from "minecs";
import type { ChunkPopulation } from "./ChunkPopulation";

/** The reported chunk counts by chunk key: the same rows as ScenePopulation.chunks, in report order (PoolIngress keeps both). */
@Component()
export class ChunkCountIndex extends Schema {
  @type("object") byKey: Map<number, ChunkPopulation>;
}
