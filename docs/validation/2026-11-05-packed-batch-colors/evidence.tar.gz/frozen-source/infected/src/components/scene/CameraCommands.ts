import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/** What the scene's pointer and steer keys ask of the camera; CameraInput runs them in push (event) order. */
export type CameraCommand =
  /** A steer key: follow the host again. */
  | { kind: "follow" }
  | { kind: "free" }
  /** A drag in free look, by screen px. */
  | { kind: "drag"; dx: number; dy: number }
  /** The mouse wheel at screen (clientX, clientY), by the wheel's delta. */
  | { kind: "wheel"; clientX: number; clientY: number; delta: number }
  /** A click on the world view: dive at screen (clientX, clientY), or refuse where it has not reached. */
  | { kind: "dive"; clientX: number; clientY: number };

@Component()
export class CameraCommands extends Commands<CameraCommand> {}
