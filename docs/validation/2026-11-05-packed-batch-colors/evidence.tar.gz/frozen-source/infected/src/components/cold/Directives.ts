import { Component, Schema, type } from "minecs";
import { Commands } from "yage/world/commands";
import type { DirectCommand, DirectiveEvent, DirectiveRecord } from "../../domain/directive";

/** Directives asked for (a journaled `direct`), drained on the authority's steps (DirectiveSystem). */
@Component()
export class DirectCommands extends Commands<DirectCommand> {}

/** Content a beat needs staged into the world (a journaled `stage`): taken by the stager registered for its kind (solver/levers.ts). */
export type StageCommand = { stage: string; at: { cx: number; cy: number }; data?: unknown };

@Component()
export class StageCommands extends Commands<StageCommand> {}

/**
 * The directives the run's cast pursue (domain/directive.ts), in the order taken, and what came of
 * them: done, refused or failed on the way (`log`, the story events of the scenario's levers).
 */
@Component()
export class Directives extends Schema {
  @type(["object"]) list: DirectiveRecord[];
  @type(["object"]) log: DirectiveEvent[];
  /** The cast walking cold on a directive or home from one, in no cell: (gid, state, timer) triples by gid; where they are is their record's `at`. */
  @type(["number"]) walkers: number[];
}
