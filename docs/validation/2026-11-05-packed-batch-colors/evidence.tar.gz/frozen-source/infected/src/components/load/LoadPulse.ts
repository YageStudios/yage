import { Schema, type } from "minecs";

export class LoadPulse extends Schema {
  @type("number") gid: number;
  @type("number") tint: number;
  @type("boolean") hive: boolean;
}
