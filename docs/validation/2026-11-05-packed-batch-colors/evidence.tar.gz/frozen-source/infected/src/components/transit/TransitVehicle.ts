import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import { TransitCar } from "./TransitCar";
export class TransitVehicle extends Schema {
  @type("number") key: number;
  @type("object") root: PIXI.Container;
  @type([TransitCar]) cars: TransitCar[];
  @type("number") seg: number;
  @type("number") seen: number;
}
