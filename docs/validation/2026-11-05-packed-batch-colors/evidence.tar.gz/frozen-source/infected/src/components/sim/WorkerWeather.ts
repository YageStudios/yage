import { Component, Schema, defaultValue, type, type World } from "minecs";
import { HOUR } from "../../domain/time";
import type { Front, Weather, WeatherSpace } from "../../domain/weather";
/** Derived samples are transient and belong to one source's planning host. */
@Component()
export class WorkerWeather extends Schema {
  @type("number")
  @defaultValue(0)
  offset: number;
  @type("number")
  @defaultValue(0)
  skies: number;
  @type("object")
  space: WeatherSpace | null;
  @type("object")
  slots: Map<string, Front[]>;
  /** The fronts alive at each game time skyAt was asked lately (a pass's towns share a handful). */
  @type("object")
  live: Map<number, Front[]>;
  @type("object")
  chunks: Map<string, {
    tick: number;
    w: Weather;
  }>;
  @type("object")
  floods: Map<string, number>;
  @type("object")
  shelters: Map<string, number>;
}
export const initializeWorkerWeather = (world: World, entity: number) => {
  // Pages and workers receive the same scenario calendar through their explicit startup inputs.
  const g = globalThis as {
    location?: {
      search?: string;
    };
    name?: string;
    process?: {
      env?: Record<string, string | undefined>;
    };
    document?: unknown;
  };
  const search = g.document ? g.location?.search : typeof g.name === "string" ? g.name : undefined;
  const value = (search ? new URLSearchParams(search).get("weather") : null) ?? g.process?.env?.INFECTED_WEATHER ?? null;
  const hours = value === null ? 0 : Number(value);
  const fields = world(WorkerWeather).store;
  fields.offset[entity] = Number.isFinite(hours) ? hours * HOUR : 0;
  fields.space[entity] = null;
  fields.slots[entity] = new Map();
  fields.live[entity] = new Map();
  fields.chunks[entity] = new Map();
  fields.floods[entity] = new Map();
  fields.shelters[entity] = new Map();
};
