import { Component, Schema, type } from "minecs";
import { PathogenTraits } from "../shared/PathogenTraits";

/** The strain's effective traits (world:strain), derived from its evolution by TraitConfig. */
@Component()
export class StrainTraits extends Schema {
  @type(PathogenTraits) traits: PathogenTraits;
}
