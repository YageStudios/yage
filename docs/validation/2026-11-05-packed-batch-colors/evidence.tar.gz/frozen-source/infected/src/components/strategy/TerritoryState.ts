import { Component, Schema, type } from "minecs";
import type { Territory, TerritoryEvent } from "../../domain/strategy/territory";
import type { OperationalFrame } from "../../domain/strategy/history";

/** One regional observation shared by every controller; only TerritorySystem writes it. */
@Component()
export class TerritoryState extends Schema {
  @type("number") tick: number;
  @type("number") revision: number;
  @type("number") nextEvent: number;
  @type(["object"]) towns: Territory[];
  @type(["object"]) events: TerritoryEvent[];
}

/** Bounded operational snapshots, owned by OperationalHistorySystem, never by the camera. */
@Component()
export class OperationalHistory extends Schema {
  @type(["object"]) frames: OperationalFrame[];
}
