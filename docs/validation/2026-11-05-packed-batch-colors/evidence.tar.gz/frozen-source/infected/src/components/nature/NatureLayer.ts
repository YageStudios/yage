import { Component, Schema, defaultValue, type } from "minecs";

/**
 * The world's nature layer (world:nature). Its cells are on nature:chunk entities (NatureChunk),
 * one for each chunk that has been degraded; untouched land has none. NatureScorchSystem
 * scorches them where the towns' fires and burn squads have been; they outlast the towns'
 * records, and a checkpoint saves them as its own run-length section (checkpoint/records.ts).
 */
@Component()
export class NatureLayer extends Schema {
  /** Bumped on every change (and on a load), so views redraw and indexes rebuild only then. */
  @type("number") @defaultValue(0) revision: number;
}
