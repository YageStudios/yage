import { Schema, type } from "minecs";

/** One region pass: the pool's tick and the seconds since the last pass. */
export class RegionPassRow extends Schema {
  @type("number") tick: number;
  @type("number") uiDt: number;
}
