import { Schema, nullable, type } from "minecs";
import { ExtremeMemory } from "./ExtremeMemory";
import { BordersState } from "./BordersState";
export class ResponseMemory extends Schema {
  @nullable() @type(BordersState) borders: BordersState | null;
  @type(ExtremeMemory) extremes: ExtremeMemory;
}
