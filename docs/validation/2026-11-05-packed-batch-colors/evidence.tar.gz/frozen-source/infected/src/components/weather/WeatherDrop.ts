import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
export class WeatherDrop extends Schema {
  @type("object") sprite: PIXI.Sprite;
  @type("number") x: number;
  @type("number") y: number;
  @type("number") vx: number;
  @type("number") vy: number;
  @type("number") life: number;
  @type("number") age: number;
  @type("number") kind: number;
  @type("number") sway: number;
  @type("boolean") alive: boolean;
}
