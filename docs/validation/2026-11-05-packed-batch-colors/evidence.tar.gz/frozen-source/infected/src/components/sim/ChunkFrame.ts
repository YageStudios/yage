import { Component, Schema, defaultValue, nullable, type } from "minecs";
import type { StepContext } from "yage/streaming";
import type { Traits } from "../../domain/disease";
import type { Weather } from "../../domain/weather";
import type { PlanningContext } from "../../worldgen/commute/context";
import { PathogenTraits } from "../shared/PathogenTraits";
import { ChunkStep } from "./ChunkStep";
import { RouteExposure } from "./RouteExposure";
import { WeatherSample } from "./WeatherSample";
/** One chunk's active step, carried outside transferable person rows in its context entity. */
@Component()
export class ChunkFrame extends Schema {
  @type("object")
  planning: PlanningContext | null;
  @type("boolean")
  @defaultValue(false)
  ready: boolean;
  @type(ChunkStep)
  ctx: StepContext;
  @type("object")
  open: (x: number, y: number) => boolean;
  @type("object")
  tiles: Uint8Array | null;
  @type("object")
  ground: Uint8Array | null;
  /** Builds the chunk's tiles on first ask (stepGround), when the step did not hand them over: warm steps mostly never ask. */
  @type("object")
  groundOf: (() => Uint8Array) | null;
  /** Whether the step knows who is out in the open (weather reaches them): the tiles are here or to be had. */
  @type("boolean")
  @defaultValue(false)
  outdoors: boolean;
  @nullable()
  @type(WeatherSample)
  weather: Weather | null;
  @type(PathogenTraits)
  weathered: Traits;
  @type("number")
  @defaultValue(1)
  stress: number;
  @type("boolean")
  @defaultValue(false)
  contagious: boolean;
  /** Set by HotContactSystem: this step runs contact (Rapier armed, not yet stepped by HotPhysicsSystem). */
  @type("boolean")
  @defaultValue(false)
  contact: boolean;
  @nullable()
  @type(RouteExposure)
  routes: RouteExposure | null;
  @type("object")
  routeCells: Float32Array;
  @type("number")
  @defaultValue(0)
  platformRats: number;
  @type("number")
  @defaultValue(0)
  t: number;
}
