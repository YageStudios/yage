import { Component, Schema, defaultValue, type } from "minecs";
import { UnrestPin } from "./UnrestPin";

/** A town's unrest (UnrestSystem): fatigue from being kept in, the unrest itself, and a debug pin. */
@Component()
export class TownUnrest extends Schema {
  @type("number") @defaultValue(0) fatigue: number;
  @type("number") @defaultValue(0) unrest: number;
  @type(UnrestPin) pin: UnrestPin;
}
