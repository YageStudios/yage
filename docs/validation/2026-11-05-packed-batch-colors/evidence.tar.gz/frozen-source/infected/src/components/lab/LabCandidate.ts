import { Schema, type } from "minecs";

/** A transfer target captured when the leap window opens. */
export class LabCandidate extends Schema {
  @type("number") eid: number;
  @type("number") x: number;
  @type("number") y: number;
  @type("boolean") bloomed: boolean;
}
