import { Component, Schema, type, type World } from "minecs";
import type { Critter } from "../../domain/critters";
import type { ObjectsNav } from "../../worldgen/terrain/models";
@Component()
export class WorkerCritters extends Schema {
  @type("object")
  chunks: Map<string, {
    tiles: Uint8Array;
    nav: ObjectsNav | null;
    critters: Critter[];
  }>;
}
export const initializeWorkerCritters = (world: World, entity: number) => {
  world(WorkerCritters).store.chunks[entity] = new Map();
};
