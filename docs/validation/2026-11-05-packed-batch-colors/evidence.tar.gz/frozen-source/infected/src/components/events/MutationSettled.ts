import { Component, defaultValue, Schema, type } from "minecs";

/** A mutation card settled this frame ("world:mutation-settled", a transient OfferResolve spawns); MutationShowcase shows it on the host. */
@Component()
export class MutationSettled extends Schema {
  @type("string") @defaultValue("") card: string;
}
