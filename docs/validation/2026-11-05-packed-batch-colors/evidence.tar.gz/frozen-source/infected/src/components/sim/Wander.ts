import { Component, defaultValue, Schema, type } from "minecs";

@Component()
export class Wander extends Schema {
  /** Target in chunk-local units. */
  @type("float32")
  @defaultValue(0)
  tx: number;

  @type("float32")
  @defaultValue(0)
  ty: number;

  /** Seconds to idle before walking on. */
  @type("float32")
  @defaultValue(0)
  wait: number;

  /** Units per second. */
  @type("float32")
  @defaultValue(30)
  speed: number;
}
