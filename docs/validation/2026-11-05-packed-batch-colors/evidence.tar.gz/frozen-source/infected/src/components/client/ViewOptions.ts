import { Component, Schema, type } from "minecs";

/** A client's display options, read from the page URL at startup (client:session; ClientSetup). */
@Component()
export class ViewOptions extends Schema {
  /** `?heat=1`: always show the controlled host's commute heat. */
  @type("boolean") heat: boolean;
  /** `?chunks=1`: always show the chunk boundaries. */
  @type("boolean") chunks: boolean;
}
