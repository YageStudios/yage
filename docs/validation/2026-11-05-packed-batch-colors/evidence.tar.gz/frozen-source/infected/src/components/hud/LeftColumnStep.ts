import { Component, Schema, nullable, type } from "minecs";
import type { Live } from "../../ui/model";

/** The published live panel the left column last stepped on: a new one steps it again. */
@Component()
export class LeftColumnStep extends Schema {
  @nullable() @type("object") live: Live | null;
}
