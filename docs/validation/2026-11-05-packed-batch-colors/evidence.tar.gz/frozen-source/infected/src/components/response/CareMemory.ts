import { Component, Schema, type } from "minecs";

/** What CareSystem has announced of a town (latched): field tents, staff walking out, the morgue and graves, the vaccine and its refusal. */
@Component()
export class CareMemory extends Schema {
  @type("boolean") tents: boolean;
  @type("boolean") quit: boolean;
  @type("boolean") morgue: boolean;
  @type("boolean") graves: boolean;
  @type("boolean") vax: boolean;
  @type("boolean") refuse: boolean;
}
