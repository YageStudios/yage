import { CabinPass } from "./CabinPass";
import { ChunkContactGrid } from "./ChunkContactGrid";
import { ChunkFrame } from "./ChunkFrame";
import { ChunkRuntime } from "./ChunkRuntime";
import { ChunkRosters } from "./ChunkRosters";
import { ChunkTally } from "./ChunkTally";
import { Condition } from "./Condition";
import { Exposure } from "./Exposure";
import { Gid } from "./Gid";
import { Leg } from "./Leg";
import { Life } from "./Life";
import { LoadEffects } from "./LoadEffects";
import { LoadPhase } from "./LoadPhase";
import { Look } from "./Look";
import { Pos } from "./Pos";
import { Role } from "./Role";
import { ViralCloud } from "./ViralCloud";
import { ViralEmission } from "./ViralEmission";
import { Wander } from "./Wander";
import { WorkerCabins } from "./WorkerCabins";
import { WorkerCollision } from "./WorkerCollision";
import { WorkerCritters } from "./WorkerCritters";
import { WorkerFire } from "./WorkerFire";
import { WorkerFloor } from "./WorkerFloor";
import { WorkerGeometry } from "./WorkerGeometry";
import { WorkerInfection } from "./WorkerInfection";
import { WorkerLifeScratch } from "./WorkerLifeScratch";
import { WorkerMeasures } from "./WorkerMeasures";
import { WorkerPlaces } from "./WorkerPlaces";
import { WorkerReactionScratch } from "./WorkerReactionScratch";
import { WorkerRoutineScratch } from "./WorkerRoutineScratch";
import { WorkerSchedule } from "./WorkerSchedule";
import { WorkerSocial } from "./WorkerSocial";
import { WorkerSurfaces } from "./WorkerSurfaces";
import { WorkerTileScratch } from "./WorkerTileScratch";
import { WorkerTravel } from "./WorkerTravel";
import { WorkerWeather } from "./WorkerWeather";
/** Declarations load before the first generation world; no worlds are created here. */
export const SIM_RUNTIME_SCHEMAS = [WorkerCritters, WorkerSurfaces, WorkerCollision, WorkerWeather, WorkerFloor, WorkerLifeScratch, WorkerSchedule, WorkerRoutineScratch, WorkerReactionScratch, WorkerFire, WorkerTravel, WorkerGeometry, WorkerTileScratch, WorkerPlaces,
  CabinPass,
  ChunkContactGrid,
  ChunkFrame,
  ChunkRuntime,
  ChunkRosters,
  ChunkTally,
  Condition,
  Exposure,
  Gid,
  Leg,
  Life,
  LoadEffects,
  LoadPhase,
  Look,
  Pos,
  Role,
  ViralCloud,
  ViralEmission,
  Wander,
  WorkerCabins,
  WorkerInfection,
  WorkerMeasures,
  WorkerSocial,
];
