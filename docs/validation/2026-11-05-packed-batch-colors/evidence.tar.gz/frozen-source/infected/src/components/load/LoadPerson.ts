import { Schema, type } from "minecs";

export class LoadPerson extends Schema {
  @type("number") slot: number;
  @type("number") target: number;
  @type("number") shown: number;
}
