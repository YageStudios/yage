import { Component, defaultValue, Schema, type } from "minecs";
import { SceneTotals } from "../scene/SceneTotals";

/** The region's totals over every chunk that has reported (scene:population), summed on each region pass by PopulationAggregateSystem; `people` prefers the pool's own count. */
@Component()
export class PopulationTotals extends Schema {
  @type(SceneTotals) totals: SceneTotals;
  @type("number") @defaultValue(0) people: number;
}
