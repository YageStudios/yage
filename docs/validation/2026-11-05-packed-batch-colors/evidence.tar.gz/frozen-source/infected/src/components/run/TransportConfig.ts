import { Component, Schema, type } from "minecs";

/** Where the run's simulation comes from, given by the run's composer (run:transport; services/run.ts). */
@Component()
export class TransportConfig extends Schema {
  /** The simulation server this run streams from ("" when it runs local workers). */
  @type("string") server: string;
  /** Whether the run streams from a server rather than local workers. */
  @type("boolean") remote: boolean;
}
