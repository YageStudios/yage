import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";

/** The name label of the park landmark under the pointer (ParkLabelView), made when first shown. */
@Component()
export class ParkLabelLayer extends Schema {
  @type("object") label: PIXI.Text | null;
}
