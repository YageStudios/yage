import type { OperationalFrame } from "../../domain/strategy/history";
import { Component, defaultValue, nullable, Schema, type } from "minecs";
import type { ChunkTransport } from "yage/streaming";
import type { ShadowDriver } from "../../services/shadow/driver";
import type { PlaceFrame } from "../../worldmap/timeline";
import type { Jump } from "../../worldmap/track";

/** A keyframe a replay saved as it went: the slot holding it and the tick it holds. */
export type ReplayKeyframe = { slot: string; tick: number };

/** Where the camera was when a scrub pulled it out to the world view: it dives back there once the seek lands. */
export type ReplayCamera = { x: number; y: number; zoom: number; following: boolean };

/**
 * A replay's viewer (client:replay, on a `?replay=` page; ReplayViewSystem): the slot it replays,
 * its shadows over what the run doesn't step hot, the keyframes it saved, and a seek under way
 * (`to`: the tick it plays on to as fast as it can, -1 for none). Its badge and seek slider are
 * the page's own elements. While the slider is held (a scrub) the camera is out on the world view,
 * which draws the places at the scrubbed tick from the saved run's timeline (nothing is simulated);
 * let go, it seeks there and, once the seek lands, dives back to where it was.
 */
@Component()
export class ReplayView extends Schema {
  @type("string") @defaultValue("") slot: string;
  /** A new shadow island's host (the page's: a shadow worker); none, no shadows. */
  @nullable() @type("object") connect: (() => ChunkTransport) | null;
  /** The journal's name for its keyframes, once it is read ("" before). */
  @type("string") @defaultValue("") journal: string;
  @nullable() @type("object") driver: ShadowDriver | null;
  @type("number") @defaultValue(-1) to: number;
  @type(["object"]) keyframes: ReplayKeyframe[];
  /** The keyframe save under way (its checkpoint id, -1 for none). */
  @type("number") @defaultValue(-1) saving: number;
  /** Cold chunks a shadow added to the ground, by key (removed from the scene once no shadow draws them). */
  @type("object") added: Set<number>;
  @nullable() @type("object") badge: HTMLElement | null;
  /** The speed the hosts were last set to by a seek (0: none set). */
  @type("number") @defaultValue(0) speed: number;
  /** The saved run's place timeline and jumps (its slot's scene:population), all of it: what a scrub shows. */
  @type(["object"]) timeline: PlaceFrame[];
  @type(["object"]) operations: OperationalFrame[];
  @type(["object"]) jumps: Jump[];
  /** The tick the saved run reached (its checkpoint's): a scrub's range takes it in, past the journal's last entry. */
  @type("number") @defaultValue(0) end: number;
  /** Out on the world view for a scrub or the seek it let go of; and where the camera dives back to after (none: it stays out). */
  @type("boolean") @defaultValue(false) out: boolean;
  @nullable() @type("object") back: ReplayCamera | null;
}
