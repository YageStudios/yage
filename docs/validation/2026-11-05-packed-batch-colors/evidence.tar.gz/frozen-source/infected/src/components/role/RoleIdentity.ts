import { Component, Schema, type } from "minecs";

/** A playable seat (role:virus): its kind and its stable id, which controllers, actors and knowledge name it by. */
@Component()
export class RoleIdentity extends Schema {
  @type("string") kind: string;
  @type("string") id: string;
}
