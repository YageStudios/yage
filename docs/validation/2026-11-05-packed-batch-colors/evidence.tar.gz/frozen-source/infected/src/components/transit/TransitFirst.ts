import { Schema, type } from "minecs";
export class TransitFirst extends Schema {
  @type("number") x: number;
  @type("number") y: number;
  @type("string") line: string;
}
