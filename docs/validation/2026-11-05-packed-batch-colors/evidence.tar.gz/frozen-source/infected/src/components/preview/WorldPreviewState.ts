/** Authoring viewer options, camera and generation state, isolated per scene. */
import { Component, Schema, defaultValue, type } from "minecs";

import { PreviewSavedSpace } from "./PreviewSavedSpace";

export type PreviewOverlay = "none" | "navigation" | "entrances" | "capacity" | "contacts";
@Component()
export class WorldPreviewState extends Schema {
  @type([PreviewSavedSpace]) saved: PreviewSavedSpace[];
  @type("string") @defaultValue("valley") spaceKey: string;
  @type("number") @defaultValue(0) seed: number;
  @type("string") @defaultValue("none") overlay: PreviewOverlay;
  @type("boolean") @defaultValue(true) labels: boolean;
  @type("boolean") @defaultValue(false) grid: boolean;
  @type("number") @defaultValue(0) x: number;
  @type("number") @defaultValue(0) y: number;
  @type("number") @defaultValue(0.2) scale: number;
  @type("number") @defaultValue(1) width: number;
  @type("number") @defaultValue(1) height: number;
  @type("number") @defaultValue(1) dpr: number;
  @type("boolean") @defaultValue(true) generating: boolean;
  @type("boolean") @defaultValue(true) deferGeneration: boolean;
  @type("boolean") @defaultValue(true) dirty: boolean;
  @type("boolean") @defaultValue(false) dragging: boolean;
  @type("number") @defaultValue(0) pointerX: number;
  @type("number") @defaultValue(0) pointerY: number;
  @type("string") @defaultValue("") stats: string;
  @type("string") @defaultValue("") info: string;
}
