import { Component, Schema, defaultValue, type } from "minecs";

/** The last refused dive: its place's dot shakes and the message shows beside it (place -1: none yet). */
@Component()
export class WorldMapRefusal extends Schema {
  @type("number") @defaultValue(-1) place: number;
  @type("string") @defaultValue("") message: string;
  /** Page time (ms) of the refusal. */
  @type("number") @defaultValue(0) at: number;
}
