import { Component } from "minecs";
import type * as PIXI from "pixi.js";
import { Commands } from "yage/world/commands";
import type { Attached } from "../../render/attach";

/**
 * What the chunk pool reports for the page-side load, in arrival order: a chunk's overlay, its
 * static tiles, or the chunk going cold. LoadIngress applies them at the start of the load pass.
 */
export type LoadIngest =
  | { kind: "overlay"; cx: number; cy: number; tick: number; bytes: Uint8Array }
  | { kind: "tiles"; cx: number; cy: number; bytes: Uint8Array }
  | { kind: "remove"; cx: number; cy: number };

/** The pool's load reports (PoolIngress, the streamer's cool callback), drained by LoadIngress. */
@Component()
export class LoadIngestCommands extends Commands<LoadIngest> {}

/**
 * A sprite for the air layer: a free particle (droplet, mote, dust) or an effect riding on a
 * pawn. LoadSpawn makes them in push order, so the layer's draw order follows the requests.
 */
export type LoadSpriteRequest =
  | { kind: "particle"; x: number; y: number; z: number; vx: number; vy: number; vz: number; life: number; tint: number; size: number; alpha: number; texture?: PIXI.Texture; blend?: PIXI.BLEND_MODES; delay?: number; rotation?: number; floor?: boolean }
  | { kind: "attach"; fx: Attached; texture: PIXI.Texture; tint: number; size: number; alpha: number; grow?: number; blend?: PIXI.BLEND_MODES };

/** (A particle waits `delay` s, hidden, before it starts; `floor` lays it on the ground under people instead of in the air.) */
/** Air sprite requests (LoadEvents, LoadSweat, LoadPulses), drained by LoadSpawn. */
@Component()
export class LoadSpriteCommands extends Commands<LoadSpriteRequest> {}

/**
 * What the player's host did on the page, drawn at once by LoadEvents, never waiting on the sim:
 * the hot world's own. A shot (the lab's ridden fighter, SimLabView) from person `gid`'s feet at
 * (x, y) toward (x + vx, y + vy), one line a pellet; a bite (HostBite) by `gid` on whoever is at
 * (x, y), from the way `angle` (`target` -1: it snapped at nothing, at its own feet). `n` is the shot's or bite's number.
 */
export type LoadStrike =
  | { kind: "shot"; gid: number; x: number; y: number; vx: number; vy: number; n: number }
  | { kind: "bite"; gid: number; target: number; x: number; y: number; angle: number; n: number }
  /** A blow landing on a defense at (x, y), struck along `angle`: its pieces (`tint`) and dust fly; `broke` when it gave way. */
  | { kind: "smash"; gid: number; x: number; y: number; angle: number; n: number; tint: number; broke: boolean };

/** The page's shots, bites and smashes (SimLabView, HostBite, SiegeEffects), drained by LoadEvents. */
@Component()
export class LoadStrikeCommands extends Commands<LoadStrike> {}
