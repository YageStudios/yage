import { Component, Schema, defaultValue, type } from "minecs";

/**
 * One funeral, an entity in a planning context's social records (WorkerSocial.records): for whom
 * (gid), from which home and household, on which day, and where (chunk and place). Laid by the
 * observation step (services/life/observe) when a death is first seen.
 */
@Component()
export class Funeral extends Schema {
  @type("float64") @defaultValue(0) gid: number;
  @type("float64") @defaultValue(0) home: number;
  @type("float64") @defaultValue(0) family: number;
  @type("float64") @defaultValue(0) day: number;
  @type("float64") @defaultValue(0) cx: number;
  @type("float64") @defaultValue(0) cy: number;
  @type("float64") @defaultValue(0) place: number;
}
