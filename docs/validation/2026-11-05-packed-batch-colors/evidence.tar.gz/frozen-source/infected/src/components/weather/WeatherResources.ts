import { Component, Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import type { ChunkScene } from "yage/streaming/layer";
import type { GroundHandle } from "../../services/ground/context";
import type { PlanningContext } from "../../worldgen/commute/context";
import type { WeatherSpace } from "../../domain/weather";
@Component()
export class WeatherResources extends Schema {
  @type("object") stage: PIXI.Container;
  @type("object") scene: ChunkScene;
  @type("object") ground: GroundHandle;
  @type("object") planning: PlanningContext;
  @type("object") space: WeatherSpace;
  @type("object") root: PIXI.Container;
  @type("object") fogLayer: PIXI.Container;
  @type("object") dropLayer: PIXI.Container;
  @type("object") splashLayer: PIXI.Container;
  /** The zoomed-out rain and snow sheets (WeatherSheet): rain near and far, then snow near and far. */
  @type("object") sheetLayer: PIXI.Container;
  @type("object") sheets: PIXI.TilingSprite[];
  @type("object") streak: PIXI.Texture;
  @type("object") flake: PIXI.Texture;
  @type("object") ring: PIXI.Texture;
  @type("object") bankTexture: PIXI.Texture;
  @type("object") sheetRain: PIXI.Texture;
  @type("object") sheetSnow: PIXI.Texture;
}
