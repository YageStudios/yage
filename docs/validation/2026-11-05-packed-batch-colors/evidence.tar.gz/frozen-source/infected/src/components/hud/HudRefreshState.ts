import { Component, defaultValue, nullable, Schema, type } from "minecs";
import { PROGRESSION } from "../../content/mutations";

/**
 * A HUD's own refresh bookkeeping: when it last showed a rate-limited news toast (HudToasts) and
 * last published the live panel (Flow, about twice a second); the unlock points it has announced
 * (every run starts with some); the strain's open offer it last showed (HudAfter); and whether it
 * has shown the end screen; and the hosts its Tab has visited since it last came round (Flow); and
 * when the scene started preparing behind the start screen and whether it is ready (PrepareVeil).
 */
@Component()
export class HudRefreshState extends Schema {
  @type("number") @defaultValue(0) lastToast: number;
  @type("number") @defaultValue(0) liveAt: number;
  @type("number") @defaultValue(PROGRESSION.startAp) apSeen: number;
  @nullable() @type("object") offerShown: object | null;
  @type("boolean") @defaultValue(false) endShown: boolean;
  @type(["number"]) cycled: number[];
  @type("number") @defaultValue(-1) preparingSince: number;
  @type("number") @defaultValue(-1) paintedSince: number;
  @type("boolean") @defaultValue(false) prepared: boolean;
}
