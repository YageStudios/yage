import { Component, defaultValue, Schema, type } from "minecs";

/** The run's frame (run:clock): the wall time (performance.now()) this frame runs at, stamped before the model runs. Authority systems read it in place of the camera's clock. */
@Component()
export class RunFrame extends Schema {
  @type("number") @defaultValue(0) now: number;
}
