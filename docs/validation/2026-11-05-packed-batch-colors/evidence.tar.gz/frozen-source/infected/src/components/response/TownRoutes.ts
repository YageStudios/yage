import { Component, Schema, defaultValue, type } from "minecs";

/** A town's animal and water reservoirs (RoutesSystem), 0–1. */
@Component()
export class TownRoutes extends Schema {
  @type("number") @defaultValue(0) fauna: number;
  @type("number") @defaultValue(0) water: number;
}
