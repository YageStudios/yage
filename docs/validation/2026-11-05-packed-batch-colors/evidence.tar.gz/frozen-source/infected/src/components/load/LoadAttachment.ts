import { Schema, type } from "minecs";
import type * as PIXI from "pixi.js";
import { LoadAnchor } from "./LoadAnchor";

export class LoadAttachment extends Schema {
  @type(LoadAnchor) anchor: LoadAnchor;
  @type("number") lx: number;
  @type("number") ly: number;
  @type("number") vx: number;
  @type("number") vy: number;
  @type("number") age: number;
  @type("number") life: number;
  @type("number") fade: number;
  @type("number") grow: number;
  @type("number") size: number;
  @type("object") sprite: PIXI.Sprite;
}
