import { Component, defaultValue, Schema, type } from "minecs";

/**
 * How a super mutant's kind (MutantDef, src/entities/mutants.json5) is drawn: its own row of the
 * pawn atlas (render/pawns/mutant.ts), one cell per look variant, in its own colours (the person's
 * palette doesn't tint it). frame: "crawler" on all fours, or "brute" upright and hulking; scale:
 * the art about its feet in the cell (the cell bounds it); height: how tall its cell stands against a
 * person's on screen (the pawn layer's scales, render/pawns/style.ts), so a brute towers. Colours are #rrggbb. hat: the share of
 * its variants that wear one; tentacles: how many grow out of it. glow: its halo in the pawn layer.
 */
@Component()
export class MutantLook extends Schema {
  @type("string") @defaultValue("brute") frame: string;
  @type("number") @defaultValue(1) scale: number;
  @type("number") @defaultValue(1) height: number;
  @type("string") @defaultValue("#b8b6ae") skin: string;
  @type("string") @defaultValue("#8d8a82") shade: string;
  @type("string") @defaultValue("#9c3b33") sinew: string;
  @type("string") @defaultValue("#e8dfc8") bone: string;
  @type("string") @defaultValue("#e8e0d0") eye: string;
  @type("string") @defaultValue("") coat: string;
  @type("string") @defaultValue("") coatShade: string;
  @type("number") @defaultValue(0) hat: number;
  @type("boolean") @defaultValue(false) brain: boolean;
  @type("boolean") @defaultValue(false) tongue: boolean;
  @type("boolean") @defaultValue(false) claws: boolean;
  @type("number") @defaultValue(0) tentacles: number;
  @type("boolean") @defaultValue(false) plates: boolean;
  @type("string") @defaultValue("stern") face: string;
  @type("string") @defaultValue("#d23a2c") glow: string;
}
