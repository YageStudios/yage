import { Component, defaultValue, Schema, type } from "minecs";

/** The transport's connection (run:transport): the server connection's status line and the newest tick the hosts reported. */
@Component()
export class StreamState extends Schema {
  @type("string") connection: string;
  /** The newest snapshot tick (PoolIngress): the report watermark the HUD and views read. */
  @type("number") @defaultValue(0) lastTick: number;
}
