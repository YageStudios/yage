import { Component, defaultValue, Schema, type } from "minecs";

/** The outbreak began this frame ("world:outbreak-begun", a transient OfferResolve spawns): its pathogen and first host, in its start town's chunk. */
@Component()
export class OutbreakBegun extends Schema {
  @type("string") @defaultValue("") pathogen: string;
  @type("number") @defaultValue(-1) gid: number;
  @type("number") @defaultValue(0) cx: number;
  @type("number") @defaultValue(0) cy: number;
}
