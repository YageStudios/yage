import type { SiegeSnapshot, Structure } from "../../domain/siege/types";
import { Component, Schema, type, type World } from "minecs";
@Component()
export class WorkerCollision extends Schema {
  @type("object") siege: SiegeSnapshot;
  @type("number") siegeIndexRevision: number;
  @type("object") siegeByChunk: Map<number, Structure[]>;
  @type("object")
  grounds: Map<number, Uint8Array>;
  @type("object")
  chunks: WeakMap<Uint8Array, {
    cx: number;
    cy: number;
  }>;
}
export const initializeWorkerCollision = (world: World, entity: number) => {
  world(WorkerCollision, entity).siege = { revision: 0, structures: [] };
  world(WorkerCollision, entity).siegeIndexRevision = -1;
  world(WorkerCollision, entity).siegeByChunk = new Map();
  const fields = world(WorkerCollision).store;
  fields.grounds[entity] = new Map();
  fields.chunks[entity] = new WeakMap();
};
