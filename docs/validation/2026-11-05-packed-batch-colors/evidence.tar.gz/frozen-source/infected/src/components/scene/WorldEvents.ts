import { Component, Schema, type } from "minecs";

/** A chunk's local event as the run heard it (services/events.ts ChunkEvent), and the chunk it happened in. */
export class WorldEvent extends Schema {
  @type("number") kind: number;
  @type("number") gid: number;
  @type("number") tick: number;
  @type("number") via: number;
  @type("number") src: number;
  @type("number") where: number;
  @type("number") place: number;
  @type("number") cx: number;
  @type("number") cy: number;
  /** People it happened to: 1, or a cold cohort's count (gid NO_SOURCE). */
  @type("number") count: number;
}

/** Events the feed keeps: the latest, for the HUD and for viewers catching up. */
export const FEED_LENGTH = 1024;

/**
 * The run's feed of the chunks' local events (services/events.ts): who caught it from whom and
 * where, who bloomed, died or was cured, applied with the counts (PoolIngress, on steps in
 * lockstep). Presentation only: nothing in the run reads it, and a checkpoint doesn't keep it.
 */
@Component()
export class WorldEvents extends Schema {
  @type([WorldEvent]) feed: WorldEvent[];
  /** Every event the feed has taken, kept or not, by kind (EventKind). */
  @type(["number"]) byKind: number[];
}
