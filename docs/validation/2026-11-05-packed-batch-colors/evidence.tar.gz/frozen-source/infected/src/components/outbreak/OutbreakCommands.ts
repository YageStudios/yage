import { Component } from "minecs";
import { Commands } from "yage/world/commands";

/**
 * What the start (the HUD's Begin, the URL), a role's routed mutations and the offer timer ask of
 * the outbreak; OfferResolve runs them in push order. Picks and allocations only come routed
 * (RoleIntentRouterSystem): with the role that asked and the command id their result answers.
 */
export type OutbreakCommand =
  /** The game starts with this pathogen in this start town (an index into ScenarioStartCatalog.towns). */
  | { kind: "begin"; pathogen: string; town: number }
  /** The role picked this card of the open offer. */
  | { kind: "pick"; card: string; role: string; command: string }
  /** A passive-tree node the role buys with unlock points. */
  | { kind: "allocate"; node: string; role: string; command: string }
  /** The open offer's deadline passed: it settles (forced) on its automatic card. */
  | { kind: "settle" };

@Component()
export class OutbreakCommands extends Commands<OutbreakCommand> {}
