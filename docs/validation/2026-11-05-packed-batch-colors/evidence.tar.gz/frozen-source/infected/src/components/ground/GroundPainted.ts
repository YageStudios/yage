import { Component, Schema, type } from "minecs";

/** Chunk keys GroundPaint painted this frame, in paint order (it clears them each run); the props and prefab statics follow them. */
@Component()
export class GroundPainted extends Schema {
  @type(["number"]) keys: number[];
  /** Chunk keys GroundFar listed from the plan this frame, not painted yet: PrefabStatics lists their buildings ahead of the paint. */
  @type(["number"]) planned: number[];
}
