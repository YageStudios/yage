import { Component, nullable, Schema, type } from "minecs";
import type { Pond } from "../../anchors/pond";
import type { Anchor } from "../../anchors/types";
import type { Carry } from "../../anchors/ripples";
import type { AnchorStoreJSON } from "../../anchors/store";
import type { Cold } from "../../domain/cold/step";
import type { Traits } from "../../domain/disease";

/**
 * The anchor pond the live run keeps (services/cold/pond.ts): the towns the full sim doesn't own
 * are pulled from it, and what the full sim does comes back to it as anchors. Only its store is the
 * run's state (the checkpoint's anchor section); the rest is made again from the boot and the store.
 */
@Component()
export class ColdPond extends Schema {
  /** The cells the boot surveyed, as the plan makes them (nobody touched yet): the pond begins from these. */
  @nullable() @type("object") boot: Map<number, Cold> | null;
  /** The pond, made on the first lockstep step it's asked for; null before (and without one). */
  @nullable() @type("object") pond: Pond | null;
  /** A checkpoint's anchors, for the pond to begin from instead of none. */
  @nullable() @type("object") restored: AnchorStoreJSON | null;
  /** The towns the full sim owns now (their latest concrete anchor isn't observed since). */
  @nullable() @type("object") concrete: Set<number> | null;
  /** The last commute word each full-sim town placed for a neighbour, by `${from}:${to}`. */
  @nullable() @type("object") sent: Map<string, Carry> | null;
  /** How many of each town's live series entries are placed already, by `${town}:${measure}`. */
  @nullable() @type("object") orders: Map<string, number> | null;
  /** A solved scenario's anchors not placed yet, soonest first (found from the journal and the store); null: to be found. */
  @nullable() @type("object") scheduled: Anchor[] | null;
  /** The strain as the pond has it now: its base and every strain anchor on it. */
  @nullable() @type("object") traits: Traits | null;
}
