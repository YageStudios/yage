import { startingWorld } from "./realworld/selection";
import type { GeographicWorld } from "./realworld/global";
import type { GeographicCheckpoint } from "./realworld/checkpoint";
import type { GeographicCellReply, GeographicCellRequest } from "./realworld/cell-messages";
/** The page's world while booting (its rasters are views of the shared source); unset once the region loader owns the sources. */
let geographicWorld: GeographicWorld | undefined;
let geographicSave: GeographicCheckpoint | undefined;
/** The geographic source worker: it prepares the starting region at boot, then every region after. */
let cellWorker: Worker | undefined;
const entry = new URLSearchParams(location.search);
const checkpointSlot = entry.get("load") || (entry.get("replay") ? entry.get("key") || entry.get("replay") : null);
if (checkpointSlot) {
  const { browserSlots } = await import("./persistence/checkpoint");
  const text = await browserSlots().read(checkpointSlot);
  if (text) geographicSave = (JSON.parse(text) as { geography?: GeographicCheckpoint }).geography;
}
/**
 * The page's entry: starts the chunk workers before anything else runs, so they load their code
 * while the page builds the world plan, hands them that plan the moment it is built
 * (src/worldgen/plan-transfer.ts) instead of each building its own, then loads the game (main.ts).
 */
import { keepPlanMessage, publishRegionMessage, retireRegionMessage, startBootWorkers, streamRegionMessage } from "./services/boot-workers";

// `?lab` runs on the lab's empty field: without its size, the page again on a 3 × 3 one (every worker builds the field from the URL).
if (new URLSearchParams(location.search).has("lab") && !new URLSearchParams(location.search).has("field")) {
  const url = new URL(location.href);
  url.searchParams.set("field", "3");
  location.replace(url.toString());
  await new Promise(() => {});
}
// `?scenario=<name>`: its save put in a slot, the page goes on as loading (or replaying) it.
if (new URLSearchParams(location.search).has("scenario")) {
  const [{ openScenario }, { browserSlots }] = await Promise.all([import("./services/scenario-page"), import("./persistence/checkpoint")]);
  if (await openScenario(location.search, browserSlots()).catch((error) => (console.error("[infected] scenario:", error), false))) await new Promise(() => {});
}
const worldCenter = startingWorld(location.search);
/**
 * The geographic source worker, made as soon as the page knows it will ask one for its starting region: it loads
 * its code while the page loads its own and checks the cached world data (it does nothing until it is asked).
 */
const earlyCellWorker = worldCenter && !geographicSave ? new Worker(new URL("./realworld/cell-worker.ts", import.meta.url), { type: "module" }) : undefined;
if (worldCenter || geographicSave) {
  const { loadRealWorld } = await import("./realworld/load");
  const { installWorldSnapshot } = await import("./realworld/runtime");
  const status = document.createElement("p");
  status.setAttribute("role", "status");
  status.textContent = "Preparing world data…";
  document.body.append(status);
  try {
    const progress = (complete: number, total: number) => {
      status.textContent = `Caching geographic sources: ${total ? Math.floor(complete / total * 100) : 100}%`;
    };
    const { preloadGeographicSources } = await import("./realworld/dataset");
    await preloadGeographicSources(progress, undefined, undefined, { citySource: true });
    if (geographicSave) {
      const [{ anchorGeographicDataset, loadGeographicDataset }, { geographicCheckpointSnapshot }] = await Promise.all([
        import("./realworld/dataset"), import("./realworld/checkpoint"),
      ]);
      // Laid out around the save's own anchor (a save under another projection is refused by its snapshot).
      const dataset = await loadGeographicDataset(progress);
      if (geographicSave.anchor?.projection === dataset.world.anchor.projection) anchorGeographicDataset(dataset, geographicSave.anchor);
      geographicWorld = dataset.world;
      installWorldSnapshot(geographicCheckpointSnapshot(geographicSave, geographicWorld));
    } else {
      // The sources the game reads whole cached, the worker decodes the world (publishing it: the page views the same
      // memory), reads the starting region and builds its plan; the page builds them itself only if the worker can't.
      // The objects request from the atlas's config, not the atlas itself: its code loads later, not before the world data is checked.
      const [{ worldDataBase }, { geographicSourceKey, geographicCentersKey }, { objectsRequest }, { shareSources, sharedSourceValue }, { geographicWorldOf }, { geographicAnchorAt }] = await Promise.all([
        import("./realworld/assets"), import("./realworld/dataset"), import("./atlas/config"), import("./realworld/shared-sources"),
        import("./realworld/global"), import("./realworld/coordinates"),
      ]);
      cellWorker = earlyCellWorker!;
      shareSources(cellWorker);
      // The page only waits on the worker from here: what the scene paints as it builds (the ground's materials, the
      // nature atlas, the fronts' textures), the item atlas's small set and the pawn atlas are begun meanwhile, in the
      // atlas workers (off-page.ts: the pawns in a lane of their own where there are the cores; the small set on this
      // page where there are none), not on the way from the scene to the first view. Begun at the cell worker's first
      // message (the world it decoded), as a worker's start needs this thread too. In one lane they go in the order
      // the first view wants them, the ground and the pawns first (one still on its way when wanted is painted again
      // on the page; the pawns just show once theirs is back). A failure is each one's to report when it paints itself.
      cellWorker.addEventListener("message", () => void Promise.all([
        import("./render/textures"), import("./render/props/painted-atlas"), import("./render/front-textures"),
        import("./render/items/painted-sets"), import("./render/pawns/atlas-off-page"),
      ]).then(([{ paintGroundEarly }, { paintNatureEarly }, { paintFrontTexturesEarly }, { paintSmallSetEarly }, { paintPawnAtlasEarly }]) => {
        paintGroundEarly();
        paintPawnAtlasEarly();
        paintNatureEarly();
        paintFrontTexturesEarly();
        paintSmallSetEarly();
      }).catch(() => {}), { once: true });
      // The game's code loads while the worker prepares the starting region, not after: the scene's modules (and so
      // main.ts's, all but main.ts itself) and those the plan is built with below. None reads the world, the atlas, the
      // snapshot or the terrain source as it loads (only from functions called later), so they load the same whenever
      // they do; the imports below take them from here. A failure shows there, where each is awaited.
      void Promise.all([
        import("./services/scene-bootstrap"), import("./atlas/install"), import("./worldgen/plan-transfer"),
        import("./worldgen/plan-cache"), import("./worldgen/runtime"),
      ]).catch(() => {});
      const reply = await startingCell(cellWorker, worldDataBase(), worldCenter!, objectsRequest());
      // The chunk workers wait for this (services/boot-workers.ts): they load their code while the page builds the plan.
      startBootWorkers();
      // Published before the reply, on the same port.
      const source = sharedSourceValue<import("./realworld/global").GeographicWorldSource>(geographicSourceKey(worldDataBase()));
      const centers = sharedSourceValue<import("./realworld/model").Center[]>(geographicCentersKey(worldDataBase()));
      // The worker's world id is the pack's plus the city detail it opened (if any): the page's world takes it whole.
      // The world is laid out true scale around its starting place (coordinates.ts): the worker anchored it there too.
      const start = centers?.find((item) => item.center_id === worldCenter);
      if ("error" in reply || !source || !centers || !start || (reply.worldSourceId !== source.sourceId && !reply.worldSourceId.startsWith(`${source.sourceId}:`))) {
        console.warn("[infected] geographic worker:", "error" in reply ? reply.error : "source differs", "- preparing the starting region here");
        const loaded = await loadRealWorld(worldCenter!, progress);
        geographicWorld = loaded.dataset.world;
        installWorldSnapshot(loaded.snapshot);
      } else {
        geographicWorld = { ...geographicWorldOf(source, centers, geographicAnchorAt(start.longitude, start.latitude)), sourceId: reply.worldSourceId };
        installWorldSnapshot({ ...reply.snapshot, geography: geographicWorld });
      }
    }
    status.remove();
  } catch (error) {
    status.textContent = `World data could not load: ${error instanceof Error ? error.message : String(error)}. Reload to retry; completed downloads are kept.`;
    throw error;
  }
}
// Generation creates ECS worlds, so every scene schema must be registered first.
await import("./services/scene-bootstrap");
const [{ activeAtlas, installAtlas, installRequestedAtlas, objectsRequest }, { packPlan, unpackPlan }, { loadPlan, savePlan }, { adoptPlan }] = await Promise.all([
  import("./atlas/install"),
  import("./worldgen/plan-transfer"),
  import("./worldgen/plan-cache"),
  import("./worldgen/runtime"),
]);
// Ordinary game entry uses the geographic source; explicit tools and scenarios select their own.
if (geographicWorld) installAtlas("earth", geographicSave?.objects ?? objectsRequest());
else installRequestedAtlas();
/** The plan message every boot worker gets: this visit's world plan, or none for a planless tool source. */
const planMessage = async (): Promise<unknown> => {
  const atlas = activeAtlas();
  if (!atlas) return { type: "infected-plan", plan: null };
  const key = atlas.atlas.manifest.spaces.find((s) => s.index === atlas.space)!.key;
  const objects = atlas.atlas.objects;
  // Last visit's plan if this build made it (plan-cache.ts), else built here once: main.ts's modules reuse it.
  const stored = key === "earth" ? null : await loadPlan(key, objects);
  if (stored) {
    // Whole again in place; its class list still holds for the copies posted below.
    adoptPlan(atlas.atlas.manifest, key, objects, unpackPlan(stored));
    return stored;
  }
  const snapshot = key === "earth" ? (await import("./realworld/runtime")).realWorldSnapshot() : undefined;
  // The starting region's plan as the geographic worker built it, when it is the one built here.
  if (snapshot?.preparedPlan) {
    if ((await import("./realworld/prepare-region")).preparedPlanFits(snapshot, objects)) adoptPlan(atlas.atlas.manifest, key, objects, unpackPlan(snapshot.preparedPlan));
    delete snapshot.preparedPlan;
  }
  const plan = atlas.atlas.plan(atlas.space);
  const fresh = packPlan(key, objects, plan);
  if (key === "earth") {
    if (snapshot?.cell && snapshot.geography) {
      const { geographicPlanHomes } = await import("./realworld/cell-homes");
      const result = geographicPlanHomes(snapshot.geography, snapshot.cell, plan);
      if (result.error !== null) throw new Error(`Cannot prepare population: ${result.error}`);
      const error = atlas.atlas.prepareGeographicHomes(result.homes);
      if (error) throw new Error(error);
      snapshot.geography.homes = [result.homes];
    }
    fresh.world = snapshot;
  }
  // Stored once the game is up and idle, off the way to the first frame.
  if (key !== "earth") setTimeout(() => (globalThis.requestIdleCallback ?? setTimeout)(() => void savePlan(fresh), { timeout: 20_000 }), 8_000);
  return fresh;
};
const packed = await planMessage();
// A replay's shadow islands start workers of their own later, and give them the same plan.
keepPlanMessage(packed);
if (geographicSave) {
  const [{ restoreGeographicCheckpoint }, { packGeographicRegion }] = await Promise.all([
    import("./realworld/checkpoint"), import("./realworld/region-transfer"),
  ]);
  try {
    restoreGeographicCheckpoint(activeAtlas()!.atlas, geographicSave,
      region => publishRegionMessage(packGeographicRegion(region)),
      !!entry.get("replay") && !entry.get("key") && !entry.get("load"));
  } catch (error) {
    const status = document.createElement("p");
    status.setAttribute("role", "alert");
    status.textContent = `The saved world could not be restored: ${error instanceof Error ? error.message : String(error)}.`;
    document.body.append(status);
    throw error;
  }
}
if (geographicWorld) {
  const source = activeAtlas()!.atlas;
  let loader: Promise<import("./realworld/region-loader").GeographicRegionLoader> | undefined;
  /** The loader once made, for the map's sketches (read every frame, so not through a promise). */
  let made: import("./realworld/region-loader").GeographicRegionLoader | undefined;
  const owner = () => (loader ??= Promise.all([import("./realworld/region-loader"), import("./realworld/cell-client"), import("./realworld/assets"), import("./realworld/shared-sources")]).then(([{ GeographicRegionLoader }, { GeographicCellClient }, { worldDataBase }, { shareSources }]) => {
      const worker = cellWorker ?? new Worker(new URL("./realworld/cell-worker.ts", import.meta.url), { type: "module" });
      // A worker started here (a save's boot) views the world the page decoded instead of decoding its own.
      if (!cellWorker) shareSources(worker);
      const client = new GeographicCellClient(worker, source.geography!, worldDataBase(), source.objects);
      addEventListener("pagehide", () => client.close(), { once: true });
      return (made = new GeographicRegionLoader(source, streamRegionMessage, (longitude, latitude, frame) => client.load(longitude, latitude, frame)));
    }));
  source.setRegionLoader({ load: chunks => owner().then(loader => loader.load(chunks)), prefetch: (cx, cy, reach) => void owner().then(loader => loader.prefetch(cx, cy, reach)),
    sketch: chunks => void owner().then(loader => loader.sketch(chunks)), sketches: () => made?.sketches() ?? [], retire: cell => source.retireGeographicRegion(cell, true) && retireRegionMessage(cell) });
  // Subsequent requests own the archives in the geographic worker; keep only the installed world here.
  geographicWorld = undefined;
}

/** The starting place's cell, read and planned on the geographic worker (an error reply when it fails). */
function startingCell(worker: Worker, base: string, center: string, objects: boolean) {
  return new Promise<GeographicCellReply>((resolve) => {
    const id = -1;
    const fail = (event: ErrorEvent) => resolve({ type: "geographic-cell", id, error: event.message || "Geographic source worker failed" });
    const reply = (event: MessageEvent<GeographicCellReply>) => {
      if (event.data?.type !== "geographic-cell" || event.data.id !== id) return;
      worker.removeEventListener("message", reply);
      worker.removeEventListener("error", fail);
      resolve(event.data);
    };
    worker.addEventListener("message", reply);
    worker.addEventListener("error", fail);
    worker.postMessage({ type: "geographic-cell", id, base, longitude: NaN, latitude: NaN, center, objects } satisfies GeographicCellRequest);
  });
}

// Map geometry and raster preparation are a boot dependency, never a surprise after Begin.
const mapWorld = activeAtlas()?.atlas.geography;
if (mapWorld) {
  const status = document.createElement("p");
  status.setAttribute("role", "status");
  status.textContent = "Preparing starting map…";
  document.body.append(status);
  try {
    const { prepareInitialMap } = await import("./realworld/map-startup");
    await prepareInitialMap(mapWorld, activeAtlas()!.atlas.objects, innerWidth, innerHeight, devicePixelRatio,
      (ready, total) => { status.textContent = `Preparing starting map: ${ready}/${total}`; });
    status.remove();
  } catch (error) {
    status.setAttribute("role", "alert");
    status.textContent = `The starting map could not load: ${error instanceof Error ? error.message : String(error)}. Reload to retry.`;
    throw error;
  }
}

// The pool takes ownership only after every worker receives the selected world plan.
void import("./main");
