import { State } from "../domain/disease";

/** Semantic facts generate both the sprite and biography; promotion never guesses from pixels. */
export type CrowdAppearance = {
  sprite: number;
  tint: number;
  age: number;
  sex: "male" | "female";
  culture: string;
  occupation: string;
};
export type CrowdWalker = {
  key: string;
  appearance: CrowdAppearance;
  state: State;
  x: number;
  y: number;
  route: string;
};
export type PooledPerson = {
  gid: number;
  state: State;
  interacted: boolean;
  knownRelationship: boolean;
  tracked: boolean;
  possessed: boolean;
  walkerKey?: string;
  appearance: CrowdAppearance;
  history: { born: number; trainedFor: string; employedAs: string };
  x: number;
  y: number;
  route: string;
};

/** Infection includes silent carriers; replacing one would erase authoritative disease state. */
export const reusableCrowdPerson = (person: PooledPerson) =>
  person.state === State.Susceptible &&
  !person.interacted &&
  !person.knownRelationship &&
  !person.tracked &&
  !person.possessed;

export const crowdMemberFor = (people: readonly PooledPerson[], walker: CrowdWalker): PooledPerson | null =>
  people.find((person) => person.walkerKey === walker.key) ?? people.find(reusableCrowdPerson) ?? null;

/** Construct a replacement record in full. The old member's biography must never leak through. */
export const materializeCrowdPerson = (
  member: PooledPerson,
  walker: CrowdWalker,
  year: number
): { person: PooledPerson | null; error: string | null } => {
  if (member.walkerKey === walker.key) return { person: member, error: null };
  if (!reusableCrowdPerson(member)) return { person: null, error: "Person identity is protected" };
  const appearance = { ...walker.appearance };
  return {
    error: null,
    person: {
      gid: member.gid,
      walkerKey: walker.key,
      appearance,
      history: { born: year - appearance.age, trainedFor: appearance.occupation, employedAs: appearance.occupation },
      state: walker.state,
      interacted: true,
      knownRelationship: false,
      tracked: false,
      possessed: false,
      x: walker.x,
      y: walker.y,
      route: walker.route,
    },
  };
};
