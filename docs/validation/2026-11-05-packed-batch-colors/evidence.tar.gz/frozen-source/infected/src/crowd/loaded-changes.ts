import { distributeLoadedPopulation, MAX_LOADED_PEOPLE, type LoadedPopulationChunk } from "./loaded-budget";

export type LoadedPopulationState = LoadedPopulationChunk & {
  /** Includes admitted load requests until they are canceled or their entities are retired. */
  materialized: number;
};

/** A transition uses currently free slots; retirements become free only after acknowledgement. */
export const loadedPopulationChanges = (chunks: readonly LoadedPopulationState[], maximum = MAX_LOADED_PEOPLE) => {
  let current = 0;
  for (const chunk of chunks) {
    if (!Number.isSafeInteger(chunk.materialized) || chunk.materialized < chunk.protected)
      throw new RangeError("Invalid materialized population count");
    current += chunk.materialized;
  }
  if (!Number.isSafeInteger(current) || current > MAX_LOADED_PEOPLE)
    throw new RangeError("Materialized population exceeds the hard loaded ceiling");
  const budget = distributeLoadedPopulation(chunks, maximum);
  const retire = new Map<string, number>();
  const demand: LoadedPopulationChunk[] = [];
  for (const chunk of chunks) {
    const target = budget.allocations.get(chunk.key)!;
    retire.set(chunk.key, Math.max(0, chunk.materialized - target));
    demand.push({ key: chunk.key, population: Math.max(0, target - chunk.materialized), protected: 0 });
  }
  const admit = distributeLoadedPopulation(demand, Math.max(0, maximum - current));
  return { targets: budget.allocations, retire, admit: admit.allocations, protectedOverflow: budget.protectedOverflow };
};
