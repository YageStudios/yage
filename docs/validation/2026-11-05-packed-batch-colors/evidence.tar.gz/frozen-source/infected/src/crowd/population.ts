import { dailyActivity, type DailyRoutineProfile } from "../domain/people/daily-routine";
export type CrowdHealthCounts = { susceptible: number; incubating: number; infected: number; dead: number };
export type CrowdConditions = {
  time: number;
  weather: number;
  fear: number;
  curfew: number;
  martialLaw: number;
  sheltering: number;
  /** Participation already resolved by the event simulation, independently of ordinary compliance. */
  protest?: number;
  evacuation?: number;
  workplaceShare?: number;
  regionalRoutine?: { profile: DailyRoutineProfile; localHour: number };
};
export type CrowdOccupationPolicy = {
  outsideShare: number;
  fearResponse: number;
  curfewCompliance: number;
  martialLawCompliance: number;
  shelterCompliance: number;
  incubatingMobility: number;
  infectedMobility: number;
};
const unit = (value: number) => Math.max(0, Math.min(1, value));

export type CrowdPresence = {
  home: CrowdHealthCounts;
  workplace: CrowdHealthCounts;
  routine: CrowdHealthCounts;
  protest: CrowdHealthCounts;
  evacuating: CrowdHealthCounts;
  dead: number;
};
const emptyCounts = (): CrowdHealthCounts => ({ susceptible: 0, incubating: 0, infected: 0, dead: 0 });

/** People stay indoors unless routine or an explicit event brings them outside. Compartments never overlap. */
export const crowdPresence = (
  population: CrowdHealthCounts,
  materialized: CrowdPresence,
  conditions: CrowdConditions,
  policy: CrowdOccupationPolicy
): CrowdPresence => {
  const regional = conditions.regionalRoutine
    ? dailyActivity(conditions.regionalRoutine.profile, conditions.regionalRoutine.localHour)
    : undefined;
  const activity =
    unit(policy.outsideShare) *
    unit(conditions.time) *
    unit(conditions.weather) *
    (regional?.street ?? 1) *
    (1 - unit(conditions.fear) * unit(policy.fearResponse)) *
    (1 - unit(conditions.curfew) * unit(policy.curfewCompliance)) *
    (1 - unit(conditions.martialLaw) * unit(policy.martialLawCompliance)) *
    (1 - unit(conditions.sheltering) * unit(policy.shelterCompliance));
  const presence: CrowdPresence = {
    home: emptyCounts(),
    workplace: emptyCounts(),
    routine: emptyCounts(),
    protest: emptyCounts(),
    evacuating: emptyCounts(),
    dead: Math.max(0, population.dead - materialized.dead),
  };
  const work = unit(conditions.workplaceShare ?? regional?.workplace ?? 0);
  const categories = ["home", "workplace", "routine", "protest", "evacuating"] as const;
  for (const state of ["susceptible", "incubating", "infected"] as const) {
    const total = population[state];
    const mobility =
      state === "susceptible" ? 1 : unit(state === "incubating" ? policy.incubatingMobility : policy.infectedMobility);
    const mobile = total * mobility;
    presence.evacuating[state] = mobile * unit(conditions.evacuation ?? 0);
    presence.protest[state] = (mobile - presence.evacuating[state]) * unit(conditions.protest ?? 0);
    presence.routine[state] = (mobile - presence.evacuating[state] - presence.protest[state]) * activity;
    const inside = Math.max(0, total - presence.evacuating[state] - presence.protest[state] - presence.routine[state]);
    presence.workplace[state] = inside * work;
    presence.home[state] = inside - presence.workplace[state];
    let known = 0,
      weight = 0;
    for (const category of categories) {
      known += materialized[category][state];
      presence[category][state] = Math.max(0, presence[category][state] - materialized[category][state]);
      weight += presence[category][state];
    }
    // A player can keep more people outside than the routine predicts. Their identities and
    // positions win; distribute the remaining aggregate residents without inventing people.
    const remaining = Math.max(0, total - known);
    let excess = Math.max(0, weight - remaining);
    for (const category of categories) {
      const reduction = Math.min(excess, presence[category][state]);
      presence[category][state] -= reduction;
      excess -= reduction;
    }
    presence.home[state] += Math.max(0, remaining - weight);
  }
  return presence;
};

/** Render budgets may thin the result, but never change the represented population or health. */
export const crowdOutside = (
  population: CrowdHealthCounts,
  materialized: CrowdPresence,
  conditions: CrowdConditions,
  policy: CrowdOccupationPolicy
): CrowdHealthCounts => {
  const presence = crowdPresence(population, materialized, conditions, policy);
  return {
    susceptible: presence.routine.susceptible + presence.protest.susceptible + presence.evacuating.susceptible,
    incubating: presence.routine.incubating + presence.protest.incubating + presence.evacuating.incubating,
    infected: presence.routine.infected + presence.protest.infected + presence.evacuating.infected,
    dead: 0,
  };
};
