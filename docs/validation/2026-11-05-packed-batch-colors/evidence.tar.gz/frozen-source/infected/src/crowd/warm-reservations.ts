import { MAX_LOADED_PEOPLE } from "./loaded-budget";

export type WarmPopulationRequest = { key: number; population: number };
type WarmPopulationDemand = WarmPopulationRequest & {
  /** Source residents per equal-area chunk; fitted demand is the fallback. */
  density?: number;
};

/** Reserve whole-chunk loads until the authority acknowledges their retirement. */
export const reserveWarmPopulation = (
  reservations: Map<number, number>,
  loaded: readonly WarmPopulationRequest[],
  retiring: ReadonlySet<number>,
  requests: readonly WarmPopulationDemand[],
  travellers: number,
  maximum = MAX_LOADED_PEOPLE
): number[] => {
  if (
    !Number.isSafeInteger(maximum) ||
    maximum < 0 ||
    maximum > MAX_LOADED_PEOPLE ||
    !Number.isSafeInteger(travellers) ||
    travellers < 0
  )
    throw new RangeError("Invalid warm population capacity");
  const loadedKeys = new Set(loaded.map((chunk) => chunk.key));
  const requestKeys = new Set<number>();
  for (const request of [...loaded, ...requests]) {
    if (
      !Number.isSafeInteger(request.key) ||
      !Number.isSafeInteger(request.population) ||
      request.population < 0
    )
      throw new RangeError("Invalid warm population request");
  }
  for (const request of requests) {
    if (
      request.density !== undefined &&
      (!Number.isFinite(request.density) || request.density < 0)
    )
      throw new RangeError("Invalid warm population density");
    if (requestKeys.has(request.key))
      throw new RangeError("Duplicate warm population request");
    requestKeys.add(request.key);
  }
  for (const [key, population] of reservations) {
    if (!Number.isSafeInteger(population) || population < 0)
      throw new RangeError("Invalid warm population reservation");
    if (!loadedKeys.has(key) && !retiring.has(key)) reservations.delete(key);
  }
  // Reported counts can grow through arrivals. A lower report does not acknowledge retirement.
  for (const chunk of loaded)
    reservations.set(
      chunk.key,
      Math.max(reservations.get(chunk.key) ?? 0, chunk.population)
    );
  const occupied = [...reservations.values()].reduce(
    (sum, count) => sum + count,
    travellers
  );
  if (!Number.isSafeInteger(occupied))
    throw new RangeError("Warm population exceeds safe integer range");
  let available = Math.max(0, maximum - occupied);
  const admitted: number[] = [];
  // Chunks have equal area: resident demand orders these whole-chunk requests by density.
  for (const request of [...requests].sort(
    (a, b) =>
      (b.density ?? b.population) - (a.density ?? a.population) || a.key - b.key
  )) {
    if (
      reservations.has(request.key) ||
      retiring.has(request.key) ||
      request.population > available
    )
      continue;
    reservations.set(request.key, request.population);
    available -= request.population;
    admitted.push(request.key);
  }
  return admitted;
};
