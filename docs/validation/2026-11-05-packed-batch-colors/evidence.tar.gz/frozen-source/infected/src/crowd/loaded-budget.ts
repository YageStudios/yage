export const MAX_LOADED_PEOPLE = 32_000_000;

export type LoadedPopulationChunk = {
  key: string;
  /** Demand for detailed entities in this chunk, not its total census or a global sample. */
  population: number;
  /** Already materialized identities which cannot be reclaimed. */
  protected: number;
};

export type LoadedPopulationBudget = {
  allocations: Map<string, number>;
  allocated: number;
  /** Protected identities survive even when a caller lowers the requested ceiling. */
  protectedOverflow: number;
};

/** Allocate only loaded population. Unused capacity does not manufacture extra residents. */
export const distributeLoadedPopulation = (
  chunks: readonly LoadedPopulationChunk[],
  maximum = MAX_LOADED_PEOPLE
): LoadedPopulationBudget => {
  if (!Number.isSafeInteger(maximum) || maximum < 0 || maximum > MAX_LOADED_PEOPLE)
    throw new RangeError("Invalid loaded population ceiling");
  const ordered = [...chunks].sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
  let protectedTotal = 0;
  let availableTotal = 0;
  for (let i = 0; i < ordered.length; i++) {
    const chunk = ordered[i];
    if (!chunk.key || (i > 0 && ordered[i - 1].key === chunk.key))
      throw new RangeError("Loaded population chunks require unique keys");
    if (
      !Number.isSafeInteger(chunk.population) ||
      chunk.population < 0 ||
      !Number.isSafeInteger(chunk.protected) ||
      chunk.protected < 0 ||
      chunk.protected > chunk.population
    )
      throw new RangeError("Invalid loaded chunk population");
    protectedTotal += chunk.protected;
    availableTotal += chunk.population - chunk.protected;
  }
  if (!Number.isSafeInteger(protectedTotal + availableTotal))
    throw new RangeError("Loaded population exceeds safe integer range");
  if (protectedTotal > MAX_LOADED_PEOPLE) throw new RangeError("Protected population exceeds the hard loaded ceiling");
  const remaining = Math.min(availableTotal, Math.max(0, maximum - protectedTotal));
  const allocations = new Map<string, number>();
  const remainders: { key: string; fraction: number }[] = [];
  let allocated = protectedTotal;
  for (const chunk of ordered) {
    const share = availableTotal ? remaining * ((chunk.population - chunk.protected) / availableTotal) : 0;
    const count = Math.floor(share);
    allocations.set(chunk.key, chunk.protected + count);
    allocated += count;
    if (count < chunk.population - chunk.protected) remainders.push({ key: chunk.key, fraction: share - count });
  }
  // Largest remainders conserve the budget without favoring the caller's chunk order.
  remainders.sort((a, b) => b.fraction - a.fraction || (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
  const missing = protectedTotal + remaining - allocated;
  for (let i = 0; i < missing; i++) {
    const key = remainders[i].key;
    allocations.set(key, allocations.get(key)! + 1);
    allocated++;
  }
  return { allocations, allocated, protectedOverflow: Math.max(0, protectedTotal - maximum) };
};
