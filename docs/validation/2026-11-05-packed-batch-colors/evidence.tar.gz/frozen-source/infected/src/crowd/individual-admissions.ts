import { MAX_LOADED_PEOPLE } from "./loaded-budget";

/** One synchronous authority pass; no other pass mutates reservations until it returns. */
export class IndividualAdmissions {
  private room: number;

  constructor(
    private readonly reservations: Map<number, number>,
    travellers: number,
    maximum = MAX_LOADED_PEOPLE
  ) {
    if (
      !Number.isSafeInteger(maximum) ||
      maximum < 0 ||
      maximum > MAX_LOADED_PEOPLE ||
      !Number.isSafeInteger(travellers) ||
      travellers < 0
    )
      throw new RangeError("Invalid individual population capacity");
    let occupied = travellers;
    for (const count of reservations.values()) {
      if (!Number.isSafeInteger(count) || count < 0)
        throw new RangeError("Invalid population reservation");
      occupied += count;
    }
    if (!Number.isSafeInteger(occupied))
      throw new RangeError("Population reservations exceed safe integer range");
    this.room = Math.max(0, maximum - occupied);
  }

  get remaining() {
    return this.room;
  }

  canCharge(key: number, count: number) {
    return (
      Number.isSafeInteger(count) &&
      count > 0 &&
      count <= this.room &&
      this.reservations.has(key)
    );
  }

  /** Preflight before source mutation; commit within the same synchronous authority pass. */
  charge(key: number, count: number) {
    const reserved = this.reservations.get(key);
    if (reserved === undefined)
      throw new RangeError("Individual admission requires a reserved chunk");
    if (!this.canCharge(key, count))
      throw new RangeError("Individual admission exceeds remaining capacity");
    this.reservations.set(key, reserved + count);
    this.room -= count;
  }
}
