/** Content table shapes. People: cultures, dress, trait labels and occupations. The checker is in ./check.ts; ./index.ts assembles every table. */
import { arr, num, obj, rec, str, type Shape } from "./check";
export type TraitInfo = { bit: number; label: string; text: string };
export type OccupationLabels = { baby: string; toddler: string; pupil: string; farmChild: string; retired: string; homemaker: string; betweenJobs: string; labourer: string };
export type Occupations = { byPlace: Record<string, string[]>; farm: string[][]; labels: OccupationLabels };
const trait = obj({ bit: num, label: str, text: str });
export const PEOPLE_SHAPES: Record<"cultures" | "dress" | "traits" | "occupations" | "households", Shape> = {
  cultures: arr(obj({ id: num, name: str, male: arr(str), female: arr(str), surnames: arr(str), dress: num, dressText: str, restDay: num, festival: obj({ name: str, every: num, offset: num }), diet: str })),
  dress: arr(str),
  traits: arr(arr(trait, 2)),
  occupations: obj({
    byPlace: rec(arr(str)),
    farm: arr(arr(str)),
    labels: obj({ baby: str, toddler: str, pupil: str, farmChild: str, retired: str, homemaker: str, betweenJobs: str, labourer: str }),
  }),
  households: obj({ house: arr(num, 6), farm: arr(num, 5), hut: arr(num, 3), cabin: arr(num, 4), flat: arr(num, 3) }),
};
