/** Content table shapes. Simulation numbers: critters, viral load, lingering, weather, disease and the sim tables. The checker is in ./check.ts; ./index.ts assembles every table. */
import type { Traits } from "../../domain/disease";
import { arr, num, obj, prim, range, str, type Shape } from "./check";
export type CritterNumbers = {
  ratsPerAlley: number; maxRats: number;
  flocksPerTile: number; maxFlocks: number; flock: readonly [number, number];
  herdsPerBlock: number; maxHerds: number; herd: readonly [number, number];
  meadowHerdsPerBlock: number; maxMeadowHerds: number;
  packsPerStreet: number; maxPacks: number; pack: readonly [number, number];
  swarmsPerBank: number; swarmsPerGrass: number; maxSwarms: number;
  ratSpeed: number; birdSpeed: number; grazeSpeed: number; dogSpeed: number;
};
/** The load model's tunable numbers (content/load.json5, without spore). */
export type LoadNumbers = { breathRadius: number; breathReach: number; sneezeLoad: number; sneezeSize: number; coughPush: number; sneezePush: number; carry: number; drag: number; startSize: number; grow: number; inhale: number; epsilon: number; surfaceMax: number; puddle: number; pickup: number; touchFurniture: number; touchDoor: number; recoil: number; walkingCough: number; restingCough: number; bleed: number; fall: number; sporePush: number; maxClouds: number };
/** content/weather.json5, section by section. */
export type WeatherTables = {
  weather: { slotHours: number; reach: number; perSlot: number; daily: number; heatWave: number; coldSnap: number; rainCool: number; snowBelow: number; wetSamples: number; snowSamples: number; stormShare: number };
  extremes: { floodSamples: number; floodEveryHours: number; floodFrom: number; floodFull: number; closeAt: number; floodReach: number; strikes: number; winterSpread: number; summerEase: number; winterIndoors: number; heatstroke: number; exposure: number };
};
/** content/disease.json5, section by section. */
export type DiseaseTables = {
  traits: Traits;
  rules: { alertShare: number; alertMinimum: number; soldiersPerVisible: number; soldierSquad: number; maxSoldierShare: number; huntCells: number; soldierSpeed: number; fleeCells: number; fleeSpeed: number; hiveSpeed: number; hostSpeed: number; coldBelowCy: number; hotAboveCy: number; victoryShare: number; extinctionGrace: number; treatPerHour: number; weatherStress: number; lifeJitter: number; hostDecay: number; decayStages: readonly number[]; warnSeconds: number; offerSeconds: number; revealShare: number; biteKill: number; biteSoldierTiles: number; huntSpeed: number; reanimateLife: number; reanimateFeed: number; scavengeFeed: number; scavengeBites: number; metabolismLife: number; metabolismWild: number; breedYear: number; beastDay: number; mutantShare: number };
  symptoms: { collapseFrom: number; bleedFloor: number; hunch: { cough: number; sneeze: number; vomit: number; bleed: number }; down: number; slowest: number; homeAtWorst: number; sitAtWorst: number };
};
/** content/sim.json5, section by section. */
export type SimTables = {
  cabin: { ventSeconds: number; platformVentSeconds: number; platformClose: number; platformRoom: number; close: number; cough: number; sneeze: number; standing: number; railTouch: number; metal: number; rail: number };
  routes: { critter: Record<"rat" | "bird" | "sheep" | "cow" | "dog" | "mosquito", number>; platformRats: number; drinksPerDay: number; drinkSeconds: number; drinkDose: number; drinkChance: number; countryReach: number };
  warm: { breath: number; cough: number; sneeze: number; spore: number; touch: number };
  shun: { reach: number; step: number; share: number };
  cold: { every: number; crowd: number; workFrom: number; workTo: number; warmRing: number; hostRing: number; budget: number };
  soldiers: { fleeDistance: number; fleeTurns: number[] };
};
const LOAD_KEYS = ["breathRadius", "breathReach", "sneezeLoad", "sneezeSize", "coughPush", "sneezePush", "carry", "drag", "startSize", "grow", "inhale", "epsilon", "surfaceMax", "puddle", "pickup", "touchFurniture", "touchDoor", "recoil", "walkingCough", "restingCough", "bleed", "fall", "sporePush", "maxClouds"];
/** content/arms.json5: weapons and what anyone can wear against the strain (src/domain/arms.ts). */
export type Weapon = { id: string; name: string; text: string; range: number; hits: number; misses: number; spread: number; pellets: number; pierce: number; /** Player shots a second at most (default hits + misses). */ rate?: number; /** Held trigger keeps firing. */ automatic?: boolean; /** Rounds a magazine, and seconds to reload one. */ magazine?: number; reload?: number; /** The player's aim (src/domain/arms.ts playerSpread). */ aim?: PlayerAim };
/** How a weapon aims in the player's hands: radians either side swinging and held still, the tiles out at which that doubles, seconds to settle, and the settling a shot throws off. */
export type PlayerAim = { loose: number; steady: number; doubles: number; settle: number; kick: number };
export type Gear = { id: string; name: string; text: string; intake: number };
export type ArmsTables = { weapons: Weapon[]; gear: Gear[] };
export const SIM_SHAPES: Record<"critters" | "load" | "linger" | "weather" | "disease" | "sim" | "arms", Shape> = {
  arms: obj({
    weapons: arr(obj({ id: str, name: str, text: str, range: num, hits: num, misses: num, spread: num, pellets: num, pierce: num, "rate?": num, "automatic?": prim("boolean"), "magazine?": num, "reload?": num, "aim?": obj({ loose: num, steady: num, doubles: num, settle: num, kick: num }) })),
    gear: arr(obj({ id: str, name: str, text: str, intake: num })),
  }),
  critters: obj({
    ...Object.fromEntries(["ratsPerAlley", "maxRats", "flocksPerTile", "maxFlocks", "herdsPerBlock", "maxHerds", "meadowHerdsPerBlock", "maxMeadowHerds", "packsPerStreet", "maxPacks", "swarmsPerBank", "swarmsPerGrass", "maxSwarms", "ratSpeed", "birdSpeed", "grazeSpeed", "dogSpeed"].map((k) => [k, num])),
    flock: range, herd: range, pack: range,
  }),
  load: obj({
    ...Object.fromEntries(LOAD_KEYS.map((k) => [k, num])),
    spore: obj({ load: num, size: num, life: num, corpses: num }),
  }),
  linger: obj({ air: arr(num, 4), surface: arr(num, 4), wind: num, wash: num }),
  weather: obj({
    weather: obj({ slotHours: num, reach: num, perSlot: num, daily: num, heatWave: num, coldSnap: num, rainCool: num, snowBelow: num, wetSamples: num, snowSamples: num, stormShare: num }),
    extremes: obj({ floodSamples: num, floodEveryHours: num, floodFrom: num, floodFull: num, closeAt: num, floodReach: num, strikes: num, winterSpread: num, summerEase: num, winterIndoors: num, heatstroke: num, exposure: num }),
  }),
  disease: obj({
    traits: obj({ pathogen: str, start: num, infectivity: num, dose: num, clearance: num, breath: num, cough: num, sneeze: num, vomit: num, cloudLoad: num, cloudSize: num, cloudLife: num, touch: num, persistence: num, stagger: num, incubation: num, lifespan: num, decay: num, reach: num, reachWeight: num, corpses: num, aggression: num, frenzy: num, bite: num, reanimate: num, scavenge: num, metabolism: num, breed: num, beasts: num, mutation: num, visibility: num, armor: num, cold: num, heat: num, pickRate: num, cascade: num, cureResist: num, reshuffle: num, evasion: num, rodent: num, bird: num, livestock: num, water: num, dog: num, mosquito: num, bleed: num, collapse: num, spores: num, silent: num, steady: num, drift: num }),
    rules: obj({ alertShare: num, alertMinimum: num, soldiersPerVisible: num, soldierSquad: num, maxSoldierShare: num, huntCells: num, soldierSpeed: num, fleeCells: num, fleeSpeed: num, hiveSpeed: num, hostSpeed: num, coldBelowCy: num, hotAboveCy: num, victoryShare: num, extinctionGrace: num, treatPerHour: num, weatherStress: num, lifeJitter: num, hostDecay: num, decayStages: arr(num), warnSeconds: num, offerSeconds: num, revealShare: num, biteKill: num, biteSoldierTiles: num, huntSpeed: num, reanimateLife: num, reanimateFeed: num, scavengeFeed: num, scavengeBites: num, metabolismLife: num, metabolismWild: num, breedYear: num, beastDay: num, mutantShare: num }),
    symptoms: obj({ collapseFrom: num, bleedFloor: num, hunch: obj({ cough: num, sneeze: num, vomit: num, bleed: num }), down: num, slowest: num, homeAtWorst: num, sitAtWorst: num }),
  }),
  sim: obj({
    cabin: obj({ ventSeconds: num, platformVentSeconds: num, platformClose: num, platformRoom: num, close: num, cough: num, sneeze: num, standing: num, railTouch: num, metal: num, rail: num }),
    routes: obj({ critter: obj({ rat: num, bird: num, sheep: num, cow: num, dog: num, mosquito: num }), platformRats: num, drinksPerDay: num, drinkSeconds: num, drinkDose: num, drinkChance: num, countryReach: num }),
    warm: obj({ breath: num, cough: num, sneeze: num, spore: num, touch: num }),
    shun: obj({ reach: num, step: num, share: num }),
    cold: obj({ every: num, crowd: num, workFrom: num, workTo: num, warmRing: num, hostRing: num, budget: num }),
    soldiers: obj({ fleeDistance: num, fleeTurns: arr(num, 5) }),
  }),
};
