/** The evolution catalog is authored in JSON5; rules import these tables explicitly. */
import { CONTENT } from "./runtime";
import type { Card, Pathogen, PassiveNode, Progression } from "../domain/mutation-types";

/** Pacing of picks and unlock points (content/progression.json5). */
export const PROGRESSION: Progression = CONTENT.progression;

/** Pathogens (content/pathogens.json5). */
export const PATHOGENS: Pathogen[] = CONTENT.pathogens;

/** Cards (content/cards.json5), in pool order. */
export const CARDS: Card[] = CONTENT.cards;

/** The passive tree's nodes (content/passive-tree.json5). */
export const TREE_NODES: PassiveNode[] = CONTENT.passiveTree.nodes;

/** Undirected links, "a-b". */
export const TREE_EDGES: string[] = CONTENT.passiveTree.edges;
