/** Content table shapes. The pathogen side: progression, pathogens, cards and the passive tree. The checker is in ./check.ts; ./index.ts assembles every table. */
import { arr, num, obj, oneOf, rec, str, type Shape } from "./check";
const effects = obj({ "add?": rec(num), "mul?": rec(num), "max?": rec(num) });
export const PATHOGEN_SHAPES: Record<"progression" | "pathogens" | "cards" | "passiveTree", Shape> = {
  progression: obj({ pickAt: arr(num), pickStep: num, apAt: arr(num), startAp: num, offerSize: num, nodeCost: obj({ start: num, small: num, notable: num, keystone: num }), followUpWeight: num }),
  pathogens: arr(obj({ id: str, name: str, tagline: str, text: str, icon: str, colour: str, fx: effects })),
  cards: arr(obj({ id: str, name: str, kind: oneOf("transmission", "symptom", "ability"), icon: str, text: str, fx: effects, "after?": arr(arr(str)), "pathogen?": str, "node?": str, "weight?": num })),
  passiveTree: obj({ nodes: arr(obj({ id: str, kind: oneOf("start", "small", "notable", "keystone"), x: num, y: num, name: str, fx: effects })), edges: arr(str) }),
};
