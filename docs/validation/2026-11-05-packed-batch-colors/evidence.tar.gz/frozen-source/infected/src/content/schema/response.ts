/** Content table shapes. The human response: towns, cure, measures, care, the military, unrest and collapse. The checker is in ./check.ts; ./index.ts assembles every table. */
import type { GateKind } from "../../domain/response/borders";
import type { Level } from "../../domain/response/measures";
import { arr, num, obj, oneOf, range, rec, str, type Shape } from "./check";
/** A response level by name (content/response.json5 names levels, src/domain/response/measures.ts Level). */
export type LevelName = keyof typeof Level;
/** content/response.json5, section by section. */
export type ResponseTables = {
  towns: { sickWeight: number; deadWeight: number; hospitalWeight: number; quietSick: number; quietDead: number; minPeople: number; riseSeconds: number; fadeSeconds: number; newsShare: number; newsSeconds: number; levels: readonly number[]; hysteresis: number; holdSeconds: number; seriesStep: number };
  cure: { fullDays: number; fromLevel: LevelName; capacity: Record<string, number>; reshuffle: number };
  measures: { maskCap: number; maskRamp: number; maskIntake: number; maskEmit: number; complyRamp: number; curfewFromHour: number; curfewToHour: number };
  hospital: { testing: readonly number[]; tracing: number; beds: number; homeCare: number; triageFrom: number; triageSeverity: number };
  care: { staffSick: number; burnout: number; staffFloor: number; staffSeconds: number; staffBack: number; tentsPerLoad: number; tentsMax: number; tentsSeconds: number; tentsDown: number; morgue: number; morgueMin: number; trialAt: number; vaxSeconds: number; efficacy: number; refuseBase: number; refuseDefiance: number; groups: readonly (readonly [number, number, number])[]; step: number };
  ambulance: { speed: number; lane: number; round: number; load: number; unload: number; reach: number; perLoad: number; crews: number; parkGap: number; parkIn: number };
  checkpoint: { inset: number; merge: number; classes: readonly string[]; queueRoom: number; built: number; pull: number };
  borders: { traffic: Record<GateKind, number>; sickTravel: number; catchSick: number; catchSilent: number; catchSilentCure: number; smuggle: number; smuggleDefiance: number; holdDays: number; heldContacts: number; hold: number; growth: number; outsideCut: number; courseDays: number; detect: number; screenDays: number; shutDays: number; onward: number; seriesStep: number; inset: number; queueRoom: number };
  outsidePeople: { country: number; space: number; abroad: number };
  routes: { faunaFromSick: number; faunaRise: number; faunaFade: number; birdCarry: number; birdSeconds: number; waterFromSick: number; waterRise: number; waterFade: number; seriesStep: number };
  fronts: { window: number; lit: number; litMax: number; faces: number; glance: number };
  military: { patrolLevel: LevelName; patrols: number; squad: number; walk: number; file: number; stopEvery: number; stopFor: number; arrest: number; cars: number; carGap: number; search: number; roll: number; shootWalled: number; shootBorder: number; shotEvery: readonly [number, number]; approach: number; bodyLies: number; evacShare: number; convoyEvery: number; convoySpeed: number; convoyGap: number; burnDead: number; burnRound: number; burnChunks: number };
  unrest: { fatigueSeconds: number; fatigueFade: number; curfewFatigue: number; closedShortage: number; lockdownShortage: number; overflowShortage: number; lootShortage: number; fatigueWeight: number; shortageWeight: number; deadWeight: number; riseSeconds: number; fadeSeconds: number; protestAt: number; lootAt: number; riotAt: number; ramp: number; streetShare: number; perSoldier: number; shopsLooted: number; buildingsBurnt: number; burnSeconds: readonly [number, number]; crowdSpread: number; protestHours: readonly [number, number]; riotHours: readonly [number, number]; seriesStep: number };
  collapse: { fallSeconds: number; fallDefiance: number; fallDead: number; borderDead: number; borderHold: number; wallDelay: number; bombDelay: number; bombDead: number; bombBurnt: number; bombSpread: number; bombBurns: readonly [number, number] };
};
const level = oneOf("None", "Masks", "Closures", "Curfew", "Lockdown", "Checkpoints");
export const RESPONSE_SHAPES: Record<"response", Shape> = {
  response: obj({
    towns: obj({ sickWeight: num, deadWeight: num, hospitalWeight: num, quietSick: num, quietDead: num, minPeople: num, riseSeconds: num, fadeSeconds: num, newsShare: num, newsSeconds: num, levels: arr(num), hysteresis: num, holdSeconds: num, seriesStep: num }),
    cure: obj({ fullDays: num, fromLevel: level, capacity: rec(num), reshuffle: num }),
    measures: obj({ maskCap: num, maskRamp: num, maskIntake: num, maskEmit: num, complyRamp: num, curfewFromHour: num, curfewToHour: num }),
    hospital: obj({ testing: arr(num), tracing: num, beds: num, homeCare: num, triageFrom: num, triageSeverity: num }),
    care: obj({ staffSick: num, burnout: num, staffFloor: num, staffSeconds: num, staffBack: num, tentsPerLoad: num, tentsMax: num, tentsSeconds: num, tentsDown: num, morgue: num, morgueMin: num, trialAt: num, vaxSeconds: num, efficacy: num, refuseBase: num, refuseDefiance: num, groups: arr(arr(num, 3)), step: num }),
    ambulance: obj({ speed: num, lane: num, round: num, load: num, unload: num, reach: num, perLoad: num, crews: num, parkGap: num, parkIn: num }),
    checkpoint: obj({ inset: num, merge: num, classes: arr(str), queueRoom: num, built: num, pull: num }),
    borders: obj({ traffic: obj({ road: num, rail: num, air: num, sea: num }), sickTravel: num, catchSick: num, catchSilent: num, catchSilentCure: num, smuggle: num, smuggleDefiance: num, holdDays: num, heldContacts: num, hold: num, growth: num, outsideCut: num, courseDays: num, detect: num, screenDays: num, shutDays: num, onward: num, seriesStep: num, inset: num, queueRoom: num }),
    outsidePeople: obj({ country: num, space: num, abroad: num }),
    routes: obj({ faunaFromSick: num, faunaRise: num, faunaFade: num, birdCarry: num, birdSeconds: num, waterFromSick: num, waterRise: num, waterFade: num, seriesStep: num }),
    fronts: obj({ window: num, lit: num, litMax: num, faces: num, glance: num }),
    military: obj({ patrolLevel: level, patrols: num, squad: num, walk: num, file: num, stopEvery: num, stopFor: num, arrest: num, cars: num, carGap: num, search: num, roll: num, shootWalled: num, shootBorder: num, shotEvery: range, approach: num, bodyLies: num, evacShare: num, convoyEvery: num, convoySpeed: num, convoyGap: num, burnDead: num, burnRound: num, burnChunks: num }),
    unrest: obj({ fatigueSeconds: num, fatigueFade: num, curfewFatigue: num, closedShortage: num, lockdownShortage: num, overflowShortage: num, lootShortage: num, fatigueWeight: num, shortageWeight: num, deadWeight: num, riseSeconds: num, fadeSeconds: num, protestAt: num, lootAt: num, riotAt: num, ramp: num, streetShare: num, perSoldier: num, shopsLooted: num, buildingsBurnt: num, burnSeconds: range, crowdSpread: num, protestHours: range, riotHours: range, seriesStep: num }),
    collapse: obj({ fallSeconds: num, fallDefiance: num, fallDead: num, borderDead: num, borderHold: num, wallDelay: num, bombDelay: num, bombDead: num, bombBurnt: num, bombSpread: num, bombBurns: range }),
  }),
};
