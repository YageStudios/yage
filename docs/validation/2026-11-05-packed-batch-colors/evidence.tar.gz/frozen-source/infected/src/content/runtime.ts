/**
 * The data tables (content/*.json5 at the repo root), loaded once per thread (page, chunk workers,
 * Node hosts and tests alike) and checked against their shapes (src/content/schema/). Each
 * table is keyed by its file name, camel-cased (passive-tree.json5 is CONTENT.passiveTree). The
 * modules that use a table (src/people.ts, src/mutations.ts and the rest) give it its game shape.
 */
import { CONTENT_KEYS, contentProblem, type ContentTables } from "./schema";

const FILES = import.meta.glob<unknown>("../../content/*.json5", { eager: true, import: "default" });

const keyOf = (path: string) => path.slice(path.lastIndexOf("/") + 1, -".json5".length).replace(/-(\w)/g, (_, c: string) => c.toUpperCase());

const load = (): ContentTables => {
  const tables: Record<string, unknown> = {};
  for (const [path, value] of Object.entries(FILES)) tables[keyOf(path)] = value;
  for (const key of CONTENT_KEYS) {
    const problem = contentProblem(key, tables[key]);
    if (problem) throw new Error(`${problem} (content/*.json5)`);
  }
  return tables as ContentTables;
};

export const CONTENT: ContentTables = load();
