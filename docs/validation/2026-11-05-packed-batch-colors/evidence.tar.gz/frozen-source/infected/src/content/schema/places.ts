/** Content table shapes. Places: terrain lots, building templates and looks, street and grammar specs, place names and world manifests. The checker is in ./check.ts; ./index.ts assembles every table. */
import type { Style } from "../../domain/styles";
import { arr, either, num, obj, oneOf, range, rec, str, yes, type Shape } from "./check";
export type TemplateSizeRow = ({ key: string; place?: undefined } | { place: string; key?: undefined }) & { w: [number, number]; h: [number, number] };
export type MaterialRow = { key: string; kind: string; pattern: string; base: number; accent: number; scale?: number };
/** Material keys (content/materials.json5) for a building's surfaces. */
export type MaterialKeys = { wall: string; floor: string; wet?: string; roof: string; paving: string; road: string };
export type StyleRow = Style & { urban?: true; paved?: true; look?: Partial<MaterialKeys> };
export type VernacularRow = MaterialKeys & { sets: { furniture: string; street: string; yard: string }; rural?: Partial<MaterialKeys>; ownWalls?: true };
export type UseLookRow = Partial<MaterialKeys> & { byCulture?: Record<string, Partial<MaterialKeys>>; byStyle?: Record<string, Partial<MaterialKeys>> };
export type PlaceNames = { heads: string[]; tails: string[]; rivers: string[]; streams: string[] };
const surfaces = { "wall?": str, "floor?": str, "wet?": str, "roof?": str, "paving?": str, "road?": str };
const someKeys = obj(surfaces);
export const PLACES_SHAPES: Record<"terrain" | "templateSizes" | "materials" | "styles" | "vernacular" | "useLooks" | "placeNames" | "streets" | "grammars" | "worlds", Shape> = {
  terrain: obj({
    lots: obj(Object.fromEntries(["town", "city", "district", "suburb", "village"].map((k) => [k, arr(range)]))),
  }),
  templateSizes: arr(either(obj({ key: str, w: range, h: range }), obj({ place: str, w: range, h: range }))),
  materials: arr(obj({ key: str, kind: oneOf("road", "paving", "floor", "wall", "roof", "infra"), pattern: str, base: num, accent: num, "scale?": num })),
  styles: arr(
    obj({ id: str, lot: range, depth: range, setback: range, gap: num, storeys: range, uses: arr((v, at) => arr(either(str, num), 2)(v, at)), vacancy: num, roof: str, "urban?": yes, "paved?": yes, "look?": someKeys }),
  ),
  vernacular: rec(obj({ wall: str, floor: str, "wet?": str, roof: str, paving: str, road: str, sets: obj({ furniture: str, street: str, yard: str }), "rural?": someKeys, "ownWalls?": yes })),
  useLooks: rec(obj({ ...surfaces, "byCulture?": rec(someKeys), "byStyle?": rec(someKeys) })),
  placeNames: obj({ heads: arr(str), tails: arr(str), rivers: arr(str), streams: arr(str) }),
  streets: rec(obj({ cls: oneOf("arterial", "collector", "local", "lane", "track", "path"), width: num, surface: oneOf("road", "trail", "path", "park"), sidewalk: num })),
  grammars: rec(obj({ along: str, across: str, drop: num })),
  worlds: rec(
    obj({
      id: str,
      seed: num,
      population: obj({ simulated: num }),
      clock: obj({ tickRate: num, maxLead: num }),
      sources: arr(obj({ id: str, name: str, use: str, licence: str, "version?": str })),
      spaces: arr(
        obj({
          index: num, key: str, name: str, profile: str,
          region: obj({ name: str, latitude: num, longitude: num, utcOffset: num, biome: str, meanTemperature: num, moisture: num }),
          chunks: range, metresPerTile: num, populationWeight: num,
        }),
      ),
    }),
  ),
};
