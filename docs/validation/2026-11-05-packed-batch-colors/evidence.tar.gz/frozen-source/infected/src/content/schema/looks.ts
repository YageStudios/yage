/** Content table shapes. Looks: transit and vehicle art, pawn, tile, gate and map colours. The checker is in ./check.ts; ./index.ts assembles every table. */
import type { PathogenLook } from "../../domain/look/sprites";
import { arr, num, obj, oneOf, prim, range, rec, str, type Shape } from "./check";
/** A motor vehicle's art (content/vehicle-looks.json5): footprint, paint, cab span and extras. */
export type VehicleLook = { len: number; wid: number; body: string; cab: [number, number]; roof?: string; tinted?: boolean; windows?: number; stripe?: string; height?: number };
/** content/looks.json5, section by section. */
export type LookTables = {
  pawn: { pathogens: PathogenLook[]; lightHairWeights: number[]; darkHairWeights: number[]; decayColours: number[] };
  tiles: number[];
  gate: { booth: number; boothEdge: number; stripe: number; boom: number; white: number; post: number; wire: number; mud: number; pen: { along: number; length: number; gap: number; depth: number }; tent: { along: number; out: number }; smugglers: number; smugglePeriod: number; smuggleSpeed: number };
  bordersMap: { status: readonly [string, string, string]; ink: string; paper: string; arrow: number; badge: number };
  worldMap: Record<"sea" | "seaShallow" | "coast" | "river" | "ink" | "paper" | "roadCase" | "road" | "roadHot" | "track" | "clean" | "cleanEdge" | "hive" | "latent" | "dead" | "alert" | "host" | "research", string> & { ladder: string[] };
  preview: { map: Record<"paper" | "sea" | "water" | "waterEdge" | "wood" | "park" | "green" | "plaza" | "yard" | "arable" | "arableRow" | "pasture" | "meadow" | "hedge" | "casing" | "road" | "arterial" | "trail" | "path" | "bridge" | "label" | "halo" | "grid", string>; roofs: Record<string, string>; tiles: number[] };
};
const TRANSIT_PALETTE_KEYS = ["outline", "glass", "warm", "highlight", "shadow", "tramSkirt", "tramRoof", "tramBand", "tramGear", "tramPantograph", "railSkirt", "railRoof", "railBand", "railVents", "railGangways", "busSkirt", "busRoof", "busBand", "busPodEdge", "busPod", "busHatches", "busSign", "busGrille", "subwaySkirt", "subwayRoof", "subwayRibs", "subwayBand", "locomotiveSkirt", "locomotiveRoof", "locomotiveBand", "locomotiveCab", "locomotiveFanEdge", "locomotiveFans", "locomotiveChevron", "headlight", "headlightPool"];
const WORLD_MAP_KEYS = ["sea", "seaShallow", "coast", "river", "ink", "paper", "roadCase", "road", "roadHot", "track", "clean", "cleanEdge", "hive", "latent", "dead", "alert", "host", "research"];
const PREVIEW_MAP_KEYS = ["paper", "sea", "water", "waterEdge", "wood", "park", "green", "plaza", "yard", "arable", "arableRow", "pasture", "meadow", "hedge", "casing", "road", "arterial", "trail", "path", "bridge", "label", "halo", "grid"];
export const LOOKS_SHAPES: Record<"transitLooks" | "looks" | "vehicleLooks", Shape> = {
  transitLooks: obj({ palette: obj(Object.fromEntries(TRANSIT_PALETTE_KEYS.map((k) => [k, num]))), cars: obj(Object.fromEntries(["tram", "rail-carriage", "bus", "subway-car", "locomotive"].map((k) => [k, obj({ len: num, wid: num })]))) }),
  looks: obj({
    pawn: obj({ pathogens: arr(oneOf("neutral", "virus", "bacteria", "fungus", "parasite", "prion"), 6), lightHairWeights: arr(num, 8), darkHairWeights: arr(num, 8), decayColours: arr(num, 4) }),
    tiles: arr(num, 31),
    gate: obj({ booth: num, boothEdge: num, stripe: num, boom: num, white: num, post: num, wire: num, mud: num, pen: obj({ along: num, length: num, gap: num, depth: num }), tent: obj({ along: num, out: num }), smugglers: num, smugglePeriod: num, smuggleSpeed: num }),
    bordersMap: obj({ status: arr(str, 3), ink: str, paper: str, arrow: num, badge: num }),
    worldMap: obj({ ...Object.fromEntries(WORLD_MAP_KEYS.map((k) => [k, str])), ladder: arr(str, 5) }),
    preview: obj({ map: obj(Object.fromEntries(PREVIEW_MAP_KEYS.map((k) => [k, str]))), roofs: rec(str), tiles: arr(num, 31) }),
  }),
  vehicleLooks: rec(obj({ len: num, wid: num, body: str, cab: range, "roof?": str, "tinted?": prim("boolean"), "windows?": num, "stripe?": str, "height?": num })),
};
