/**
 * The game's entity definitions (src/entities/**.json5: items, NPC archetypes), as yage entity
 * definitions (name, inherits, components), loaded here once per thread (page, chunk workers,
 * Node hosts and tests alike) and resolved through yage's pure definitions core. Data tables that
 * aren't entities are in content/ at the root (src/content/runtime.ts).
 *
 * Files are read in path order and a file may hold one definition or an array, so a table keeps
 * its order through numbered file names and array order. Accessors (src/domain/items.ts and the
 * rest) rebuild each table's old shape from the components, so callers don't change.
 */
import { componentOf, definitionsFromModules, resolveDefinitions, type EntityDefinition, type FlexibleEntityDefinition } from "yage/entity/definitions";

export { componentOf };
export type { EntityDefinition, FlexibleEntityDefinition };

const MODULES = import.meta.glob("../entities/**/*.json5", { eager: true });

/** Every definition as written (unresolved), in file and array order. */
export const RAW_DEFINITIONS = definitionsFromModules(MODULES);

/** Every definition, resolved, in file and array order (keyed by lowercased name). */
export const DEFINITIONS = resolveDefinitions(RAW_DEFINITIONS);

/** Definitions whose name starts with `prefix` (a kind, e.g. "item:"), in order; bases (no `prefix`-free name) included. */
export const definitionsOf = (prefix: string): EntityDefinition[] => {
  const out: EntityDefinition[] = [];
  for (const [name, def] of DEFINITIONS) if (name.startsWith(prefix)) out.push(def);
  return out;
};

/** A component's data without its `type`. */
export const dataOf = <T>(def: EntityDefinition, type: string): T | undefined => {
  const c = componentOf(def, type);
  if (!c) return undefined;
  const { type: _type, ...data } = c;
  return data as T;
};

/** The one definition named `name` (throws when missing). */
export const definition = (name: string): EntityDefinition => {
  const def = DEFINITIONS.get(name.toLowerCase());
  if (!def) throw new Error(`Missing entity definition ${name}`);
  return def;
};
