/**
 * The shapes of the data tables in content/*.json5 (src/content/runtime.ts loads them), and a
 * small checker that holds each table to its shape when it loads, so a typo in a table fails at
 * once with the table and path rather than as a wrong-looking world.
 *
 * Table shapes live by area in this folder (people, pathogen, places, sim, response, looks), on the
 * combinators in ./check.ts; this file assembles them.
 *
 * Entity definitions (src/entities) are not here: yage's definitions core resolves those.
 */
import type { WorldManifest } from "../../atlas/manifest";
import type { GrammarSpec, StreetSpec } from "../../domain/grammars";
import type { Card, Pathogen, PassiveNode, Progression } from "../../domain/mutation-types";
import type { Culture } from "../../domain/people/culture";
import type { Shape } from "./check";
import { LOOKS_SHAPES, type LookTables, type VehicleLook } from "./looks";
import { PATHOGEN_SHAPES } from "./pathogen";
import { PEOPLE_SHAPES, type Occupations, type TraitInfo } from "./people";
import { PLACES_SHAPES, type MaterialRow, type PlaceNames, type StyleRow, type TemplateSizeRow, type UseLookRow, type VernacularRow } from "./places";
import { RESPONSE_SHAPES, type ResponseTables } from "./response";
import { SIM_SHAPES, type ArmsTables, type CritterNumbers, type DiseaseTables, type LoadNumbers, type SimTables, type WeatherTables } from "./sim";

/** Every table, by its key in CONTENT (the file name, camel-cased). */
export type ContentTables = {
  terrain: { lots: Record<"town" | "city" | "district" | "suburb" | "village", [number, number][]> };
  households: Record<"house" | "farm" | "hut" | "cabin" | "flat", number[]>;
  transitLooks: { palette: Record<"outline" | "glass" | "warm" | "highlight" | "shadow" | "tramSkirt" | "tramRoof" | "tramBand" | "tramGear" | "tramPantograph" | "railSkirt" | "railRoof" | "railBand" | "railVents" | "railGangways" | "busSkirt" | "busRoof" | "busBand" | "busPodEdge" | "busPod" | "busHatches" | "busSign" | "busGrille" | "subwaySkirt" | "subwayRoof" | "subwayRibs" | "subwayBand" | "locomotiveSkirt" | "locomotiveRoof" | "locomotiveBand" | "locomotiveCab" | "locomotiveFanEdge" | "locomotiveFans" | "locomotiveChevron" | "headlight" | "headlightPool", number>; cars: Record<"tram" | "rail-carriage" | "bus" | "subway-car" | "locomotive", { len: number; wid: number }> };
  cultures: Culture[];
  dress: string[];
  traits: [TraitInfo, TraitInfo][];
  occupations: Occupations;
  progression: Progression;
  pathogens: Pathogen[];
  cards: Card[];
  passiveTree: { nodes: PassiveNode[]; edges: string[] };
  templateSizes: TemplateSizeRow[];
  materials: MaterialRow[];
  styles: StyleRow[];
  vernacular: Record<string, VernacularRow>;
  useLooks: Record<string, UseLookRow>;
  placeNames: PlaceNames;
  critters: CritterNumbers;
  vehicleLooks: Record<string, VehicleLook>;
  streets: Record<string, StreetSpec>;
  grammars: Record<string, GrammarSpec>;
  /** Scenario manifests by id, without the versions code fills in. */
  worlds: Record<string, Omit<WorldManifest, "generator" | "content">>;
  load: LoadNumbers & { spore: { load: number; size: number; life: number; corpses: number } };
  linger: { air: number[]; surface: number[]; wind: number; wash: number };
  weather: WeatherTables;
  disease: DiseaseTables;
  response: ResponseTables;
  sim: SimTables;
  arms: ArmsTables;
  looks: LookTables;
};

const SHAPES: Record<keyof ContentTables, Shape> = {
  terrain: PLACES_SHAPES.terrain,
  households: PEOPLE_SHAPES.households,
  transitLooks: LOOKS_SHAPES.transitLooks,
  cultures: PEOPLE_SHAPES.cultures,
  dress: PEOPLE_SHAPES.dress,
  traits: PEOPLE_SHAPES.traits,
  occupations: PEOPLE_SHAPES.occupations,
  progression: PATHOGEN_SHAPES.progression,
  pathogens: PATHOGEN_SHAPES.pathogens,
  cards: PATHOGEN_SHAPES.cards,
  passiveTree: PATHOGEN_SHAPES.passiveTree,
  templateSizes: PLACES_SHAPES.templateSizes,
  materials: PLACES_SHAPES.materials,
  styles: PLACES_SHAPES.styles,
  vernacular: PLACES_SHAPES.vernacular,
  useLooks: PLACES_SHAPES.useLooks,
  placeNames: PLACES_SHAPES.placeNames,
  critters: SIM_SHAPES.critters,
  streets: PLACES_SHAPES.streets,
  grammars: PLACES_SHAPES.grammars,
  worlds: PLACES_SHAPES.worlds,
  load: SIM_SHAPES.load,
  linger: SIM_SHAPES.linger,
  weather: SIM_SHAPES.weather,
  disease: SIM_SHAPES.disease,
  response: RESPONSE_SHAPES.response,
  sim: SIM_SHAPES.sim,
  arms: SIM_SHAPES.arms,
  looks: LOOKS_SHAPES.looks,
  vehicleLooks: LOOKS_SHAPES.vehicleLooks,
};

export const CONTENT_KEYS = Object.keys(SHAPES) as (keyof ContentTables)[];

/** The first problem with a table, or undefined when it has its shape. */
export const contentProblem = (key: keyof ContentTables, value: unknown): string | undefined => SHAPES[key](value, `content ${key}`);
