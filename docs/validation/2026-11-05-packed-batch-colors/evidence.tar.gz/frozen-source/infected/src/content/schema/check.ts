/** The content checker: a shape is a function that returns the first problem at a path, or undefined. */
export type Shape = (v: unknown, at: string) => string | undefined;
export const kind = (v: unknown) => (Array.isArray(v) ? "array" : v === null ? "null" : typeof v);
export const prim = (t: "string" | "number" | "boolean"): Shape => (v, at) =>
  typeof v === t && (t !== "number" || Number.isFinite(v)) ? undefined : `${at}: expected ${t}, got ${kind(v)}`;
export const str = prim("string");
export const num = prim("number");
export const yes: Shape = (v, at) => (v === true ? undefined : `${at}: expected true (or leave it out), got ${JSON.stringify(v)}`);
export const oneOf = (...values: string[]): Shape => (v, at) => (values.includes(v as string) ? undefined : `${at}: expected one of ${values.join(", ")}, got ${JSON.stringify(v)}`);
export const arr = (item: Shape, length?: number): Shape => (v, at) => {
  if (!Array.isArray(v)) return `${at}: expected array, got ${kind(v)}`;
  if (length !== undefined && v.length !== length) return `${at}: expected ${length} entries, got ${v.length}`;
  for (let i = 0; i < v.length; i++) {
    const e = item(v[i], `${at}[${i}]`);
    if (e) return e;
  }
};
export const rec = (value: Shape): Shape => (v, at) => {
  if (kind(v) !== "object") return `${at}: expected object, got ${kind(v)}`;
  for (const [k, x] of Object.entries(v as object)) {
    const e = value(x, `${at}.${k}`);
    if (e) return e;
  }
};
/** An object with exactly these fields (a trailing "?" marks an optional one). */
export const obj = (fields: Record<string, Shape>): Shape => (v, at) => {
  if (kind(v) !== "object") return `${at}: expected object, got ${kind(v)}`;
  const o = v as Record<string, unknown>;
  const known = new Set<string>();
  for (const [f, shape] of Object.entries(fields)) {
    const optional = f.endsWith("?");
    const name = optional ? f.slice(0, -1) : f;
    known.add(name);
    if (o[name] === undefined) {
      if (optional) continue;
      return `${at}.${name}: missing`;
    }
    const e = shape(o[name], `${at}.${name}`);
    if (e) return e;
  }
  for (const k of Object.keys(o)) if (!known.has(k)) return `${at}.${k}: unknown field`;
};
export const either = (...shapes: Shape[]): Shape => (v, at) => {
  const errors = shapes.map((s) => s(v, at));
  return errors.includes(undefined) ? undefined : errors[0];
};

export const range = arr(num, 2);
