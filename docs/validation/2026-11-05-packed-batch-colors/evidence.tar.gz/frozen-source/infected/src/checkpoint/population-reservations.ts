import { CHUNK_COORD_MAX, chunkKey } from "yage/streaming";
import { MAX_LOADED_PEOPLE } from "../crowd/loaded-budget";

const MAX_KEY = chunkKey(CHUNK_COORD_MAX, CHUNK_COORD_MAX);

/** Restore the high-water reservations before chunk loads or individual admissions can run. */
export const decodePopulationReservations = (rows: unknown, warm: readonly number[] | null): Map<number, number> | null => {
  if (rows === null && warm === null) return null;
  if (!Array.isArray(rows)) throw new Error("checkpoint: geographic population reservations are missing");
  const reservations = new Map<number, number>();
  let total = 0;
  for (const row of rows) {
    if (!Array.isArray(row) || row.length !== 2) throw new Error("checkpoint: geographic population reservation is malformed");
    const [key, count] = row;
    if (!Number.isSafeInteger(key) || key < 0 || key > MAX_KEY || !Number.isSafeInteger(count) || count < 0 || reservations.has(key))
      throw new Error("checkpoint: geographic population reservation is malformed");
    total += count;
    if (total > MAX_LOADED_PEOPLE) throw new Error("checkpoint: geographic population reservations exceed capacity");
    reservations.set(key, count);
  }
  if (warm?.some((key) => !reservations.has(key))) throw new Error("checkpoint: a warm chunk has no geographic population reservation");
  return reservations;
};
