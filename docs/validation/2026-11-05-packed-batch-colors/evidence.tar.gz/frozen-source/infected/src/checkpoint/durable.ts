/**
 * What a checkpoint saves: for each durable definition, the fields each of its components keeps,
 * and why everything else is left out. A component is saved whole or by field; whatever a record
 * doesn't hold comes back from the definition's defaults, the run's seed and header, or the first
 * frame after the load. The writer copies only what is named here, and test/durable.test.ts holds
 * every component of every durable definition to it, so a new component or field must be placed.
 *
 * A checkpoint is taken at the end of an authority step's frame (the reports held for later steps
 * go in a section of their own), so the per-frame and per-pass state (cleared or set again before
 * anyone reads it) never needs saving.
 */

/** One definition's record: the saved fields by component, and the reason for each left-out component or "Component.field". */
export type DurableRecord = {
  saved: Record<string, readonly string[]>;
  left: Record<string, string>;
};

const QUEUE = "a command queue, drained in the frame it is pushed";
const PER_FRAME = "set again every frame before anyone reads it";
const PER_PASS = "this pass's bookkeeping, set again at the start of every pass";
const ID = "the record's id";

const ROLE: DurableRecord = {
  saved: { RoleIdentity: ["kind", "id"], RoleAuthority: ["actions"], ControlBinding: ["controller", "epoch", "fallback"] },
  left: {
    "ControlBinding.seen": "each controller's last intent; cleared on load, where the raised epoch turns away anything older",
    RoleIntents: QUEUE,
    PossessionCommands: QUEUE,
    ActionResults: QUEUE,
    RoleResultLog: "the HUD's log of recent results; a loaded run starts it empty",
  },
};

const OFFICE_AI: DurableRecord = {
  saved: { ControllerIdentity: ["id", "kind", "role"], OfficeDecisionState: ["sequence", "epoch"] },
  left: {},
};

/** The durable definitions, by name. */
export const DURABLE: Record<string, DurableRecord> = {
  "run:clock": {
    saved: { PlayClockState: ["baseMs", "changedAt", "speed", "paused"] },
    left: {
      PlayClockCommands: QUEUE,
      RunFrame: PER_FRAME,
      AuthorityStep: "rebuilt from the header's tick and the held section: the save is taken on a step",
    },
  },
  "run:journal": {
    saved: { CommandJournal: ["entries"] },
    left: { JournalCommands: QUEUE, JournalReplay: "a replay's feed, set by the page that plays it" },
  },
  "world:outbreak": {
    saved: { OutbreakState: ["started", "seeded", "startGid", "seededTick"], ScenarioOverrides: ["ladder"] },
    left: { RunSeed: "the header's seed" },
  },
  "world:strain": {
    saved: {
      EvolutionState: ["evolution"],
      StrainTraits: ["traits"],
      MutationOfferState: ["offer"],
      EvolutionBudget: ["absorbed", "earned"],
      TraitRevision: ["configuredAt"],
      MadeMutants: ["made"], HeldCaptives: ["held"],
      OfferClock: ["pointsLeft", "offerLine", "pointLine"],
      RandomStream: ["state"],
    },
    left: { OutbreakCommands: QUEUE, TraitRequests: QUEUE, InfectionRef: "the simulation lab's alone (a run keeps the empty default), and the lab never saves" },
  },
  "role:objective": { saved: { GoalProgress: ["extinctFor", "outcome", "reason"] }, left: {} },
  "scene:population": {
    saved: {
      ScenePopulation: ["spread", "chunks", "announced", "generated", "places", "jumps"],
      PopulationTotals: ["totals", "people"],
      PlaceTimeline: ["frames"],
      CastRecords: ["cast"],
      Directives: ["list", "log", "walkers"],
    },
    left: {
      ChunkCountIndex: "the same rows as ScenePopulation.chunks, indexed again by key on load",
      WorldEvents: "the presentation feed of the chunks' events; a load starts it empty",
      ColdCells: "the cold cells go in the checkpoint's own section (records.ts cold), their flows found again from the plan",
      ColdPond: "its anchors go in the checkpoint's own section (records.ts anchors); the pond and the rest are made again from the boot's survey and them",
      CastCommands: QUEUE,
      DirectCommands: QUEUE,
      StageCommands: QUEUE,
    },
  },
  "region:response": {
    saved: {
      RegionResponse: ["pending"],
      TerritoryState: ["tick", "revision", "nextEvent", "towns", "events"],
      OperationalHistory: ["frames"],
      ResearchState: ["cure", "reshuffles", "tick"],
      RegionMemory: ["memory"],
    },
    left: {
      TierIdentity: ID,
      "RegionResponse.notices": "drained into toasts at the end of the pass that pushed them",
      "RegionResponse.due": PER_PASS,
      "RegionResponse.tick": PER_PASS,
      "RegionResponse.respond": PER_PASS,
      "RegionResponse.before": PER_PASS,
      "RegionResponse.grew": PER_PASS,
      RegionMap: "built from the run's seed (the planning context and world map)",
      RegionGates: "the border gates, found again from the plan and the map; loaded borders carry on over them",
      ResponseInputs: PER_PASS,
      RegionTowns: "the region:town entities, found again by their ids",
      RegionTopology: "built from the world map",
      ScenarioStartCatalog: "built from the world map",
      RegionCadence: "the HUD's frame-clock beat (wall time); in lockstep the passes fall on steps",
      RegionPass: PER_FRAME,
    },
  },
  "region:town": {
    saved: {
      TownResponse: ["index", "state", "series", "levelBefore", "fullBefore"],
      CareMemory: ["tents", "quit", "morgue", "graves", "vax", "refuse"],
      TownRoutes: ["fauna", "water"],
      TownUnrest: ["fatigue", "unrest", "pin"],
      TownCollapse: ["strain", "bordered", "borderChanged"],
      TownMilitary: ["burnPin"],
      ExtremeTownMemory: ["storm", "blizzard", "heat", "cold", "flood"],
      TownNews: ["collapse", "unrest"],
      TownSecurity: ["burn"],
    },
    left: { TierIdentity: ID, TownPolicyOrders: QUEUE, SecurityOrders: QUEUE },
  },
  "role:virus": { saved: { ...ROLE.saved, StrainRef: ["strain"] }, left: ROLE.left },
  "role:governor": { saved: { ...ROLE.saved, TierRef: ["key"] }, left: ROLE.left },
  "role:mayor": { saved: { ...ROLE.saved, TierRef: ["key"] }, left: ROLE.left },
  "role:knowledge": { saved: { RoleRef: ["role"] }, left: { KnowledgeSummary: PER_FRAME } },
  "controller:player": {
    saved: { ControllerIdentity: ["id", "kind", "role"] },
    left: {
      PlayerSource: "a reloaded client numbers its intents from 0 again, under the raised epoch, and holds no keys",
      PlayerIntents: QUEUE,
    },
  },
  "controller:virus-ai": {
    saved: { ControllerIdentity: ["id", "kind", "role"], VirusDecisionState: ["next", "cycleAt", "sequence", "epoch"], RandomStream: ["state"] },
    left: {},
  },
  "controller:governor-ai": OFFICE_AI,
  "controller:mayor-ai": OFFICE_AI,
  "control:actor": {
    saved: { SiegeState: ["revision", "structures", "cooldowns", "events", "fortifiedAt"], StrategyState: ["nextOperation", "nextEvent", "operations", "events"], RtsState: ["commanding", "nextOrder", "nextHorde", "units", "hordes", "contacts", "history"], RoleRef: ["role"], ControlledHost: ["gid", "state", "lifeLeft", "lifeAt", "warned", "slot", "lastSeek", "visited", "located"], SteerSendState: ["steer", "sent", "sentAt"] },
    left: {
      "ControlledHost.drawn": "the presentation's point",
      "ControlledHost.streamed": "the presentation's point",
      "SteerSendState.at": "the page's walk, sent again on its next step",
      ActorOrders: QUEUE,
      SiegeOrders: QUEUE,
      StrategyOrders: QUEUE,
      RtsOrders: QUEUE,
      RtsReports: QUEUE,
    },
  },
};

/**
 * Definitions a checkpoint leaves out whole, and why. Every definition of a run-state kind (role:,
 * controller:, region:, tier:, run:, world:, scene:, streaming:, nature:) is in DURABLE or here, so
 * the authority digest (checkpoint/digest.ts) can't miss new run state unnoticed.
 */
export const NOT_DURABLE: Record<string, string> = {
  "world:response-export": "the response's export, made again from the towns after the load",
  "run:transport": "the session's connection and its metrics",
  "run:checkpoint": "the checkpoint's own requests, status and slots",
  "world:notice": "a toast, gone when it fades",
  "world:outbreak-begun": "an event for the presentation, gone the next frame",
  "world:mutation-settled": "an event for the presentation, gone the next frame",
  "world:nature": "its revision only, bumped again on the load",
  "nature:chunk": "not a record: the checkpoint's nature section holds the chunks' cells",
  "run:hot": "the warm set is the checkpoint's warm section; the hot set is each viewer's view, sent again as the viewer watches after the load",
  "world:host-taken": "an event for the presentation, gone the next frame",
  "streaming:world-feed": "the boot's chunk feed: a load boots its world the same way first",
  "scene:camera": "the viewer's camera, not the run's",
};
