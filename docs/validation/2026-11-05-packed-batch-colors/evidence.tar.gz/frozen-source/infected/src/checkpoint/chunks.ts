/**
 * A checkpoint's chunk section: the chunks of granular towns (a town with its own office) and every
 * chunk the warm set has warm (WarmSet), as `{ space, cx, cy, bytes }` with exactly the bytes
 * ChunkHost.unload makes, in base64. The cold ones are the save's cells (records.ts); chunks off the
 * map are regenerated from the seed, with the nature layer over it.
 *
 * Cold chunks are copied from the run's cold store (AuthorityTransport.cold, which clients stream with); hot and warm ones are taken by their hosts
 * without unloading them (ChunkPool.save), stamped for the limit's tick like anything else sent
 * to them, so every host takes its chunks at the start of that one tick. On a load they go back
 * through the hosts' own Load path, on the limit's tick, so the module's `restored` hook (its
 * restore stack: LoadRestoreSystem) runs for them as for a cold chunk coming back.
 */
import { chunkKey, chunkX, chunkY, spaceChunkKey, type PendingPost, type SavedChunk, type SavedState } from "yage/streaming";
import { RegionMap } from "../components/response/RegionMap";
import { TownResponse } from "../components/response/TownResponse";
import { AuthorityTransport } from "../components/run/AuthorityTransport";
import { TierIdentity } from "../components/tier/TierIdentity";
import type { Pass } from "../domain/response/pass";
import { fromBase64, toBase64 } from "../domain/nature";
import { tierIndex } from "../services/tiers";
import { WarmSet } from "../components/run/WarmSet";
import type { World } from "minecs";
import { findSingleEntity } from "yage/world/single";

export type CheckpointChunk = { space: number; cx: number; cy: number; bytes: string };

/** The chunks a checkpoint keeps, in key order: every chunk of each granular town. */
export const keptChunks = (g: Pass): { cx: number; cy: number }[] => {
  const index = tierIndex(g);
  const places = g.single(RegionMap).worldMap.places;
  const keys = new Set<number>();
  for (const key of index.offices.keys()) {
    const eid = index.tiers.get(key);
    if (eid === undefined || g.getTypedUnsafe(TierIdentity, eid).tier !== "town") continue;
    for (const chunk of places[g.getTypedUnsafe(TownResponse, eid).index]?.chunks ?? []) keys.add(chunk);
  }
  return [...keys].sort((a, b) => a - b).map((key) => ({ cx: chunkX(key), cy: chunkY(key) }));
};

/** The chunks a checkpoint keeps now, in key order: the granular towns' (keptChunks) and the warm set's. */
export const savedChunks = (g: Pass): { cx: number; cy: number }[] => {
  const keys = new Set(keptChunks(g).map(({ cx, cy }) => chunkKey(cx, cy)));
  const eid = findSingleEntity(g as unknown as World, WarmSet);
  if (eid >= 0) for (const key of g.getTypedUnsafe(WarmSet, eid).warm) keys.add(key);
  return [...keys].sort((a, b) => a - b).map((key) => ({ cx: chunkX(key), cy: chunkY(key) }));
};

/** The serialized worlds of the run's cold chunks. */
const coldOf = (g: Pass): ReadonlyMap<number, Uint8Array> => g.single(AuthorityTransport).cold ?? new Map();

/**
 * The kept chunks now: loaded ones from their hosts (taken at the start of the limit's tick, which
 * resolves as `tick`), cold ones from `cold` (the run's store by default). A kept chunk that is
 * neither was never generated, and is generated again from the seed.
 */
export const saveChunks = async (g: Pass, cold: ReadonlyMap<number, Uint8Array> = coldOf(g)): Promise<SavedState> => {
  const pool = g.single(AuthorityTransport).pool;
  const kept = savedChunks(g);
  const loaded = kept.filter(({ cx, cy }) => pool.chunks.has(spaceChunkKey(0, cx, cy)));
  const { tick, chunks, shared, posts } = await pool.save(loaded);
  const out = [...chunks];
  for (const { cx, cy } of kept) {
    const bytes = cold.get(chunkKey(cx, cy));
    if (bytes && !pool.chunks.has(spaceChunkKey(0, cx, cy))) out.push({ space: 0, cx, cy, bytes: bytes.slice() });
  }
  out.sort((a, b) => spaceChunkKey(a.space, a.cx, a.cy) - spaceChunkKey(b.space, b.cx, b.cy));
  return { tick, chunks: out, shared, posts };
};

export const encodeChunks = (chunks: readonly SavedChunk[]): CheckpointChunk[] =>
  chunks.map(({ space, cx, cy, bytes }) => ({ space, cx, cy, bytes: toBase64(bytes) }));

/** The section's chunks as bytes; refuses a malformed entry. */
export const decodeChunks = (chunks: readonly CheckpointChunk[]): SavedChunk[] =>
  chunks.map((chunk, i) => {
    const { space, cx, cy, bytes } = chunk ?? ({} as CheckpointChunk);
    if (![space, cx, cy].every(Number.isInteger) || typeof bytes !== "string" || !bytes) throw new Error(`checkpoint: chunk ${i} is malformed`);
    return { space, cx, cy, bytes: fromBase64(bytes) };
  });

/** Hands the chunks to their hosts through Load, joining on the limit's tick (replacing what the boot generated). */
export const loadChunks = (g: Pass, chunks: readonly SavedChunk[]) => {
  const pool = g.single(AuthorityTransport).pool;
  for (const { space, cx, cy, bytes } of chunks) pool.load(cx, cy, bytes, undefined, space);
};

/** The hosts' pending posts as a checkpoint keeps them: bytes in base64. */
export type CheckpointPost = { tick: number; kind: number; source: number; seq: number; bytes: string };

export const encodePosts = (posts: readonly PendingPost[]): CheckpointPost[] =>
  posts.map(({ tick, kind, source, seq, bytes }) => ({ tick, kind, source, seq, bytes: toBase64(bytes) }));

/** The section's posts as bytes; refuses a malformed entry. */
export const decodePosts = (posts: readonly CheckpointPost[]): PendingPost[] =>
  posts.map((post, i) => {
    const { tick, kind, source, seq, bytes } = post ?? ({} as CheckpointPost);
    if (![tick, kind, source, seq].every(Number.isFinite) || typeof bytes !== "string" || !bytes) throw new Error(`checkpoint: post ${i} is malformed`);
    return { tick, kind, source, seq, bytes: fromBase64(bytes) };
  });
