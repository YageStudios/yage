/**
 * The authority's state as one value: a 64-bit hash of a checkpoint's canonical text (every durable
 * record, the cold cells, the warm set and the warm and granular chunks' bytes, the held reports, the
 * hosts' config, shared state and pending posts, and the nature layer), bar its header (build,
 * scenario, created). Objects' keys are sorted, so two runs in the same state give the same digest
 * whatever order they built it in; Maps and Sets keep their order, since what iterates them sees it.
 */
import type { Checkpoint } from "./records";

/** The checkpoint's canonical text: sorted keys, the codec's tags for what JSON can't hold. */
export const canonicalText = (doc: Checkpoint) => {
  const { build: _build, scenario: _scenario, created: _created, ...state } = doc;
  const parts: string[] = [];
  const write = (value: unknown): void => {
    if (value === null || value === undefined) return void parts.push("null");
    if (typeof value === "number") return void parts.push(Number.isFinite(value) ? String(value) : `{"$num":"${value}"}`);
    if (typeof value === "string") return void parts.push(JSON.stringify(value));
    if (typeof value === "boolean") return void parts.push(value ? "true" : "false");
    if (Array.isArray(value)) {
      parts.push("[");
      value.forEach((v, i) => (i && parts.push(","), write(v)));
      return void parts.push("]");
    }
    if (value instanceof Map) return void (parts.push('{"$map":'), write([...value]), parts.push("}"));
    if (value instanceof Set) return void (parts.push('{"$set":'), write([...value]), parts.push("}"));
    if (typeof value === "object") {
      const keys = Object.keys(value as object).filter((k) => (value as Record<string, unknown>)[k] !== undefined).sort();
      parts.push("{");
      keys.forEach((k, i) => (i && parts.push(","), parts.push(JSON.stringify(k), ":"), write((value as Record<string, unknown>)[k])));
      return void parts.push("}");
    }
    throw new Error(`digest: cannot hash a ${typeof value}`);
  };
  write(state);
  return parts.join("");
};

/** Two 32-bit lanes (FNV-1a and a multiply-xorshift) over the text's UTF-16 units, as 16 hex digits. */
export const hashText = (text: string) => {
  let a = 0x811c9dc5;
  let b = 0x9e3779b9;
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i);
    a = Math.imul(a ^ c, 0x01000193);
    b = Math.imul(b ^ c, 0x85ebca6b);
    b ^= b >>> 13;
  }
  b = Math.imul(b ^ (b >>> 16), 0xc2b2ae35);
  return (a >>> 0).toString(16).padStart(8, "0") + ((b ^ (b >>> 16)) >>> 0).toString(16).padStart(8, "0");
};

/** The digest of a complete checkpoint (its chunk section taken). */
export const digestOf = (doc: Checkpoint) => hashText(canonicalText(doc));
