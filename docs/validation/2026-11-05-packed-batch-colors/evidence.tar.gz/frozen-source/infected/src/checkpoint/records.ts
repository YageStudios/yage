/**
 * A checkpoint as JSON records: one per durable entity, `{ id, def, components }`, holding only the
 * fields the manifest (./durable.ts) saves. Ids are stable across boots (a tier's key, a role's id,
 * a controller's role and id), so a load matches each record to the entity a fresh boot spawned,
 * opens what the boot didn't (a town's office), removes durable entities the save didn't have, and
 * writes the saved fields over the definition's defaults, and the nature layer's chunks
 * (nature:chunk) from a section of its own, run-length coded. The indexes over them are then rebuilt:
 * the region's town list, the chunk rows by key, the authority step and the response's export.
 * The cold cells (ColdCells, without their commute flows, which are the plan's) and the warm set's
 * chunks go back as they were. Last, the granular towns' and the warm chunks' worlds (./chunks.ts) go back to the hosts.
 *
 * Taken in two halves (systems/checkpoint): the records at the end of a step (captureCheckpoint),
 * then, once the hosts have answered, the chunk section they took at the start of the limit's tick
 * and the reports they made for the ticks between, held for the steps after (completeCheckpoint).
 * In lockstep a load goes into a boot whose hosts haven't run: they resume at `workerTick`, the
 * held reports wait for their steps again, and the limit is where the save's step left it, so the
 * run goes on from the save as it went on from the step.
 *
 * No player is at a loaded run's seats: every role a player held is disconnected to its fallback
 * (PossessionSystem, on the next frame before any intent is routed), raising its epoch, and its AI
 * drives on from the policies as the player left them. The player may take it again.
 */
import { getComponentByType, hasComponent, isComponentRegistered, removeEntity, type Schema, type World } from "minecs";
import { pushCommand } from "yage/world/commands";
import { entitiesWith } from "yage/world/single";
import { OutbreakState } from "../components/outbreak/OutbreakState";
import { ChunkCountIndex } from "../components/scene/ChunkCountIndex";
import { ScenePopulation } from "../components/scene/ScenePopulation";
import { GoalProgress } from "../components/objective/GoalProgress";
import { RegionResponse } from "../components/response/RegionResponse";
import { RegionTowns } from "../components/response/RegionTowns";
import { TownResponse } from "../components/response/TownResponse";
import { ControlBinding } from "../components/role/ControlBinding";
import { ControllerIdentity } from "../components/role/ControllerIdentity";
import { PossessionCommands } from "../components/role/PossessionCommands";
import { RoleIdentity } from "../components/role/RoleIdentity";
import { RoleRef } from "../components/role/RoleRef";
import { TierRef } from "../components/role/TierRef";
import { AuthorityStep, heldOrder } from "../components/run/AuthorityStep";
import { AuthorityTransport } from "../components/run/AuthorityTransport";
import { PlayClockState } from "../components/scene/PlayClockState";
import { RunSeed } from "../components/run/RunSeed";
import { ControlledHost } from "../components/scene/ControlledHost";
import { EvolutionState } from "../components/strain/EvolutionState";
import { TierIdentity } from "../components/tier/TierIdentity";
import type { Pass } from "../domain/response/pass";
import { STEP_TICKS, lockstepOf } from "../services/authority-time";
import { exportResponse } from "../services/response-export";
import { openTownOffice } from "../services/role-spawn";
import { DURABLE } from "./durable";
import { NATURE_SIDE, decodeNature, encodeNature, fromBase64, toBase64 } from "../domain/nature";
import { showcaseOf } from "../domain/load/overlay";
import { loadNatureGrid, natureGridOf } from "../services/nature";
import { decodeChunks, decodePosts, encodeChunks, encodePosts, keptChunks, loadChunks, type CheckpointChunk, type CheckpointPost } from "./chunks";
import { chunkKey, chunkX, chunkY, type PendingPost, type SavedChunk } from "yage/streaming";
import { findSingleEntity } from "yage/world/single";
import { ColdCells, type ColdCell } from "../components/cold/ColdCells";
import { WarmSet } from "../components/run/WarmSet";
import { CommandJournal } from "../components/run/Journal";
import { commuteFlows } from "../domain/cold/flows";
import { STAGES } from "../domain/cold/step";
import { applyExit } from "../systems/cold/ColdCrossingSystem";
import { holdReport } from "../systems/scene/PoolIngress";
import { InfectionConfigSystem } from "../systems/sim/InfectionConfigSystem";
import { decodeConfig } from "../domain/response/measures";
import { collisionMemory } from "../sim/host-state";
import { siegeSnapshot } from "../services/rts";
import { RegionMap } from "../components/response/RegionMap";
import type { AnchorStoreJSON } from "../anchors/store";
import type { Anchor } from "../anchors/types";
import { pondStore, restorePond } from "../services/cold/pond";
import { AtlasTerrain } from "../worldgen/layout";
import { captureGeographicCheckpoint, geographicCheckpointMatches, type GeographicCheckpoint } from "../realworld/checkpoint";
import { decodePopulationReservations } from "./population-reservations";
import type { ReadOnlyGameModel } from "yage/game/GameModel";

export const FORMAT = "infected-checkpoint";
/** What saveChunks took: the chunk section, the tick it was taken at the start of, and in lockstep the hosts' shared state and pending posts. */
export type SavedSection = { tick: number; chunks: readonly SavedChunk[]; shared?: Uint8Array | null; posts?: readonly PendingPost[] };
export const VERSION = 18;

export type CheckpointRecord = { id: string; def: string; components: Record<string, Record<string, unknown>> };
/**
 * A host report for a tick after the step, held for the step that covers it: its bytes in base64,
 * and kind "locate" for where a role's host was, "exit" for people who walked into a cold chunk
 * (with the chunk they left).
 */
export type CheckpointReport = { tick: number; cx: number; cy: number; bytes: string; kind?: "locate" | "exit"; from?: number };
/** A cold cell (ColdCell) bar what the plan gives it again: where it is, and its commute flows. */
export type CheckpointCell = Pick<ColdCell, "key" | "s" | "e" | "i" | "d" | "soldiers" | "alert" | "overrides" | "out">;
export type Checkpoint = {
  format: typeof FORMAT;
  version: number;
  build: string;
  seed: number;
  scenario: string;
  /** The authority's latest step. */
  tick: number;
  /** The tick the chunk section was taken at the start of (without one, the newest tick the hosts reported). */
  workerTick: number;
  created: string;
  records: CheckpointRecord[];
  /** Prepared geographic source inputs and append-only identity ownership. Absent for authored worlds. */
  geography?: GeographicCheckpoint;
  populationReservations?: [number, number][] | null;
  /** The nature layer, run-length coded (domain/nature.ts), in base64. */
  nature: string;
  /** The granular towns' chunk worlds, as the hosts serialize them, in base64 (./chunks.ts). */
  chunks: CheckpointChunk[];
  /** The host reports for the ticks from `tick` to before `workerTick`, in (tick, chunk) order: the hosts don't run those again. */
  held: CheckpointReport[];
  /** The cold cells, in key order. */
  cold: CheckpointCell[];
  /** The warm set's chunks (WarmSet.warm) in key order; null before its first step (or running free). */
  warm: number[] | null;
  /** The anchor pond's store (services/cold/pond.ts): every anchor the run placed; null before it had a pond. */
  anchors: AnchorStoreJSON | null;
  /** What the hosts were last configured with (the strain's traits and the response), in base64; "" when never. */
  config: string;
  /** The entities the hosts track (ChunkPool.tracking) and the inputs last sent for the controlled ones (ChunkPool.controlled, bytes in base64), sent again on load. */
  tracked?: number[];
  inputs?: { gid: number; bytes: string }[];
  /**
   * Lockstep: what the hosts' posts built up, which every host holds alike (yage ChunkModule.saveShared,
   * src/sim/shared-state.ts), in base64, and the posts made before `workerTick` that land from it on:
   * both given back before the first tick (ChunkPool.restore).
   */
  shared?: string;
  posts?: CheckpointPost[];
};

const has = (g: Pass, type: typeof Schema, eid: number) => isComponentRegistered(g as unknown as World, type) && hasComponent(g as unknown as World, type, eid);

/** One component each durable definition holds, so that together they find every durable entity. */
const ANCHORS = [ControllerIdentity, RoleIdentity, RoleRef, TownResponse, RegionResponse, PlayClockState, CommandJournal, OutbreakState, EvolutionState, GoalProgress, ScenePopulation];

/** Which durable definition `eid` was spawned from, and its stable id; undefined for anything else. */
const identify = (g: Pass, eid: number): { def: string; id: string } | undefined => {
  if (has(g, ControllerIdentity, eid)) {
    const c = g.getTypedUnsafe(ControllerIdentity, eid);
    const def = c.kind === "player" ? "controller:player" : c.role === "virus" ? "controller:virus-ai" : `controller:${c.role.split(":")[0]}-ai`;
    return { def, id: `controller:${c.role}/${c.id}` };
  }
  if (has(g, RoleIdentity, eid)) {
    const r = g.getTypedUnsafe(RoleIdentity, eid);
    return { def: `role:${r.kind}`, id: `role:${r.id}` };
  }
  if (has(g, ControlledHost, eid)) return { def: "control:actor", id: `actor:${g.getTypedUnsafe(RoleRef, eid).role}` };
  if (has(g, RoleRef, eid)) return { def: "role:knowledge", id: `knowledge:${g.getTypedUnsafe(RoleRef, eid).role}` };
  if (has(g, TownResponse, eid)) return { def: "region:town", id: g.getTypedUnsafe(TierIdentity, eid).key };
  if (has(g, RegionResponse, eid)) return { def: "region:response", id: g.getTypedUnsafe(TierIdentity, eid).key };
  if (has(g, PlayClockState, eid)) return { def: "run:clock", id: "run:clock" };
  if (has(g, CommandJournal, eid)) return { def: "run:journal", id: "run:journal" };
  if (has(g, OutbreakState, eid)) return { def: "world:outbreak", id: "world:outbreak" };
  if (has(g, EvolutionState, eid)) return { def: "world:strain", id: "world:strain" };
  if (has(g, GoalProgress, eid)) return { def: "role:objective", id: "role:objective" };
  if (has(g, ScenePopulation, eid)) return { def: "scene:population", id: "scene:population" };
  return undefined;
};

/** Every durable entity by its stable id (in entity order). */
const durables = (g: Pass) => {
  const out = new Map<string, { def: string; eid: number }>();
  const world = g as unknown as World;
  const eids = new Set<number>();
  for (const anchor of ANCHORS) if (isComponentRegistered(world, anchor)) for (const eid of entitiesWith(world, anchor)) eids.add(eid);
  for (const eid of [...eids].sort((a, b) => a - b)) {
    const known = identify(g, eid);
    if (!known) continue;
    if (out.has(known.id)) throw new Error(`checkpoint: two entities share the id ${known.id}`);
    out.set(known.id, { def: known.def, eid });
  }
  return out;
};

const classOf = (type: string) => {
  const cls = getComponentByType(type);
  if (!cls) throw new Error(`checkpoint: ${type} is not a registered component`);
  return cls;
};

// Byte arrays (zoning fields and other rasters) as base64, chunked so a large field never blows the call stack.
const bytesToBase64 = (bytes: Uint8Array) => {
  let text = "";
  for (let i = 0; i < bytes.length; i += 0x8000) text += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(text);
};
const base64ToBytes = (text: string) => Uint8Array.from(atob(text), (c) => c.charCodeAt(0));

// JSON with the values JSON can't hold tagged: non-finite numbers, Maps, Sets and byte arrays.
const replacer = function (this: unknown, _key: string, value: unknown): unknown {
  if (typeof value === "number" && !Number.isFinite(value)) return { $num: String(value) };
  if (value instanceof Uint8Array) return { $u8: bytesToBase64(value) };
  if (value instanceof Map) return { $map: [...value] };
  if (value instanceof Set) return { $set: [...value] };
  if (value !== null && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) !== Object.prototype) {
    throw new Error(`checkpoint: cannot save a ${value.constructor?.name ?? "class"} instance`);
  }
  return value;
};
const reviver = (_key: string, value: unknown): unknown => {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return value;
  const v = value as Record<string, unknown>;
  if ("$num" in v) return Number(v.$num);
  if ("$map" in v) return new Map(v.$map as [unknown, unknown][]);
  if ("$set" in v) return new Set(v.$set as unknown[]);
  if ("$u8" in v) return base64ToBytes(v.$u8 as string);
  return value;
};
export const encodeCheckpoint = (doc: Checkpoint) => JSON.stringify(doc, replacer);
export const decodeCheckpoint = (text: string) => JSON.parse(text, reviver) as Checkpoint;

const optional = <T>(g: Pass, type: new () => T): T | null => {
  const eid = findSingleEntity(g as unknown as World, type as never);
  return eid < 0 ? null : (g.getTypedUnsafe(type as never, eid) as T);
};
const coldCellsOf = (g: Pass): ColdCell[] => optional(g, ColdCells)?.cells ?? [];
const warmSetOf = (g: Pass) => optional(g, WarmSet);

/** The first half of a checkpoint of `g`: its records and nature layer, at the end of a step (no chunk or held section yet). */
export const captureCheckpoint = (g: Pass, header: { build?: string; scenario?: string; created?: string } = {}): Checkpoint => {
  const step = g.single(AuthorityStep);
  if (step.geographicLoading) throw new Error("checkpoint: geographic admission is pending");
  if (step.held?.some((report) => report.tick < step.last)) throw new Error("checkpoint: host reports from before the step are held; take it on a step");
  if (lockstepOf(g) && step.next === 0) throw new Error("checkpoint: the first step hasn't run yet");
  const records: CheckpointRecord[] = [];
  for (const [id, { def, eid }] of durables(g)) {
    const components: CheckpointRecord["components"] = {};
    for (const [type, fields] of Object.entries(DURABLE[def].saved)) {
      const data = g.getTypedUnsafe(classOf(type), eid) as unknown as Record<string, unknown>;
      const out: Record<string, unknown> = {};
      for (const field of fields) out[field] = data[field];
      components[type] = out;
    }
    records.push({ id, def, components });
  }
  // By id, so the same world writes the same text whatever order its entities were spawned in.
  records.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  // A value the codec refuses is named by where it is.
  for (const { id, components } of records) {
    for (const [type, data] of Object.entries(components)) {
      for (const [field, value] of Object.entries(data)) {
        try {
          JSON.stringify(value, replacer);
        } catch (error) {
          throw new Error(`${error instanceof Error ? error.message : String(error)} (${id} ${type}.${field})`);
        }
      }
    }
  }
  // Through the codec now, so the checkpoint holds no references into the live world.
  return decodeCheckpoint(
    encodeCheckpoint({
      format: FORMAT,
      version: VERSION,
      build: header.build ?? "",
      seed: g.single(RunSeed).seed,
      scenario: header.scenario ?? "",
      tick: step.last,
      workerTick: -1,
      created: header.created ?? new Date().toISOString(),
      records,
      ...(() => {
        const terrain = g.single(RegionMap).planning.source;
        if (!(terrain instanceof AtlasTerrain) || !terrain.atlas.geography) return {};
        return {
          geography: captureGeographicCheckpoint(terrain.atlas),
          populationReservations: g.single(AuthorityTransport).populationReservations === null ? null : [...g.single(AuthorityTransport).populationReservations!].sort((a, b) => a[0] - b[0]),
        };
      })(),
      nature: toBase64(encodeNature(natureGridOf(g))),
      chunks: [],
      held: [],
      cold: coldCellsOf(g).map(({ key, s, e, i, d, soldiers, alert, overrides, out }) => ({ key, s, e, i, d, soldiers, alert, overrides, out })),
      warm: (() => {
        const set = warmSetOf(g);
        return set?.started ? [...set.warm].sort((a, b) => a - b) : null;
      })(),
      anchors: pondStore(g as unknown as ReadOnlyGameModel),
      // Everything configured before now lands by the limit's tick, where the chunks are taken.
      config: (() => {
        const bytes = g.single(AuthorityTransport).pool.configured;
        return bytes ? toBase64(bytes) : "";
      })(),
      // Likewise what the hosts track and steer: the hosts keep it, the save doesn't take it from them.
      tracked: [...g.single(AuthorityTransport).pool.tracking],
      inputs: [...g.single(AuthorityTransport).pool.controlled].map(([gid, bytes]) => ({ gid, bytes: toBase64(bytes) })),
    }),
  );
};

/**
 * The second half: the chunk section `saved` took (saveChunks) and the reports held now for the
 * ticks before it. Without a chunk section the hosts' clock is the committed tick (lockstep) or the
 * newest they reported.
 */
export const completeCheckpoint = (g: Pass, doc: Checkpoint, saved: SavedSection = { tick: -1, chunks: [] }): Checkpoint => {
  const pool = g.single(AuthorityTransport).pool;
  const workerTick = saved.tick >= 0 ? saved.tick : lockstepOf(g) ? pool.committed : pool.hosts.reduce((max, h) => Math.max(max, h.tick), 0);
  const held = (g.single(AuthorityStep).held ?? [])
    // No absorb is held while a save is taken: it starts only once the warm set has none to come (AuthoritySaveSystem).
    .filter((report): report is typeof report & { kind?: "locate" | "exit" } => report.tick >= doc.tick && report.tick < workerTick && report.kind !== "absorb")
    .sort(heldOrder)
    .map(({ tick, cx, cy, bytes, kind, from }) => ({ tick, cx, cy, bytes: toBase64(bytes), ...(kind ? { kind } : {}), ...(from !== undefined ? { from } : {}) }));
  const shared = saved.shared ? { shared: toBase64(saved.shared) } : {};
  const posts = saved.posts?.length ? { posts: encodePosts(saved.posts) } : {};
  return { ...doc, workerTick, chunks: encodeChunks(saved.chunks), held, ...shared, ...posts };
};

/** The checkpoint of `g` now, between frames, in one go: with the chunk section `saved` took (saveChunks). */
export const writeCheckpoint = (
  g: Pass,
  header: { build?: string; scenario?: string; created?: string } = {},
  saved: SavedSection = { tick: -1, chunks: [] },
): Checkpoint => completeCheckpoint(g, captureCheckpoint(g, header), saved);

/** The cold section as cells (without what the plan gives them); refuses a malformed entry or one out of key order. */
const decodeCells = (cold: readonly CheckpointCell[]): CheckpointCell[] =>
  cold.map((cell, n) => {
    const { key, s, e, i, d, soldiers, alert, overrides, out } = cell ?? ({} as CheckpointCell);
    const ints = (list: unknown) => Array.isArray(list) && list.every(Number.isFinite);
    if (![key, s, d, soldiers, alert].every(Number.isFinite) || ![e, i, overrides, out].every(ints) || e.length !== STAGES || i.length !== STAGES || overrides.length % 3 !== 0 || (n > 0 && cold[n - 1].key >= key))
      throw new Error(`checkpoint: cold cell ${n} is malformed`);
    return { key, s, e: [...e], i: [...i], d, soldiers, alert, overrides: [...overrides], out: [...out] };
  });

/** The anchor section as a store's JSON (a copy); refuses a malformed anchor or one out of order. */
const decodeAnchors = (json: AnchorStoreJSON | null): AnchorStoreJSON | null => {
  if (json === null) return null;
  if (!json || !Number.isFinite(json.now) || !Array.isArray(json.anchors)) throw new Error("checkpoint: the anchor section is malformed");
  const anchors = json.anchors.map((a, n) => {
    const { id, kind, town, tick, payload, parents, seal } = a ?? ({} as Anchor);
    const scalar = (v: unknown) => typeof v === "number" || typeof v === "string" || typeof v === "boolean";
    if (typeof id !== "string" || typeof kind !== "string" || !Number.isInteger(town) || !Number.isFinite(tick) || !payload || typeof payload !== "object" || !Object.values(payload).every(scalar) || !Array.isArray(parents) || (seal !== undefined && !Number.isFinite(seal)))
      throw new Error(`checkpoint: anchor ${n} is malformed`);
    if (n > 0 && json.anchors[n - 1].tick > tick) throw new Error(`checkpoint: anchor ${n} is out of order`);
    return { id, kind, town, tick, payload: { ...payload }, parents: parents.map(String), ...(seal !== undefined ? { seal } : {}) };
  });
  return { now: json.now, anchors };
};

/** The held section as reports; refuses a malformed entry. */
const decodeHeld = (held: readonly CheckpointReport[]) =>
  held.map((report, i) => {
    const { tick, cx, cy, bytes, kind, from } = report ?? ({} as CheckpointReport);
    if (![tick, cx, cy].every(Number.isInteger) || typeof bytes !== "string" || !bytes || (kind !== undefined && kind !== "locate" && kind !== "exit") || (kind === "exit") !== Number.isInteger(from))
      throw new Error(`checkpoint: held report ${i} is malformed`);
    return { tick, cx, cy, bytes: fromBase64(bytes), ...(kind ? { kind } : {}), ...(kind === "exit" ? { from: from! } : {}) };
  });

/**
 * Loads `doc` into `g`, a fresh boot of the same seed (its region seeded, its virus role spawned).
 * Accepts v18 and migrates v14–v17; refuses other versions, unknown definitions and unplaceable records.
 */
/** A v17-and-older chunk key (yage's old (cx + 32768) · 2¹⁶ + (cy + 32768)) as its 19-bit one. */
const widenKey = (key: number) => chunkKey(Math.floor(key / 65536) - 32768, (key % 65536) - 32768);
/**
 * Person/chunk bytes are unchanged. v14 lacks RTS; v15 lacks siege/operations; v16 lacks territory/history;
 * v17 and older pack chunk keys 16 bits an axis (v18 uses yage's 19-bit keys: a true-scale Earth).
 */
export const upgradeCheckpoint = (saved: Checkpoint): Checkpoint => {
  if (saved.format !== FORMAT || ![14, 15, 16, 17].includes(saved.version)) return saved;
  const doc = decodeCheckpoint(encodeCheckpoint(saved));
  doc.version = VERSION;
  for (const cell of doc.cold ?? []) if (Number.isInteger(cell?.key)) cell.key = widenKey(cell.key);
  if (Array.isArray(doc.warm)) doc.warm = doc.warm.map((key) => (Number.isInteger(key) ? widenKey(key) : key));
  if (Array.isArray(doc.populationReservations))
    doc.populationReservations = doc.populationReservations.map((row) => (Array.isArray(row) && Number.isInteger(row[0]) ? [widenKey(row[0]), row[1]] : row));
  for (const report of doc.held ?? []) if (report?.kind === "exit" && Number.isInteger(report.from)) report.from = widenKey(report.from!);
  if (saved.version === 17) return doc;
  for (const record of doc.records) {
    if (record.def === "control:actor" && saved.version < 16) {
      if (saved.version === 14) record.components.RtsState = { commanding: false, nextOrder: 1, nextHorde: 1, units: [], hordes: [], contacts: [], history: [] };
      record.components.SiegeState = { revision: 0, structures: [], cooldowns: {}, events: [], fortifiedAt: -1 };
      record.components.StrategyState = { nextOperation: 1, nextEvent: 1, operations: [], events: [] };
    }
    if (record.def === "region:response") {
      record.components.TerritoryState = { tick: -1, revision: 0, nextEvent: 1, towns: [], events: [] };
      record.components.OperationalHistory = { frames: [] };
    }
    if (record.def === "role:virus") {
      const authority = record.components.RoleAuthority;
      if (authority && Array.isArray(authority.actions)) authority.actions = [...new Set([...authority.actions, "rtsMode", "rtsOrder", "rtsHorde", "rtsRelease", "siegeStrike", "strategyOrder", "strategyCancel"])];
    }
  }
  return doc;
};

export const readCheckpoint = (g: Pass, input: Checkpoint) => {
  const doc = upgradeCheckpoint(input);
  if (doc.format !== FORMAT || doc.version !== VERSION) throw new Error(`checkpoint: ${doc.format} v${doc.version} is not ${FORMAT} v${VERSION}`);
  if (doc.seed !== g.single(RunSeed).seed) throw new Error(`checkpoint: saved with seed ${doc.seed}, booted with ${g.single(RunSeed).seed}`);
  for (const record of doc.records) if (!DURABLE[record.def]) throw new Error(`checkpoint: unknown definition ${record.def}`);
  const nature = decodeNature(fromBase64(doc.nature ?? ""), NATURE_SIDE * NATURE_SIDE);
  const chunks = decodeChunks(doc.chunks ?? []);
  const held = decodeHeld(doc.held ?? []);
  const cold = decodeCells(doc.cold ?? []);
  const warm = doc.warm ?? null;
  const anchors = decodeAnchors(doc.anchors ?? null);
  if (warm !== null && (!Array.isArray(warm) || !warm.every(Number.isInteger))) throw new Error("checkpoint: the warm set is malformed");
  const config = doc.config ? fromBase64(doc.config) : null;
  if (config && !decodeConfig(config).response) throw new Error("checkpoint: the hosts' config is malformed");
  const terrain = g.single(RegionMap).planning.source;
  const geographic = terrain instanceof AtlasTerrain && !!terrain.atlas.geography;
  if (!!doc.geography !== geographic || (doc.geography && !geographicCheckpointMatches((terrain as AtlasTerrain).atlas, doc.geography)))
    throw new Error("checkpoint: geographic source was not restored for this save");
  const reservations = doc.geography ? decodePopulationReservations(doc.populationReservations, warm) : null;
  const pool = g.single(AuthorityTransport).pool;
  const lockstep = lockstepOf(g);
  if (lockstep && (pool.limit !== 0 || pool.startTick !== 0)) throw new Error("checkpoint: the hosts have run; load into a fresh boot");
  // The offices a fresh boot doesn't have: a granular town's.
  for (const record of doc.records) if (record.def === "role:mayor") openTownOffice(g, String(record.components.TierRef.key));
  const kept = new Set([...keptChunks(g).map(({ cx, cy }) => chunkKey(cx, cy)), ...(warm ?? [])]);
  for (const { space, cx, cy } of chunks) if (space !== 0 || !kept.has(chunkKey(cx, cy))) throw new Error(`checkpoint: chunk ${cx},${cy} is in no granular town and not warm`);
  const live = durables(g);
  const saved = new Set(doc.records.map((r) => r.id));
  for (const [id, { eid }] of live) if (!saved.has(id)) removeEntity(g as unknown as World, eid);
  // Fresh rows for every record (decoded copies: nothing here is shared with `doc`).
  for (const record of decodeCheckpoint(encodeCheckpoint(doc)).records) {
    const found = live.get(record.id);
    if (!found || found.def !== record.def) throw new Error(`checkpoint: no ${record.def} ${record.id} in this boot`);
    const manifest = DURABLE[record.def].saved;
    for (const [type, data] of Object.entries(record.components)) {
      const fields = manifest[type];
      if (!fields) continue;
      const target = g.getTypedUnsafe(classOf(type), found.eid) as unknown as Record<string, unknown>;
      for (const field of fields) if (field in data) target[field] = data[field];
    }
  }
  loadNatureGrid(g, nature);
  // The cold cells, their flows from the cells the boot surveyed (the plan's), and the warm set.
  const cells = optional(g, ColdCells);
  if (cells) {
    const planning = g.single(RegionMap).planning;
    const surveyed = new Map(cells.cells.map((cell) => [cell.key, cell]));
    cells.cells = cold.map((cell) => {
      const cx = chunkX(cell.key);
      const cy = chunkY(cell.key);
      const { flowTo, flowN } = surveyed.get(cell.key) ?? commuteFlows(cx, cy, planning);
      return { ...cell, cx, cy, flowTo, flowN } as ColdCell;
    });
  } else if (cold.length) throw new Error("checkpoint: cold cells, and this boot has none");
  restorePond(g as unknown as ReadOnlyGameModel, anchors);
  if (doc.geography) g.single(AuthorityTransport).populationReservations = reservations;
  const set = warmSetOf(g);
  if (set) {
    set.started = warm !== null;
    set.warm = new Set(warm ?? []);
    set.leaving.clear();
  }
  // The seats the save's players held go back to their fallbacks.
  for (const eid of entitiesWith(g as unknown as World, [ControlBinding, PossessionCommands])) {
    const binding = g.getTypedUnsafe(ControlBinding, eid);
    if (binding.controller !== binding.fallback) pushCommand(g.getTypedUnsafe(PossessionCommands, eid), { kind: "disconnect", controller: binding.controller });
  }
  // The indexes over what was written.
  const towns = g.single(RegionTowns);
  towns.towns = [...entitiesWith(g as unknown as World, TownResponse)].sort((a, b) => g.getTypedUnsafe(TownResponse, a).index - g.getTypedUnsafe(TownResponse, b).index);
  const population = g.single(ScenePopulation);
  g.single(ChunkCountIndex).byKey = new Map(population.chunks.map((row) => [row.key, row]));
  const step = g.single(AuthorityStep);
  step.tick = -1;
  step.last = doc.tick;
  step.next = lockstepOf(g) ? doc.tick + STEP_TICKS : 0;
  step.held = [];
  step.hold = false;
  step.geographicLoading = false;
  // Main-thread collision must match durable damage immediately, before any new trait request.
  collisionMemory(g.single(RegionMap).planning).siege = siegeSnapshot(g as unknown as ReadOnlyGameModel);
  // The hosts start where the chunk section was taken, and everything sent from here lands there.
  if (lockstep) pool.resume(doc.workerTick);
  if (config) {
    const decoded = decodeConfig(config);
    InfectionConfigSystem.setResponse(decoded.response!, g.single(RegionMap).planning);
    InfectionConfigSystem.setDirectives(decoded.directives, g.single(RegionMap).planning);
    pool.configure(config);
  }
  if (doc.tracked?.length) pool.track(doc.tracked);
  for (const { gid, bytes } of doc.inputs ?? []) {
    // A showcase the hosts already played goes back without it (its chunk's showcased tick isn't saved).
    const input = fromBase64(bytes);
    const pick = showcaseOf(input);
    if (pick && pick.tick < doc.workerTick) input[2] = 0;
    pool.input(gid, input);
  }
  for (const { tick, kind, from, ...report } of held) {
    // An exit's people go into the chunk they walked into, or its cell (ColdCrossingSystem).
    if (kind === "exit") step.held.push({ tick, key: chunkKey(report.cx, report.cy), ...report, kind, from, apply: () => applyExit(g as never, report.bytes) });
    else holdReport(g, tick, { ...report, ...(kind ? { kind } : {}) });
  }
  exportResponse(g);
  loadChunks(g, chunks);
  // What the posts built up on the hosts, and the posts still to land, where the chunks run now.
  if (lockstep && (doc.shared || doc.posts?.length)) pool.restore(doc.shared ? fromBase64(doc.shared) : null, decodePosts(doc.posts ?? []));
  // Where the save's step left the limit, so the next step's sends land where they did.
  if (lockstep) pool.setLimit(doc.tick + 2 * STEP_TICKS);
};
