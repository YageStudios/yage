/**
 * The anchors placed (types.ts): in tick order (ties by id), indexed by town and step. Placed only
 * forward (`now`), never changed by a query; saved whole (the checkpoint's anchor section).
 */
import { type Anchor, GLOBAL, stepOf } from "./types";

const before = (a: Anchor, b: Anchor) => a.tick - b.tick || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);

export type AnchorStoreJSON = { now: number; anchors: Anchor[] };

export class AnchorStore {
  private list: Anchor[] = [];
  private byTown = new Map<number, Map<number, Anchor[]>>();
  private ids = new Set<string>();
  /** The latest tick placed at: nothing goes in before it. */
  now = 0;

  add(anchor: Anchor) {
    if (this.ids.has(anchor.id)) throw new Error(`anchors: ${anchor.id} is placed already`);
    if (anchor.tick < this.now) throw new Error(`anchors: ${anchor.id} at ${anchor.tick} is before ${this.now}`);
    this.now = anchor.tick;
    this.ids.add(anchor.id);
    let at = this.list.length;
    while (at > 0 && before(this.list[at - 1], anchor) > 0) at--;
    this.list.splice(at, 0, anchor);
    const step = stepOf(anchor.tick);
    let town = this.byTown.get(anchor.town);
    if (!town) this.byTown.set(anchor.town, (town = new Map()));
    const list = town.get(step) ?? [];
    list.push(anchor);
    list.sort(before);
    town.set(step, list);
  }

  has(id: string) {
    return this.ids.has(id);
  }

  /** Every anchor, in order. */
  all(): readonly Anchor[] {
    return this.list;
  }

  /** The anchors that take effect at `town` on `step`, in order. */
  at(town: number, step: number): readonly Anchor[] {
    return this.byTown.get(town)?.get(step) ?? [];
  }

  /** The whole-run anchors (the strain's), in order. */
  global(): readonly Anchor[] {
    return this.list.filter((a) => a.town === GLOBAL);
  }

  toJSON(): AnchorStoreJSON {
    return { now: this.now, anchors: this.list.map((a) => ({ ...a, payload: { ...a.payload }, parents: [...a.parents] })) };
  }

  static fromJSON(json: AnchorStoreJSON) {
    const store = new AnchorStore();
    for (const a of json.anchors) store.add(a);
    store.now = json.now;
    return store;
  }
}
