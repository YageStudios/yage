/**
 * The pond: a town's course pulled from the seed and the anchors (types.ts). Each town goes in
 * leaps: its rates now (the cold tier's own model: domain/cold/step.ts's pressure, stages and
 * dose) held over a span no longer than its piece of the day, and short enough that its contagion
 * moves by no more than LEAP_SHARE; over it, the susceptible are infected by a binomial, and every
 * stage's people move on down the stages by their exact chances (systematically drawn: chain), as
 * many stages as the span takes them. Whatever arrives (an anchor, a ripple, the shift's turn)
 * cuts the leap there and the next is drawn from the new rates.
 *
 * Every draw is the seed's (keyed by the town and its count of changes), so a town's course from
 * any state of it is the same however often it's replayed: what's kept is what can't be drawn
 * again, the inputs (anchors placed, ripples told) and a few states of each town, sparser the
 * further back (KEEP). A town wakes only when something is due there: what arrives, its next leap, and the
 * shift's turn while contagion is about. Quiet time, a healthy town nothing reaches, and an emptied one
 * cost nothing, however long the run.
 *
 * Towns are coupled only by ripples (ripples.ts), each at least a step (STEP) on its way: the
 * towns wake in tick order off one queue, so whatever reaches a town by a tick was told before it
 * gets there. Towns are live from what they begin with (the strain, nobody), an anchor placed or a
 * ripple told there, or being asked; the rest aren't resolved at all.
 *
 * Placing an anchor at t takes its town back to before t, from its last kept state before then;
 * nothing before it changes. What a town taken back had told from then on is held, not unsaid:
 * told again the same (the same ripple, tick and payload) it stands, and the town it reached
 * stands as it is; told otherwise, or not told by the time the town has gone past it, it's unsaid,
 * and the town it reached goes back to before it in turn (as does one a ripple reaches after it's
 * resolved past it). So a change goes only as far as it changes what towns tell: a town whose every
 * arrival is the same goes the same.
 */
import { binomial, unitOf } from "../domain/cold/draws";
import { type Cold, COLD, coldPressure, residents, STAGES } from "../domain/cold/step";
import { State, type Traits } from "../domain/disease";
import { MEASURES as RESPONSE, measuresOf } from "../domain/response/measures";
import { DAY_SECONDS, HOUR, START_HOUR } from "../domain/time";
import { hash, TICK_RATE } from "../domain/world";
import { beastHazard, bodiesOf, breedOf, sickShare, effectsOf, killsOf, lifeRateOf, risenShare, routeHazard, type TraitEffects, wildOf } from "../traits";
import { type PondMap, type TownGraph, townGraph } from "./graph";
import {
  type Carry,
  closedOf,
  countsOf,
  infectedOf,
  livingOf,
  type Counts,
  Heard,
  lastOf,
  MEASURES,
  Next,
  type RippleContext,
  rippleKind,
  type Spawn,
  strengthTo,
  reach,
  townRules,
  type Pending,
  type TownState,
  freshExtra,
} from "./ripples";
import { AnchorStore } from "./store";
import { roamNext } from "./systems";
import { type Anchor, GLOBAL, type Payload, STEP, type TownEvent } from "./types";

export type PondConfig = {
  seed: number;
  /** The cold cells as the run begins. */
  cells: readonly Cold[];
  map: PondMap;
  traits: Traits;
  /** What the weather does to spread at a town now (domain/weather.ts spreadFactor); 1 by default. */
  weather?: (town: number, tick: number, traits: Traits) => number;
  /**
   * The towns' own doings (their governors, falls, emptying): on unless off, as to set the course
   * against the stepped cold model's; a tick: on before it only (a solved history handed to the
   * live offices from then on).
   */
  rules?: boolean | number;
  /**
   * The strain's course known beforehand: its traits changing at each tick (as a live run's AI
   * evolved it), as `strain` anchors there would. A solve plans on it before it has placed the
   * anchors those ticks come after (placing is forward only).
   */
  course?: readonly { tick: number; payload: Partial<Traits> }[];
  /** How often a town's state is kept, how many at most, and how many latest are never thinned (KEEP; a test's, to replay more). */
  keep?: { every: number; most: number; latest: number; span?: number };
  /**
   * The world's systems beyond the strain's spread (systems.ts), off unless given (the live run's
   * offices and hosts do these themselves): `roam`, the infected moving on in hordes (a town rule);
   * `life`, the living's own course, births and deaths of age, a share a year.
   */
  systems?: { roam?: boolean; life?: { births: number; deaths: number } };
};

/** A year of ticks (the living's own course goes by them). */
const YEAR_TICKS = 365 * DAY_SECONDS * TICK_RATE;

/**
 * How many of a town's own wakes go by between the states kept of it (a tick between replays from
 * the one before), and how many are kept at most: past that, every other of the older ones goes
 * (the latest few stay, for placing near now), so the further back, the sparser.
 */
const KEEP = { every: 64, most: 16, latest: 4, span: DAY_SECONDS * TICK_RATE };

/**
 * Thins a town's kept states: its first, its latest few, its latest by `now` (nothing's placed before
 * it, so a rewind goes back no further), and every other one between.
 */
const thin = (snaps: TownState[], few: number, now: number) => {
  let floor = 0;
  while (floor + 1 < snaps.length && snaps[floor + 1].tick <= now) floor++;
  const keep = [snaps[0]];
  const latest = snaps.length - few;
  for (let k = 1;k < latest;k++) if (k % 2 === 0 || k === floor) keep.push(snaps[k]);
  snaps.splice(0, latest, ...keep);
};

/**
 * The whole-run anchors: `strain` (the traits from then: its payload over the base), and `rules`
 * (the towns' own doings on or off from then: `on`, as a solved scenario hands its towns over to
 * the live offices at its end).
 */
export const GLOBAL_KINDS = new Set(["strain", "rules"]);
/** How much a leap may move the town's contagion (or use up its susceptible) by, as a share. */
const LEAP_SHARE = 0.25;
/** How much a town's commute word must change before it tells its neighbours again. */
const CARRY_CHANGE = 0.1;

const enum Purpose {
  Infect = 3,
  Bitten = 7,
  Killed = 8,
  Born = 5,
  Aged = 6,
  Bred = 9,
  Chain = 0x300,
}

/** A town as the pond sees it. */
export type TownView = {
  town: number;
  tick: number;
  people: number;
  susceptible: number;
  incubating: number;
  infected: number;
  dead: number;
  /** Of the living, the immune; everyone ever infected here; born here. */
  immune: number;
  got: number;
  born: number;
  /** Of the well, those who've died of age and illness here (the living's own course). */
  aged: number;
  walls: number;
  sealed: boolean;
  level: number;
  border: number;
  cordon: number;
  burn: number;
  closed: boolean;
  fallen: number;
  empty: number;
  story: readonly TownEvent[];
  digest: number;
};

/** A live town: its state at its latest wake (valid on to the queue's front), its kept states, and its wakes since the latest kept. */
type Line = { state: TownState; snaps: TownState[]; since: number };
type Told = { from: number; at: number; anchor: Anchor };

/** The first index in a (tick, id)-ordered list after `tick`. */
const after = (list: readonly Anchor[], tick: number) => {
  let lo = 0;
  let hi = list.length;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (list[mid].tick > tick) hi = mid;
    else lo = mid + 1;
  }
  return lo;
};

const byTickId = (a: Anchor, b: Anchor) => a.tick - b.tick || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);

/** Towns by when they next wake (earliest first; a stale entry is skipped on the way out: Pond.due). */
class WakeQueue {
  private ticks: number[] = [];
  private towns: number[] = [];

  get size() {
    return this.ticks.length;
  }

  /** The earliest tick queued. */
  peek() {
    return this.ticks.length ? this.ticks[0] : Infinity;
  }

  push(tick: number, town: number) {
    const { ticks, towns } = this;
    let i = ticks.length;
    ticks.push(tick);
    towns.push(town);
    while (i > 0) {
      const up = (i - 1) >> 1;
      if (ticks[up] < tick || (ticks[up] === tick && towns[up] <= town)) break;
      ticks[i] = ticks[up];
      towns[i] = towns[up];
      i = up;
    }
    ticks[i] = tick;
    towns[i] = town;
  }

  /** The earliest queued town (its tick: peek before). */
  pop() {
    const { ticks, towns } = this;
    const town = towns[0];
    const tick = ticks.pop()!;
    const last = towns.pop()!;
    const n = ticks.length;
    if (!n) return town;
    let i = 0;
    while (true) {
      let child = 2 * i + 1;
      if (child >= n) break;
      if (child + 1 < n && (ticks[child + 1] < ticks[child] || (ticks[child + 1] === ticks[child] && towns[child + 1] < towns[child]))) child++;
      if (tick < ticks[child] || (tick === ticks[child] && last <= towns[child])) break;
      ticks[i] = ticks[child];
      towns[i] = towns[child];
      i = child;
    }
    ticks[i] = tick;
    towns[i] = last;
    return town;
  }

  copy() {
    const out = new WakeQueue();
    out.ticks = [...this.ticks];
    out.towns = [...this.towns];
    return out;
  }
}

const cloneState = (s: TownState): TownState => ({
  ...s,
  c: { s: s.c.s, e: [...s.c.e], i: [...s.c.i], d: s.c.d },
  pending: { ...s.pending },
  carried: new Map(s.carried),
  sent: new Map(s.sent),
  orders: { level: [...s.orders.level], border: [...s.orders.border], cordon: [...s.orders.cordon], burn: [...s.orders.burn] },
  heard: new Map(s.heard),
  story: [...s.story],
  x: { ...s.x },
});

/** A town state's digest (what a seal holds). */
export const digestOf = (s: TownState) => {
  const words: number[] = [s.town, s.c.s, ...s.c.e, ...s.c.i, s.c.d, s.fallen, s.empty, s.asked, s.warned ? 1 : 0, s.concrete, s.story.length];
  for (const m of MEASURES) for (const [v, at] of s.orders[m]) words.push(v, at);
  for (const [t, f] of [...s.heard].sort((a, b) => a[0] - b[0])) words.push(t, f);
  // What the systems made of it (only if they did: a history without them digests as it did).
  const x = s.x;
  if (x.walls || x.sealed || x.tide || x.im || x.born || x.aged || x.bare) words.push(x.walls, x.sealed ? 1 : 0, ...(x.tide ?? [0]), x.im, x.born, x.aged, x.bare ? 1 : 0);
  const bytes = new Uint32Array(Float64Array.from(words).buffer);
  return hash(...bytes);
};

/**
 * The town's day in pieces: the shift (COLD.workFrom..workTo), curfew's hours, and the rest. A
 * town's rates are piecewise constant: whatever turns with time of itself (the shift, curfew, the
 * weather) is read at its piece's start, and a town with contagion about wakes at each turn; while
 * its orders are still taking hold (RAMPING), at each hour. So the pieces are the town's own, not
 * cut where something happens to arrive.
 */
const HOUR_TICKS = HOUR * TICK_RATE;
const HOUR_ZERO = -START_HOUR * HOUR_TICKS;
const DAY_TICKS = DAY_SECONDS * TICK_RATE;
const EDGES = [COLD.workFrom, COLD.workTo, RESPONSE.curfewFrom * 24, RESPONSE.curfewTo * 24].map((h) => h * HOUR_TICKS).sort((a, b) => a - b);
/** How long after its latest order a town's measures are still taking hold (three of the slower ramp's time constants). */
const RAMPING = 3 * Math.max(RESPONSE.complyRamp, RESPONSE.maskRamp) * TICK_RATE;
const dayOf = (tick: number) => HOUR_ZERO + Math.floor((tick - HOUR_ZERO) / DAY_TICKS) * DAY_TICKS;
const hourOf = (tick: number) => HOUR_ZERO + Math.floor((tick - HOUR_ZERO) / HOUR_TICKS) * HOUR_TICKS;
/** The start of the piece of the day `tick` is in. */
const pieceOf = (tick: number) => {
  const day = dayOf(tick);
  for (let k = EDGES.length - 1;k >= 0;k--) if (tick - day >= EDGES[k]) return day + EDGES[k];
  return day - DAY_TICKS + EDGES[EDGES.length - 1];
};
/** The start of the next piece after `tick`'s. */
const nextPiece = (tick: number) => {
  const day = dayOf(tick);
  for (const edge of EDGES) if (tick - day < edge) return day + edge;
  return day + DAY_TICKS + EDGES[0];
};
const working = (tick: number) => {
  const into = tick - dayOf(tick);
  return into >= COLD.workFrom * HOUR_TICKS && into < COLD.workTo * HOUR_TICKS;
};
/** Whether `state`'s orders are still taking hold at `tick`. */
const ramping = (state: TownState, tick: number) => {
  const level = state.orders.level;
  return level.length > 0 && level[level.length - 1][0] > 0 && tick - level[level.length - 1][1] < RAMPING;
};
/** Where `state`'s rates are read for `tick`: its piece's start, or the hour's while its orders take hold. */
const readAt = (state: TownState, tick: number) => (ramping(state, tick) ? Math.max(pieceOf(tick), hourOf(tick)) : pieceOf(tick));
/** When `state`'s rates are next read after `tick`. */
const nextRead = (state: TownState, tick: number) => (ramping(state, tick) ? Math.min(nextPiece(tick), hourOf(tick) + HOUR_TICKS) : nextPiece(tick));

/** Into `out`: Poisson(mean)'s chances of 0..n−1. */
const poissonInto = (out: Float64Array, mean: number, n: number) => {
  let term = Math.exp(-mean);
  for (let j = 0;j < n;j++) {
    out[j] = term;
    term *= mean / (j + 1);
  }
};

const LAST = 2 * STAGES;
const stepsE = new Float64Array(STAGES);
const stepsI = new Float64Array(STAGES);
const stepsB = new Float64Array(STAGES);
const chances = new Float64Array(LAST + 1);

/**
 * Where a town's people go in `dt` seconds down the stages (incubating 0..STAGES−1, bloomed
 * STAGES..2·STAGES−1, then dead), into `out`: `n[k]` of stage k, `incubate` and `life` a stage's
 * rate. Each stage's people are shared out by their chances (Poisson steps at their rate; those
 * that bloom go on at the bloomed's for what's left of the span after their expected bloom),
 * systematically drawn with one uniform `u(k)`: the counts are whole, add up, and are right on
 * average.
 */
const chain = (n: readonly number[], dt: number, incubate: number, life: number, u: (k: number) => number, out: number[]) => {
  out.fill(0);
  poissonInto(stepsE, incubate * dt, STAGES);
  poissonInto(stepsI, life * dt, STAGES);
  for (let k = 0;k < LAST;k++) {
    if (n[k] <= 0) continue;
    chances.fill(0);
    if (k < STAGES) {
      let left = 1;
      for (let j = 0;j < STAGES - k;j++) {
        chances[k + j] = stepsE[j];
        left -= stepsE[j];
      }
      if (left > 1e-12) {
        poissonInto(stepsB, life * Math.max(0, dt - (STAGES - k) / incubate), STAGES);
        let dead = left;
        for (let j = 0;j < STAGES;j++) {
          chances[STAGES + j] += left * stepsB[j];
          dead -= left * stepsB[j];
        }
        chances[LAST] += Math.max(0, dead);
      }
    } else {
      let left = 1;
      for (let j = 0;j < LAST - k;j++) {
        chances[k + j] = stepsI[j];
        left -= stepsI[j];
      }
      chances[LAST] = Math.max(0, left);
    }
    const v = u(k);
    let cum = 0;
    let was = 0;
    for (let j = k;j <= LAST;j++) {
      cum += chances[j];
      const upTo = j === LAST ? n[k] : Math.min(n[k], Math.floor(n[k] * cum + v));
      out[j] += upTo - was;
      was = upTo;
    }
  }
  return out;
};

const cohorts = new Array<number>(LAST).fill(0);
const movedScratch = new Array<number>(LAST + 1).fill(0);
const freshScratch = new Array<number>(LAST + 1).fill(0);

const within = (h: number, dt: number) => (h > 0 ? 1 - Math.exp(-h * dt) : 0);

/** Whether two payloads say the same (as they're made: the same keys in the same order). */
const samePayload = (a: Payload, b: Payload) => {
  const ka = Object.keys(a);
  const kb = Object.keys(b);
  if (ka.length !== kb.length) return false;
  for (let k = 0;k < ka.length;k++) {
    const x = a[ka[k]];
    const y = b[ka[k]];
    if (ka[k] !== kb[k] || (x !== y && (typeof x !== "object" || typeof y !== "object" || JSON.stringify(x) !== JSON.stringify(y)))) return false;
  }
  return true;
};

const changed = (a: number, b: number) => (a === 0) !== (b === 0) || Math.abs(a - b) > CARRY_CHANGE * Math.max(Math.abs(a), Math.abs(b));

/** Whether a commute word has changed enough to tell again (a town's own rule, and the full sim's: services/cold/pond.ts). */
export const carryChanged = (word: Carry, last: Carry | undefined) => !last || changed(word.vp, last.vp) || changed(word.vr, last.vr) || changed(word.pw, last.pw);

/** `total` split over `weights` in proportion, whole (largest remainder; ties to the first). */
export const apportion = (total: number, weights: readonly number[]) => {
  const sum = weights.reduce((a, b) => a + b, 0);
  if (sum <= 0 || total <= 0) return weights.map(() => 0);
  const exact = weights.map((w) => (total * w) / sum);
  const out = exact.map(Math.floor);
  let left = total - out.reduce((a, b) => a + b, 0);
  const order = exact.map((x, j) => [x - out[j], j] as const).filter(([f]) => f > 0).sort((a, b) => b[0] - a[0] || a[1] - b[1]);
  for (const [, j] of order) {
    if (left <= 0) break;
    out[j]++;
    left--;
  }
  return out;
};

/** The town's well as a share of its living (what a feeding host finds about it). */
const preyOf = (c: Counts, people = livingOf(c)) => {
  return people > 0 ? c.s / people : 0;
};

/**
 * The hazard on each of a town's well beyond what passes in the air and on surfaces: its bloomed's
 * bites (TraitEffects.bites over its living), its feral beasts' (kept out by its walls, as a horde
 * is), and its animals and water (traits/carriers.ts). The bites alone too, to tell the bitten from
 * the rest.
 */
const besides = (c: Counts, fx: TraitEffects, walls: number, n = countsOf(c)) => {
  const sick = sickShare(n.infected, n.dead, n.incubating, n.people + n.dead);
  const host = fx.bites > 0 && n.people > 0 ? (fx.bites * n.infected) / n.people : 0;
  const beast = beastHazard(fx, sick) * Math.max(0, 1 - walls);
  const bites = host + beast;
  return { bites, kills: killsOf(fx, host, beast), all: bites + routeHazard(fx, sick) };
};

/** A cell's share of its town's counts (Pond.cellsOf). */
export type CellCounts = { key: number; s: number; e: number[]; i: number[]; d: number };

export class Pond {
  readonly graph: TownGraph;
  readonly store: AnchorStore;
  /** What it was made from (its cells as they were then), to make another the same (the solver's). */
  readonly config: PondConfig;
  private readonly seed: number;
  private readonly base: Traits;
  private readonly weather: (town: number, tick: number, traits: Traits) => number;
  private readonly keep: { every: number; most: number; latest: number; span?: number };
  /** The towns' own doings go on before this tick. */
  private readonly rules: number;
  /** Whether the infected move on of themselves (systems.ts ROAM), and the living's own course a year (births, deaths of age). */
  private readonly roam: boolean;
  private readonly lifeRates: { births: number; deaths: number } | null;
  /** Each town's people as it begins, its commuters out (to each neighbour), and who comes in from each neighbour untold. */
  private readonly start: Counts[];
  private readonly n0: number[];
  private readonly flows: { to: number; n: number }[][];
  private readonly baseline: Map<number, Carry>[];
  /** The towns whose people come to work in each (that it doesn't go to): it tells them what its streets hold, as they bring it home. */
  private readonly homes: number[][];
  /** Each town's cells and their residents as the run began (how its counts spread over them). */
  private readonly weights0: [number, number][][];
  private lines: (Line | null)[] = [];
  private inbox: Anchor[][] = [];
  private told: Told[][] = [];
  /** What each town taken back had told from then on, till it's told again the same (kept) or not (unsaid): by tick told. */
  private held: Told[][] = [];
  /** Each live town's next wake as queued (Infinity: none). */
  private due: number[] = [];
  private queue = new WakeQueue();
  private placed: Anchor[][] = [];
  private globals: readonly Anchor[] | null = null;
  /** The strain's traits from each strain anchor on (built from the globals). */
  private strains: { tick: number; traits: Traits }[] | null = null;
  /** The streets' hazard and commute shares after() last found, for schedule() to take up on the same tick. */
  private lastStreets: { state: TownState; at: number; traits: Traits; shares: ReturnType<Pond["shares"]>; pw: number } | null = null;
  private strainHit: { of: unknown; from: number; to: number; traits: Traits | null } = { of: null, from: 0, to: 0, traits: null };
  private lastMeasures: { level: unknown; length: number; tick: number; at: ReturnType<typeof measuresOf> | null } = { level: null, length: 0, tick: NaN, at: null };
  /** What resolving has cost (changes applied, ripples arrived and told, times a town woke at all), for the bench. */
  readonly stats = { leaps: 0, arrivals: 0, told: 0, wakes: 0 };

  constructor(config: PondConfig, store = new AnchorStore()) {
    this.config = { ...config, cells: config.cells.map((c) => ({ ...c, e: [...c.e], i: [...c.i], overrides: [...c.overrides], out: [...c.out], flowTo: [...c.flowTo], flowN: [...c.flowN] })) };
    this.seed = config.seed;
    this.base = config.traits;
    this.weather = config.weather ?? (() => 1);
    this.keep = config.keep ?? KEEP;
    this.rules = config.rules === undefined || config.rules === true ? Infinity : config.rules === false ? -Infinity : config.rules;
    this.store = store;
    this.roam = config.systems?.roam === true;
    this.lifeRates = config.systems?.life ?? null;
    this.graph = townGraph(config.cells, config.map);
    const { towns, townOf } = this.graph;
    this.start = towns.map(() => ({ s: 0, e: new Array<number>(STAGES).fill(0), i: new Array<number>(STAGES).fill(0), d: 0 }));
    const out = towns.map(() => new Map<number, number>());
    for (const cell of config.cells) {
      const town = townOf.get(cell.key)!;
      const c = this.start[town];
      c.s += cell.s;
      c.d += cell.d;
      for (let k = 0;k < STAGES;k++) {
        c.e[k] += cell.e[k];
        c.i[k] += cell.i[k];
      }
      for (let o = 0;o < cell.overrides.length;o += 3) {
        const state = cell.overrides[o + 1];
        if (state === State.Incubating) c.e[0]++;
        else if (state === State.Infected) c.i[0]++;
        else if (state === State.Dead) c.d++;
        else c.s++;
      }
      cell.flowTo.forEach((key, f) => {
        const to = townOf.get(key);
        if (to === undefined || to === town) return;
        out[town].set(to, (out[town].get(to) ?? 0) + cell.flowN[f]);
      });
    }
    this.weights0 = towns.map((t) => t.cells.map((key) => [key, 0] as [number, number]));
    for (const cell of config.cells) {
      const list = this.weights0[townOf.get(cell.key)!];
      list.find(([key]) => key === cell.key)![1] = residents(cell);
    }
    this.n0 = this.start.map((c) => residents({ ...c, overrides: [] } as unknown as Cold) - c.d);
    this.flows = out.map((m) => [...m].sort((a, b) => a[0] - b[0]).map(([to, n]) => ({ to, n })));
    this.baseline = towns.map(() => new Map());
    this.flows.forEach((list, from) => {
      for (const { to, n } of list) this.baseline[to].set(from, { vp: n, vr: 0, pw: 0 });
    });
    this.homes = towns.map((_, town) => [...this.baseline[town].keys()].filter((from) => !this.flows[town].some((f) => f.to === from)).sort((a, b) => a - b));
    this.placed = towns.map(() => []);
    for (const a of store.all()) if (a.town !== GLOBAL) this.placed[a.town].push(a);
    this.reset();
  }

  /** Forgets every town's course, and makes live again the towns that begin moving (the strain, nobody, an anchor placed). */
  private reset() {
    const { towns } = this.graph;
    this.lines = towns.map(() => null);
    this.inbox = towns.map(() => []);
    this.told = towns.map(() => []);
    this.held = towns.map(() => []);
    this.due = towns.map(() => Infinity);
    this.queue = new WakeQueue();
    this.start.forEach((c, town) => {
      const n = countsOf(c);
      if (n.incubating + n.infected > 0 || n.people <= 0 || this.placed[town].length) this.lineOf(town);
    });
  }

  /**
   * A copy to try anchors on: the same history so far (its store and memo copied), going its own way
   * from here; this one is left as it is.
   */
  fork(): Pond {
    const copy: Pond = Object.create(Pond.prototype);
    Object.assign(copy, this, {
      store: AnchorStore.fromJSON(this.store.toJSON()),
      lines: this.lines.map((line) => (line ? { state: cloneState(line.state), snaps: [...line.snaps], since: line.since } : null)),
      inbox: this.inbox.map((box) => [...box]),
      told: this.told.map((list) => [...list]),
      held: this.held.map((list) => [...list]),
      due: [...this.due],
      queue: this.queue.copy(),
      placed: this.placed.map((list) => [...list]),
      globals: null,
      strains: null,
      strainHit: { of: null, from: 0, to: 0, traits: null },
      lastStreets: null,
      lastMeasures: { level: null, length: 0, tick: NaN, at: null },
      stats: { ...this.stats },
    });
    return copy;
  }

  // -------------------------------------------------------------------------------------------
  // Placing

  /**
   * Places an anchor (forward only), drops what it could change, and seals it: its town's state
   * just before it (tick − 1), resolved now. Its id is `${kind}@${town}:${tick}` (#n for another
   * at the same).
   */
  place(input: { kind: string; town: number; tick: number; payload?: Payload }): Anchor {
    if (!rippleKind(input.kind) && !GLOBAL_KINDS.has(input.kind)) throw new Error(`anchors: no ripple "${input.kind}"`);
    if (input.town !== GLOBAL && !(input.town >= 0 && input.town < this.graph.towns.length)) throw new Error(`anchors: no town ${input.town}`);
    if (!(input.tick >= 0)) throw new Error(`anchors: tick ${input.tick}`);
    if (input.tick < this.store.now) throw new Error(`anchors: ${input.kind} at ${input.tick} is before ${this.store.now}`);
    let id = `${input.kind}@${input.town}:${input.tick}`;
    for (let n = 1;this.store.has(id);n++) id = `${input.kind}@${input.town}:${input.tick}#${n}`;
    if (input.town === GLOBAL) this.drop(input.tick);
    else this.rewind(input.town, input.tick);
    const anchor: Anchor = { id, kind: input.kind, town: input.town, tick: input.tick, payload: { ...(input.payload ?? {}) }, parents: [] };
    if (input.town !== GLOBAL) anchor.seal = digestOf(this.stateAt(input.town, input.tick - 1));
    this.store.add(anchor);
    if (input.town === GLOBAL) {
      this.globals = null;
      this.strains = null;
      this.lines.forEach((line, town) => line && this.wake(town));
    } else {
      const list = this.placed[input.town];
      let i = list.length;
      while (i > 0 && byTickId(list[i - 1], anchor) > 0) i--;
      list.splice(i, 0, anchor);
      this.lineOf(input.town);
      this.wake(input.town);
    }
    return anchor;
  }

  /**
   * Forgets what an anchor at `tick` could change (all of it with no tick): each town goes back to
   * before `tick` (a town's own anchor takes only its town back: place), from its last kept state
   * before then, and what it told from then on is held (rewind).
   */
  drop(tick = -Infinity) {
    if (tick === -Infinity) return this.reset();
    this.lines.forEach((line, t) => line && this.rewind(t, tick));
  }

  /**
   * Takes `town` back to before `tick`: nothing at or after it applied. What it told from then on is
   * held (told sooner, it'll tell the same again): told again the same it stands, else it's unsaid
   * (tell, settle). A town taken back to a kept state still has what it told since that state, so
   * taking it back again later (an arrival unsaid there) holds what it told from then on too.
   */
  private rewind(town: number, before: number) {
    const line = this.lines[town];
    if (!line) return;
    const told = this.told[town];
    if (line.state.tick >= before) {
      let k = line.snaps.length - 1;
      while (k > 0 && line.snaps[k].tick >= before) k--;
      line.snaps.length = k + 1;
      line.state = cloneState(line.snaps[k]);
      line.since = 0;
    } else if (!told.some((t) => t.at >= before)) return;
    // Held wherever it stands in the list (one told again the same goes back on at its end, out of order).
    const gone = told.filter((t) => t.at >= before);
    if (gone.length) {
      this.told[town] = told.filter((t) => t.at < before);
      const held = this.held[town];
      held.push(...gone);
      held.sort((a, b) => a.at - b.at);
    }
    this.wake(town);
  }

  /** Unsays a ripple told: out of the inbox it reached, and that town back to before it. */
  private unsay(gone: Told) {
    const to = gone.anchor.town;
    const box = this.inbox[to];
    const i = box.indexOf(gone.anchor);
    if (i >= 0) box.splice(i, 1);
    this.rewind(to, gone.anchor.tick);
    this.wake(to);
  }

  /** What `town` held, told at a tick before its next wake `next` and not told again: unsaid (it's gone past it). */
  private settle(town: number, next: number) {
    const held = this.held[town];
    if (!held.length || held[0].at >= next) return;
    let n = 0;
    while (n < held.length && held[n].at < next) n++;
    for (const gone of held.splice(0, n)) this.unsay(gone);
  }

  /** Whether every seal still holds (a store loaded elsewhere resolves the same). */
  verify(): string[] {
    const bad: string[] = [];
    for (const a of this.store.all()) if (a.seal !== undefined && digestOf(this.stateAt(a.town, a.tick - 1)) !== a.seal) bad.push(a.id);
    return bad;
  }

  // -------------------------------------------------------------------------------------------
  // Asking

  /** Town `town` at `tick`. */
  town(town: number, tick: number): TownView {
    const s = this.stateAt(town, tick);
    const c = countsOf(s.c);
    return {
      town,
      tick,
      people: c.people + s.x.im,
      susceptible: c.s,
      incubating: c.incubating,
      infected: c.infected,
      dead: c.dead,
      immune: s.x.im,
      got: s.x.got,
      born: s.x.born,
      aged: s.x.aged,
      walls: s.x.walls,
      sealed: s.x.sealed,
      level: lastOf(s.orders.level),
      border: lastOf(s.orders.border),
      cordon: lastOf(s.orders.cordon),
      burn: lastOf(s.orders.burn),
      closed: closedOf(s),
      fallen: s.fallen,
      empty: s.empty,
      story: s.story,
      // Hashed only if asked (most asking wants the counts).
      get digest() {
        return digestOf(s);
      },
    };
  }

  /** How many towns have been resolved at all (the cone's breadth so far). */
  resolved() {
    return this.lines.filter(Boolean).length;
  }

  /** What's kept: the live towns, their kept states, and the ripples told (the history's inputs; the bench's). */
  kept() {
    let states = 0;
    let told = 0;
    for (const line of this.lines) if (line) states += line.snaps.length + 1;
    for (const list of this.told) told += list.length;
    return { towns: this.resolved(), states, told };
  }

  /** How `town`'s people spread over its cells at `tick`: as the run began, or as last observed (observe's w<key>). */
  weightsOf(town: number, tick: number): [number, number][] {
    const placed = this.placedAt(town);
    let i = after(placed, tick) - 1;
    while (i >= 0 && placed[i].kind !== "observe") i--;
    const weights: [number, number][] = i >= 0 ? this.weights0[town].map(([key]) => [key, Number(placed[i].payload[`w${key}`] ?? 0)]) : this.weights0[town].map(([key, w]) => [key, w]);
    // Since: the cast who set off from a cell and came back to it.
    for (let j = i + 1;j < after(placed, tick);j++) {
      const a = placed[j];
      if (a.kind !== "leave" && a.kind !== "join") continue;
      const cell = weights.find(([key]) => key === a.payload.key);
      if (cell) cell[1] = Math.max(0, cell[1] + (a.kind === "join" ? 1 : -1));
    }
    return weights;
  }

  /**
   * `town`'s counts at `tick` spread over its cells, as a promotion makes them: each cell as many as
   * its weight (weightsOf), the dead first, then the bloomed from the last stage back, the
   * incubating likewise, the susceptible last, each share in proportion to the room a cell has
   * left (apportion). The same counts give the same cells.
   */
  cellsOf(town: number, tick: number): CellCounts[] {
    const c = this.stateAt(town, tick).c;
    const weights = this.weightsOf(town, tick);
    const total = countsOf(c).people + c.d;
    const room = apportion(total, weights.map(([, w]) => w));
    const cells: CellCounts[] = weights.map(([key]) => ({ key, s: 0, e: new Array<number>(STAGES).fill(0), i: new Array<number>(STAGES).fill(0), d: 0 }));
    const fill = (n: number, put: (cell: CellCounts, k: number) => void) => {
      const share = apportion(n, room);
      share.forEach((k, j) => {
        room[j] -= k;
        put(cells[j], k);
      });
    };
    fill(c.d, (cell, k) => (cell.d += k));
    for (let k = STAGES - 1;k >= 0;k--) fill(c.i[k], (cell, n) => (cell.i[k] += n));
    for (let k = STAGES - 1;k >= 0;k--) fill(c.e[k], (cell, n) => (cell.e[k] += n));
    fill(c.s, (cell, k) => (cell.s += k));
    return cells;
  }

  /** The towns `town` commutes to, and how many of its people go to each (as the run began). */
  flowsOf(town: number): readonly { to: number; n: number }[] {
    return this.flows[town];
  }

  /**
   * What `town` tells each neighbour of the commute at `tick` with `counts` for its people: the
   * full sim's town speaks for itself this way (placed as carry anchors), as the pond's would.
   */
  wordFrom(town: number, counts: Counts, tick: number): { to: number; word: Carry }[] {
    const state = this.stateAt(town, tick);
    state.c = { s: counts.s, e: [...counts.e], i: [...counts.i], d: counts.d };
    state.concrete = -1;
    const traits = this.traitsAt(tick);
    const words = this.carryTo(state, readAt(state, tick), traits);
    return [...this.flows[town].map(({ to }, k) => ({ to, word: words[k] })), ...this.homeWords(state, tick, traits)];
  }

  /** What the town tells those who come to work in it of its streets (their hazard at work: they bring it home). */
  private homeWords(state: TownState, tick: number, traits: Traits): { to: number; word: Carry }[] {
    const homes = this.homes[state.town];
    if (!homes.length) return [];
    const at = readAt(state, tick);
    const { away, total } = this.shares(state, at);
    const pw = this.streets(state, at, traits, away * total, true);
    return homes.map((to) => ({ to, word: { vp: 0, vr: 0, pw } }));
  }

  /** A town's walls as it stands now (its latest wake; 0 before it has one): asking runs nothing. */
  wallsOf(town: number): number {
    return this.lines[town]?.state.x.walls ?? 0;
  }

  /**
   * A town's carriers (incubating and bloomed) at `tick`: what town(town, tick) has, without the
   * copy. The living's own course (life) moves only the well and the immune, so where its latest
   * wake is at or before `tick` its counts are already the answer.
   */
  carriersAt(town: number, tick: number): number {
    this.runTo(tick);
    // Never woken (nothing placed there, nothing told it by `tick`) and quiet as it began (no carriers, no dead, the
    // commute's word of no contagion): nothing has passed it the strain, so none carry it, and it needn't be run to say so.
    if (!this.lines[town] && this.start[town].d <= 0) return 0;
    this.lineOf(town);
    this.runTo(tick);
    const line = this.lines[town]!;
    const c = line.state.tick <= tick ? line.state.c : this.stateAt(town, tick).c;
    const n = countsOf(c);
    return n.incubating + n.infected;
  }

  /**
   * A town's story as far as it has gone, at least to `tick` (not a copy: read, don't keep). Its
   * events at or before `tick` are town(town, tick).story's, without the copy or a replay: the
   * story is history, and a replay to `tick` tells the same events to `tick` as the line that went
   * on past it (the seed's draws). Those after `tick` are the caller's to leave out.
   */
  storyTo(town: number, tick: number): readonly TownEvent[] {
    this.lineOf(town);
    this.runTo(tick);
    return this.lines[town]!.state.story;
  }

  /** Everyone ever infected in a town by `tick` (town(town, tick).got), without the copy where its latest wake is at or before `tick`. */
  gotAt(town: number, tick: number): number {
    this.lineOf(town);
    this.runTo(tick);
    const line = this.lines[town]!;
    return line.state.tick <= tick ? line.state.x.got : this.stateAt(town, tick).x.got;
  }

  /** A town's state at `tick` (a copy: asking changes nothing but the memo). */
  stateAt(town: number, tick: number): TownState {
    this.lineOf(town);
    this.runTo(tick);
    const line = this.lines[town]!;
    let state: TownState;
    if (line.state.tick <= tick) {
      state = cloneState(line.state);
      state.tick = Math.max(state.tick, tick);
    } else {
      // Gone on past it: replayed from the kept state before it (its draws are the seed's).
      let k = line.snaps.length - 1;
      while (k > 0 && line.snaps[k].tick > tick) k--;
      state = cloneState(line.snaps[k]);
      this.advance(state, tick, false);
    }
    // The living's own course since its latest wake, as far as `tick` (drawn from that wake on: the same however it's asked).
    this.life(state, tick);
    return state;
  }

  // -------------------------------------------------------------------------------------------
  // Resolving

  /** Wakes every live town due by `tick`, in tick order (what it tells is queued at the town it reaches). */
  private runTo(tick: number) {
    while (this.queue.peek() <= tick) {
      const at = this.queue.peek();
      const town = this.queue.pop();
      if (this.due[town] !== at) continue;
      this.due[town] = Infinity;
      const line = this.lines[town]!;
      // Kept as it stands by `now` too: nothing's placed before it, so no rewind goes back further.
      const now = this.store.now;
      if (at > now && line.state.tick <= now && line.snaps[line.snaps.length - 1].tick < line.state.tick) this.snap(line);
      const arrival = this.advance(line.state, at, true);
      // Every so many wakes, or (a town that wakes seldom) a day on, if it's woken a few times since.
      const span = this.keep.span ?? Infinity;
      if (++line.since >= this.keep.every || (line.since * 8 >= this.keep.every && line.state.tick - line.snaps[line.snaps.length - 1].tick >= span)) this.snap(line);
      this.wake(town, arrival);
    }
  }

  private snap(line: Line) {
    line.snaps.push(cloneState(line.state));
    line.since = 0;
    if (line.snaps.length > this.keep.most) thin(line.snaps, this.keep.latest, this.store.now);
  }

  /** Queues `town`'s next wake (what arrives, or its pending change), if it's moved. */
  private wake(town: number, arrival?: number) {
    const line = this.lines[town];
    if (!line) return;
    const at = Math.min(arrival ?? this.nextArrival(line.state), line.state.pending.end);
    this.settle(town, at);
    if (at === this.due[town]) return;
    this.due[town] = at;
    if (at < Infinity) this.queue.push(at, town);
  }

  /** `town`'s course, made live (as it began) if it wasn't. */
  private lineOf(town: number): Line {
    let line = this.lines[town];
    if (!line) {
      const c = this.start[town];
      const state: TownState = {
        town,
        tick: -1,
        c: { s: c.s, e: [...c.e], i: [...c.i], d: c.d },
        pending: { kind: Next.None, start: -1, end: Infinity, index: -1, h: 0 },
        draws: 0,
        carried: new Map(this.baseline[town]),
        sent: new Map([...this.flows[town].map(({ to, n }): [number, Carry] => [to, { vp: n, vr: 0, pw: 0 }]), ...this.homes[town].map((to): [number, Carry] => [to, { vp: 0, vr: 0, pw: 0 }])]),
        orders: { level: [], border: [], cordon: [], burn: [] },
        heard: new Map(),
        fallen: -1,
        empty: -1,
        asked: 0,
        warned: false,
        people0: this.n0[town],
        concrete: -1,
        story: [],
        x: freshExtra(),
      };
      line = { state, snaps: [cloneState(state)], since: 0 };
      this.lines[town] = line;
      this.wake(town);
    }
    return line;
  }

  private traitsAt(tick: number): Traits {
    if (!this.strains) {
      this.globals ??= this.store.global();
      this.strains = [];
      let traits = this.base;
      const changes = [...(this.config.course ?? []), ...this.globals.filter((a) => a.kind === "strain").map((a) => ({ tick: a.tick, payload: a.payload as Partial<Traits> }))];
      // In tick order, the course before an anchor on the same tick (a stable sort).
      changes.sort((a, b) => a.tick - b.tick);
      for (const c of changes) this.strains.push({ tick: c.tick, traits: (traits = { ...traits, ...c.payload }) });
    }
    // Asked of the same stretch again and again: the last one found, while the strains stand.
    const hit = this.strainHit;
    if (hit.of === this.strains && tick >= hit.from && tick < hit.to) return hit.traits!;
    let traits = this.base;
    let from = -Infinity;
    let to = Infinity;
    for (const s of this.strains) {
      if (s.tick > tick) {
        to = s.tick;
        break;
      }
      traits = s.traits;
      from = s.tick;
    }
    this.strainHit = { of: this.strains, from, to, traits };
    return traits;
  }

  /** The town's measures at `tick` (asked of the same orders again and again within a wake). */
  private measures(state: TownState, tick: number) {
    const m = this.lastMeasures;
    const level = state.orders.level;
    if (m.level !== level || m.length !== level.length || m.tick !== tick) {
      m.level = level;
      m.length = level.length;
      m.tick = tick;
      m.at = measuresOf(level, tick);
    }
    return m.at!;
  }

  /** Whether the towns' own doings go on at `tick`: as the latest `rules` anchor by then says, else as configured. */
  private rulesAt(tick: number) {
    let on = tick < this.rules;
    this.globals ??= this.store.global();
    for (const a of this.globals) {
      if (a.tick > tick) break;
      if (a.kind === "rules") on = a.payload.on === true;
    }
    return on;
  }

  /** The next thing to arrive at `state`'s town after its tick: placed, told, the shift, the strain. */
  private nextArrival(state: TownState) {
    // The shift only matters where there's contagion about: elsewhere quiet time costs nothing.
    let at = this.contagious(state) ? nextRead(state, state.tick) : Infinity;
    if (state.tick < 0) at = 0;
    this.globals ??= this.store.global();
    for (const a of this.globals) if (a.tick > state.tick) {
      at = Math.min(at, a.tick);
      break;
    }
    const placed = this.placedAt(state.town);
    const p = after(placed, state.tick);
    if (p < placed.length) at = Math.min(at, placed[p].tick);
    const box = this.inbox[state.town];
    const b = after(box, state.tick);
    if (b < box.length) at = Math.min(at, box[b].tick);
    // Its infected move on no sooner than this (roamNext), so where something comes first there's no asking where.
    if (Math.max(state.tick + 1, state.x.roamAt) < at && this.roam && infectedOf(state.c) > 0 && this.rulesAt(state.tick)) at = Math.min(at, roamNext(state, this.graph, this.n0));
    return at;
  }

  /** Whether anything in or coming into the town passes the strain on (so its hazard turns with the shift). */
  private contagious(state: TownState) {
    // An emptied town is a dead end: nobody comes or goes, and what's left of it goes on by its own changes.
    if (state.concrete >= 0 || state.empty >= 0) return false;
    const c = state.c;
    // With none well here and no visitors, there's nobody for the shift to matter to.
    if (c.s <= 0) {
      let visited = false;
      for (const word of state.carried.values()) if (word.vp > 0) visited = true;
      if (!visited) return false;
    }
    for (let k = 0;k < STAGES;k++) if (c.e[k] > 0 || c.i[k] > 0) return true;
    if (c.d > 0 && this.contagion(c, this.traitsAt(state.tick)).corpses > 0) return true;
    for (const word of state.carried.values()) if (word.vr > 0 || word.pw > 0) return true;
    return false;
  }

  /** The anchors placed at a town, in order. */
  private placedAt(town: number): readonly Anchor[] {
    return this.placed[town];
  }

  /** Every arrival at `town` on `tick`, in contract order. */
  private arriving(town: number, tick: number) {
    const out: Anchor[] = [];
    for (const list of [this.placedAt(town), this.inbox[town]]) for (let i = after(list, tick - 0.5);i < list.length && list[i].tick === tick;i++) out.push(list[i]);
    return out.sort(byTickId);
  }

  /**
   * Plays `state` on to `to`: its pending leap if it ends first, else what arrives (cutting the
   * leap short: its share of its span happens), then a fresh leap.
   * `record`: tell what it sets off (the memo's own course; a replay of an earlier tick has told it).
   */
  /** Runs `state` on to `to`; its next arrival after (as nextArrival would find it there). */
  private advance(state: TownState, to: number, record: boolean): number {
    while (true) {
      const arrival = this.nextArrival(state);
      const end = state.pending.end;
      // Nothing comes before `to`, so moving its tick up to `to` doesn't move the next arrival.
      if (Math.min(arrival, end) > to) {
        state.tick = Math.max(state.tick, to);
        return arrival;
      }
      this.stats.wakes++;
      this.life(state, Math.min(arrival, end));
      if (end <= arrival) {
        this.applyPending(state, end, end);
        state.tick = end;
        this.after(state, end, record);
        this.schedule(state, end);
        // What arrives on the same tick is still to come (the next arrival is looked for after it).
        if (end < arrival) continue;
      }
      if (state.pending.kind === Next.Leap) this.applyPending(state, arrival, state.pending.end);
      state.pending = { kind: Next.None, start: arrival, end: Infinity, index: -1, h: 0 };
      const come = this.arriving(state.town, arrival);
      const ctx: RippleContext | null = come.length ? { graph: this.graph, seed: this.seed, tick: arrival, traits: this.traitsAt(arrival), people0: this.n0, roam: this.roam } : null;
      for (const a of come) {
        this.stats.arrivals++;
        const spawns = rippleKind(a.kind)?.cold(state, a, ctx!) ?? [];
        if (record) this.tell(state, a.id, spawns, arrival);
      }
      state.tick = arrival;
      this.after(state, arrival, record);
      this.schedule(state, arrival);
    }
  }

  /** What the town does of itself (its rules), and what it tells its neighbours of the commute, once its counts or standing have moved. */
  private after(state: TownState, tick: number, record: boolean) {
    // The full sim's town says what it does itself (wordFrom, placed as carry anchors).
    if (state.concrete >= 0) return;
    const ctx: RippleContext = { graph: this.graph, seed: this.seed, tick, traits: this.traitsAt(tick), people0: this.n0, roam: this.roam };
    if (this.rulesAt(tick))
      for (const rule of townRules()) {
        const spawns = rule.cold(state, ctx);
        if (record && spawns?.length) this.tell(state, `${rule.kind}@${state.town}:${tick}`, spawns, tick);
      }
    const spawns: Spawn[] = [];
    const send = (to: number, word: Carry) => {
      if (!carryChanged(word, state.sent.get(to)!)) return;
      const r = reach(state, to, tick, STEP);
      if (r.strength <= 0 && word.vp + word.vr + word.pw > 0) return;
      state.sent.set(to, word);
      spawns.push({ kind: "carry", town: to, tick: r.tick, payload: { from: state.town, ...word } });
    };
    const flows = this.flows[state.town];
    const homes = this.homes[state.town];
    if (flows.length || homes.length) {
      // What it tells those it sends to work and those who come to it share its streets (asked once).
      const at = readAt(state, tick);
      const shares = this.shares(state, at);
      const pw = this.streets(state, at, ctx.traits, shares.away * shares.total, true);
      this.lastStreets = { state, at, traits: ctx.traits, shares, pw };
      if (flows.length) {
        const words = this.carryTo(state, at, ctx.traits, shares, pw);
        for (let k = 0;k < flows.length;k++) send(flows[k].to, words[k]);
      }
      for (const to of homes) send(to, { vp: 0, vr: 0, pw });
    }
    if (record && spawns.length) this.tell(state, `carry@${state.town}:${tick}`, spawns, tick);
  }

  /** Puts what an anchor or a rule set off into the towns it reaches, with causal ids. */
  private tell(state: TownState, parent: string, spawns: Spawn[], at: number) {
    spawns.forEach((s, index) => {
      const kind = rippleKind(s.kind);
      if (!kind) throw new Error(`anchors: no ripple "${s.kind}"`);
      if (s.town !== state.town && !this.graph.towns[state.town].neighbours.includes(s.town)) throw new Error(`anchors: ${s.kind} from ${state.town} to ${s.town}, not a neighbour`);
      if (s.tick < at + STEP) throw new Error(`anchors: ${s.kind} at ${s.tick} is sooner than a step after ${at}`);
      const anchor: Anchor = { id: `${parent}>${s.kind}@${s.town}#${index}`, kind: s.kind, town: s.town, tick: s.tick, payload: s.payload, parents: [parent] };
      const box = this.inbox[s.town];
      // Held (told before the town was taken back): told the same, it stands; otherwise it's unsaid.
      const held = this.held[state.town];
      const h = held.findIndex((x) => x.anchor.id === anchor.id);
      if (h >= 0) {
        const [was] = held.splice(h, 1);
        if (was.anchor.tick === anchor.tick && samePayload(was.anchor.payload, anchor.payload)) {
          this.told[state.town].push(was);
          return;
        }
        this.unsay(was);
      }
      // Told already (a town replayed from a kept state tells the same again).
      for (let j = after(box, anchor.tick - 0.5);j < box.length && box[j].tick === anchor.tick;j++) if (box[j].id === anchor.id) return;
      // Reaching a town resolved past it: that town goes back to before it.
      if (this.lineOf(s.town).state.tick >= anchor.tick) this.rewind(s.town, anchor.tick);
      let i = box.length;
      while (i > 0 && byTickId(box[i - 1], anchor) > 0) i--;
      box.splice(i, 0, anchor);
      this.told[state.town].push({ from: state.town, at, anchor });
      this.stats.told++;
      this.wake(s.town);
    });
  }

  // -------------------------------------------------------------------------------------------
  // The town's rates (the cold tier's model, one town well mixed)

  /** Commuters to each neighbour, as a share of the town's living (closures thin them), and the share away now. */
  private shares(state: TownState, tick: number) {
    const m = this.measures(state, tick);
    const n0 = Math.max(1, state.people0);
    let total = 0;
    const list = this.flows[state.town].map(({ to, n }) => {
      const share = (n * strengthTo(state, to)) / n0;
      total += share;
      return { to, share };
    });
    const scale = total > 1 ? 1 / total : 1;
    for (const l of list) l.share = l.share * scale;
    return { list, away: 1 - m.lockdown, total: Math.min(1, total), masks: m.masks };
  }

  private contagion(c: Counts, traits: Traits) {
    const { rE, rI, rD } = effectsOf(traits).rates;
    let living = 0;
    for (let k = 0;k < STAGES;k++) living += c.e[k] * rE + c.i[k] * rI;
    return { living, corpses: c.d * rD };
  }

  /** The hazard on the town's streets (per dose), with its commuters away (`gone` of the living) and its neighbours' in (at work). */
  private streets(state: TownState, tick: number, traits: Traits, gone: number, visitors: boolean) {
    const r = this.contagion(state.c, traits);
    let people = livingOf(state.c) * (1 - gone) + state.c.d;
    let rate = r.living * (1 - gone) + r.corpses;
    if (visitors)
      for (const word of state.carried.values()) {
        people += word.vp;
        rate += word.vr;
      }
    const masks = this.measures(state, tick).masks;
    const fx = effectsOf(traits);
    const scale = fx.infectivity * this.weather(state.town, tick, traits) * (1 - RESPONSE.maskEmit * masks) * (1 - RESPONSE.maskIntake * masks);
    return coldPressure(rate, people, fx, scale) / fx.dose;
  }

  /** What the town tells each neighbour it commutes with of the commute (as at work hours), in flows' order. */
  private carryTo(state: TownState, tick: number, traits: Traits, shares = this.shares(state, tick), pw = this.streets(state, tick, traits, shares.away * shares.total, true)): Carry[] {
    const { list, away } = shares;
    const people = livingOf(state.c);
    const r = this.contagion(state.c, traits);
    return list.map(({ share }) => ({ vp: people * away * share, vr: r.living * away * share, pw }));
  }

  /** The hazard on each of the town's susceptible now: at home, and with whoever is at work over the border. */
  private hazard(state: TownState, tick: number, traits: Traits) {
    if (!working(tick)) return this.streets(state, tick, traits, 0, false);
    // As the town's commute words just found them (after, on the same tick), or asked afresh.
    const last = this.lastStreets;
    this.lastStreets = null;
    const same = last !== null && last.state === state && last.at === tick && last.traits === traits;
    const { list, away, total } = same ? last.shares : this.shares(state, tick);
    let h = (1 - away * total) * (same ? last.pw : this.streets(state, tick, traits, away * total, true));
    for (const { to, share } of list) h += away * share * (state.carried.get(to)?.pw ?? 0);
    return h;
  }

  /** How wild the land about a town is: its homes (the living and the dead) a cell, as the cold step reads a cell's (traits/effects.ts wildOf). */
  private wildAt(state: TownState, people = livingOf(state.c)) {
    return wildOf((people + state.c.d) / Math.max(1, this.graph.towns[state.town].cells.length));
  }

  /** Young a second each of the town's bloomed has (breedOf: its wilds, and the share of its homes the dead's). */
  private bredAt(state: TownState, fx: TraitEffects, wild?: number, people?: number) {
    if (!(fx.breed > 0) || state.c.d <= 0) return 0;
    return breedOf(fx, wild ?? this.wildAt(state), state.c.d / ((people ?? livingOf(state.c)) + state.c.d));
  }

  /**
   * The town's next leap from its rates now: to the end of its piece of the day, or sooner where its
   * contagion would move by more than LEAP_SHARE over it (the infected coming, the incubating
   * blooming, the bloomed dying) or its susceptible be used up by more than that.
   */
  private schedule(state: TownState, tick: number) {
    const traits = this.traitsAt(tick);
    const fx = effectsOf(traits);
    const c = state.c;
    // The town's counts, summed once for all that reads them here.
    const counts = countsOf(c);
    const more = besides(c, fx, state.x.walls, counts);
    const h = this.hazard(state, readAt(state, tick), traits) + more.all;
    const incubate = STAGES / fx.incubation;
    const wild = this.wildAt(state, counts.people);
    const life = lifeRateOf(fx, STAGES, preyOf(c, counts.people), wild, risenShare(fx, more.bites, h, more.kills), bodiesOf(counts.dead, counts.infected));
    const bred = this.bredAt(state, fx, wild, counts.people);
    if (!(c.s * h > 0 || counts.incubating > 0 || (counts.infected > 0 && (life > 0 || bred > 0))) || state.concrete >= 0) {
      state.pending = { kind: Next.None, start: tick, end: Infinity, index: -1, h };
      return;
    }
    const { rE, rI, rD } = fx.rates;
    const r = this.contagion(c, traits);
    // The newly infected count at the most they'll pass on over it (an incubation quick to bloom blooms within the leap).
    const flux = c.s * h * Math.max(rE, rI) + c.e[STAGES - 1] * incubate * Math.abs(rI - rE) + c.i[STAGES - 1] * life * Math.abs(rI - rD);
    // The well's own chance a leap (none left, nothing for it to bound).
    let span = h > 0 && c.s > 0 ? LEAP_SHARE / h : Infinity;
    if (flux > 0) span = Math.min(span, (LEAP_SHARE * Math.max(r.living + r.corpses, rE, rI)) / flux);
    // The bloomed's young: their numbers grow by no more than LEAP_SHARE over it.
    if (bred > 0 && counts.infected > 0) span = Math.min(span, LEAP_SHARE / bred);
    // With nothing to bound it (none yet in the last stage), a leap goes a stage at most.
    if (span === Infinity) span = Math.min(counts.incubating > 0 ? 1 / incubate : Infinity, counts.infected > 0 && life > 0 ? 1 / life : Infinity);
    // The day's pieces matter only to the well (their hazard turns with them): a town with none goes on in leaps as long as its carriers allow.
    const end = Math.min(c.s > 0 ? nextRead(state, tick) : Infinity, Math.max(tick + 1, Math.ceil(tick + span * TICK_RATE)));
    state.pending = { kind: Next.Leap, start: tick, end, index: state.draws++, h, ...(more.bites > 0 ? { hb: more.bites, hk: more.kills } : {}) };
  }

  private keyOf(town: number) {
    return hash(town, 0x9e37);
  }

  /**
   * The living's own course (births, deaths of age) from the town's last bringing up to `tick`,
   * drawn from then: at each wake (the town's own), and on a copy asked between (stateAt).
   */
  private life(state: TownState, tick: number) {
    const rates = this.lifeRates;
    const x = state.x;
    if (!rates || state.concrete >= 0 || tick <= x.lifeAt) {
      if (!rates) x.lifeAt = Math.max(x.lifeAt, tick);
      return;
    }
    const years = (tick - x.lifeAt) / YEAR_TICKS;
    const key = this.keyOf(state.town);
    const living = state.c.s + x.im;
    const born = binomial(living, within(rates.births, years), this.seed, key, x.lifeAt, Purpose.Born);
    const aged = binomial(state.c.s, within(rates.deaths, years), this.seed, key, x.lifeAt, Purpose.Aged);
    state.c.s += born - aged;
    x.born += born;
    x.aged += aged;
    x.lifeAt = tick;
  }

  /** The traits at `tick` (the base, as strain anchors since have moved them). */
  traits(tick: number): Traits {
    return this.traitsAt(tick);
  }

  /** The living's own course (births, deaths of age a year), or null if off. */
  get lifeOf() {
    return this.lifeRates;
  }

  /** The seed every draw is keyed on. */
  get seedOf() {
    return this.seed;
  }

  /** Applies the town's pending leap as of `at` (cut short at `at` of its span to `end`). */
  private applyPending(state: TownState, at: number, _end: number) {
    const p = state.pending;
    if (p.kind === Next.None) return;
    const dt = (at - p.start) / TICK_RATE;
    if (dt <= 0) return;
    this.stats.leaps++;
    const fx = effectsOf(this.traitsAt(p.start));
    const c = state.c;
    const incubate = STAGES / fx.incubation;
    const people = livingOf(c);
    const wild = this.wildAt(state, people);
    const life = lifeRateOf(fx, STAGES, preyOf(c, people), wild, risenShare(fx, p.hb ?? 0, p.h, p.hk ?? fx.kills), bodiesOf(c.d, infectedOf(c)));
    const bred = this.bredAt(state, fx, wild, people);
    let bloomed = 0;
    for (let k = 0;k < STAGES;k++) bloomed += c.i[k];
    const key = this.keyOf(state.town);
    const u = (k: number) => unitOf(this.seed, key, p.index, Purpose.Chain + k);
    let infected = binomial(c.s, within(p.h, dt), this.seed, key, p.index, Purpose.Infect);
    // Of them, the bitten (their share of the hazard), and of those a raging bite kills: dead, or risen bloomed.
    const kills = p.hk ?? fx.kills;
    const killed = p.hb && kills > 0 && infected > 0 ? binomial(binomial(infected, p.hb / p.h, this.seed, key, p.index, Purpose.Bitten), kills, this.seed, key, p.index, Purpose.Killed) : 0;
    const risen = fx.rises > 0 ? killed : 0;
    c.s -= killed;
    state.x.got += risen;
    infected -= killed;
    for (let k = 0;k < STAGES;k++) {
      cohorts[k] = c.e[k];
      cohorts[STAGES + k] = c.i[k];
    }
    const moved = chain(cohorts, dt, incubate, life, u, movedScratch);
    // The newly infected, infected on average halfway through, go on for the half left.
    if (infected > 0) {
      cohorts.fill(0);
      cohorts[0] = infected;
      chain(cohorts, dt / 2, incubate, life, (k) => u(LAST + k), freshScratch);
      for (let j = 0;j <= LAST;j++) moved[j] += freshScratch[j];
    }
    c.s -= infected;
    state.x.got += infected;
    for (let k = 0;k < STAGES;k++) {
      c.e[k] = moved[k];
      c.i[k] = moved[STAGES + k];
    }
    c.d += moved[LAST] + killed - risen;
    c.i[0] += risen;
    // The bloomed's young (as many as the leap began with have them), born bloomed into the dead's homes.
    const born = bred > 0 && bloomed > 0 ? Math.min(c.d, binomial(bloomed, within(bred, dt), this.seed, key, p.index, Purpose.Bred)) : 0;
    c.d -= born;
    c.i[0] += born;
    state.x.got += born;
  }
}

export { Heard };
