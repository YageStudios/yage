/**
 * The world's systems beyond the strain's spread (ripples.ts has the spread, the orders, the falls
 * and parties on the road): what a story is made of over months and years, each with its cold
 * resolver (tier parity: none needs a town simulated closely to happen).
 *
 * - Walls and seals: a town fortified holds out its infected and its fighters count for more; a town
 *   sealed (a blockade, a quarantine's edge) lets nobody in or out, people, parties or hordes, bar a party bound for it (let in at its gate).
 * - Tides: a town reachable only at low water (an island's causeway): whatever comes waits for it.
 * - Hordes: where a town's infected outnumber its living they move on, a share at a time, to the
 *   neighbour whose people draw them (the biggest they haven't heard is emptied); walls fight them.
 * - The living's own course (births, age), the immune (vaccinated, cured), resettlers brought in,
 *   the evacuated taken out, famine, a sweep of soldiers through the infected.
 * - Cast fates and arrivals: a cast person born, landed, or dead of something not the strain.
 * - People against their own: a riot against a town's orders, a garrison's mutiny, a cast person
 *   sold out to raiders, a broadcast that draws the neighbours' well in.
 *
 * Staged ripples (the solver's `stage` levers) are the ones a story puts in: a feature of the world
 * the run didn't come to by itself (a wall built, a boat landing, a baby). Each is a placed anchor,
 * so the history is still the seed's and the anchors'.
 */
import { binomial, unitOf } from "../domain/cold/draws";
import { STAGES } from "../domain/cold/step";
import { DAY_SECONDS } from "../domain/time";
import { TICK_RATE } from "../domain/world";
import type { TownGraph } from "./graph";
import {
  closedOf,
  countsOf,
  FIGHTERS,
  FLIGHT_DELAY,
  GOVERNOR_AT,
  lastOf,
  ORDER_DELAY,
  Heard,
  keyOf,
  killInfected,
  notices,
  registerRipple,
  rollFight,
  say,
  type Spawn,
  type TownRule,
  type TownState,
  travelTicks,
  waitTide,
  WALLS,
  reach,
  registerRule,
} from "./ripples";
import { STEP } from "./types";
import { effectsOf } from "../traits";

const DAY_TICKS = DAY_SECONDS * TICK_RATE;

/** The living susceptible: up to `n` taken, how many. */
const take = (state: TownState, n: number) => {
  const k = Math.max(0, Math.min(state.c.s, Math.floor(n)));
  state.c.s -= k;
  return k;
};

registerRipple({
  kind: "fortify",
  about: "a town walled (walls 0 … 1): fewer get in or out, hordes are fought at its walls, its fighters count for more",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const walls = Math.max(0, Math.min(1, Number(anchor.payload.walls ?? 1)));
    if (walls === state.x.walls) return;
    state.x.walls = walls;
    say(state, ctx.tick, "fortified", anchor.id, { walls });
  },
});

registerRipple({
  kind: "seal",
  about: "a town sealed tight (a blockade, a quarantine's edge): nobody in or out, people, parties or hordes, bar a party bound for it (on: false opens it)",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const on = anchor.payload.on !== false;
    if (on === state.x.sealed) return;
    state.x.sealed = on;
    say(state, ctx.tick, on ? "sealed" : "unsealed", anchor.id);
    return notices(state, ctx);
  },
});

registerRipple({
  kind: "tide",
  about: "a town reachable only at low water: open `open` ticks of every `period`, from `phase`",
  delay: STEP,
  cold: (state, anchor) => {
    const p = anchor.payload;
    state.x.tide = [Math.max(1, Number(p.period)), Math.max(1, Number(p.open)), Number(p.phase ?? 0)];
  },
});

registerRipple({
  kind: "resettle",
  about: "people brought in from outside (a reconstruction, a boat of survivors): n of them, well",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const n = Math.max(0, Math.floor(Number(anchor.payload.n ?? 0)));
    state.c.s += n;
    say(state, ctx.tick, "resettled", anchor.id, { n });
  },
});

registerRipple({
  kind: "evacuate",
  about: "a share of a town's well taken out of it (and off the map): a rescue, an airlift",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const well = state.c.s;
    const n = take(state, state.c.s * Math.min(1, Number(anchor.payload.share ?? 1)));
    say(state, ctx.tick, "evacuated", anchor.id, { n, well });
  },
});

registerRipple({
  kind: "famine",
  about: "a town's food runs out: a share of its well die of it (not of the strain)",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const died = binomial(state.c.s, Math.min(1, Number(anchor.payload.share ?? 0.2)), ctx.seed, keyOf(anchor.id), ctx.tick, 0x60);
    const well = state.c.s;
    state.c.s -= died;
    state.x.aged += died;
    say(state, ctx.tick, "famine", anchor.id, { died, well });
  },
});

registerRipple({
  kind: "sweep",
  about: "soldiers through a town's infected (n of them, as able and armed as given), rolled as a fight: won, they hunt down every bloomed one",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const p = anchor.payload;
    const infected = countsOf(state.c).infected;
    const soldiers = Math.max(1, Number(p.n ?? 50));
    const fight = rollFight(ctx.seed, keyOf(anchor.id), ctx.tick, { n: soldiers, skill: Number(p.skill ?? 2), gear: Number(p.gear ?? 2) }, { n: infected, ...effectsOf(ctx.traits).fight });
    // Won, they go on through the streets and hunt down the rest of the bloomed (the bitten they can't tell yet).
    const cleared = killInfected(state.c, fight.winner === "a" ? infected : fight.lossB);
    say(state, ctx.tick, "sweep", anchor.id, { soldiers, lost: fight.lossA, cleared, winner: fight.winner });
  },
});

registerRipple({
  kind: "vaccinate",
  about: "a share of a town's well made immune (a vaccine)",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const well = state.c.s;
    const n = take(state, state.c.s * Math.min(1, Number(anchor.payload.share ?? 1)));
    state.x.im += n;
    say(state, ctx.tick, "vaccinated", anchor.id, { n, well });
  },
});

registerRipple({
  kind: "treat",
  about: "a share of a town's carriers cured (incubating and bloomed alike): immune from then",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    // What takes of it: the strain's resistance, its evasion of the tests, the cure it knocked back.
    const share = Math.min(1, Number(anchor.payload.share ?? 1)) * effectsOf(ctx.traits).cure;
    let n = 0;
    for (let k = 0;k < STAGES;k++) {
      const e = Math.round(state.c.e[k] * share);
      const i = Math.round(state.c.i[k] * share);
      state.c.e[k] -= e;
      state.c.i[k] -= i;
      n += e + i;
    }
    state.x.im += n;
    say(state, ctx.tick, "cured", anchor.id, { n });
  },
});

registerRipple({
  kind: "appear",
  about: "a cast person comes into the world at a town: born there, or landed there (cause), immune if so",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const p = anchor.payload;
    if (p.immune) state.x.im++;
    else state.c.s++;
    if (p.cause === "born") state.x.born++;
    say(state, ctx.tick, String(p.cause ?? "born") === "born" ? "born" : "landed", anchor.id, { gid: Number(p.gid ?? -1), ...(p.mother !== undefined ? { mother: p.mother } : {}) });
  },
});

registerRipple({
  kind: "fate",
  about: "a cast person's end of something not the strain where they are (illness, age, an accident, a rescue off the map: cause)",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const p = anchor.payload;
    const cause = String(p.cause ?? "illness");
    if (cause === "rescued") return void say(state, ctx.tick, "rescued", anchor.id, { gid: Number(p.gid) });
    if (state.c.s > 0) {
      state.c.s--;
      state.x.aged++;
    }
    say(state, ctx.tick, "cast-died", anchor.id, { gid: Number(p.gid), cause });
  },
});

registerRipple({
  kind: "bite",
  about: "a cast person bitten where they are (by one of its infected, or one met on the way): they turn there",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    if (state.c.s > 0) {
      state.c.s--;
      state.c.e[0]++;
      state.x.got++;
    }
    say(state, ctx.tick, "cast-turned", anchor.id, { gid: Number(anchor.payload.gid) });
  },
});

registerRipple({
  kind: "capture",
  about: "a cast person seized where they are (by `by`, if named) to be held at `to` (the directive laid with it walks them there): told, nothing else changes",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const p = anchor.payload;
    say(state, ctx.tick, "cast-captured", anchor.id, { gid: Number(p.gid), to: Number(p.to ?? state.town), ...(p.by ? { by: String(p.by) } : {}) });
  },
});

registerRipple({
  kind: "free",
  about: "a captive cast person let go where they're held (by `by`, if named): told; the strain can reach them again",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const p = anchor.payload;
    say(state, ctx.tick, "cast-freed", anchor.id, { gid: Number(p.gid), ...(p.by ? { by: String(p.by) } : {}) });
  },
});

registerRipple({
  kind: "mutate",
  about: "a cast person made a super mutant where they are (a mad scientist's captive): bloomed there, the kind `kind` (the live run's made record, domain/mutants.ts madeOf)",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    if (state.c.s > 0) {
      state.c.s--;
      state.c.i[0]++;
      state.x.got++;
    }
    say(state, ctx.tick, "cast-made", anchor.id, { gid: Number(anchor.payload.gid), kind: String(anchor.payload.kind ?? "") });
  },
});

// ---------------------------------------------------------------------------------------------
// Hordes

/** Where a town's infected move on: at least `min` of them, outnumbering the living `prey` to one; `share` a time, every `every`, `pace` times a walker's speed. */
export const ROAM = { min: 8, prey: 1, share: 0.3, every: DAY_TICKS / 2, pace: 2 };

/** A horde's counts by stage, from a payload's i0…. */
const hordeOf = (p: Record<string, unknown>) => Array.from({ length: STAGES }, (_, k) => Math.max(0, Math.floor(Number(p[`i${k}`] ?? 0))));

/** Sends a share of `state`'s bloomed to `to` as a horde (the spawn, or nothing if none go). */
const sendHorde = (state: TownState, graph: TownGraph, to: number, tick: number, share: number): Spawn[] => {
  // Hordes go over closures (it's people they keep out); out of a sealed town, none. Set on a sealed one (roaming, they pass it by: roamTarget), they're held or fought at its walls.
  if (state.x.sealed) return [];
  const thin = share * (1 - WALLS.hold * state.x.walls);
  const payload: Record<string, number> = { from: state.town };
  let n = 0;
  for (let k = 0;k < STAGES;k++) {
    const go = Math.floor(state.c.i[k] * thin);
    state.c.i[k] -= go;
    payload[`i${k}`] = go;
    n += go;
  }
  if (!n) return [];
  payload.n = n;
  return marchOn(state, graph, to, tick, payload);
};

/** A horde's next town on its way to `to` (a neighbour, or the first of the road there: `dest` kept for it to march on). */
const marchOn = (state: TownState, graph: TownGraph, to: number, tick: number, payload: Record<string, number>): Spawn[] => {
  const next = graph.towns[state.town].neighbours.includes(to) ? to : graph.path(state.town, to)?.[1];
  if (next === undefined) return [];
  const out = next === to ? payload : { ...payload, dest: to };
  if (next === to) delete out.dest;
  return [{ kind: "horde", town: next, tick: reach(state, next, tick, travelTicks(graph, state.town, next) / ROAM.pace, "travel").tick, payload: out }];
};

registerRipple({
  kind: "horde",
  about: "a horde of infected reaching a town: in, unless its walls and fighters beat them off, or it's sealed (walled, it fights them at its walls first)",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const wait = waitTide(state, anchor, ctx.tick);
    if (wait) return wait;
    const i = hordeOf(anchor.payload);
    const n = i.reduce((a, b) => a + b, 0);
    if (!n) return;
    // On its way somewhere further: through, by the road (a walled town's gates shut on it, and it goes round).
    const dest = anchor.payload.dest;
    if (typeof dest === "number" && dest !== state.town) {
      say(state, ctx.tick, "horde-passed", anchor.id, { n, from: Number(anchor.payload.from), to: dest });
      return marchOn(state, ctx.graph, dest, ctx.tick, { ...(anchor.payload as Record<string, number>), from: state.town });
    }
    let enter = n;
    const well = state.c.s;
    const defenders = Math.floor(state.c.s * FIGHTERS);
    // Sealed and unwalled, its gates keep them out; sealed and walled, it fights them at its walls, and (beaten there) still keeps them out.
    if (state.x.sealed && !(state.x.walls > 0 && defenders > 0)) return void say(state, ctx.tick, "horde-held", anchor.id, { n, from: Number(anchor.payload.from) });
    if (state.x.walls > 0 && defenders > 0) {
      const fight = rollFight(ctx.seed, keyOf(anchor.id), ctx.tick, { n, ...effectsOf(ctx.traits).fight }, { n: defenders, skill: 1 + WALLS.defend * state.x.walls, gear: 1 });
      // Those the horde brings down at the walls: killed, or (as the walls are weak) bitten and turned.
      const lost = take(state, fight.lossB);
      const turned = Math.round(lost * (1 - state.x.walls));
      state.c.e[0] += turned;
      state.x.got += turned;
      state.c.d += lost - turned;
      const told = { n, from: Number(anchor.payload.from), killed: fight.lossA, lost, turned, well };
      if (fight.winner === "b") return void say(state, ctx.tick, "horde-repelled", anchor.id, told);
      if (state.x.sealed) return void say(state, ctx.tick, "horde-held", anchor.id, told);
      say(state, ctx.tick, "horde-walls", anchor.id, told);
      enter = n - fight.lossA;
      state.c.d += fight.lossA;
    }
    for (let k = 0;k < STAGES;k++) state.c.i[k] += Math.floor((i[k] * enter) / n);
    say(state, ctx.tick, "horde", anchor.id, { n: enter, from: Number(anchor.payload.from) });
  },
});

registerRipple({
  kind: "infest",
  about: "infected come into a town from the wilds unseen (n of them): where none were known to be",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const n = Math.max(0, Math.floor(Number(anchor.payload.n ?? 10)));
    if (!n || state.x.sealed) return;
    state.c.i[0] += n;
    // They settle in a while before moving on.
    state.x.roamAt = Math.max(state.x.roamAt, ctx.tick + ROAM.every);
    say(state, ctx.tick, "infested", anchor.id, { n });
  },
});

registerRipple({
  kind: "unleash",
  about: "a share of a town's infected set on a neighbour as a horde (to)",
  delay: STEP,
  cold: (state, anchor, ctx) => sendHorde(state, ctx.graph, Number(anchor.payload.to), ctx.tick, Math.min(1, Number(anchor.payload.share ?? 0.5))),
});

/**
 * Where `state`'s infected would go now: the neighbour whose people draw them most (as big as it was
 * known to be), not heard emptied or sealed, drawn by `u`; -1 if they stay (too few, prey enough
 * here, or nowhere to go).
 */
export const roamTarget = (state: TownState, graph: TownGraph, people0: readonly number[], u: number) => {
  if (state.concrete >= 0 || state.x.sealed) return -1;
  // countsOf's sums, in its order (asked on every wake of a town with infected in it).
  let incubating = 0;
  let infected = 0;
  for (let k = 0;k < STAGES;k++) {
    incubating += state.c.e[k];
    infected += state.c.i[k];
  }
  if (infected < ROAM.min || state.c.s + incubating + infected - infected + state.x.im >= ROAM.prey * infected) return -1;
  let total = 0;
  const ways = graph.towns[state.town].neighbours;
  for (const n of ways) if (!((state.heard.get(n) ?? 0) & (Heard.Empty | Heard.Sealed | Heard.Bare))) total += people0[n];
  if (total <= 0) return -1;
  let at = u * total;
  for (const n of ways) {
    if ((state.heard.get(n) ?? 0) & (Heard.Empty | Heard.Sealed | Heard.Bare)) continue;
    at -= people0[n];
    if (at < 0) return n;
  }
  return ways[ways.length - 1];
};

/** When `state`'s infected next move on (Infinity: they won't as things stand). */
export const roamNext = (state: TownState, graph: TownGraph, people0: readonly number[]) =>
  roamTarget(state, graph, people0, 0.5) < 0 ? Infinity : Math.max(state.tick + 1, state.x.roamAt);

export const ROAM_RULE: TownRule = {
  kind: "roam",
  delay: STEP,
  cold: (state, ctx) => {
    if (!ctx.roam || ctx.tick < state.x.roamAt) return;
    const to = roamTarget(state, ctx.graph, ctx.people0, unitOf(ctx.seed, state.town, ctx.tick, 0x50));
    if (to < 0) return;
    state.x.roamAt = ctx.tick + ROAM.every;
    const out = sendHorde(state, ctx.graph, to, ctx.tick, ROAM.share);
    if (out.length) say(state, ctx.tick, "horde-left", undefined, { n: Number(out[0].payload.n), to });
    return out;
  },
};

registerRule(ROAM_RULE);

// ---------------------------------------------------------------------------------------------
// People against their own

/** The share of a town's well who keep its orders (police, wardens), and how able and armed they are. */
export const KEEPERS = { share: 0.01, skill: 2, gear: 2 };

const fallen = (state: TownState, n: number) => {
  const k = take(state, n);
  state.c.d += k;
  return k;
};

registerRipple({
  kind: "riot",
  about: "a share of a town's well rise against its orders (share), rolled against its keepers: won, the orders fall and the office loses the town",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const well = state.c.s;
    const rioters = Math.floor(state.c.s * Math.min(1, Number(anchor.payload.share ?? 0.1)));
    if (rioters <= 0) return;
    const keepers = Math.max(1, Math.floor(state.c.s * KEEPERS.share));
    const fight = rollFight(ctx.seed, keyOf(anchor.id), ctx.tick, { n: rioters, skill: 1, gear: 1 }, { n: keepers, skill: KEEPERS.skill, gear: KEEPERS.gear });
    const lost = fallen(state, fight.lossA + fight.lossB);
    const winner = fight.winner === "a" ? "rioters" : "keepers";
    say(state, ctx.tick, "riot", anchor.id, { rioters, keepers, lost, winner, well });
    if (winner === "keepers") return;
    // The checkpoints are torn down and nobody's left to order new ones.
    const was = closedOf(state);
    for (const series of [state.orders.level, state.orders.border, state.orders.cordon]) if (lastOf(series) !== 0) series.push([0, ctx.tick]);
    state.asked = GOVERNOR_AT.length;
    if (closedOf(state) !== was) return notices(state, ctx);
  },
});

registerRipple({
  kind: "mutiny",
  about: "a share of a town's garrison (its fighters, or garrison) turn on the rest, rolled; won, its officer (gid) falls with them",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const p = anchor.payload;
    const well = state.c.s;
    const garrison = Math.max(2, Math.floor(Number(p.garrison ?? state.c.s * FIGHTERS)));
    const mutineers = Math.max(1, Math.floor(garrison * Math.min(0.95, Number(p.share ?? 0.5))));
    const fight = rollFight(ctx.seed, keyOf(anchor.id), ctx.tick, { n: mutineers, skill: 2, gear: 2 }, { n: garrison - mutineers, skill: 2, gear: 2 });
    const lost = fallen(state, fight.lossA + fight.lossB);
    const winner = fight.winner === "a" ? "mutineers" : "loyal";
    say(state, ctx.tick, "mutiny", anchor.id, { mutineers, garrison, lost, winner, well });
    const gid = Number(p.gid ?? -1);
    if (winner === "mutineers" && gid >= 0) {
      fallen(state, 1);
      say(state, ctx.tick, "cast-died", anchor.id, { gid, cause: "fight" });
    }
  },
});

registerRipple({
  kind: "betray",
  about: "a cast person (by) sells another (gid) out to raiders (n of them), rolled: beaten, the one sold out dies",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const p = anchor.payload;
    const gid = Number(p.gid);
    const fight = rollFight(ctx.seed, keyOf(anchor.id), ctx.tick, { n: Math.max(1, Number(p.n ?? 8)), skill: 1.5, gear: 1.5 }, { n: 1, skill: Number(p.skill ?? 1), gear: Number(p.gear ?? 1) });
    const died = fight.winner === "a";
    say(state, ctx.tick, "betrayed", anchor.id, { by: Number(p.by), whom: gid, died });
    if (!died) return;
    fallen(state, 1);
    say(state, ctx.tick, "cast-died", anchor.id, { gid, cause: "fight" });
  },
});

/** The share of a heeding town's well who set off for a broadcast's town. */
export const HEED = 0.15;

registerRipple({
  kind: "broadcast",
  about: "word put out from a town (a radio) that it's safe: its neighbours' well come in (share), unless sealed, emptied or shut away",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    say(state, ctx.tick, "broadcast", anchor.id, { by: Number(anchor.payload.by ?? -1) });
    const share = Number(anchor.payload.share ?? HEED);
    return ctx.graph.towns[state.town].neighbours.map((town) => ({ kind: "heed", town, tick: reach(state, town, ctx.tick, ORDER_DELAY, "word").tick, payload: { to: state.town, share } }));
  },
});

registerRipple({
  kind: "heed",
  about: "a town hears a broadcast: a share of its well set off for the broadcast's town",
  delay: ORDER_DELAY,
  cold: (state, anchor, ctx) => {
    const to = Number(anchor.payload.to);
    if (state.empty >= 0 || state.x.sealed || (state.heard.get(to) ?? 0) & (Heard.Empty | Heard.Sealed)) return;
    const share = Math.min(1, Number(anchor.payload.share ?? HEED));
    const well = state.c.s;
    const s = take(state, state.c.s * share);
    const payload: Record<string, number> = { from: state.town, people: s, s };
    let people = s;
    for (let k = 0;k < STAGES;k++) {
      const e = Math.floor(state.c.e[k] * share);
      state.c.e[k] -= e;
      payload[`e${k}`] = e;
      people += e;
    }
    if (!people) return;
    payload.people = people;
    say(state, ctx.tick, "heeded", anchor.id, { to, people, s, well });
    const way = reach(state, to, ctx.tick, FLIGHT_DELAY);
    return [{ kind: "flight", town: to, tick: way.tick, payload }];
  },
});
