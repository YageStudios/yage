/**
 * The pond's towns: every cold cell belongs to one (its place, or the nearest place for the
 * countryside), and two towns are neighbours when people commute between them or a road joins
 * them. Ripples between towns only ever go to a neighbour, so how far a town is (in hops) bounds
 * how soon anything can reach it.
 */
import { chunkX, chunkY } from "yage/streaming";
import { CHUNK_SIZE } from "../domain/world";
import type { Cold } from "../domain/cold/step";

/** What the pond needs of the world map (worldmap/places.ts WorldMap has all of it). */
export type PondMap = {
  places: readonly { x: number; y: number }[];
  placeOf: ReadonlyMap<number, number>;
  links: readonly { from: number; to: number }[];
};

export type TownNode = {
  index: number;
  /** Its cells' keys, ascending. */
  cells: number[];
  /** Its neighbours, ascending. */
  neighbours: number[];
  /** Centre, world units. */
  x: number;
  y: number;
};

export type TownGraph = {
  towns: TownNode[];
  /** Cell key → town. */
  townOf: Map<number, number>;
  /** Hops from `from` to every town (Infinity: unreachable). */
  hops: (from: number) => readonly number[];
  /** The fewest-hop way from `from` to `to` (lowest towns first on ties), both ends in; null if none. */
  path: (from: number, to: number) => number[] | null;
};

const centreOf = (key: number) => ({ x: (chunkX(key) + 0.5) * CHUNK_SIZE, y: (chunkY(key) + 0.5) * CHUNK_SIZE });

/** How many towns' searches a graph keeps. */
const SEARCHES_KEPT = 64;

export const townGraph = (cells: readonly Pick<Cold, "key" | "flowTo">[], map: PondMap): TownGraph => {
  if (!map.places.length) throw new Error("anchors: a pond needs a town");
  const townOf = new Map<number, number>();
  for (const cell of cells) {
    let town = map.placeOf.get(cell.key) ?? -1;
    if (town < 0) {
      const at = centreOf(cell.key);
      let best = Infinity;
      map.places.forEach((p, i) => {
        const d = Math.hypot(p.x - at.x, p.y - at.y);
        if (d < best) {
          best = d;
          town = i;
        }
      });
    }
    townOf.set(cell.key, town);
  }
  const towns: TownNode[] = map.places.map((p, index) => ({ index, cells: [], neighbours: [], x: p.x, y: p.y }));
  const near = towns.map(() => new Set<number>());
  const join = (a: number, b: number) => {
    if (a === b || a < 0 || b < 0) return;
    near[a].add(b);
    near[b].add(a);
  };
  for (const cell of [...cells].sort((a, b) => a.key - b.key)) {
    const town = townOf.get(cell.key)!;
    towns[town].cells.push(cell.key);
    for (const to of cell.flowTo) join(town, townOf.get(to) ?? -1);
  }
  for (const link of map.links) join(link.from, link.to);
  towns.forEach((t, i) => (t.neighbours = [...near[i]].sort((a, b) => a - b)));
  // The latest few searches (a live pond asks from many towns over a run: they aren't all kept).
  const bfs = new Map<number, { hops: number[]; via: number[] }>();
  const search = (from: number) => {
    let found = bfs.get(from);
    if (found) return found;
    if (bfs.size >= SEARCHES_KEPT) bfs.delete(bfs.keys().next().value!);
    const hops = towns.map(() => Infinity);
    const via = towns.map(() => -1);
    hops[from] = 0;
    const queue = [from];
    for (let q = 0;q < queue.length;q++) {
      const t = queue[q];
      for (const n of towns[t].neighbours) {
        if (hops[n] !== Infinity) continue;
        hops[n] = hops[t] + 1;
        via[n] = t;
        queue.push(n);
      }
    }
    found = { hops, via };
    bfs.set(from, found);
    return found;
  };
  return {
    towns,
    townOf,
    hops: (from) => search(from).hops,
    path: (from, to) => {
      const { hops, via } = search(from);
      if (hops[to] === Infinity) return null;
      const way = [to];
      while (way[0] !== from) way.unshift(via[way[0]]);
      return way;
    },
  };
};
