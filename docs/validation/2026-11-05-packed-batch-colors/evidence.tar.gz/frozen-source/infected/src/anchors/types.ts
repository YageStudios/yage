/**
 * Anchors: the run's history as ripples in a pond. An anchor is something that happened at a town
 * at a tick (an outbreak begun, an order given, someone sent on their way), and what it sets off
 * (ripples.ts) reaches other towns later: never sooner than one cold step, never back in time. The
 * seed and the anchors placed (store.ts) are the whole history; a town's state at a tick is pulled
 * (pond.ts) by resolving only its causal past, and any order of asking gives the same answers.
 *
 * The contract every ripple keeps:
 * 1. One history: the seed and the sealed anchors define it; a query computes part of it, never makes it.
 * 2. Causality runs one way: a ripple's least delay is a cold step (STEP), so what a town is at t
 *    is fixed by what reached it before t, and asking at t + Δ leaves t as it was.
 * 3. No sequential random: every draw is a hash of the seed and what it's for (domain/cold/draws.ts).
 * 4. Causal ids: a ripple's id is its cause's, the town, its kind and its index there.
 * 5. At a town, what arrives on a step applies in tick order, ties by id.
 * 6. Sealed: placing an anchor resolves its own past then and there; a query never changes one.
 * 7. Forward only: an anchor is placed at a tick no earlier than the last placed (the store's `now`).
 */
import { COLD } from "../domain/cold/step";

export type Payload = Record<string, number | string | boolean>;

export type Anchor = {
  id: string;
  kind: string;
  /** The town it happens at (an index into the pond's towns), or GLOBAL for the whole run (the strain). */
  town: number;
  tick: number;
  payload: Payload;
  /** What set it off (ids): none for an anchor placed, its cause for a ripple. */
  parents: string[];
  /** Its town's state just before it, as resolved when it was placed (pond.ts `digestOf`). */
  seal?: number;
};

export const GLOBAL = -1;

/** A cold step: the pond's grain, and the least any ripple takes. */
export const STEP = COLD.every;

/** The step an anchor at `tick` takes effect on (its tick, or the next step after). */
export const stepOf = (tick: number) => Math.max(0, Math.ceil(tick / STEP));

/** Something a town tells of what it went through (the beats read these). */
export type TownEvent = { tick: number; kind: string; id?: string; args?: Payload };
