/**
 * What anchors set off (types.ts): each kind of ripple, resolved cold. Every kind can happen at any
 * tier, only at different grain: here a town is its people's counts, and a fight is a dice roll on
 * the fighters, their skill and their gear, where up close (warm, hot) it would be people. The
 * fine tiers fold their outcome back as an anchor; promoting a town pins what the cold rolls made.
 *
 * A ripple to another town goes at a delay and with a strength (`reach`), by its channel: people,
 * someone travelling, or word. Closures and a fallen order slow it and thin it (a letter on
 * horseback, not the internet), they don't stop it. Zero is only ever one channel's at one time:
 * an emptied town has nobody to send, yet may still be crossed and still hears word.
 *
 * Cold outcomes are the outcome (tier parity as authority): a fight rolled here is the fight, and a
 * fine tier that shows it plays out what was rolled, never rolls again.
 *
 * Town rules are what a town does of itself as its counts move: its governor's orders, its fall
 * (and the people who flee it), the news of its dying, its emptying.
 */
import { binomial, unitOf } from "../domain/cold/draws";
import { STAGES } from "../domain/cold/step";
import type { Traits } from "../domain/disease";
import { Level } from "../domain/response/measures";
import { COLLAPSE, deadShare } from "../domain/response/collapse";
import { CHUNK_SIZE, hash, TICK_RATE } from "../domain/world";
import { DAY_SECONDS } from "../domain/time";
import { TICKS_PER_CHUNK } from "../domain/directive";
import type { TownGraph } from "./graph";
import { type Anchor, type Payload, STEP, type TownEvent } from "./types";
import { DANGER, effectsOf, INFECTED_SKILL } from "../traits";

type Series = [number, number][];

export const MEASURES = ["level", "border", "cordon", "burn"] as const;
export type Measure = (typeof MEASURES)[number];

/** What a town has heard of a neighbour (notices): it shut itself, or nobody is left. */
export const enum Heard {
  Closed = 1,
  Empty = 2,
  /** Sealed tight (a blockade): nobody goes there at all. */
  Sealed = 4,
  /** None left there to prey on (all bloomed, or gone): hordes don't go there. */
  Bare = 8,
}

/** A town's people by state: the susceptible, the incubating and the bloomed by stage, the dead. */
export type Counts = { s: number; e: number[]; i: number[]; d: number };

/** What a town tells a neighbour of the commute between them (work hours): its people there and their contagion, and the load its own streets put on visitors (a hazard, per dose). */
export type Carry = { vp: number; vr: number; pw: number };

/**
 * What a town's next change is: none, or a leap from `start` to `end` that moves every one of its
 * people on by their chances over it (the hazard on the susceptible, `h`, held over it). A leap
 * is cut where something arrives, its share up to then happening (its draws then differ from the
 * uncut leap's, still the seed's).
 */
export const enum Next {
  None = 0,
  Leap = 2,
}
/** A town's next leap; `hb`, of its hazard `h`, its bloomed's bites (where the strain bites). */
export type Pending = { kind: Next; start: number; end: number; index: number; h: number; hb?: number; hk?: number };

/** A town as the pond resolves it: its people, its orders, what it has heard and told. */
export type TownState = {
  town: number;
  /** Resolved to: everything at or before it applied. */
  tick: number;
  c: Counts;
  pending: Pending;
  /** Changes drawn so far: each next change's draws are keyed by its count, not by what arrived. */
  draws: number;
  /** The latest commute word from each neighbour, and the last it told each. */
  carried: Map<number, Carry>;
  sent: Map<number, Carry>;
  orders: Record<Measure, Series>;
  heard: Map<number, number>;
  /** Ticks it fell and emptied (-1: not). */
  fallen: number;
  empty: number;
  /** The highest level its own governor has asked for. */
  asked: number;
  /** Whether it has told its neighbours it is dying. */
  warned: boolean;
  /** Its residents as it began. */
  people0: number;
  /** The tick the full sim took it over (-1: the pond's): it holds still here, and what it does comes back as anchors. */
  concrete: number;
  story: TownEvent[];
  x: Extra;
};

/**
 * What a town has beyond its people's counts and orders (the systems of systems.ts): its walls and
 * seal, its tide, its immune, and its people's own course over the years.
 */
export type Extra = {
  /** How well walled it is (0 open … 1 a fortress): fewer get in or out, and its fighters hold. */
  walls: number;
  /** Shut tight (a blockade): nobody leaves or comes, people, travellers or the infected. */
  sealed: boolean;
  /** Reachable only at low water: [period, open, phase] ticks (open from phase, every period); null: always. */
  tide: readonly number[] | null;
  /** The immune (vaccinated, cured, born to it): alive, never infected. */
  im: number;
  /** Everyone ever infected here (a cast person's chance to have been among them). */
  got: number;
  /** Born here, and died of age or illness here, over the years (the living's own course). */
  born: number;
  aged: number;
  /** The tick its people's own course was last brought up to. */
  lifeAt: number;
  /** When its infected may next move on (roam: systems.ts). */
  roamAt: number;
  /** Nobody left to prey on (none well or immune), as its neighbours were last told. */
  bare: boolean;
};

export const freshExtra = (): Extra => ({ walls: 0, sealed: false, tide: null, im: 0, got: 0, born: 0, aged: 0, lifeAt: 0, roamAt: 0, bare: false });

export type RippleContext = {
  graph: TownGraph;
  seed: number;
  tick: number;
  traits: Traits;
  /** Every town's living as the run began (how big a town is known to be, from afar). */
  people0: readonly number[];
  /** Whether the infected move on of themselves (hordes: systems.ts). */
  roam: boolean;
};

/** A ripple set off: where, when, and what it carries. */
export type Spawn = { kind: string; town: number; tick: number; payload: Payload };

export type RippleKind = {
  kind: string;
  about: string;
  /** The least it takes to arrive (at least a step). */
  delay: number;
  /** A placed one can set the world moving from its town (the pond's front: pond.ts). */
  carrier?: boolean;
  /** Its cold resolver: what it does at the town it reaches, and what it sets off. */
  cold: (state: TownState, anchor: Anchor, ctx: RippleContext) => Spawn[] | void;
};

export type TownRule = { kind: string; delay: number; cold: (state: TownState, ctx: RippleContext) => Spawn[] | void };

const KINDS = new Map<string, RippleKind>();
const RULES: TownRule[] = [];

export const registerRipple = (kind: RippleKind) => {
  if (kind.delay < STEP) throw new Error(`anchors: ${kind.kind} must take at least a step`);
  KINDS.set(kind.kind, kind);
};
export const rippleKind = (kind: string) => KINDS.get(kind) ?? null;
export const rippleKinds = () => [...KINDS.values()].sort((a, b) => (a.kind < b.kind ? -1 : a.kind > b.kind ? 1 : 0));
export const townRules = (): readonly TownRule[] => RULES;
export const registerRule = (rule: TownRule) => void RULES.push(rule);

// ---------------------------------------------------------------------------------------------
// Reading a town

export const lastOf = (series: Series, fallback = 0) => (series.length ? series[series.length - 1][0] : fallback);

/** Whether a town has shut itself: its border, checkpoints, or walls. */
export const closedOf = (state: TownState) =>
  lastOf(state.orders.border) === 1 || lastOf(state.orders.level) >= Level.Checkpoints || lastOf(state.orders.cordon) >= 1;

export const countsOf = (c: Counts) => {
  let incubating = 0;
  let infected = 0;
  for (let k = 0;k < STAGES;k++) {
    incubating += c.e[k];
    infected += c.i[k];
  }
  return { people: c.s + incubating + infected, s: c.s, incubating, infected, dead: c.d };
};

/** countsOf(c).infected, without the rest (asked on every wake). */
export const infectedOf = (c: Counts) => {
  let infected = 0;
  for (let k = 0;k < STAGES;k++) infected += c.i[k];
  return infected;
};

/** countsOf(c).people, summed the same way, without the rest. */
export const livingOf = (c: Counts) => {
  let incubating = 0;
  let infected = 0;
  for (let k = 0;k < STAGES;k++) {
    incubating += c.e[k];
    infected += c.i[k];
  }
  return c.s + incubating + infected;
};

/** How much a closure lets through, and how much longer it takes. */
/** A closed town's checkpoint: a traveller waits there `wait` ticks (half an hour) to be let by. */
export const CLOSED = { capacity: 0.15, slow: 4, wait: 15 * TICK_RATE };

/** How a ripple from `state`'s town gets to its neighbour `to`: strength 1 open, less through closures, 0 with nobody to carry it. */
export const strengthTo = (state: TownState, to: number) => {
  const heard = state.heard.get(to) ?? 0;
  if (state.empty >= 0 || heard & (Heard.Empty | Heard.Sealed) || state.x.sealed) return 0;
  return (closedOf(state) ? CLOSED.capacity : 1) * (heard & Heard.Closed ? CLOSED.capacity : 1) * (1 - WALLS.hold * state.x.walls);
};

/** How much walls keep out (of people, at full walls) and how much they make each defender worth. */
export const WALLS = { hold: 0.9, defend: 9 };

/** Whether a tide [period, open, phase] lets anyone over at `tick`. */
export const tideOpen = (tide: readonly number[] | null, tick: number) => {
  if (!tide) return true;
  const [period, open, phase] = tide;
  return (((tick - phase) % period) + period) % period < open;
};

/** The first tick at or after `tick` the tide lets anyone over. */
export const tideNext = (tide: readonly number[] | null, tick: number) => {
  if (!tide || tideOpen(tide, tick)) return tick;
  const [period, , phase] = tide;
  return tick + (period - ((((tick - phase) % period) + period) % period));
};

/** What arrives at a tidal town under high water waits for the low (the same again, then): null if it's open. */
export const waitTide = (state: TownState, anchor: Anchor, tick: number): Spawn[] | null => {
  if (tideOpen(state.x.tide, tick)) return null;
  return [{ kind: anchor.kind, town: state.town, tick: Math.max(tick + STEP, Math.ceil(tideNext(state.x.tide, tick) / STEP) * STEP), payload: anchor.payload }];
};

/**
 * What a ripple travels as, each through a closure and a collapse its own way:
 * - people: commuters and the fleeing, as many as the town has; a closure lets few through, slowly.
 * - travel: someone on their own way (a directive); a closure slows them, nothing in a town stops
 *   them (an emptied one may be crossed), only having no way at all.
 * - word: orders and news; a closure doesn't stop it, a fallen town is slow to send it (a letter
 *   on horseback, not the wire).
 * A ripple in flight is the world as it set off: a later closure doesn't call it back.
 */
export type Channel = "people" | "travel" | "word";

/** How much slower a fallen town's word goes. */
export const FALLEN_SLOW = 4;

/** When a ripple of base delay `delay` set off now from `state`'s town reaches `to` as `channel`, and how strong (0: it never does). */
export const reach = (state: TownState, to: number, tick: number, delay: number, channel: Channel = "people") => {
  const heard = state.heard.get(to) ?? 0;
  // A traveller waits at the checkpoint of a closed town they leave or come to, if somebody's left to keep it.
  const kept = closedOf(state) && state.empty < 0 && !state.x.bare;
  const wait = channel !== "travel" ? 0 : (kept ? CLOSED.wait : 0) + (heard & Heard.Closed && !(heard & (Heard.Empty | Heard.Bare)) ? CLOSED.wait : 0);
  const shut = channel === "travel" ? 1 : (closedOf(state) ? CLOSED.slow : 1) * (heard & Heard.Closed ? CLOSED.slow : 1);
  const slow = channel === "word" ? (state.fallen >= 0 ? FALLEN_SLOW : 1) : shut;
  const strength = channel === "people" ? strengthTo(state, to) : channel === "travel" && (state.x.sealed || heard & Heard.Sealed) ? 0 : 1;
  // Out of a tidal town, people and travellers go at low water (word goes by boat, or signal).
  const from = channel === "word" ? tick : tideNext(state.x.tide, tick);
  return { tick: from + Math.max(STEP, Math.ceil((delay * slow + wait) / STEP) * STEP), strength };
};

/** The ticks it takes to travel between two towns' centres. */
export const travelTicks = (graph: TownGraph, from: number, to: number) => {
  const a = graph.towns[from];
  const b = graph.towns[to];
  return Math.max(STEP, Math.round((Math.hypot(a.x - b.x, a.y - b.y) / CHUNK_SIZE) * TICKS_PER_CHUNK));
};

/** A string as a draw key. */
export const keyOf = (text: string) => hash(...Array.from(text, (ch) => ch.charCodeAt(0)));

export const say = (state: TownState, tick: number, kind: string, id?: string, args?: Payload) =>
  void state.story.push({ tick, kind, ...(id ? { id } : {}), ...(args ? { args } : {}) });

/** Takes up to `n` of the living susceptible, returning how many. */
const takeSusceptible = (c: Counts, n: number) => {
  const k = Math.min(c.s, n);
  c.s -= k;
  return k;
};

// ---------------------------------------------------------------------------------------------
// The kinds

export const ORDER_DELAY = 2 * STEP;
export const NOTICE_DELAY = STEP;
export const FLIGHT_DELAY = 3 * STEP;
/** The share of a fallen town's living who flee it, and where under so few it counts as emptied (of those it began with). */
export const FLIGHT = 0.3;
export const EMPTY_FLOOR = 0.02;
/** The visible sick share of the living at which a governor asks for each level (Masks … Checkpoints). */
export const GOVERNOR_AT = [0.002, 0.008, 0.02, 0.05, 0.1];

/** Notices of `state`'s town's standing to every neighbour (closed, emptied), by word. */
export const notices = (state: TownState, ctx: RippleContext): Spawn[] => {
  const flags = (closedOf(state) ? Heard.Closed : 0) | (state.empty >= 0 ? Heard.Empty : 0) | (state.x.sealed ? Heard.Sealed : 0) | (state.x.bare ? Heard.Bare : 0);
  return ctx.graph.towns[state.town].neighbours.map((town) => ({ kind: "notice", town, tick: reach(state, town, ctx.tick, NOTICE_DELAY, "word").tick, payload: { from: state.town, flags } }));
};

/** The next hop of a party's way to `to` from `state`'s town, or why there is none. */
const hopOn = (state: TownState, ctx: RippleContext, root: string, payload: Payload): Spawn[] | string => {
  const to = payload.to as number;
  const way = ctx.graph.path(state.town, to);
  if (!way) return "no way";
  const next = way[1];
  const leg = legTicks(ctx.graph, state.town, next, payload);
  const r = reach(state, next, ctx.tick, leg, "travel");
  // A sealed town still lets in at its gate a party that's bound for it (a refuge's own); nobody else.
  const bound = next === to && !state.x.sealed && !((state.heard.get(next) ?? 0) & Heard.Empty);
  if (r.strength <= 0 && !bound) return "sealed";
  return [{ kind: "hop", town: next, tick: r.tick, payload: { ...payload, root, leg } }];
};

registerRipple({
  kind: "outbreak",
  about: "the strain's first case at a town",
  delay: STEP,
  carrier: true,
  cold: (state, anchor, ctx) => {
    const c = state.c;
    if (c.s <= 0) return;
    c.s--;
    c.e[0]++;
    state.x.got++;
    say(state, ctx.tick, "outbreak", anchor.id);
  },
});

registerRipple({
  kind: "order",
  about: "an office's order reaching a town: its level, border, cordon or burn",
  delay: ORDER_DELAY,
  cold: (state, anchor, ctx) => {
    const measure = anchor.payload.measure as Measure;
    const series = state.orders[measure];
    if (!series) return;
    const value = Number(anchor.payload.value);
    if (lastOf(series, measure === "level" ? 0 : 0) === value && series.length) return;
    const was = closedOf(state);
    // An order the live offices gave carries the tick they gave it (`at`), so its ramps run from there.
    series.push([value, typeof anchor.payload.at === "number" ? anchor.payload.at : ctx.tick]);
    say(state, ctx.tick, measure, anchor.id, { value });
    if (closedOf(state) !== was) return notices(state, ctx);
  },
});

registerRipple({
  kind: "notice",
  about: "word of a neighbour's standing: shut, or emptied (then nobody comes from there)",
  delay: NOTICE_DELAY,
  cold: (state, anchor) => {
    const from = anchor.payload.from as number;
    const flags = anchor.payload.flags as number;
    state.heard.set(from, flags);
    if (flags & Heard.Empty) state.carried.set(from, { vp: 0, vr: 0, pw: 0 });
  },
});

registerRipple({
  kind: "carry",
  about: "the commute between two towns: who comes over from a neighbour, what they bring, and what its streets hold",
  delay: STEP,
  cold: (state, anchor) =>
    void state.carried.set(anchor.payload.from as number, { vp: anchor.payload.vp as number, vr: anchor.payload.vr as number, pw: anchor.payload.pw as number }),
});

/** Counts from a payload's s, e0…, i0…, d. */
export const countsFromPayload = (p: Payload): Counts => ({
  s: Number(p.s ?? 0),
  e: Array.from({ length: STAGES }, (_, k) => Number(p[`e${k}`] ?? 0)),
  i: Array.from({ length: STAGES }, (_, k) => Number(p[`i${k}`] ?? 0)),
  d: Number(p.d ?? 0),
});

/** A payload of counts (countsFromPayload's). */
export const countsPayload = (c: Counts): Payload => {
  const p: Payload = { s: c.s, d: c.d };
  c.e.forEach((n, k) => (p[`e${k}`] = n));
  c.i.forEach((n, k) => (p[`i${k}`] = n));
  return p;
};

registerRipple({
  kind: "concrete",
  about: "the full sim taking a town over (a player near, its people crossing): it holds still here, and what it does comes back as anchors",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    if (state.concrete >= 0) return;
    state.concrete = ctx.tick;
    say(state, ctx.tick, "concrete", anchor.id);
  },
});

registerRipple({
  kind: "observe",
  about: "the full sim handing a town back: its people as they were when it was left (and how they're spread over its cells, w<key>)",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    state.c = countsFromPayload(anchor.payload);
    state.concrete = -1;
    say(state, ctx.tick, "observed", anchor.id);
  },
});

/** A count bucket (domain/cold/cast.ts's: 0 susceptible, the incubating, the bloomed, then the dead), by one. */
const shift = (c: Counts, bucket: number, by: 1 | -1) => {
  if (bucket <= 0) c.s = Math.max(0, c.s + by);
  else if (bucket <= STAGES) c.e[bucket - 1] = Math.max(0, c.e[bucket - 1] + by);
  else if (bucket <= 2 * STAGES) c.i[bucket - 1 - STAGES] = Math.max(0, c.i[bucket - 1 - STAGES] + by);
  else c.d = Math.max(0, c.d + by);
};

registerRipple({
  kind: "leave",
  about: "a cast person setting off from home on a directive: out of its counts (bucket b) and its cell's (key) until they're back",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    shift(state.c, Number(anchor.payload.b), -1);
    say(state, ctx.tick, "left-home", anchor.id, { gid: anchor.payload.gid });
  },
});

registerRipple({
  kind: "join",
  about: "a cast person back home from a directive: into its counts (bucket b) and its cell's (key) as they came back",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    shift(state.c, Number(anchor.payload.b), 1);
    say(state, ctx.tick, "came-home", anchor.id, { gid: anchor.payload.gid });
  },
});

registerRipple({
  kind: "flight",
  about: "people fleeing a fallen town, arriving at a neighbour",
  delay: FLIGHT_DELAY,
  cold: (state, anchor, ctx) => {
    const wait = waitTide(state, anchor, ctx.tick);
    if (wait) return wait;
    if (state.x.sealed) return void say(state, ctx.tick, "turned-away", anchor.id, { from: anchor.payload.from, people: anchor.payload.people });
    const c = state.c;
    c.s += anchor.payload.s as number;
    for (let k = 0;k < STAGES;k++) c.e[k] += anchor.payload[`e${k}`] as number;
    say(state, ctx.tick, "refugees", anchor.id, { from: anchor.payload.from, people: anchor.payload.people });
  },
});

// ---------------------------------------------------------------------------------------------
// Parties on the road: a cast person, a few together, or a band (n in all, most of them nobody the
// story names), each as able (skill) and armed (gear) as they are. A party with an n is taken from
// its town's people as it sets off and joins the town it gets to; one without is the cast alone
// (their home's counts keep them, as a cold walker's do). Every town a party passes, its infected
// may take some (killed, or bitten: they turn there), rolled on how thick they are on its streets
// and the party's power; a named one's fate is their own draw.

/** A party's cast: its lead (gid; -1, none) and those with them (`with`, gids joined by commas). */
export const castIn = (p: Payload): number[] => [
  ...(Number(p.gid ?? -1) >= 0 ? [Number(p.gid)] : []),
  ...String(p.with ?? "")
    .split(",")
    .filter(Boolean)
    .map(Number),
];

/** Whether a told event is of `gid` (its lead, or one with them). */
export const ofGid = (e: TownEvent, gid: number) => e.args?.gid === gid || String(e.args?.with ?? "").split(",").includes(String(gid));

const partyArgs = (p: Payload): Payload => ({ gid: Number(p.gid ?? -1), ...(p.with ? { with: String(p.with) } : {}), ...(p.n !== undefined ? { n: Number(p.n) } : {}) });

/** How deadly a town's infected are to a party among them at base (the strain's: TraitEffects.danger). */
export { DANGER };
const DAY_TICKS = DAY_SECONDS * TICK_RATE;
/** How long a party's among a town's infected where its way ends (days), before it's indoors. */
const SETTLING = 0.1;

/** A party's leg from `from` to `to` (its `pace`: a car, a convoy, quicker than walking). */
export const legTicks = (graph: TownGraph, from: number, to: number, p: Payload = {}) =>
  Math.max(STEP, Math.round(travelTicks(graph, from, to) / Math.max(0.1, Number(p.pace ?? 1))));
/** The share of a town's well who'll fight for it. */
export const FIGHTERS = 0.2;
/** How hard each infected fights at base (the strain's: TraitEffects.fight). */
export { INFECTED_SKILL };

const immuneIn = (p: Payload, gid: number) => String(p.immune ?? "").split(",").includes(String(gid));

/** `p` with only `kept` of its cast and `n` in all (if it counts). */
const thinned = (p: Payload, kept: number[], n: number): Payload => ({ ...p, gid: kept[0] ?? -1, with: kept.slice(1).join(","), ...(p.n !== undefined ? { n } : {}) });

/** A party passing through `state`'s town: its infected may take some (killed; bitten, they turn here). Null: nobody's left. */
const encounter = (state: TownState, ctx: RippleContext, root: string, p: Payload): Payload | null => {
  const infected = countsOf(state.c).infected;
  if (infected <= 0) return p;
  const dens = Math.min(1, infected / Math.max(50, state.people0));
  const power = Math.max(0.1, Number(p.skill ?? 1) * Number(p.gear ?? 1));
  // As long among them as the leg it came by (the town's breadth), or settling in where it's going.
  const days = (p.to === state.town ? SETTLING : Number(p.leg ?? DAY_TICKS / 10) / DAY_TICKS) * dens;
  const danger = effectsOf(ctx.traits).danger;
  const pDie = 1 - Math.exp((-danger.die * days) / power);
  const pBite = 1 - Math.exp((-danger.bite * days) / power);
  const cast = castIn(p);
  const kept: number[] = [];
  for (const gid of cast) {
    if (unitOf(ctx.seed, gid, ctx.tick, 0x40) < pDie) {
      state.c.d++;
      say(state, ctx.tick, "cast-died", root, { gid, cause: "infected" });
    } else if (unitOf(ctx.seed, gid, ctx.tick, 0x41) < pBite && !immuneIn(p, gid)) {
      state.c.e[0]++;
      say(state, ctx.tick, "cast-turned", root, { gid });
    } else kept.push(gid);
  }
  const anon = Math.max(0, Number(p.n ?? cast.length) - cast.length);
  const key = keyOf(root);
  const died = binomial(anon, pDie, ctx.seed, key, ctx.tick, 0x42);
  const bitten = binomial(anon - died, pBite, ctx.seed, key, ctx.tick, 0x43);
  state.c.d += died;
  state.c.e[0] += bitten;
  if (died + bitten) say(state, ctx.tick, "party-losses", root, { ...partyArgs(p), died, bitten });
  const n = anon - died - bitten + kept.length;
  if (n <= 0) {
    say(state, ctx.tick, "party-lost", root, partyArgs(p));
    return null;
  }
  return thinned(p, kept, n);
};

export type Side = { n: number; skill: number; gear: number };

/**
 * A fight, rolled: each side's power is its fighters × skill × gear × a draw (0.5–1.5); the
 * stronger wins, and each side loses a share of its fighters as the other's power over both says.
 */
export const rollFight = (seed: number, key: number, tick: number, a: Side, b: Side) => {
  const roll = (purpose: number) => unitOf(seed, key, tick, purpose);
  const powerA = a.n * a.skill * a.gear * (0.5 + roll(1));
  const powerB = b.n * b.skill * b.gear * (0.5 + roll(2));
  const total = powerA + powerB;
  const shareA = total > 0 ? powerA / total : 0.5;
  const lossA = Math.min(a.n, Math.round(a.n * (1 - shareA) * (0.3 + 0.5 * roll(3))));
  const lossB = Math.min(b.n, Math.round(b.n * shareA * (0.3 + 0.5 * roll(4))));
  return { winner: powerA >= powerB ? ("a" as const) : ("b" as const), lossA, lossB };
};

/** Kills `n` of a town's bloomed (the latest stages first), as dead. */
export const killInfected = (c: Counts, n: number) => {
  let left = n;
  for (let k = STAGES - 1;k >= 0 && left > 0;k--) {
    const t = Math.min(c.i[k], left);
    c.i[k] -= t;
    c.d += t;
    left -= t;
  }
  return n - left;
};

/** The cast of a party who fall when it loses `loss` of its `n`: each by their own draw. */
const castFallen = (state: TownState, ctx: RippleContext, root: string, p: Payload, loss: number, n: number) => {
  const kept: number[] = [];
  for (const gid of castIn(p))
    if (n > 0 && unitOf(ctx.seed, gid, ctx.tick, 0x44) < loss / n) say(state, ctx.tick, "cast-died", root, { gid, cause: "fight" });
    else kept.push(gid);
  return kept;
};

/** A party at the end of its way: a raid fights the town first; a counted party joins it. */
const arrive = (state: TownState, ctx: RippleContext, root: string, p: Payload) => {
  let n = Number(p.n ?? castIn(p).length);
  let kept = castIn(p);
  if (p.raid) {
    const defenders = Math.floor(state.c.s * FIGHTERS);
    const fight = rollFight(ctx.seed, keyOf(root), ctx.tick, { n, skill: Number(p.skill ?? 1), gear: Number(p.gear ?? 1) }, { n: defenders, skill: 1 + WALLS.defend * state.x.walls, gear: 1 });
    kept = castFallen(state, ctx, root, p, fight.lossA, n);
    n -= fight.lossA;
    const well = state.c.s;
    const killed = takeSusceptible(state.c, fight.lossB);
    state.c.d += killed + fight.lossA;
    say(state, ctx.tick, "raid", root, { ...partyArgs(p), winner: fight.winner, lossA: fight.lossA, lossB: fight.lossB, killed, well });
    // Beaten off, the raiders that are left go; winning, they stay.
    if (fight.winner === "b") return;
  }
  if (p.n !== undefined && n > 0) state.c.s += n;
  say(state, ctx.tick, "directive-done", root, partyArgs(thinned(p, kept, n)));
  if (p.settle) say(state, ctx.tick, "settled", root, partyArgs(thinned(p, kept, n)));
};

/** A party that can't go on: a counted one stays where it is (one of its people now). */
const stopped = (state: TownState, ctx: RippleContext, root: string, p: Payload, reason: string) => {
  if (p.n !== undefined) state.c.s += Number(p.n);
  say(state, ctx.tick, "directive-failed", root, { ...partyArgs(p), reason });
};

registerRipple({
  kind: "direct",
  about: "a party set on its way to a town (a directive): a cast person, a few together, or a band of n",
  delay: STEP,
  carrier: true,
  cold: (state, anchor, ctx) => {
    let p = anchor.payload;
    if (p.n !== undefined) {
      const cast = castIn(p).length;
      const take = Math.min(Math.max(0, Number(p.n) - cast), state.c.s);
      state.c.s -= take;
      p = { ...p, n: cast + take };
    }
    if (p.to === state.town) return void arrive(state, ctx, anchor.id, p);
    const next = hopOn(state, ctx, anchor.id, p);
    if (typeof next === "string") return void stopped(state, ctx, anchor.id, p, next);
    say(state, ctx.tick, "left-town", anchor.id, partyArgs(p));
    return next;
  },
});

registerRipple({
  kind: "hop",
  about: "a party reaching the next town on its way",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const wait = waitTide(state, anchor, ctx.tick);
    if (wait) return wait;
    const root = anchor.payload.root as string;
    if (state.x.sealed && anchor.payload.to !== state.town) return void say(state, ctx.tick, "directive-failed", root, { ...partyArgs(anchor.payload), reason: "sealed" });
    say(state, ctx.tick, "entered-town", root, partyArgs(anchor.payload));
    const p = encounter(state, ctx, root, anchor.payload);
    if (!p) return;
    const until = p.until;
    if (typeof until === "number" && ctx.tick > until) return void stopped(state, ctx, root, p, "out of time");
    if (p.to === state.town) return void arrive(state, ctx, root, p);
    const next = hopOn(state, ctx, root, p);
    if (typeof next === "string") return void stopped(state, ctx, root, p, next);
    say(state, ctx.tick, "left-town", root, partyArgs(p));
    return next;
  },
});

/**
 * A fight, rolled (rollFight). Side a is the town's own (its fallen from its living susceptible),
 * or a party (gid, with: its cast fall each by their own draw); side b, another of the town's, or
 * its infected (`against: "infected"`: as many as there are, unless b says, their fallen dead for
 * good). Its outcome is sealed with it (the story's `fight`): up close, it's shown to that outcome.
 */
registerRipple({
  kind: "fight",
  about: "a fight at a town between two sides (or a side and its infected), rolled on fighters, skill and gear",
  delay: STEP,
  cold: (state, anchor, ctx) => {
    const p = anchor.payload;
    const infected = p.against === "infected";
    const a = Math.max(0, Number(p.a ?? castIn(p).length));
    const b = Math.max(0, infected ? Math.min(countsOf(state.c).infected, Number(p.b ?? Infinity)) : Number(p.b ?? 0));
    const them = effectsOf(ctx.traits).fight;
    const sides = { a: { n: a, skill: Number(p.skillA ?? 1), gear: Number(p.gearA ?? 1) }, b: { n: b, skill: Number(p.skillB ?? (infected ? them.skill : 1)), gear: Number(p.gearB ?? (infected ? them.gear : 1)) } };
    const fight = rollFight(ctx.seed, keyOf(anchor.id), ctx.tick, sides.a, sides.b);
    const party = castIn(p).length > 0;
    if (party) castFallen(state, ctx, anchor.id, p, fight.lossA, a);
    let killed: number;
    // Of the town's well, those who fell (the one followed among them: solver/follow.ts).
    const well = state.c.s;
    let fell: number;
    if (infected) {
      fell = party ? 0 : takeSusceptible(state.c, fight.lossA);
      killed = fell + killInfected(state.c, fight.lossB);
      if (!party) state.c.d += fight.lossA;
    } else killed = fell = takeSusceptible(state.c, (party ? 0 : fight.lossA) + fight.lossB);
    say(state, ctx.tick, "fight", anchor.id, { winner: fight.winner, lossA: fight.lossA, lossB: fight.lossB, killed, fell, well, ...(party ? partyArgs(p) : {}), ...(infected ? { against: "infected" } : {}) });
  },
});

/** A cast person's way to `to`, starting at the town they're in; with others (`with`), or as a band of `n`, as able and armed as given. */
export const directPayload = (gid: number, to: number, until?: number, party: Payload = {}): Payload => ({ gid, to, ...(until === undefined ? {} : { until }), ...party });

// ---------------------------------------------------------------------------------------------
// The towns' own doings

const living = (state: TownState) => countsOf(state.c).people + state.x.im;

RULES.push({
  kind: "governor",
  delay: ORDER_DELAY,
  cold: (state, ctx) => {
    if (state.empty >= 0) return;
    const c = countsOf(state.c);
    // The bloomed it notices (the strain's: how visible, how silent, how they fall).
    const share = c.people ? (c.infected * effectsOf(ctx.traits).seen) / c.people : 0;
    let want = 0;
    while (want < GOVERNOR_AT.length && share >= GOVERNOR_AT[want]) want++;
    if (want <= Math.max(state.asked, lastOf(state.orders.level))) return;
    state.asked = want;
    return [{ kind: "order", town: state.town, tick: ctx.tick + ORDER_DELAY, payload: { measure: "level", value: want, by: "governor" } }];
  },
});

RULES.push({
  kind: "dying",
  delay: ORDER_DELAY,
  cold: (state, ctx) => {
    if (state.warned || state.empty >= 0) return;
    const c = countsOf(state.c);
    if (deadShare({ people: c.people, dead: c.dead }) < COLLAPSE.borderDead) return;
    state.warned = true;
    say(state, ctx.tick, "dying");
    return ctx.graph.towns[state.town].neighbours.map((town) => ({ kind: "order", town, tick: reach(state, town, ctx.tick, ORDER_DELAY, "word").tick, payload: { measure: "border", value: 1, against: state.town } }));
  },
});

RULES.push({
  kind: "fall",
  delay: FLIGHT_DELAY,
  cold: (state, ctx) => {
    if (state.fallen >= 0 || state.empty >= 0) return;
    const now = countsOf(state.c);
    if (deadShare({ people: now.people, dead: now.dead }) < COLLAPSE.fallDead) return;
    state.fallen = ctx.tick;
    say(state, ctx.tick, "town-fell", undefined, { well: state.c.s });
    const ways = ctx.graph.towns[state.town].neighbours.map((town) => ({ town, ...reach(state, town, ctx.tick, FLIGHT_DELAY) })).filter((w) => w.strength > 0);
    if (!ways.length) return;
    const c = state.c;
    const out: Spawn[] = [];
    const from = { s: c.s, e: [...c.e] };
    for (const way of ways) {
      const share = (FLIGHT * way.strength) / ways.length;
      const s = Math.min(c.s, Math.floor(from.s * share));
      const e = from.e.map((n, k) => Math.min(c.e[k], Math.floor(n * share)));
      const people = s + e.reduce((x, y) => x + y, 0);
      if (!people) continue;
      c.s -= s;
      e.forEach((n, k) => (c.e[k] -= n));
      const payload: Payload = { from: state.town, people, s };
      e.forEach((n, k) => (payload[`e${k}`] = n));
      out.push({ kind: "flight", town: way.town, tick: way.tick, payload });
      // Told here too, of the well who went (the one followed among them: solver/follow.ts).
      say(state, ctx.tick, "fled", undefined, { to: way.town, people, s });
    }
    return out;
  },
});

RULES.push({
  kind: "empty",
  delay: NOTICE_DELAY,
  cold: (state, ctx) => {
    if (state.empty >= 0) return;
    const people = living(state);
    if (people > 0 && people >= EMPTY_FLOOR * state.people0) return;
    state.empty = ctx.tick;
    say(state, ctx.tick, "town-emptied");
    return notices(state, ctx);
  },
});

RULES.push({
  kind: "bare",
  delay: NOTICE_DELAY,
  cold: (state, ctx) => {
    // Only worth telling where there are infected to roam (a town of the well alone isn't bare).
    const bare = state.c.s + state.x.im <= 0 && countsOf(state.c).infected > 0;
    if (bare === state.x.bare || state.empty >= 0) return;
    state.x.bare = bare;
    return notices(state, ctx);
  },
});
