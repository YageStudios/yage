import { geographicWeather } from "../realworld/world-climate";
import { gameToGeographic, type GeographicAnchor, type GeographicPoint } from "../realworld/coordinates";
import { forecastSky } from "../realworld/forecast";
/**
 * Weather and climate: moving fronts over the world as a pure function of (seed, space, time,
 * position). The page draws it (rain, snow, fog, overcast light, the fronts on the world map) and
 * the workers feel it (how long the strain hangs in air and lives on surfaces, outdoor spread, the
 * heat/cold tolerance traits, people sheltering indoors). Samples use source-owned transient
 * caches: a chunk that turns hot late sees exactly the sky a chunk simulated all along has.
 *
 * Model. Time is cut into slots of SLOT game seconds; each slot of each space seeds a few fronts.
 * A front is a soft elliptical band (long across its motion, narrow along it) that drifts across
 * the space at a steady velocity, swelling in and dying out over its life. Its kind is drawn from
 * the season and the region's moisture: rain (snow where it is freezing), heat waves, cold snaps
 * and fog banks. On top: the region's seasonal mean temperature, a daily swing, and dawn mist in
 * damp places. Ground wetness and snow cover look back over a fixed handful of past samples.
 *
 * Units: positions in chunks (fractional, world space of the streamed world), time in game
 * seconds (time.ts `clock`).
 */
import { DAYS_PER_YEAR, seasonPhase, seasonStrength } from "../atlas/clock";
import { climateAt } from "../atlas/regions";
import { CONTENT } from "../content/runtime";
import { weatherMemory } from "../sim/host-state";
import type { PlanningContext } from "../worldgen/commute/context";
import type { AtlasTerrain } from "../worldgen/layout";
import { Tile, type ObjectsNav } from "../worldgen/terrain/index";
import { RULES, type Traits } from "./disease";
import { clock, DAY_SECONDS, HOUR } from "./time";
import { CHUNK_SIZE, CHUNK_TILES, hash, SEED, TILE, WORLD_MAX, WORLD_MIN } from "./world";
export const enum FrontKind {
  Rain = 0,
  Heat = 1,
  Cold = 2,
  Fog = 3
}
export const FRONT_NAMES = ["rain", "heat wave", "cold snap", "fog"];
export type Front = {
  kind: FrontKind;
  /** Game seconds: born, peak, gone. */
  born: number;
  life: number;
  /** Centre at mid-life (chunks) and velocity (chunks per game second). */
  x: number;
  y: number;
  vx: number;
  vy: number;
  /** Half-length across the motion and half-width along it (chunks). */
  across: number;
  along: number;
  /** Peak intensity 0..1. */
  peak: number;
  /** A rain front that is a storm: gales and lightning, a blizzard where it snows. */
  storm?: boolean;
};
/** Where the weather happens: one streamed space's extent and climate. */
export type WeatherSpace = {
  /** Engine space index (0 = the legacy world). */
  index: number;
  cx0: number;
  cy0: number;
  cx1: number;
  cy1: number;
  /** Mean temperature (°C) at chunk row cy on fractional day `day` (season, no fronts, no daily swing). */
  base(cy: number, day: number): number;
  moisture: number;
  latitude: number;
  /** A sky held where it is (the simulation lab, src/simlab/field.ts): the fronts are left out. */
  readonly force?: WeatherForce | null;
};
/** A held sky, in skyAt's terms (the temperature stays the space's base and the daily swing). */
export type WeatherForce = { precip: number; fog: number; cloud: number; heat: number; cold: number; storm: number; wind: number };
export type Weather = {
  /** °C, with season, time of day and fronts. */
  temperature: number;
  /** Falling precipitation 0..1: rain and snow split by temperature. */
  rain: number;
  snow: number;
  fog: number;
  /** Cloud cover 0..1 (dims the light). */
  cloud: number;
  /** Heat wave and cold snap strength here, 0..1. */
  heat: number;
  cold: number;
  /** Wind direction (radians) and strength 0..1, from the strongest front nearby. */
  windAngle: number;
  wind: number;
  /** Ground: wet 0..1 after rain, snow cover 0..1. */
  wetness: number;
  snowCover: number;
  /** Storm strength here 0..1 (gales, lightning; with snow, a blizzard). */
  storm: number;
};
/** The numbers are data (content/weather.json5). */
const { slotHours, ...weather } = CONTENT.weather.weather;
export const WEATHER = { slot: slotHours * HOUR, ...weather };
// ---------------------------------------------------------------------------------------------
// Spaces
const legacyBase = (cy: number) => (cy < RULES.coldBelowCy ? -14 : cy > RULES.hotAboveCy ? 41 : 12);
/** The streamed space (the atlas one, else the legacy world). */
export const weatherSpace = (context: PlanningContext): WeatherSpace => {
  const memory = weatherMemory(context);
  if (memory.space)
    return memory.space;
  const source = context.source;
  // A source with a weather space of its own (the lab's field).
  const own = (source as { weatherSpace?: () => WeatherSpace } | null)?.weatherSpace?.();
  if (own) {
    memory.space = own;
    return own;
  }
  const atlas = source && "atlas" in source ? source as AtlasTerrain : null;
  let space: WeatherSpace;
  if (atlas) {
    const def = atlas.atlas.manifest.spaces.find((s) => s.index === atlas.space);
    if (!def)
      throw new Error("Weather source has no declared space");
    const [w, h] = def.chunks;
    const { cx: ox, cy: oy } = def.origin ?? { cx: 0, cy: 0 };
    space = {
      index: def.index,
      cx0: ox - w / 2,
      cy0: oy - h / 2,
      cx1: ox + w / 2 - 1,
      cy1: oy + h / 2 - 1,
      base: (_cy, day) => climateAt(def, day).temperature,
      moisture: def.region.moisture,
      latitude: def.region.latitude,
    };
  }
  else {
    space = { index: 0, cx0: WORLD_MIN, cy0: WORLD_MIN, cx1: WORLD_MAX, cy1: WORLD_MAX, base: legacyBase, moisture: 0.55, latitude: 0 };
  }
  memory.space = space;
  return space;
};
// ---------------------------------------------------------------------------------------------
// Fronts
const unit = (h: number) => (h >>> 8) / 16777216;
/** -1 deep winter .. +1 high summer, scaled by how seasonal the latitude is. */
export const seasonWarmth = (space: WeatherSpace, t: number) => -Math.cos(seasonPhase(t / DAY_SECONDS, space.latitude) * Math.PI * 2) * seasonStrength(space.latitude);
/** The fronts a slot seeds (cached; pure in seed, space and slot). */
export const frontsOfSlot = (space: WeatherSpace, slot: number, context: PlanningContext): Front[] => {
  const slotCache = weatherMemory(context).slots;
  const key = `${space.index}:${slot}`;
  let list = slotCache.get(key);
  if (list)
    return list;
  list = [];
  const t0 = slot * WEATHER.slot;
  const warmth = seasonWarmth(space, t0 + WEATHER.slot / 2);
  const m = space.moisture;
  // Weights per kind; the chance of any front at all rises with moisture and the season's extremes.
  const w = [m * (1.6 - 0.3 * warmth), Math.max(0, warmth) * 0.5, Math.max(0, -warmth) * 0.45, m * 0.2];
  const total = w[0] + w[1] + w[2] + w[3];
  const w0 = space.cx1 - space.cx0 + 1;
  const h0 = space.cy1 - space.cy0 + 1;
  for (let k = 0;k < WEATHER.perSlot;k++) {
    const h = (i: number) => unit(hash(SEED, space.index, slot, k, i, 0x77ea));
    if (h(0) > 0.4 + 0.45 * m)
      continue;
    let pick = h(1) * total;
    let kind = FrontKind.Rain;
    for (let i = 0;i < 4;i++) {
      if (pick < w[i]) {
        kind = i as FrontKind;
        break;
      }
      pick -= w[i];
    }
    const life = (kind === FrontKind.Heat || kind === FrontKind.Cold ? 14 + h(2) * 16 : kind === FrontKind.Fog ? 5 + h(2) * 5 : 7 + h(2) * 9) * HOUR;
    // Prevailing westerlies with some spread; fog banks barely move, heat and cold sit broad.
    const angle = (h(3) - 0.5) * 1.4 + (h(4) < 0.2 ? Math.PI : 0);
    const speed = (kind === FrontKind.Fog ? 0.1 : kind === FrontKind.Rain ? 0.7 + h(5) * 0.9 : 0.25 + h(5) * 0.3) / HOUR;
    const across = kind === FrontKind.Rain ? 8 + h(6) * 10 : kind === FrontKind.Fog ? 3 + h(6) * 4 : 10 + h(6) * 10;
    const along = kind === FrontKind.Rain ? 2.5 + h(7) * 3.5 : kind === FrontKind.Fog ? 2.5 + h(7) * 3 : 7 + h(7) * 7;
    // Storms (a separate draw, so the rest of the sky is unchanged): heavier, slower, deeper.
    const storm = kind === FrontKind.Rain && h(12) < WEATHER.stormShare * (0.5 + m);
    list.push({
      kind,
      born: t0 + h(8) * WEATHER.slot,
      life,
      x: space.cx0 + (h(9) * 1.2 - 0.1) * w0,
      y: space.cy0 + (h(10) * 1.2 - 0.1) * h0,
      vx: Math.cos(angle) * speed * (storm ? 0.6 : 1),
      vy: Math.sin(angle) * speed * (storm ? 0.6 : 1),
      across,
      along: storm ? along * 1.4 : along,
      peak: storm ? 0.9 + h(11) * 0.1 : 0.55 + h(11) * 0.45,
      ...(storm ? { storm: true } : {}),
    });
  }
  if (slotCache.size > 4096) {
    const first = slotCache.keys().next();
    if (!first.done)
      slotCache.delete(first.value);
  }
  slotCache.set(key, list);
  return list;
};
/** Every front alive at game time t. */
export const frontsAt = (space: WeatherSpace, t: number, out: Front[] = [], context: PlanningContext): Front[] => {
  out.length = 0;
  const now = Math.floor(t / WEATHER.slot);
  for (let s = now - WEATHER.reach;s <= now;s++) {
    for (const f of frontsOfSlot(space, s, context))
      if (t >= f.born && t < f.born + f.life)
        out.push(f);
  }
  return out;
};
/** Time envelope: swells in over the first quarter, fades over the last third. */
const envelope = (f: Front, t: number) => {
  const a = (t - f.born) / f.life;
  if (a <= 0 || a >= 1)
    return 0;
  const s = (x: number) => x * x * (3 - 2 * x);
  return a < 0.25 ? s(a / 0.25) : a > 0.67 ? s((1 - a) / 0.33) : 1;
};
/** Where a front's centre is at t (chunks). */
export const frontCentre = (f: Front, t: number) => {
  const dt = t - (f.born + f.life / 2);
  return { x: f.x + f.vx * dt, y: f.y + f.vy * dt };
};
/**
 * A front's strength at (x, y) chunks and time t, 0..peak; `halo` widens it (cloud cover reaches
 * further than the rain). The leading edge is ragged by a slow wobble so a rain line looks like one.
 */
export const frontAt = (f: Front, x: number, y: number, t: number, halo = 1) => {
  const e = envelope(f, t);
  if (!e)
    return 0;
  const dt = t - (f.born + f.life / 2);
  const dx = x - (f.x + f.vx * dt);
  const dy = y - (f.y + f.vy * dt);
  // Well outside the band's widest reach (the wobble swells it at most 1.4 times along): nothing,
  // without the trigonometry. The margin keeps this to points the band test below would refuse too.
  const reach = Math.max(f.along * 1.4, f.across) * halo;
  if (dx * dx + dy * dy > reach * reach * 1.01)
    return 0;
  const speed = Math.hypot(f.vx, f.vy) || 1;
  const ux = f.vx / speed;
  const uy = f.vy / speed;
  const along = dx * ux + dy * uy;
  const across = -dx * uy + dy * ux;
  // Ragged edge: the band bulges and thins along its length.
  const wobble = 1 + 0.25 * Math.sin(across * 0.9 + f.born * 0.001) + 0.15 * Math.sin(across * 2.3 + f.x);
  const q = (along / (f.along * wobble * halo)) ** 2 + (across / (f.across * halo)) ** 2;
  if (q >= 1)
    return 0;
  const k = 1 - q;
  return f.peak * e * k * k;
};
// ---------------------------------------------------------------------------------------------
// Weather at a point
/** Game time on this source's weather calendar. */
export const weatherTime = (t: number, context: PlanningContext) => t + weatherMemory(context).offset;
/** Shift one source's calendar, invalidating only that owner's derived samples. */
export const setWeatherOffset = (hours: number, context: PlanningContext) => {
  const memory = weatherMemory(context);
  memory.offset = hours * HOUR;
  memory.slots.clear();
  memory.live.clear();
  memory.chunks.clear();
  memory.shelters.clear();
  memory.floods.clear();
};
/** Temperature, precipitation and fog at (x, y) chunks, game time t, without the ground's memory. */
/** Sky evaluations so far in a context (tests bound the cost of a query). */
export const weatherSkies = (context: PlanningContext) => weatherMemory(context).skies;
/** Where (x, y) chunks is on the globe: one closed-form inverse (coordinates.ts). */
const geographicPointOf = (anchor: GeographicAnchor, x: number, y: number) => gameToGeographic(anchor, x * CHUNK_SIZE, y * CHUNK_SIZE);
const skyAt = (space: WeatherSpace, x: number, y: number, t: number, context: PlanningContext) => {
  const memory = weatherMemory(context);
  memory.skies++;
  t += memory.offset;
  const day = t / DAY_SECONDS;
  const hour = ((t / HOUR) % 24 + 24) % 24;
  let temperature = space.base(Math.floor(y), day) + WEATHER.daily * Math.sin(((hour - 9) / 24) * Math.PI * 2);
  if (context.source && "atlas" in context.source) {
    const atlas = context.source as AtlasTerrain;
    if (atlas.atlas.geography) {
      const point = geographicPointOf(atlas.atlas.geography.anchor, x, y);
      // Source frames use physical seconds from scenario start; the sim day is compressed.
      const forecastSeconds = (t - clock(0)) * 86400 / DAY_SECONDS;
      return geographicWeather(atlas.atlas.geography, point.longitude, point.latitude, forecastSeconds);
    }
    const forecast = atlas.atlas.manifest.spaces.find(def => def.index === space.index)?.forecast;
    const sky = forecast && forecastSky(forecast, t);
    if (sky) return sky;
  }
  const force = space.force;
  if (force)
    return { temperature, precip: force.precip, fog: force.fog, cloud: force.cloud, heat: force.heat, cold: force.cold, wind: force.wind, windAngle: 0.6, storm: force.storm };
  let precip = 0;
  let fog = 0;
  let cloud = 0;
  let heat = 0;
  let cold = 0;
  let wind = 0.15;
  let windAngle = 0;
  let strongest = 0;
  let storm = 0;
  // Every point asked at one time (a pass's towns, now and the hours they look back) shares that time's live fronts.
  let fronts = memory.live.get(t);
  if (!fronts) {
    if (memory.live.size >= 256) memory.live.clear();
    memory.live.set(t, (fronts = frontsAt(space, t, [], context)));
  }
  for (const f of fronts) {
    const v = frontAt(f, x, y, t);
    // A rain band's cloud and wind reach further than its rain.
    const reachV = f.kind === FrontKind.Rain ? frontAt(f, x, y, t, 1.8) : v;
    if (f.kind === FrontKind.Rain) {
      precip = Math.max(precip, v);
      if (f.storm)
        storm = Math.max(storm, v / f.peak);
      cloud = Math.max(cloud, Math.min(1, reachV * 1.4));
      temperature += WEATHER.rainCool * v;
    }
    else if (f.kind === FrontKind.Heat) {
      heat = Math.max(heat, v);
      temperature += WEATHER.heatWave * v;
    }
    else if (f.kind === FrontKind.Cold) {
      cold = Math.max(cold, v);
      temperature += WEATHER.coldSnap * v;
      cloud = Math.max(cloud, v * 0.4);
    }
    else {
      fog = Math.max(fog, v);
      cloud = Math.max(cloud, v * 0.5);
    }
    if (reachV > strongest && f.kind !== FrontKind.Fog) {
      strongest = reachV;
      windAngle = Math.atan2(f.vy, f.vx);
      wind = 0.15 + reachV * 0.85;
    }
  }
  // A storm's gale, whichever front set the direction.
  if (storm > 0)
    wind = Math.max(wind, Math.min(1, 0.35 + storm * 0.9));
  // Dawn mist in damp places on some mornings.
  const dawn = Math.max(0, 1 - Math.abs(hour - 6.5) / 2.5);
  if (dawn > 0) {
    const misty = unit(hash(SEED, space.index, Math.floor(day), 0x3157)) < space.moisture * 0.6 ? 1 : 0;
    fog = Math.max(fog, misty * dawn * dawn * 0.7 * (1 - wind));
  }
  return { temperature, precip, fog, cloud, heat, cold, wind, windAngle, storm };
};
/** The sky alone (no ground memory): cheap, for particles and the map. */
export const skyWeather = (x: number, y: number, t: number, space: WeatherSpace | undefined, context: PlanningContext) => {
  space ??= weatherSpace(context);
  const sky = skyAt(space, x, y, t, context);
  const snowing = sky.temperature < WEATHER.snowBelow;
  return { temperature: sky.temperature, rain: snowing ? 0 : sky.precip, snow: snowing ? sky.precip : 0, fog: Math.min(1, sky.fog), cloud: Math.min(1, Math.max(sky.cloud, sky.precip)), heat: sky.heat, cold: sky.cold, wind: sky.wind, windAngle: sky.windAngle, storm: sky.storm };
};
/** Weather at (x, y) in chunks (fractional) and game time t. */
export const weatherAt = (x: number, y: number, t: number, space: WeatherSpace | undefined, context: PlanningContext): Weather => {
  space ??= weatherSpace(context);
  const sky = skyAt(space, x, y, t, context);
  const snowing = sky.temperature < WEATHER.snowBelow;
  // Ground memory, from a fixed handful of past samples.
  // Even moderate rain soaks the ground; it dries over hours (faster in the warm).
  let wet = snowing ? 0 : sky.precip * 1.5;
  const dry = HOUR * (sky.temperature > 25 ? 2 : sky.temperature > 12 ? 3.5 : 6);
  for (let k = 1;k <= WEATHER.wetSamples;k++) {
    const past = skyAt(space, x, y, t - k * HOUR, context);
    if (past.temperature >= WEATHER.snowBelow)
      wet = Math.max(wet, past.precip * 1.5 * Math.exp((-k * HOUR) / dry));
  }
  let snowCover = 0;
  if (sky.temperature < 4) {
    let depth = snowing ? sky.precip * 0.5 : 0;
    for (let k = 1;k <= WEATHER.snowSamples;k++) {
      const past = skyAt(space, x, y, t - k * 2 * HOUR, context);
      if (past.temperature < WEATHER.snowBelow)
        depth += past.precip * 0.45;
    }
    snowCover = Math.min(1, depth) * Math.min(1, Math.max(0, (4 - sky.temperature) / 4));
  }
  return {
    temperature: sky.temperature,
    rain: snowing ? 0 : sky.precip,
    snow: snowing ? sky.precip : 0,
    fog: Math.min(1, sky.fog),
    cloud: Math.min(1, Math.max(sky.cloud, sky.precip)),
    heat: sky.heat,
    cold: sky.cold,
    windAngle: sky.windAngle,
    wind: sky.wind,
    wetness: Math.min(1, wet),
    snowCover,
    storm: sky.storm,
  };
};
/** A chunk's weather (at its centre) at a world tick. Cached for the latest tick per chunk. */
export const chunkWeather = (cx: number, cy: number, tick: number, context: PlanningContext): Weather => {
  const space = weatherSpace(context);
  const chunkCache = weatherMemory(context).chunks;
  const key = `${space.index}:${cx},${cy}`;
  const hit = chunkCache.get(key);
  if (hit && hit.tick === tick)
    return hit.w;
  const w = weatherAt(cx + 0.5, cy + 0.5, clock(tick), space, context);
  if (chunkCache.size > 4096) {
    const first = chunkCache.keys().next();
    if (!first.done)
      chunkCache.delete(first.value);
  }
  chunkCache.set(key, { tick, w });
  return w;
};
// ---------------------------------------------------------------------------------------------
// Extremes: storms, floods, seasons. Still pure in (seed, space, time, position).
/** The numbers are data (content/weather.json5). */
const { floodEveryHours, ...extremes } = CONTENT.weather.extremes;
export const EXTREMES = { ...extremes, floodEvery: floodEveryHours * HOUR };
/**
 * How flooded the low ground near (x, y) chunks is at game time t, 0..1: rivers and ponds rise with
 * the rain of the last day (heavy and slow storms do it, a passing shower doesn't) and fall back as
 * it dries. Half-hour steps, one value per chunk.
 */
export const floodAt = (x: number, y: number, t: number, space: WeatherSpace | undefined, context: PlanningContext) => {
  space ??= weatherSpace(context);
  const floodCache = weatherMemory(context).floods;
  const q = Math.floor(t / (HOUR / 2));
  const cx = Math.floor(x);
  const cy = Math.floor(y);
  const key = `${space.index}:${cx},${cy}:${q}`;
  const hit = floodCache.get(key);
  if (hit !== undefined)
    return hit;
  const t0 = q * (HOUR / 2);
  let rain = 0;
  for (let k = 0;k < EXTREMES.floodSamples;k++) {
    const sky = skyAt(space, cx + 0.5, cy + 0.5, t0 - k * EXTREMES.floodEvery, context);
    // Older rain has partly run off; snow doesn't flood (until it melts, which we leave out).
    if (sky.temperature >= WEATHER.snowBelow)
      rain += sky.precip * (1 - k / (EXTREMES.floodSamples * 1.6));
  }
  const v = smooth(EXTREMES.floodFrom, EXTREMES.floodFull, rain);
  if (floodCache.size > 8192) {
    const first = floodCache.keys().next();
    if (!first.done)
      floodCache.delete(first.value);
  }
  floodCache.set(key, v);
  return v;
};
/**
 * A lightning flash at (x, y) chunks and game time t, 0..1 (bright at the strike, gone in half a
 * second). Strikes fall in 6-second windows per 4-chunk cell, more often the stronger the storm.
 */
export const lightningAt = (x: number, y: number, t: number, space: WeatherSpace | undefined, context: PlanningContext) => {
  space ??= weatherSpace(context);
  const win = Math.floor(t / 6);
  const gx = Math.floor(x / 4);
  const gy = Math.floor(y / 4);
  const r = unit(hash(SEED, space.index, gx, gy, win, 0x11e7));
  if (r > EXTREMES.strikes)
    return 0;
  const storm = skyAt(space, x, y, win * 6, context).storm;
  if (storm < 0.25 || r > EXTREMES.strikes * storm)
    return 0;
  const at = win * 6 + unit(hash(SEED, gx, gy, win, 0x11e8)) * 5;
  const dt = t - at;
  if (dt < 0 || dt > 0.5)
    return 0;
  // A double flicker.
  return dt < 0.08 ? 1 : dt < 0.16 ? 0.3 : dt < 0.24 ? 0.8 : 1 - (dt - 0.24) / 0.26;
};
export const SEASON_NAMES = ["winter", "spring", "summer", "autumn"] as const;
export type Season = (typeof SEASON_NAMES)[number];
/** The season at game time t (by the space's latitude), and how far into it (0..1). */
export const seasonAt = (t: number, space: WeatherSpace | undefined, context: PlanningContext) => {
  space ??= weatherSpace(context);
  const phase = seasonPhase(weatherTime(t, context) / DAY_SECONDS, space.latitude);
  const q = (phase + 0.125) * 4;
  const i = Math.floor(q) % 4;
  return { season: SEASON_NAMES[i], index: i, progress: q - Math.floor(q), warmth: seasonWarmth(space, weatherTime(t, context)) };
};
/** The season's own spread factor: winter crowds people indoors, summer airs them out. */
export const seasonSpread = (t: number, space: WeatherSpace | undefined, context: PlanningContext) => {
  space ??= weatherSpace(context);
  const w = seasonWarmth(space, weatherTime(t, context));
  return 1 + EXTREMES.winterSpread * Math.max(0, -w) - EXTREMES.summerEase * Math.max(0, w);
};
/**
 * Hospital admissions from the weather itself at a place (share of a full ward, 0..): heatstroke in
 * a heat wave past 30 °C, exposure in bitter cold and blizzards. The old and the homeless first.
 */
export const exposureAdmissions = (w: Pick<Weather, "temperature" | "snow" | "storm">) => EXTREMES.heatstroke * smooth(30, 38, w.temperature) + EXTREMES.exposure * Math.max(smooth(-5, -18, w.temperature), smooth(0.2, 0.8, w.storm) * Math.min(1, w.snow * 2));
/** Short label: "rain 9°C", "snow −3°C", "heat wave 31°C", "fog 6°C", "clear 14°C". */
export const weatherLabel = (w: Weather) => {
  const what = w.snow > 0.12 ? "snow" : w.rain > 0.12 ? "rain" : w.heat > 0.3 ? "heat wave" : w.cold > 0.3 ? "cold snap" : w.fog > 0.3 ? "fog" : w.cloud > 0.4 ? "overcast" : "clear";
  return `${what} ${Math.round(w.temperature)}°C`;
};
/** The game's coarse climate band by temperature (the HUD's "temperate"). */
export const bandOf = (temperature: number) => (temperature < -2 ? "cold" : temperature > 28 ? "hot" : "temperate");
// ---------------------------------------------------------------------------------------------
// Effects on the strain and on people. Per chunk and tick, so hot and warm chunks agree.
const smooth = (a: number, b: number, x: number) => {
  const k = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return k * k * (3 - 2 * k);
};
/**
 * Spread multiplier from the tolerance traits: 1 in mild weather, easing into `traits.cold` below
 * 2 °C (fully by −8 °C) and into `traits.heat` above 26 °C (fully by 34 °C). The legacy world's
 * cold and hot bands sit past both ends, so they keep their flat factors.
 */
export const toleranceFactor = (temperature: number, traits: Traits) => {
  const c = smooth(2, -8, temperature);
  const h = smooth(26, 34, temperature);
  return (1 - c - h) + c * traits.cold + h * traits.heat;
};
/** How long the strain lasts in air and on surfaces here, relative to mild dry weather. */
export const survival = (w: Weather) => {
  const chill = smooth(10, -5, w.temperature);
  const hot = smooth(24, 36, w.temperature);
  return {
    // Cold, damp, still air keeps droplets aloft; rain washes them out; heat dries them.
    air: (1 + 0.45 * chill + 0.5 * w.fog) * (1 - 0.35 * Math.max(w.rain, w.snow * 0.6)) * (1 - 0.3 * hot),
    // Cold surfaces keep it for longer; hot ones bake it off.
    surface: (1 + 0.8 * chill) * (1 - 0.45 * hot),
  };
};
/** Breath and clouds outdoors in falling rain or snow pass on less (washed air, hoods up, hurrying). */
export const outdoorFactor = (w: Weather) => 1 - 0.4 * Math.max(w.rain, w.snow * 0.8);
/** Whether a tile is under a roof (building floors, furniture, stairs). */
const roofed = (tile: number) => tile === Tile.Floor || (tile >= Tile.Bed && tile <= Tile.Shelf) || tile === Tile.Partition || (tile >= Tile.StairsN && tile <= Tile.StairsW);
/**
 * Whether a chunk-local point (world units) is out in the open. Objects mode asks the building
 * footprints (its tiles carry no buildings); otherwise the tile says.
 */
export const outdoorAt = (tiles: Uint8Array, cx: number, cy: number, x: number, y: number, owner: PlanningContext | ObjectsNav | null) => {
  const nav = owner && "host" in owner ? owner.source?.objects : owner;
  if (nav)
    return nav.placeAt(cx, cy, x / TILE, y / TILE) === null;
  const tx = Math.min(CHUNK_TILES - 1, Math.max(0, Math.floor(x / TILE)));
  const ty = Math.min(CHUNK_TILES - 1, Math.max(0, Math.floor(y / TILE)));
  return !roofed(tiles[ty * CHUNK_TILES + tx]);
};
/**
 * outdoorAt for presentation (a view's rain, its clouds' enclosure): under any building's footprint
 * is indoors, answered without the chunk's layout, which the page would otherwise build just to ask.
 * The sim keeps outdoorAt (by place).
 */
export const openAirAt = (tiles: Uint8Array, cx: number, cy: number, x: number, y: number, owner: PlanningContext | ObjectsNav | null) => {
  const nav = owner && "host" in owner ? owner.source?.objects : owner;
  if (nav)
    return !nav.inBuilding(cx, cy, x / TILE, y / TILE);
  return outdoorAt(tiles, cx, cy, x, y, null);
};
/** Traits as the weather at a chunk and tick has them (cloud life and surface persistence). */
export const weathered = (traits: Traits, cx: number, cy: number, tick: number, context: PlanningContext): Traits => {
  const s = survival(chunkWeather(cx, cy, tick, context));
  if (Math.abs(s.air - 1) < 1e-3 && Math.abs(s.surface - 1) < 1e-3)
    return traits;
  return { ...traits, cloudLife: traits.cloudLife * s.air, persistence: traits.persistence * s.surface };
};
/** The full spread factor of a chunk at a tick (replaces the old row-band climateFactor). */
export const spreadFactor = (cx: number, cy: number, tick: number, traits: Traits, context: PlanningContext) => toleranceFactor(chunkWeather(cx, cy, tick, context).temperature, traits) * seasonSpread(clock(tick), undefined, context);
/**
 * How much people want a roof over them (0..1) in a chunk at game time t: rain, snow and bitter
 * cold all day; in a heat wave, around the middle of the day (shade and indoor cool).
 */
export const shelterAt = (cx: number, cy: number, t: number, context: PlanningContext) => {
  const shelterCache = weatherMemory(context).shelters;
  // Quarter-hour steps, so a whole segment's choices see one sky (and repeat calls are cheap).
  const q = Math.floor(t / (HOUR / 4));
  const space = weatherSpace(context);
  const key = `${space.index}:${cx},${cy}:${q}`;
  const hit = shelterCache.get(key);
  if (hit !== undefined)
    return hit;
  t = q * (HOUR / 4);
  const sky = skyAt(space, cx + 0.5, cy + 0.5, t, context);
  const snowing = sky.temperature < WEATHER.snowBelow;
  const w = { temperature: sky.temperature, rain: snowing ? 0 : sky.precip, snow: snowing ? sky.precip : 0, fog: sky.fog };
  const hour = ((t / HOUR) % 24 + 24) % 24;
  const midday = Math.max(0, 1 - Math.abs(hour - 14) / 4.5);
  const hot = smooth(26, 34, w.temperature) * midday;
  const bitter = smooth(2, -10, w.temperature);
  // Storms and floods keep everyone in; winter's dark evenings keep more in.
  const evening = Math.max(0, 1 - Math.abs(hour - 19) / 3.5);
  const winter = Math.max(0, -seasonWarmth(space, t + weatherMemory(context).offset)) * EXTREMES.winterIndoors * evening;
  const flood = floodAt(cx + 0.5, cy + 0.5, t, space, context);
  const v = Math.min(1, Math.max(w.rain * 1.1, w.snow, bitter * 0.8, hot * 0.85, w.fog * 0.2, sky.storm, flood * 0.7, winter));
  if (shelterCache.size > 8192) {
    const first = shelterCache.keys().next();
    if (!first.done)
      shelterCache.delete(first.value);
  }
  shelterCache.set(key, v);
  return v;
};
/** Tiles: each world chunk is CHUNK_TILES across (re-exported for the page's particle maths). */
export const WEATHER_TILES = CHUNK_TILES;
export { DAYS_PER_YEAR };
