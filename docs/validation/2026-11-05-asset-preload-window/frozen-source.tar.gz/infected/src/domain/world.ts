import type { PersonAddressContext } from "./person-address";
/** World layout shared by the page and the chunk workers. */
export const TILE = 16;
export const CHUNK_TILES = 128;
/** Chunk side in world units (pixels at zoom 1). */
export const CHUNK_SIZE = TILE * CHUNK_TILES;
/** How far (world units) past its chunk's border someone strays before the neighbour takes them. */
export const HANDOFF_MARGIN = 32;
/** The world is WORLD_CHUNKS × WORLD_CHUNKS chunks, centred on chunk 0,0. */
export const WORLD_CHUNKS = 64;
export const WORLD_MIN = -WORLD_CHUNKS / 2;
export const WORLD_MAX = WORLD_CHUNKS / 2 - 1;
export const TICK_RATE = 60;
export const WARM_EVERY = 48;
/** Lockstep (a local pool's workers): ticks between a hand-off or post and the tick it lands on. */
export const LOCKSTEP_LEAD = 2;
export const SEED = 1337;

export const inWorld = (cx: number, cy: number) => cx >= WORLD_MIN && cx <= WORLD_MAX && cy >= WORLD_MIN && cy <= WORLD_MAX;

/** Deterministic 32-bit hash of integers. */
export const hash = (...values: number[]) => {
  let h = 0x811c9dc5;
  for (const value of values) {
    h = Math.imul(h ^ (value | 0), 0x01000193);
    h ^= h >>> 15;
    h = Math.imul(h, 0x2c1b3c6d);
    h ^= h >>> 12;
  }
  return h >>> 0;
};

/** A small seeded generator (mulberry32). */
export const rng = (seed: number) => {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

/**
 * Geographic residents use their source's immutable population/home allocations. The numeric
 * scope preserves authored fixtures and saves whose IDs encode a small region's coordinates.
 * A missing geographic allocation is a generation invariant failure, never a wrapped fallback.
 */
export const gidFor = (cx: number, cy: number, index: number, scope: number | PersonAddressContext = 0) => {
  if (typeof scope !== "number" && scope.source?.personAddresses) {
    const gid = scope.source.personAddresses.id({ cx, cy, index });
    if (gid === null) throw new RangeError(`No resident identity for ${cx},${cy}:${index}`);
    return gid;
  }
  const space = typeof scope === "number" ? scope : scope.space;
  return inWorld(cx, cy)
    ? (((cy - WORLD_MIN) * WORLD_CHUNKS + (cx - WORLD_MIN)) * 16384 + index + (space & 31) * 0x4000000) >>> 0
    : (0x80000000 | ((cx & 1023) << 21) | ((cy & 1023) << 11) | (index & 2047)) >>> 0;
};
