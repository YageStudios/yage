import type { MapLandscapeSource } from "../../realworld/map-landscape-source";
import type { MapLandscapeLayer } from "../../worldmap/landscape-layer";
import type { MapRoadSource } from "../../realworld/map-road-source";
import type { MapRoadLayer } from "../../worldmap/road-layer";
import type { MapTileLayer } from "../../worldmap/tile-layer";
import type { MapAreaLayer } from "../../worldmap/area-layer";
import type { StampGpuLibrary } from "../../worldmap/stamp-tile";
import type { GeographicWorld } from "../../realworld/global";
import type { GeographicMapTiles } from "../../realworld/map-tile-client";
import { Component, Schema, nullable, type } from "minecs";
import type * as PIXI from "pixi.js";
import type { MapLayers } from "../../worldmap/layer";

/** The strategic map's external handles: the stage it draws on, its retained layers, and the weather wash canvas (WorldMapAssets allocates and releases them). */
@Component()
export class WorldMapResources extends Schema {
  @nullable() @type("object") geography: GeographicWorld | null;
  @nullable() @type("object") tiles: GeographicMapTiles | null;
  @nullable() @type("object") terrain: MapTileLayer | null;
  @nullable() @type("object") detailTiles: GeographicMapTiles | null;
  @nullable() @type("object") detailLayer: MapTileLayer | null;
  @nullable() @type("object") stampLibrary: StampGpuLibrary | null;
  @nullable() @type("object") landscape: MapLandscapeSource | null;
  @nullable() @type("object") landscapeLayer: MapLandscapeLayer | null;
  @nullable() @type("object") roads: MapRoadSource | null;
  @nullable() @type("object") roadLayer: MapRoadLayer | null;
  @nullable() @type("object") lakeLayer: MapAreaLayer | null;
  @nullable() @type("object") keepAlive: ((texture: PIXI.Texture) => void) | null;
  @nullable() @type("object") upload: ((texture: PIXI.Texture) => void) | null;
  @type("object") stage: PIXI.Container;
  /** The retained base, overlay and legend rasters (worldmap/layer). */
  @nullable() @type("object") layers: MapLayers | null;
  @nullable() @type("object") wash: HTMLCanvasElement | null;
  /** The camera scale last frame, and when (ms) it last changed: a drifted drawing sharpens once the zoom rests. */
  @type("number") lastScale: number;
  @type("number") zoomedAt: number;
  /** How many plans the map's detail had when last counted, and when (ms): a newly prepared one redraws the base. */
  @type("number") plans: number;
  @type("number") plansAt: number;
}
