import {readFile,writeFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const home='/tmp/asset-preload-window',sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function pin(file){const bytes=await readFile(file);return{file,bytes:bytes.length,sha256:sha(bytes)};}
async function walk(dir){let paths=[];for(const row of await readdir(dir,{withFileTypes:true})){const path=dir+'/'+row.name;if(row.isDirectory())paths.push(...await walk(path));else paths.push(path);}return paths;}
const variants={};
for(const [i,name]of ['original','candidate'].entries()){
 const dir=home+'/'+name,report=JSON.parse(await readFile(dir+'/http-preflight.json'));
 if(report.errors.length||report.epochs.length!==1)throw Error('HTTP closure not green');
 const files=await walk(dir+'/cache');const optimizerFiles=await Promise.all(files.sort().map(pin));
 variants[name]={port:5423+i,manifest:await pin(dir+'/source-manifest.json'),ledger:await pin(dir+'/asset-pins.jsonl'),sourceEpoch:report.epochs[0],optimizerFiles,httpPreflight:await pin(dir+'/http-preflight.json')};
}
const original=JSON.parse(await readFile(variants.original.manifest.file)),candidate=JSON.parse(await readFile(variants.candidate.manifest.file));
const changes=original.files.filter((row,i)=>{if(row.path!==candidate.files[i].path)throw Error('Source inventory order changed');return row.sha256!==candidate.files[i].sha256;}).map(row=>({path:row.path,before:row.sha256,after:candidate.files.find(r=>r.path===row.path).sha256}));
if(changes.length!==1||changes[0].path!=='yage/engine/data/AssetCache.ts')throw Error('Expected single runtime source delta');
const runtimeHelpers=['driver.mjs','process-guard.mjs','isolate-inventory.mjs','expected.json','native-benchmark-contract.md','fixture-controls.mjs','fixture-controls.json'];
for(const name of ['original','candidate'])for(const file of ['config.mjs','pinned-source.mjs','asset-plugin.mjs','response-accounting.mjs','fixture.mjs','expected.json'])runtimeHelpers.push(name+'/'+file);
const helpers=await Promise.all(runtimeHelpers.map(file=>pin(home+'/'+file)));
const ready={v:1,sourceRoot:'/tmp/infected-active-current-20261104',baseManifestSHA256:original.baseManifestSHA256,heads:original.heads,changes,variants,helpers,controls:{cache:await pin(home+'/controls.json'),types:await pin(home+'/types.json'),coverage:await pin(home+'/coverage-summary.json'),fixture:await pin(home+'/fixture-controls.json')},limits:{coldMs:45000,warmMs:45000,moduleReadyMs:15000,verificationMs:15000,browserMs:90000,maxPSS:4*1024**3,minAvailable:8*1024**3,pssIntervalMs:500,metadataMs:3000,getterBytes:4096,maxReceipts:256},qualification:'Actual complete dataset/cache/IndexedDB benchmark, no game/main/scene/atlas/map/worker execution. Sequential original then candidate fresh browser profiles share OS page cache. Base engine685 remains distinct from current marker850; only AssetCache differs. Concurrent failure suffix side effects explicitly documented; no cache policy/GC/entity/retention change.'};
await writeFile(home+'/ready.json',JSON.stringify(ready,null,2));
console.log(JSON.stringify({ready:await pin(home+'/ready.json'),changes,variants:Object.fromEntries(Object.entries(variants).map(([k,v])=>[k,{port:v.port,sourceEpoch:v.sourceEpoch,optimizerFiles:v.optimizerFiles.length,manifest:v.manifest,ledger:v.ledger}]))},null,2));
