import type { AssetRecord, AssetStore } from "yage/data/AssetCache";

type ReadPhases = { key: string; path?: string; requestedBytes?: number; offset?: number; reads: number; readMs: number; writes: number; writeMs: number; headersMs: number; bodyMs: number; bodyBytes: number; status?: number; failures: number };
type Pending = { phase: "read" | "write" | "headers" | "body"; key: string; bytes: number; started: number };

/** Measures the cache's existing transaction boundaries without changing when bytes become ready. */
export class MapAssetReadTrace {
  private boot = Array<number>(26).fill(0);
  private bootPending = Array<number>(8).fill(0);
  private records = new Map<string, ReadPhases>();
  private requests = new Map<string, string>();
  private pending = new Set<Pending>();
  private totals = { reads: 0, readMs: 0, writes: 0, writeMs: 0, headersMs: 0, bodyMs: 0, bodyBytes: 0, failures: 0, peakWriteBytes: 0 };
  constructor(private now: () => number = () => performance.now()) {}
  register(base: string, asset: AssetRecord) {
    const record = this.record(asset.sha256);
    record.path = asset.path; record.requestedBytes = asset.bytes; record.offset = asset.offset;
    const range = asset.offset !== undefined && asset.bytes ? `bytes=${asset.offset}-${asset.offset + asset.bytes - 1}` : "";
    this.requests.set(`${new URL(asset.path, base).href}|${range}`, asset.sha256);
    if (this.requests.size > 256) this.requests.delete(this.requests.keys().next().value!);
  }
  private record(key: string) {
    let record = this.records.get(key);
    if (!record) {
      record = { key, reads: 0, readMs: 0, writes: 0, writeMs: 0, headersMs: 0, bodyMs: 0, bodyBytes: 0, failures: 0 };
      this.records.set(key, record);
      if (this.records.size > 256) for (const candidate of this.records.keys()) {
        if (candidate !== key && ![...this.pending].some(item => item.key === candidate)) { this.records.delete(candidate); break; }
      }
    }
    return record;
  }
  private async measure<T>(phase: Pending["phase"], key: string, bytes: number, run: () => Promise<T>): Promise<T> {
    const pending = { phase, key, bytes, started: this.now() }, record = this.record(key);
    this.pending.add(pending);
    if (phase === "read") this.boot[12]++;
    if (phase === "headers") { this.bootPending[6]++; this.bootPending[7] = Math.max(this.bootPending[7], this.bootPending[6]); }
    if (phase === "write") { this.boot[16]++; this.bootPending[3]++; this.bootPending[4] += bytes; this.bootPending[5] = Math.max(this.bootPending[5], this.bootPending[4]); }
    if (phase === "body") { this.boot[8]++; this.bootPending[0]++; this.bootPending[1] += bytes; this.bootPending[2] = Math.max(this.bootPending[2], this.bootPending[1]); }
    this.totals.peakWriteBytes = Math.max(this.totals.peakWriteBytes, this.pendingWriteBytes());
    try {
      const value = await run();
      if (phase === "read") { this.boot[13]++; if (value instanceof ArrayBuffer) this.boot[14] += value.byteLength; }
      if (phase === "write") { this.boot[17]++; this.boot[18] += bytes; }
      if (phase === "body") { this.boot[9]++; if (value instanceof ArrayBuffer) this.boot[10] += value.byteLength; }
      return value;
    }
    catch (error) {
      if (phase === "read") this.boot[15]++;
      if (phase === "headers") this.boot[25]++;
      if (phase === "write") this.boot[19]++;
      if (phase === "body") this.boot[11]++;
      record.failures++; this.totals.failures++; throw error;
    }
    finally {
      const elapsed = this.now() - pending.started;
      if (phase === "read") { record.reads++; this.totals.reads++; record.readMs += elapsed; this.totals.readMs += elapsed; }
      if (phase === "write") { record.writes++; this.totals.writes++; record.writeMs += elapsed; this.totals.writeMs += elapsed; }
      if (phase === "headers") { record.headersMs += elapsed; this.totals.headersMs += elapsed; }
      if (phase === "body") { record.bodyMs += elapsed; this.totals.bodyMs += elapsed; }
      this.pending.delete(pending);
      if (phase === "headers") this.bootPending[6]--;
      if (phase === "write") { this.bootPending[3]--; this.bootPending[4] -= bytes; }
      if (phase === "body") { this.bootPending[0]--; this.bootPending[1] -= bytes; }
    }
  }
  private pendingWriteBytes() {
    let bytes = 0;
    for (const pending of this.pending) if (pending.phase === "write") bytes += pending.bytes;
    return bytes;
  }
  store(store: AssetStore): AssetStore {
    return {
      read: key => this.measure("read", key, this.records.get(key)?.requestedBytes ?? 0, () => store.read(key)),
      write: (key, bytes) => this.measure("write", key, bytes.byteLength, () => store.write(key, bytes)),
    };
  }
  fetch(fetcher: typeof fetch): typeof fetch {
    return async (input, init) => {
      const url = input instanceof Request ? input.url : String(input);
      const range = new Headers(init?.headers).get("Range") ?? "";
      const key = this.requests.get(`${url}|${range}`) ?? `${url}|${range}`;
      const city = url.split("?")[0].endsWith("/city_detail.zip");
      this.boot[0]++; if (city) this.boot[20]++;
      if (range) {
        const closed = /^bytes=(\d+)-(\d+)$/.exec(range);
        if (closed && +closed[2] >= +closed[1]) {
          const requested = +closed[2] - +closed[1] + 1;
          this.boot[1]++; this.boot[2] += requested; if (city) this.boot[21] += requested;
        } else this.boot[3]++;
      }
      const response = await this.measure("headers", key, 0, () => fetcher(input, init));
      if (response.status === 200) this.boot[4]++;
      else if (response.status === 206) { this.boot[5]++; if (city) this.boot[22]++; }
      else this.boot[6]++;
      const lengthHeader = response.headers.get("Content-Length");
      const knownLength = lengthHeader !== null && /^\d+$/.test(lengthHeader) && Number.isSafeInteger(+lengthHeader);
      const length = knownLength ? +lengthHeader : 0;
      if (knownLength) this.boot[7] += length; else this.boot[24]++;
      const record = this.record(key);
      record.status = response.status;
      const arrayBuffer = response.arrayBuffer.bind(response);
      // Keep the original Response (status, headers and errors), timing only the body method AssetCache uses.
      response.arrayBuffer = async () => {
        const bytes = await this.measure("body", key, length, arrayBuffer);
        if (city) this.boot[23] += bytes.byteLength;
        record.bodyBytes += bytes.byteLength; this.totals.bodyBytes += bytes.byteLength;
        return bytes;
      };
      return response;
    };
  }
  bootSnapshot() { return { t: this.boot.slice(), p: this.bootPending.slice() }; }
  snapshot(key?: string) {
    const now = this.now();
    return { ...this.totals, pendingWriteBytes: this.pendingWriteBytes(),
      pending: [...this.pending].map(item => ({ ...item, path: this.records.get(item.key)?.path, elapsedMs: now - item.started })),
      last: key && this.records.has(key) ? { ...this.records.get(key)! } : undefined };
  }
}
export type MapAssetReadSnapshot = ReturnType<MapAssetReadTrace["snapshot"]>;
