import {
  AssetCache,
  IndexedDBAssetStore,
  type AssetRecord,
} from "yage/data/AssetCache";
import { MapAssetReadTrace } from "./map-asset-read-trace";
export type WorldAssetManifest = {
  schema: number;
  generated_utc: string;
  files: AssetRecord[];
  /** The archives' member index (tools/index-world-archives.mjs), when imported: apart from `files`, which pin the source's identity. */
  members?: AssetRecord;
  /** Baked city detail (landmarks, streets, zoning; tools/import-worldmap.mjs), when the pack has it: apart from `files`, read by range only. */
  city_detail?: AssetRecord & { schema: string; source_release: string };
  /** Worldwide OSM land polygons, simplified by zoom and read by range. */
  coastlines?: AssetRecord;
  /** Retained global coast triangles; no raster fallback is enlarged during zoom. */
  map_coast?: AssetRecord;
  /** Finest source coastline, pre-triangulated into independently verified raw surface shards. */
  map_coast_fine?: AssetRecord;
  /** Global inland-water contours; separate from the ocean coastline. */
  map_lakes?: AssetRecord;
  /** Import-time surveyed street instances; index pins every geographic tile independently. */
  map_roads?: AssetRecord;
  /** Pre-triangulated parks/water plus instanced river and transport linework. */
  map_landscape?: AssetRecord;
  /** Exact canonical shells baked for a pinned source, generator and geographic anchor. */
  map_shells?: AssetRecord & { encoding?: string };
  /** Single-LOD canonical building instances grouped in fixed geographic storage tiles. */
  map_shell_instances?: AssetRecord & { encoding: string; storageZoom: number; instanceAtlasSchema?: number };
};
/** Bundled manifest pins data identity even when reopening the map without a network. */
import manifest from "./asset-manifest.json";
export const WORLD_ASSETS: WorldAssetManifest = manifest;
export const worldDataBase = () =>
  new URL(
    `${import.meta.env.BASE_URL}world-data/`,
    typeof document === "undefined" ? new URL("../", location.href).href : location.href
  ).href;
let cache: AssetCache | undefined;
export const worldAssetReadTrace = new MapAssetReadTrace();
(globalThis as any).__currentBootIO = () => {
  const existing = cache as unknown as { pending: Map<string, unknown>; verified: Set<string> } | undefined;
  return { v: 1, r: typeof document === "undefined" ? 1 : 0, ...worldAssetReadTrace.bootSnapshot(),
    c: [existing ? 1 : 0, existing?.pending.size ?? 0, existing?.verified.size ?? 0],
    a: [performance.timeOrigin, performance.now()] };
};
/** One cache per context shares pending reads and verification state. */
export const worldAssetCache = () =>
  (cache ??= new AssetCache(worldAssetReadTrace.store(new IndexedDBAssetStore(indexedDB, "infected-world-data")), worldAssetReadTrace.fetch((input, init) => fetch(input, init))));
export const readWorldAsset = (base: string, asset: AssetRecord) => {
  worldAssetReadTrace.register(base, asset);
  return worldAssetCache().load(base, asset);
};
export const worldAsset = (path: string): AssetRecord => {
  const asset = WORLD_ASSETS.files.find(
    (asset) => asset.path === (path.endsWith(".gz") ? `${path}.bin` : path)
  );
  if (!asset) throw new Error(`Unknown world asset: ${path}`);
  return asset;
};
