import ts from '/data/workspace/sky-harbor/worldmap-integration/infected/node_modules/typescript/lib/typescript.js';
import {writeFile} from 'node:fs/promises';
const home='/tmp/asset-preload-window',root=home+'/checkpoint/yage',engine='/data/workspace/sky-harbor/worldmap-integration/yage';
const program=ts.createProgram([root+'/engine/data/AssetCache.ts',root+'/test/asset-preload.test.ts',root+'/test/asset-cache.test.ts'],{strict:true,noEmit:true,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,moduleResolution:ts.ModuleResolutionKind.Bundler,lib:['lib.es2022.d.ts','lib.dom.d.ts'],types:['node'],typeRoots:[engine+'/node_modules/@types'],paths:{vitest:[engine+'/node_modules/vitest']}});
const diagnostics=ts.getPreEmitDiagnostics(program).map(d=>({file:d.file?.fileName,line:d.file&&d.start!==undefined?d.file.getLineAndCharacterOfPosition(d.start).line+1:null,code:d.code,text:ts.flattenDiagnosticMessageText(d.messageText,'\n')}));
await writeFile(home+'/portable-types.json',JSON.stringify(diagnostics,null,2)+'\n');console.log(JSON.stringify({diagnostics:diagnostics.length,first:diagnostics.slice(0,5)}));if(diagnostics.length)process.exitCode=1;
