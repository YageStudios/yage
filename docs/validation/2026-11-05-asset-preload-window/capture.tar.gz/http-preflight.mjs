import {writeFile} from 'node:fs/promises';
import ts from '/data/workspace/sky-harbor/worldmap-integration/infected/node_modules/typescript/lib/typescript.js';
const home='/tmp/asset-preload-window',root='/tmp/infected-active-current-20261104';
for(const [index,variant]of ['original','candidate'].entries()){
 const origin='http://127.0.0.1:'+(5423+index),queue=['/@fs'+home+'/'+variant+'/fixture.mjs'],seen=new Set(queue),rows=[],edges=[],errors=[],epochs=new Set(),identities=new Map();
 const began=Date.now();
 const html=await fetch(origin+'/preload-benchmark.html');const markup=await html.text();if(!html.ok||!html.headers.get('content-type')?.includes('text/html')||markup.includes('boot.ts')||markup.includes('main.ts'))throw Error('Wrong fixture HTML');
 for(let cursor=0;cursor<queue.length;cursor++){
  if(queue.length>4000)throw Error('Import closure capacity exceeded');
  const url=queue[cursor];
  try{
   const response=await fetch(origin+url,{signal:AbortSignal.timeout(15000)}),code=await response.text(),mime=response.headers.get('content-type')??'';
   const actual=new URL(url,origin);if(actual.searchParams.has('g'))epochs.add(actual.searchParams.get('g'));
   const row={url,status:response.status,mime,bytes:Buffer.byteLength(code)};rows.push(row);
   if(!response.ok||!/(javascript|ecmascript)/i.test(mime)||/^\s*(?:<!doctype|<html)/i.test(code)){errors.push({...row,body:code.slice(0,200)});continue;}
   const pos=actual.pathname.indexOf('/yage/engine/');if(pos>=0){const key=actual.pathname.slice(pos+6),canonical='/@fs'+root+'/yage/'+key;if(actual.pathname!==canonical)errors.push({url,error:'Noncanonical engine identity',canonical});const prior=identities.get(key);if(prior&&prior!==actual.pathname)errors.push({url,error:'Duplicate engine identity'});identities.set(key,actual.pathname);}
   if(/\/(boot|main)\.ts$/.test(actual.pathname))errors.push({url,error:'Game entry in fixture closure'});
   for(const item of ts.preProcessFile(code,true,true).importedFiles){const spec=item.fileName;if(!spec.startsWith('/')&&!spec.startsWith('.'))continue;const next=new URL(spec,origin+url);if(next.origin!==origin)throw Error('External import');const path=next.pathname+next.search;edges.push({from:url,to:path});if(!seen.has(path)){seen.add(path);queue.push(path);}}
  }catch(error){errors.push({url,error:error.stack});}
 }
 const report={began,ended:Date.now(),variant,rows,edges,epochs:[...epochs],engineKeys:identities.size,errors};
 await writeFile(home+'/'+variant+'/http-preflight.json',JSON.stringify(report,null,2));console.log(JSON.stringify({variant,modules:rows.length,edges:edges.length,epochs:report.epochs,engineKeys:identities.size,errors:errors.slice(0,4)}));if(errors.length||epochs.size!==1)process.exitCode=1;
}
