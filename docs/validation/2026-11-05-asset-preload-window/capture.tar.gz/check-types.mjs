import ts from '/data/workspace/sky-harbor/worldmap-integration/infected/node_modules/typescript/lib/typescript.js';
import {writeFile} from 'node:fs/promises';
const home='/tmp/asset-preload-window',variants={};
for(const variant of ['original','candidate']){
 const program=ts.createProgram([home+'/'+variant+'.ts'],{strict:true,noEmit:true,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,lib:['lib.es2022.d.ts','lib.dom.d.ts'],types:[]});
 variants[variant]=ts.getPreEmitDiagnostics(program).map(d=>({file:d.file?.fileName,line:d.file&&d.start!==undefined?d.file.getLineAndCharacterOfPosition(d.start).line+1:null,code:d.code,text:ts.flattenDiagnosticMessageText(d.messageText,'\n')}));
}
await writeFile(home+'/types.json',JSON.stringify(variants,null,2)+'\n');console.log(JSON.stringify(variants));if(variants.original.length||variants.candidate.length)process.exitCode=1;
