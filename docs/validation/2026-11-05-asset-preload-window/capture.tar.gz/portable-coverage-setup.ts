import { afterAll } from "vitest";
import { writeFileSync } from "node:fs";
afterAll(() => { writeFileSync(`/tmp/asset-preload-window/portable-coverage-${process.pid}-${Math.random()}.json`, JSON.stringify((globalThis as any).__coverage__)); });
