import base from './portable-test.config.mjs';
export default {...base,plugins:[{name:'original-actual-module-control',enforce:'pre',resolveId(id,importer){if(id==='../engine/data/AssetCache'&&importer?.includes('/checkpoint/yage/test/'))return '/tmp/asset-preload-window/original.ts';}}],test:{...base.test,include:['test/asset-preload.test.ts']}};
