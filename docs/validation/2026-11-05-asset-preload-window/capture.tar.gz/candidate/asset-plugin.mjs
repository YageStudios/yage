import { responseAccounting } from './response-accounting.mjs';
import { createReadStream, readFileSync, existsSync } from 'node:fs';
import { mkdir, stat, readFile, appendFile, rename } from 'node:fs/promises';
import { pipeline } from 'node:stream/promises';
import { Transform } from 'node:stream';
import { createWriteStream } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, dirname } from 'node:path';
import { gunzipSync } from 'node:zlib';
export function guardedAssets({ source, target, ledger, expectedManifest, fallback }) {
  const pending = new Map(), pins = new Map();
  const responses = responseAccounting();
  let total = 0, failure = null, roadTotal = 0, baselineTotal = 0;
  const limit = 2 * 1024 ** 3, roadLimit = 512 * 1024 ** 2;
  const expected = new Map();
  const collect = value => { if (!value || typeof value !== 'object') return; if (typeof value.path === 'string' && typeof value.sha256 === 'string') expected.set('world-data/' + value.path, value); for (const child of Object.values(value)) collect(child); };
  const manifest = JSON.parse(readFileSync(expectedManifest, 'utf8'));
  collect(manifest);
  // Only the frozen manifest's verified catalog chain may authorize individual children.
  const visitedCatalogs = new Set();
  const catalog = (asset, encoding = asset.encoding ?? 'gzip') => {
    if (visitedCatalogs.has(asset.path)) return;
    const candidates = [resolve(target, 'world-data/' + asset.path), resolve(source, 'world-data/' + asset.path)];
    const indexPath = candidates.find(path => existsSync(path) && (() => { const bytes = readFileSync(path); return bytes.length === asset.bytes && createHash('sha256').update(bytes).digest('hex') === asset.sha256; })());
    if (!indexPath) throw Error('Current frozen catalog not preflighted: ' + asset.path);
    const bytes = readFileSync(indexPath);
    visitedCatalogs.add(asset.path);
    const value = JSON.parse((encoding === 'raw' ? bytes : gunzipSync(bytes)).toString('utf8'));
    collect(value);
    if (value.cellIndex) catalog(value.cellIndex);
    for (const child of Object.values(value.directories ?? {})) catalog(child, child.encoding ?? 'raw');
  };
  for (const name of ['map_roads', 'map_landscape', 'map_shells', 'map_shell_instances', 'map_coast_fine']) if (manifest[name]) catalog(manifest[name]);
  if (existsSync(ledger)) for (const line of readFileSync(ledger, 'utf8').split('\n').filter(Boolean)) {
    const pin = JSON.parse(line);
    if (pins.has(pin.path)) throw Error('Duplicate asset ledger pin: ' + pin.path);
    pins.set(pin.path, pin); total += pin.bytes;
    if (pin.path.includes('/map-roads/')) roadTotal += pin.bytes; else baselineTotal += pin.bytes;
    const declared = expected.get(pin.path);
    if (declared && (declared.bytes !== pin.bytes || declared.sha256 !== pin.sha256)) throw Error('Existing asset pin differs from frozen manifest: ' + pin.path);
  }
  async function materialize(path) {
    if (pins.has(path)) return pins.get(path);
    if (pending.has(path)) return pending.get(path);
    const task = (async () => {
      const declared = expected.get(path);
      if (!declared) throw Error('Asset absent from current frozen manifest/catalogs: ' + path);
      const copy = resolve(target, path);
      if (!copy.startsWith(target + '/')) throw Error('Unsafe private asset path');
      const road = path.includes('/map-roads/');
      if (!road && baselineTotal + declared.bytes > limit) throw Error('Diagnostic mandatory asset budget exceeds 2 GiB');
      if (road && roadTotal + declared.bytes > roadLimit) throw Error('Diagnostic lazy road budget exceeds 512 MiB');
      total += declared.bytes;
      if (road) roadTotal += declared.bytes; else baselineTotal += declared.bytes;
      const candidates = [[target, copy], [source, resolve(source, path)], ...(fallback ? [[fallback, resolve(fallback, path)]] : [])];
      let pin;
      for (const [pool, original] of candidates) {
        if (!original.startsWith(pool + '/') || !existsSync(original)) continue;
        const before = await stat(original);
        if (before.size !== declared.bytes) continue;
        const digest = createHash('sha256'); let bytes = 0;
        const reuse = pool === source || pool === target;
        if (reuse) {
          for await (const chunk of createReadStream(original)) { digest.update(chunk); bytes += chunk.length; }
        } else {
          await mkdir(dirname(copy), { recursive: true });
          await pipeline(createReadStream(original), new Transform({ transform(chunk, _, callback) { digest.update(chunk); bytes += chunk.length; callback(null, chunk); } }), createWriteStream(copy + '.pending'));
        }
        const after = await stat(original), sha256 = digest.digest('hex');
        if (before.size !== after.size || before.mtimeMs !== after.mtimeMs || bytes !== before.size) throw Error('Asset changed during pin: ' + path);
        if (bytes !== declared.bytes || sha256 !== declared.sha256) continue;
        if (!reuse) await rename(copy + '.pending', copy);
        pin = { path, source: original, copy: reuse ? original : copy, bytes, sha256, mtimeMs: before.mtimeMs, readOnlyReuse: reuse };
        break;
      }
      if (!pin) throw Error('Current declared asset unavailable or mismatched: ' + path);
      pins.set(path, pin); await appendFile(ledger, JSON.stringify(pin) + '\n'); return pin;
    })();
    pending.set(path, task);
    try { return await task; } finally { pending.delete(path); }
  }
  return { name: 'diagnostic-guarded-assets', configureServer(server) {
    server.middlewares.use(async (req, res, next) => {
      const path = decodeURIComponent(new URL(req.url ?? '/', 'http://local').pathname);
      if (path === '/__diagnostic/boot') { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ v: 1, total, baselineTotal, roadTotal, failed: failure !== null, responses: responses.snapshot() })); return; }
      if (path === '/__diagnostic/assets') { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ total, baselineTotal, limit, roadTotal, roadLimit, failure, responses: responses.snapshot(), pins: [...pins.values()] })); return; }
      if (!path.startsWith('/world-data/')) return next();
      responses.observe(req, res, path);
      try {
        const pin = await materialize(path.slice(1));
        let start = 0, end = pin.bytes - 1;
        if (req.headers.range) { const match = /^bytes=(\d+)-(\d*)$/.exec(req.headers.range); if (!match) throw Error('Unsupported Range'); start = +match[1]; if (match[2]) end = +match[2]; res.statusCode = 206; res.setHeader('Content-Range', `bytes ${start}-${end}/${pin.bytes}`); }
        res.setHeader('Content-Length', end - start + 1); res.setHeader('Content-Type', path.endsWith('.json') ? 'application/json' : 'application/octet-stream');
        res.setHeader('Accept-Ranges', 'bytes'); await pipeline(createReadStream(pin.copy, { start, end }), res);
      } catch (error) { failure = error.stack; res.statusCode = 500; res.end(String(error)); }
    });
  } };
}
