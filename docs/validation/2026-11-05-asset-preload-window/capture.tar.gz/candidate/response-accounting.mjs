import {errorMonitor} from 'node:events';
export function responseAccounting(){
  const rows=Array.from({length:6},()=>Array(13).fill(0));
  function observe(req,res,path){
    const family=path.endsWith('/city_detail.zip')?1:path.includes('/coastlines.zip')||path.includes('/map-coast')?2:path.endsWith('.zip')?3:path.includes('/data/map-')?4:5;
    const selected=[rows[0],rows[family]],add=(field,value=1)=>{for(const row of selected)row[field]+=value;};
    add(0);const range=typeof req.headers.range==='string'?/^bytes=(\d+)-(\d*)$/.exec(req.headers.range):null;
    if(range){const start=+range[1],end=range[2]?+range[2]:null;if(end===null)add(3);else if(Number.isSafeInteger(start)&&Number.isSafeInteger(end)&&end>=start){add(1);add(2,end-start+1);}}
    const write=res.write,end=res.end;let accepted=0,classified=false,finished=false,aborted=false,depth=0,finishSeen=false;
    const classify=()=>{if(classified)return;classified=true;add(res.statusCode===200?4:res.statusCode===206?5:6);const raw=res.getHeader('Content-Length'),text=typeof raw==='string'||typeof raw==='number'?String(raw):'',length=/^\d+$/.test(text)?Number(text):NaN;if(Number.isSafeInteger(length)&&length>=0)add(7,length);else add(12);};
    const cleanup=()=>{res.removeListener('finish',onFinish);res.removeListener('close',onClose);res.removeListener(errorMonitor,onError);if(res.write===wrappedWrite)res.write=write;if(res.end===wrappedEnd)res.end=end;};
    const finalize=()=>{if(!finishSeen||depth||finished||aborted)return;finished=true;classify();add(9);add(10,accepted);cleanup();};
    const onFinish=()=>{finishSeen=true;finalize();};
    const onError=()=>{if(!finished&&!aborted){aborted=true;add(11);classify();cleanup();}};
    const onClose=()=>{if(!finished)onError();else cleanup();};
    const size=(chunk,encoding)=>typeof chunk==='string'?Buffer.byteLength(chunk,typeof encoding==='string'?encoding:undefined):Buffer.isBuffer(chunk)||ArrayBuffer.isView(chunk)?chunk.byteLength:0;
    const account=(original,receiver,args)=>{depth++;try{const result=original.apply(receiver,args),bytes=size(args[0],args[1]);accepted+=bytes;add(8,bytes);classify();return result;}finally{depth--;finalize();}};
    function wrappedWrite(...args){return account(write,this,args);}
    function wrappedEnd(...args){return account(end,this,args);}
    res.once('finish',onFinish);res.once('close',onClose);res.once(errorMonitor,onError);res.write=wrappedWrite;res.end=wrappedEnd;
  }
  return{observe,snapshot:()=>({v:1,k:rows.map(row=>row.slice())})};
}
