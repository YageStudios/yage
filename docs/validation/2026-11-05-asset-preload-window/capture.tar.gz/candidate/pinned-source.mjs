import {readFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {createHash} from 'node:crypto';
export function pinnedSource(manifest,root){
  const files=new Map(),aliases=new Map();
  for(const row of manifest.files){const canonical=root+'/'+row.path;files.set(canonical,row);aliases.set(canonical,canonical);aliases.set(row.source,canonical);}
  const engine=JSON.parse(readFileSync(files.get(root+'/yage/package.json').file));
  function engineSource(id){
    const key=id==='yage'?'.':'./'+id.slice(5);
    let selected=engine.exports[key],replacement=null;
    if(!selected)for(const [pattern,target]of Object.entries(engine.exports)){
      if(!pattern.includes('*'))continue;
      const [first,last]=pattern.split('*');
      if(key.startsWith(first)&&key.endsWith(last)){selected=target;replacement=key.slice(first.length,key.length-last.length);break;}
    }
    let source=typeof selected==='string'?selected:selected?.['yage-source'];
    if(!source)throw Error('No frozen yage source export '+id);
    if(replacement!==null)source=source.replace('*',replacement);
    const canonical=resolve(root+'/yage',source);
    if(!files.has(canonical))throw Error('Yage source export outside frozen inventory '+id);
    return canonical;
  }
  return{name:'pinned-current-active-source',enforce:'pre',resolveId(id,importer){
    const q=id.indexOf('?'),bare=q<0?id:id.slice(0,q),query=q<0?'':id.slice(q);
    if(bare==='yage'||bare.startsWith('yage/'))return engineSource(bare)+query;
    if(!bare.startsWith('/')&&(!bare.startsWith('.')||!importer))return;
    const path=bare.startsWith('/')?bare.replace(/^\/@fs/,''):resolve(dirname(importer.split('?')[0]),bare);
    for(const candidate of[path,path+'.ts',path+'/index.ts'])if(aliases.has(candidate))return aliases.get(candidate)+query;
  },load(id){
    const row=files.get(id.split('?')[0]);if(!row)return;
    const bytes=readFileSync(row.file);
    if(bytes.length!==row.bytes||createHash('sha256').update(bytes).digest('hex')!==row.sha256)throw Error('Current frozen source changed '+row.path);
    return id.includes('?raw')?'export default '+JSON.stringify(bytes.toString()):bytes.toString();
  }};
}
