import {preloadGeographicSources} from '/@fs/tmp/infected-active-current-20261104/infected/src/realworld/dataset.ts';
const expected=await (await fetch(new URL('./expected.json',import.meta.url))).json();
const sha=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');
const base=new URL('/world-data/',location.href).href;
let state={v:1,status:'ready',phase:null,requested:null,completed:null,duration:null,progressCount:0,lastProgress:null,progressSHA256:null,verification:null,error:null};
let active=false;
const getter=()=>({...state,io:typeof globalThis.__currentBootIO==='function'?globalThis.__currentBootIO():null,a:[performance.timeOrigin,performance.now()]});
globalThis.__preloadBenchmark=getter;
globalThis.__startPreloadBenchmark=phase=>{
 if(active||!['cold','warm'].includes(phase)||phase==='cold'&&state.status!=='ready'||phase==='warm'&&state.status!=='verified')throw Error('Invalid benchmark phase/order');
 active=true;
 const progress=new Float64Array(expected.count*2);
 state={...state,status:'running',phase,requested:performance.now(),completed:null,duration:null,progressCount:0,lastProgress:null,progressSHA256:null,error:null};
 void (async()=>{
  try{
   await preloadGeographicSources((complete,total)=>{
    const at=state.progressCount;
    if(at>=expected.count)throw Error('Progress receipt capacity exceeded');
    progress[at*2]=complete;progress[at*2+1]=total;
    state.progressCount++;state.lastProgress=[complete,total];
   },base,undefined,{citySource:true});
   state.completed=performance.now();state.duration=state.completed-state.requested;
   state.status='hashing-progress';
   state.progressSHA256=await sha(progress.buffer);
   if(state.progressCount!==expected.count||state.progressSHA256!==expected.progressSHA256)throw Error('Complete ordered progress differs');
   state.status=phase==='cold'?'cold-complete':'complete';
  }catch(error){state.status='failed';state.error=String(error?.stack??error);}
  finally{active=false;}
 })();
 return getter();
};
globalThis.__verifyPreloadBenchmark=()=>{
 if(active||state.status!=='cold-complete')throw Error('Cold persistent commits not complete');
 active=true;state.status='verifying';
 void (async()=>{
  let db;
  const began=performance.now();
  try{
   db=await new Promise((resolve,reject)=>{const request=indexedDB.open('infected-world-data',1);request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);request.onupgradeneeded=()=>{request.transaction.abort();reject(Error('Expected database absent'));};});
   const keys=await new Promise((resolve,reject)=>{const tx=db.transaction('assets','readonly'),request=tx.objectStore('assets').getAllKeys();tx.oncomplete=()=>resolve(request.result);tx.onabort=()=>reject(tx.error??Error('Membership transaction aborted'));tx.onerror=()=>reject(tx.error);});
   const keysSHA256=await sha(new TextEncoder().encode(JSON.stringify(keys.sort())));
   if(keys.length!==expected.keysCount||keysSHA256!==expected.keysSHA256)throw Error('Full committed membership differs');
   const samples=[];
   for(const sample of expected.samples){
    const body=await new Promise((resolve,reject)=>{const tx=db.transaction('assets','readonly'),request=tx.objectStore('assets').get(sample.sha256);tx.oncomplete=()=>resolve(request.result);tx.onabort=()=>reject(tx.error??Error('Readback transaction aborted'));tx.onerror=()=>reject(tx.error);});
    if(!(body instanceof ArrayBuffer)||body.byteLength!==sample.bytes||await sha(body)!==sample.sha256)throw Error('Committed readback differs');
    samples.push({sha256:sample.sha256,bytes:body.byteLength});
   }
   state.verification={began,completed:performance.now(),keyCount:keys.length,keysSHA256,samples,mode:'actual IndexedDB readonly after commit'};
   state.status='verified';
  }catch(error){state.status='failed';state.error=String(error?.stack??error);}
  finally{db?.close();active=false;}
 })();
 return getter();
};
