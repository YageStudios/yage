import {chromium} from '/data/workspace/sky-harbor/worldmap-integration/infected/node_modules/playwright-core/index.mjs';
import {readFile,writeFile,appendFile,mkdir} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {createHash} from 'node:crypto';
import {Worker} from 'node:worker_threads';
import {openIsolateInventory} from './isolate-inventory.mjs';
const home='/tmp/asset-preload-window',variant=process.argv[3];
if(!['original','candidate'].includes(variant))throw Error('Explicit variant required');
const out=home+'/'+variant+'/observation';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const bounded = (promise, ms, label) => {
  let timer;
  return Promise.race([promise, new Promise((_, reject) => timer = setTimeout(() => reject(Error(label + ' exceeded ' + ms + ' ms')), ms))]).finally(() => clearTimeout(timer));
};
async function hashFile(file) {
  const digest = createHash('sha256'); let bytes = 0;
  for await (const chunk of createReadStream(file)) { digest.update(chunk); bytes += chunk.length; }
  return { bytes, sha256: digest.digest('hex') };
}
async function hardwareReceipt(browser) {
  const row = { requested: Date.now(), status: 'unavailable', activeRenderer: null, matchesPriorNVIDIARenderer: null };
  let cdp;
  try {
    cdp = await bounded(browser.newBrowserCDPSession(), 500, 'Hardware browser CDP session');
    const value = await bounded(cdp.send('SystemInfo.getInfo'), 500, 'Passive GPU identity');
    row.activeRenderer = typeof value.gpu?.auxAttributes?.glRenderer === 'string' ? value.gpu.auxAttributes.glRenderer : null;
    row.matchesPriorNVIDIARenderer = row.activeRenderer === null ? null : row.activeRenderer.includes('NVIDIA');
    row.devices = (value.gpu?.devices ?? []).slice(0, 8).map(device => Object.fromEntries(['vendorId', 'deviceId', 'vendorString', 'deviceString', 'driverVendor', 'driverVersion'].map(key => [key, device[key] ?? null])));
    row.deviceOverflow = (value.gpu?.devices?.length ?? 0) > 8;
    row.status = row.activeRenderer === null ? 'active renderer unavailable' : 'available';
    if (Buffer.byteLength(JSON.stringify(row)) > 4096) { delete row.devices; row.status = 'hardware reply exceeds cap'; }
  } catch (error) { row.error = error.stack; row.status = 'unsupported or failed'; }
  finally { if (cdp) try { await bounded(cdp.detach(), 500, 'Hardware CDP detach'); } catch (error) { row.detachError = error.stack; } }
  row.received = Date.now();
  return row;
}
const readyBytes=await readFile(home+'/ready.json'),ready=JSON.parse(readyBytes);
if(hash(readyBytes)!==process.argv[2])throw Error('Exact approved READY required');
const selected=ready.variants[variant],sourceBytes=await readFile(selected.manifest.file),manifest=JSON.parse(sourceBytes);
if(hash(sourceBytes)!==selected.manifest.sha256)throw Error('Source manifest changed');
const origin='http://127.0.0.1:'+selected.port;
async function pinGuard(){for(const row of [...manifest.files,...selected.optimizerFiles,...ready.helpers]){const actual=await hashFile(row.file);if(actual.bytes!==row.bytes||actual.sha256!==row.sha256)throw Error('Pinned file changed '+row.file);}return{at:Date.now(),manifestSHA256:hash(sourceBytes)};}
async function serverJSON(path,cap=4096){const response=await fetch(origin+path,{signal:AbortSignal.timeout(3000)});if(!response.ok||!response.headers.get('content-type')?.includes('application/json'))throw Error('Endpoint is not JSON '+path);const text=await response.text();if(Buffer.byteLength(text)>cap)throw Error('Endpoint cap '+path);return JSON.parse(text);}
async function assetGuard(label){const state=await serverJSON('/__diagnostic/assets',1024*1024);await writeFile(out+'/'+label+'-assets.json',JSON.stringify(state));if(state.failure||state.baselineTotal>state.limit||state.roadTotal>state.roadLimit)throw Error('Asset guard failure');for(const row of state.pins){const actual=await hashFile(row.copy);if(actual.bytes!==row.bytes||actual.sha256!==row.sha256)throw Error('Asset changed '+row.path);}return{at:Date.now(),pins:state.pins.length,responses:state.responses};}
await mkdir(out); // An existing successful or failed observation is never overwritten.
const sourceBefore=await pinGuard(),assetsBefore=await assetGuard('before');
if((await hashFile(selected.ledger.file)).sha256!==selected.ledger.sha256)throw Error('Initial ledger changed');
let owned,browser,page,guard,inventory,memory=null,stopReason=null,failure=null,launch=null,hardware=null,navigation=null;
const errors=[],failed=[],warnings=[],secondary=[],receipts=[],modules=new Set(),epochs=new Set();let overflow=false;
const record=(list,value,cap)=>{if(list.length>=cap){overflow=true;return;}list.push(value);};
const cleanup=async(label,run)=>{try{return await run();}catch(error){secondary.push({label,error:error.stack});return null;}};
async function capture(label,isolate=false){const row={label,began:Date.now()};try{const values=await Promise.all([
 bounded(page.evaluate(()=>{const value=typeof globalThis.__preloadBenchmark==='function'?globalThis.__preloadBenchmark():null;return{benchmark:value,visible:document.visibilityState,game:typeof globalThis.__infected!=='undefined'};}),3000,'Fixed page state'),
 serverJSON('/__diagnostic/boot')]);
 row.page=values[0];row.server=values[1];row.received=Date.now();
 if(Buffer.byteLength(JSON.stringify(row.page))>4096)throw Error('Getter cap exceeded');
 if(row.page.visible!=='visible'||row.page.game)throw Error('Fixture visibility/game guard');
 if(row.server.failed)throw Error('Asset server failure');
 if(isolate){const value=await bounded(inventory.capture(label),3000,'Isolate counters');row.isolatesFile='isolate-'+receipts.length+'.json';await writeFile(out+'/'+row.isolatesFile,JSON.stringify(value));if(value.targets.some(t=>t.type==='worker'))throw Error('Unexpected worker in cache-only fixture');}
 return row;
 }catch(error){row.error=error.stack;throw error;}finally{row.ended=Date.now();if(receipts.length>=256)throw Error('Receipt capacity exceeded');receipts.push(row);await appendFile(out+'/receipts.jsonl',JSON.stringify(row)+'\n');}}
function runtimeGuard(){if(stopReason)throw Error('Independent guard '+stopReason);if(overflow||errors.length||failed.length||epochs.size>1)throw Error('Runtime/identity/capacity guard');}
async function waitFor(label,predicate,deadline){while(Date.now()<deadline){runtimeGuard();const row=await capture(label);const value=row.page.benchmark;if(value?.status==='failed')throw Error(value.error);if(predicate(value))return value;await new Promise(resolve=>setTimeout(resolve,250));}throw Error(label+' exceeded original phase deadline');}
try{
 owned=await chromium.launchServer({executablePath:'/usr/bin/chromium',headless:false,args:[],timeout:3000});
 launch={at:Date.now(),rootPID:owned.process().pid,args:owned.process().spawnargs,viewport:{width:1687,height:1067},DPR:1,headless:false};await writeFile(out+'/launch.json',JSON.stringify(launch));
 guard=new Worker(new URL('./process-guard.mjs',import.meta.url),{workerData:{rootPID:launch.rootPID,maxPSS:4*1024**3,minAvailable:8*1024**3,deadlineMs:90000}});
 guard.on('message',value=>{memory=value;if(value.kind==='stop')stopReason=value.reason;});guard.on('error',error=>{stopReason=error.stack;owned.close().catch(()=>{});});
 browser=await chromium.connect(owned.wsEndpoint());hardware=await hardwareReceipt(browser);await writeFile(out+'/hardware.json',JSON.stringify(hardware));
 page=await browser.newPage({viewport:launch.viewport,deviceScaleFactor:1});
 page.on('pageerror',error=>record(errors,{at:Date.now(),error:error.stack},100));
 page.on('requestfailed',request=>record(failed,{at:Date.now(),url:request.url(),error:request.failure()},100));
 page.on('response',response=>{if(response.status()>=400)record(failed,{at:Date.now(),url:response.url(),status:response.status()},100);});
 page.on('console',message=>{if(['warning','error'].includes(message.type()))record(warnings,{at:Date.now(),type:message.type(),text:message.text()},100);});
 page.on('request',request=>{const url=new URL(request.url());if(modules.size>=4000&&!modules.has(request.url()))overflow=true;modules.add(request.url());if(url.searchParams.has('g')){const epoch=url.searchParams.get('g');epochs.add(epoch);if(epoch!==selected.sourceEpoch)record(errors,{error:'Source epoch differs '+epoch},100);}if(url.pathname.includes('/yage/engine/')&&!url.pathname.startsWith('/@fs'+ready.sourceRoot+'/yage/engine/'))record(errors,{error:'Noncanonical engine URL '+request.url()},100);if(/\/(?:boot|main)\.ts(?:\?|$)/.test(request.url()))record(errors,{error:'Game boot imported'},100);});
 inventory=await bounded(openIsolateInventory(browser,page),3000,'Isolate setup');
 const requested=Date.now();await page.goto(origin+'/preload-benchmark.html',{waitUntil:'commit',timeout:3000});navigation={requested,committed:Date.now()};await writeFile(out+'/navigation.json',JSON.stringify(navigation));
 await waitFor('module-ready',value=>value?.status==='ready',Date.now()+15000);await capture('before-cold',true);
 for(const phase of ['cold','warm']){
  const requested=Date.now(),receipt=await bounded(page.evaluate(phase=>globalThis.__startPreloadBenchmark(phase),phase),3000,phase+' request');
  await writeFile(out+'/'+phase+'-request.json',JSON.stringify({requested,received:Date.now(),receipt}));
  const completed=await waitFor(phase,value=>value?.status===(phase==='cold'?'cold-complete':'complete'),requested+45000);
  await writeFile(out+'/'+phase+'-completed.json',JSON.stringify(completed));await capture('after-'+phase,true);
  if(phase==='cold'){
   const requested=Date.now(),receipt=await bounded(page.evaluate(()=>globalThis.__verifyPreloadBenchmark()),3000,'Verification request');await writeFile(out+'/verification-request.json',JSON.stringify({requested,received:Date.now(),receipt}));
   await waitFor('persistent-verification',value=>value?.status==='verified',requested+15000);await capture('after-verification');
  }
 }
 runtimeGuard();if(epochs.size!==1)throw Error('Missing source epoch');
}catch(error){failure=error.stack;await writeFile(out+'/primary-failure.json',JSON.stringify({at:Date.now(),failure}));}
finally{
 if(inventory)await cleanup('inventory-close',async()=>{secondary.push(...await inventory.close());});
 if(guard){await cleanup('guard-finish',()=>bounded(new Promise(resolve=>{guard.on('message',value=>{if(value.kind==='finished'){memory=value;resolve();}});guard.postMessage('finish');}),3000,'Guard finish'));await cleanup('guard-terminate',()=>guard.terminate());}
 await cleanup('browser-close',()=>browser?.close());await cleanup('owned-server-close',()=>owned?.close());
 const sourceAfter=await cleanup('source-after',pinGuard),assetsAfter=await cleanup('assets-after',()=>assetGuard('after'));
 await writeFile(out+'/result.json',JSON.stringify({variant,readySHA256:hash(readyBytes),sourceBefore,sourceAfter,assetsBefore,assetsAfter,launch,hardware,navigation,memory,stopReason,failure,secondary,errors,warnings,failed,overflow,epochs:[...epochs],modules:[...modules],receiptCount:receipts.length,note:'Complete actual cold/warm IndexedDB preload only; no game/scene/atlas/map/workers. Metadata/isolate/sampler overhead retained, fresh profiles share OS cache. No FPS, late-memory or travel conclusion.'}));
}
if(failure||secondary.length)process.exitCode=1;
