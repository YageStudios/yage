import {readFile,writeFile} from 'node:fs/promises';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {webcrypto,createHash} from 'node:crypto';
const home='/tmp/asset-preload-window',source=await readFile(home+'/fixture.mjs','utf8');
const hash=b=>createHash('sha256').update(b).digest('hex');
const body=new Uint8Array([4,7,9]).buffer,key=hash(Buffer.from(body));
const vector=new Float64Array([0,6,1,6,3,6,6,6]);
const expected={count:4,progressSHA256:hash(Buffer.from(vector.buffer)),keysCount:1,keysSHA256:hash(JSON.stringify([key])),samples:[{sha256:key,bytes:3}]};
function harness({extra=false,reject=null}={}){
 let release,reads=0,loads=0,opened=0;
 const held=new Promise(resolve=>release=resolve);
 const factory={open(){opened++;const req={};queueMicrotask(()=>{req.result={close(){},transaction(name,mode){assert.equal(name,'assets');assert.equal(mode,'readonly');const tx={objectStore(){return{getAllKeys(){reads++;const request={result:[key]};queueMicrotask(()=>tx.oncomplete());return request;},get(received){assert.equal(received,key);reads++;const request={result:body};queueMicrotask(()=>tx.oncomplete());return request;}}}};return tx;}};req.onsuccess();});return req;}};
 const context=vm.createContext({ArrayBuffer,Float64Array,Uint8Array,TextEncoder,URL,performance,crypto:webcrypto,location:{href:'http://127.0.0.1:5423/preload-benchmark.html'},indexedDB:factory,expected,
 preloadGeographicSources:async(progress,base,members,options)=>{loads++;assert.equal(base,'http://127.0.0.1:5423/world-data/');assert.equal(members,undefined);assert.equal(options.citySource,true);for(const pair of [[0,6],[1,6],[3,6],[6,6]])progress(...pair);if(extra)progress(6,6);await held;if(reject)throw reject;}});
 const code=source.replace(/^import[^\n]+\n/,'').replace("const expected=await (await fetch(new URL('./expected.json',import.meta.url))).json();",'const expected=globalThis.expected;');
 new vm.Script(code).runInContext(context);
 return{context,release,stats:()=>({reads,loads,opened})};
}
async function settled(h){for(let i=0;i<30;i++){const value=h.context.__preloadBenchmark();if(!['running','hashing-progress','verifying'].includes(value.status))return value;await new Promise(resolve=>setTimeout(resolve,2));}throw Error('Fixture control did not settle');}
const controls=[];
{
 const h=harness();assert.equal(h.context.__preloadBenchmark().status,'ready');assert.deepEqual(h.stats(),{reads:0,loads:0,opened:0});
 assert.throws(()=>h.context.__startPreloadBenchmark('warm'),/Invalid/);
 const receipt=h.context.__startPreloadBenchmark('cold');assert.equal(receipt.status,'running');assert.throws(()=>h.context.__startPreloadBenchmark('cold'),/Invalid/);
 h.release();let result=await settled(h);assert.equal(result.status,'cold-complete');assert.equal(result.progressSHA256,expected.progressSHA256);assert.equal(result.progressCount,4);assert.ok(result.completed>=result.requested);
 h.context.__verifyPreloadBenchmark();result=await settled(h);assert.equal(result.status,'verified');assert.equal(result.verification.keyCount,1);assert.equal(h.stats().reads,2);
 h.context.__startPreloadBenchmark('warm');result=await settled(h);assert.equal(result.status,'complete');assert.equal(h.stats().loads,2);assert.equal(h.stats().opened,1);
 const before=h.stats();for(let i=0;i<20;i++)h.context.__preloadBenchmark();assert.deepEqual(h.stats(),before);assert.ok(Buffer.byteLength(JSON.stringify(result))<4096);controls.push('cold/warm order, complete ordered progress hash, actual readonly adapter events, passive bounded getter');
}
{
 const h=harness({extra:true});h.context.__startPreloadBenchmark('cold');const result=await settled(h);assert.equal(result.status,'failed');assert.match(result.error,/capacity/);assert.equal(h.stats().opened,0);controls.push('overflow fails before unbounded progress storage or persistent verification');
}
{
 const h=harness({reject:Error('original-preload-failure')});h.context.__startPreloadBenchmark('cold');h.release();const result=await settled(h);assert.equal(result.status,'failed');assert.match(result.error,/original-preload-failure/);assert.equal(result.completed,null);controls.push('preload failure retains incomplete timing and cannot qualify output');
}
await writeFile(home+'/fixture-controls.json',JSON.stringify({controls,qualification:'Fixture lifecycle controls with controlled preload/IDB events; actual cache/store semantics covered independently. No native throughput or allocation claim.'},null,2));console.log(JSON.stringify({passed:controls.length,controls}));
