import json,pathlib,statistics,datetime
h=pathlib.Path('/tmp/asset-preload-window')
schema=json.load(open('/tmp/current-boot-allocation/io-schema.json'))
report={'qualification':['One original→candidate pair with fresh browser profiles and shared OS page cache.','Coordinator reported overlapping external coastline IAB5323 camera replay; team-exclusive was not globally host-isolated.','No FPS, late-game memory, travel or eviction/return acceptance.'],'variants':{}}
for variant in ['original','candidate']:
 p=h/variant/'observation'; result=json.load(open(p/'result.json')); rows=[json.loads(x) for x in open(p/'receipts.jsonl')]
 named={r['label']:r for r in rows if r['label'] in ['before-cold','after-cold','after-verification','after-warm']}
 def io(label):return named[label]['page']['benchmark']['io']
 def delta(start,end,key):return dict(zip(schema['totals'],[b-a for a,b in zip(io(start)[key],io(end)[key])]))
 cold=json.load(open(p/'cold-completed.json'));warm=json.load(open(p/'warm-completed.json'))
 assert cold['progressCount']==warm['progressCount']==13057
 assert cold['progressSHA256']==warm['progressSHA256']=='106c90f9e06f7043213ce3137533e10d2b9d050c94ac201d75de167f8f4ae959'
 assert warm['verification']['keyCount']==13057 and warm['verification']['keysSHA256']=='a29a32096c4f63576d656c69186cd5867c35d9d8493d1c61b9d385d34b84227a'
 cd=delta('before-cold','after-cold','t');wd=delta('after-verification','after-warm','t')
 assert cd['networkRequests']==cd['storeWriteCommits']==cd['bodyCompletions']==13057
 assert cd['storeWriteCommittedBytes']==cd['bodyCompletedBytes']==870867266
 assert cd['cityHTTP206Responses']==13050 and cd['cityBodyCompletedBytes']==859005902
 assert wd['networkRequests']==wd['storeWriteBegins']==wd['storeWriteCommits']==0
 assert wd['storeReadBegins']==wd['storeReadCompletions']==1 and wd['storeReadReturnedBytes']==2235906
 assert not result['failure'] and not result['stopReason'] and not result['secondary'] and not result['errors'] and not result['failed']
 memory=result['memory']['rows'];peak=max(memory,key=lambda r:r['pss']);roles={}
 for r in peak['processes']:roles[r['role']]=roles.get(r['role'],0)+r['pss']
 costs=[r['samplingMs'] for r in memory];reads=[r for row in memory for r in row['reads']]
 inventories=[]
 for f in sorted(p.glob('isolate-*.json')):
  d=json.load(open(f));inventories.append({'file':f.name,'elapsedMs':d['elapsedMs'],'complete':d['complete'],'samples':[{'type':s['type'],'fields':s['fields'],'isolateId':s['isolateId'],'missingFields':s['missingFields']} for s in d['samples']],'missing':d['missing'],'unsupported':d['unsupported'],'notSampled':d['notSampled']})
 for label in ['after-cold','after-warm']:
  assert named[label]['server']['responses']['k'][0][10]==870867266
 value={'coldMs':cold['duration'],'warmMs':warm['duration'],'coldIO':cd,'warmIO':wd,'peakPending':dict(zip(schema['pending'],io('after-cold')['p'])),'verification':warm['verification'],'PSS':{'samples':len(memory),'peakBytes':peak['pss'],'peakAt':peak['at'],'peakRoles':roles,'minimumAvailableBytes':min(r['available'] for r in memory),'samplingMs':{'total':sum(costs),'median':statistics.median(costs),'max':max(costs)},'perProcessReadMsTotal':sum(r['ended']-r['began'] for r in reads)},'isolateInventories':inventories,'sourceGuardsEqual':result['sourceBefore']['manifestSHA256']==result['sourceAfter']['manifestSHA256'],'assetsBeforeAfterPins':[result['assetsBefore']['pins'],result['assetsAfter']['pins']],'hardware':result['hardware'],'errors':{'failure':result['failure'],'stop':result['stopReason'],'page':result['errors'],'request':result['failed'],'cleanup':result['secondary']},'cleanupRootPID':{'pid':result['launch']['rootPID'],'absentAtAnalysis':not pathlib.Path('/proc/'+str(result['launch']['rootPID'])).exists()},'receiptCount':result['receiptCount']}
 report['variants'][variant]=value
original=report['variants']['original'];candidate=report['variants']['candidate']
report['comparison']={'coldSavedMs':original['coldMs']-candidate['coldMs'],'coldReductionPercent':100*(original['coldMs']-candidate['coldMs'])/original['coldMs'],'warmAddedMs':candidate['warmMs']-original['warmMs'],'PSSPeakAddedBytes':candidate['PSS']['peakBytes']-original['PSS']['peakBytes'],'fullColdIOEqual':original['coldIO']==candidate['coldIO'],'fullWarmIOEqual':original['warmIO']==candidate['warmIO'],'verificationEqual':{k:original['verification'][k]==candidate['verification'][k] for k in ['keyCount','keysSHA256','samples']}}
(h/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'comparison':report['comparison'],'variants':{k:{'coldMs':v['coldMs'],'warmMs':v['warmMs'],'PSS':v['PSS'],'peakPending':v['peakPending']} for k,v in report['variants'].items()}},indent=2))
