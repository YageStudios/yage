import base from './portable-test.config.mjs';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),{createInstrumenter}=require('/home/robert/.npm/_npx/b8d86e6551a4f492/node_modules/istanbul-lib-instrument');
export default {...base,plugins:[{name:'actual-preload-changed-coverage',enforce:'post',transform(code,id){if(!id.endsWith('/engine/data/AssetCache.ts'))return;const instrumenter=createInstrumenter({esModules:true,produceSourceMap:true});return{code:instrumenter.instrumentSync(code,id,this.getCombinedSourcemap()),map:instrumenter.lastSourceMap()};}}],test:{...base.test,setupFiles:['/tmp/asset-preload-window/portable-coverage-setup.ts']}};
