# Complete preload pair: scope and limits

The original and private concurrency candidate each completed once in a fresh headed browser profile. Both processes ended with status 0, no guard stop, no page/request errors and no cleanup failures. Both browser root PIDs were absent at the subsequent cleanup check.

The measured cold wrapper interval was 27,832.9 ms for the original and 20,634.3 ms for the candidate. The warm wrapper interval was 53.5 ms and 63.0 ms respectively; this observed warm regression must remain visible. These are one-pair observations, not distributions or a host-isolated throughput estimate.

The coordinator reported that the separate coastline chat was concurrently running an isolated game camera replay in the in-app browser on port 5323. The team lanes were held, but the host was not globally isolated. The original also preceded the candidate, and the fresh browser profiles shared the operating-system page cache. No failed run was retried and no guard was widened.

Both cold calls requested all 13,050 city ranges plus six whole assets, preceded by the member-index load. Each recorded 13,057 cache reads, fetches, response bodies and committed writes, totaling 870,867,266 bytes. All city responses were HTTP 206; no whole-city fallback occurred. The public ordered progress vectors and full committed key sets match their pinned expected hashes. Actual readonly IndexedDB verification checked full membership and three committed body samples after cold timing.

Both warm calls made one additional cache-store readonly read of the 2,235,906-byte member index. Neither made a new network fetch or persistent write. The verification's independent readonly transactions are outside the cache trace and outside the cold/warm timing windows.

The maximum observed declared body bytes and pending write bytes were 9,461,248 in both variants. The maximum pending header count rose from one to four. These counters concern declared/body/store boundaries, not a bound on all native or browser allocations. Actual tree PSS peaked at 1,718,764,544 bytes for the original and 1,727,223,808 bytes for the candidate; role and sampler summaries remain to be finalized.

The benchmark imports the actual frozen dataset/cache implementation and performs no game boot, scene preparation, map upload, atlas painting or worker work. It therefore cannot close late startup renderer/GPU growth, active 60 FPS, geographic travel, map-only demand or normal eviction/return lifetime gates. The frozen engine baseline is 685ce27c; the separately committed 85005374 surface marker change is not silently included in these results. Canonical AssetCache bytes remain unchanged.
