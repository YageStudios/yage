import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import ts from '/data/workspace/sky-harbor/worldmap-integration/infected/node_modules/typescript/lib/typescript.js';
const home = '/tmp/asset-preload-window';
const variants = {};
for (const name of ['original', 'candidate']) {
  const file = home + '/' + name + '.ts', output = ts.transpileModule(await readFile(file, 'utf8'), { fileName: file, compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, sourceMap: true, inlineSources: true } });
  let code = output.outputText;
  if (name === 'candidate' && process.argv.includes('--coverage')) {
    const require = createRequire(import.meta.url), { createInstrumenter } = require('/home/robert/.npm/_npx/b8d86e6551a4f492/node_modules/istanbul-lib-instrument');
    code = createInstrumenter({ esModules: true, produceSourceMap: true }).instrumentSync(code, file + '.js', JSON.parse(output.sourceMapText));
  }
  variants[name] = await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'));
}
const report = [], tick = () => new Promise(resolve => setImmediate(resolve));
async function until(accept) { const end = Date.now() + 1000; while (!accept()) { if (Date.now() >= end) throw Error('Held operation did not reach boundary'); await tick(); } }
async function record(size, seed) { const body = Uint8Array.from({ length: size }, (_, i) => (seed + i) % 256); return { body, path: 'data/' + seed, bytes: size, sha256: Buffer.from(await crypto.subtle.digest('SHA-256', body)).toString('hex') }; }
function memory() { const entries = new Map(); return { entries, store: { read: async key => entries.get(key), write: async (key, body) => { entries.set(key, body); } } }; }
const largest = await record(8, 100), assets = await Promise.all(Array.from({ length: 7 }, (_, i) => record(1, i + 1)));

test('input-order progress, commit readiness, count/byte bounds and ordinary coalescing', { timeout: 5000 }, async () => {
  const { AssetCache } = variants.candidate, entries = new Map(), commits = [], progress = [], fetched = new Map();
  let liveBytes = 0, liveCount = 0, peakBytes = 0, peakCount = 0, hold = false;
  const byPath = new Map([largest, ...assets].map(row => [row.path, row]));
  const store = { read: async key => entries.get(key), write: async (key, body) => {
    if (hold) await new Promise(resolve => commits.push({ key, resolve }));
    entries.set(key, body); liveBytes -= body.byteLength; liveCount--;
  } };
  const cache = new AssetCache(store, async url => {
    const row = byPath.get(new URL(url).pathname.slice(1)); fetched.set(row.sha256, (fetched.get(row.sha256) ?? 0) + 1);
    liveBytes += row.bytes; liveCount++; peakBytes = Math.max(peakBytes, liveBytes); peakCount = Math.max(peakCount, liveCount);
    return new Response(row.body);
  });
  await cache.load('https://local/', largest); peakBytes = peakCount = 0; hold = true;
  const task = cache.preload('https://local/', [largest, ...assets], (done, total) => progress.push([done, total]));
  assert.deepEqual(progress, [[0, 15], [8, 15]]); // Warm verified progress keeps the original synchronous path.
  await until(() => commits.length === 4);
  const ordinary = cache.load('https://local/', assets[0]);
  for (const row of commits.filter(row => row.key !== assets[0].sha256)) row.resolve();
  await tick(); assert.deepEqual(progress, [[0, 15], [8, 15]]);
  hold = false; commits.find(row => row.key === assets[0].sha256).resolve(); await task; const returned = await ordinary;
  assert.deepEqual(progress, [[0, 15], ...Array.from({ length: 8 }, (_, i) => [8 + i, 15])]);
  assert.equal(peakCount, 4); assert(peakBytes <= largest.bytes); assert.equal(fetched.get(assets[0].sha256), 1);
  assert.equal(returned, entries.get(assets[0].sha256)); assert.equal(cache.pending.size, 0);
  assert.equal(cache.verified.size, 8); for (const asset of assets) assert.deepEqual(new Uint8Array(entries.get(asset.sha256)), asset.body);
  report.push({ control: 'Held/reordered persistent commits; exact progress, warm synchronous skip, ordinary coalescing', peakCount, peakDeclaredBytes: peakBytes, largestDeclaredBytes: largest.bytes });
});

test('large records serialize at the byte bound; zero and duplicate hashes remain complete', { timeout: 5000 }, async () => {
  const empty = await record(0, 20), rows = [await record(8, 30), await record(8, 40), empty, empty];
  for (const [name, { AssetCache }] of Object.entries(variants)) {
    const { store, entries } = memory(), seen = [], progress = []; let active = 0, peak = 0;
    const cache = new AssetCache(store, async url => { const row = rows.find(row => new URL(url).pathname.endsWith('/' + row.path)); seen.push(row.sha256); active += row.bytes; peak = Math.max(peak, active); await tick(); active -= row.bytes; return new Response(row.body); });
    await cache.preload('https://local/', rows, (done, total) => progress.push([done, total]));
    assert.deepEqual(progress, [[0, 16], [8, 16], [16, 16], [16, 16], [16, 16]]); assert.equal(entries.size, 3); assert(peak <= 8); assert.equal(seen.filter(key => key === empty.sha256).length, 1);
    report.push({ control: 'Large/zero/duplicate records', variant: name, peakDeclaredBytes: peak });
  }
});

test('first input error and progress errors preserve identity, settle dispatched suffix and start no next window', { timeout: 5000 }, async () => {
  for (const failureAt of [0, 2]) {
    const rows = [largest, ...assets], { entries, store } = memory(), failure = { marker: failureAt }, seen = [], progress = [], commits = [];
    // Warm the largest record so four small records can actually overlap.
    entries.set(largest.sha256, largest.body.buffer);
    const cache = new variants.candidate.AssetCache({ ...store, write: async (key, bytes) => { await tick(); if (key === assets[failureAt].sha256) throw failure; entries.set(key, bytes); commits.push(key); } }, async url => { const row = rows.find(row => new URL(url).pathname.endsWith('/' + row.path)); seen.push(row.sha256); return new Response(row.body); });
    await cache.load('https://local/', largest);
    await assert.rejects(cache.preload('https://local/', rows, (done, total) => progress.push([done, total])), error => error === failure);
    assert.equal(seen.length, 4); assert.equal(cache.pending.size, 0); assert.equal(commits.length, 3);
    assert.deepEqual(progress, [[0, 15], [8, 15], ...Array.from({ length: failureAt }, (_, i) => [9 + i, 15])]);
    report.push({ control: 'Original error identity and explicit cached suffix', failureAt, dispatched: seen.length, cachedSuffix: commits.filter(key => assets.findIndex(row => row.sha256 === key) > failureAt).length });
  }
  const { store, entries } = memory(), failure = { progress: true }, rows = [largest, ...assets.slice(0, 4)], cache = new variants.candidate.AssetCache(store, async url => new Response(rows.find(row => new URL(url).pathname.endsWith('/' + row.path)).body));
  await cache.load('https://local/', largest);
  await assert.rejects(cache.preload('https://local/', rows, done => { if (done > largest.bytes) throw failure; }), error => error === failure);
  assert.equal(entries.size, 5); // The dispatched window settles, including suffix commits after the callback fails.
  assert.equal(cache.pending.size, 0);
});

test('cached/corrupt/invalid/integrity/HTTP/range and retry results match the actual original', { timeout: 5000 }, async () => {
  for (const [name, { AssetCache }] of Object.entries(variants)) {
    const { store, entries } = memory(), row = await record(4, 60), progress = [], requests = [];
    entries.set(row.sha256, new ArrayBuffer(4)); let bad = true;
    const cache = new AssetCache(store, async (_url, init) => { requests.push(new Headers(init?.headers).get('Range')); return new Response(bad ? 'wrong' : row.body, { status: 206 }); });
    await assert.rejects(cache.preload('https://local/', [{ ...row, offset: 7 }]), /integrity/);
    bad = false; await cache.preload('https://local/', [{ ...row, offset: 7 }], (done, total) => progress.push([done, total]));
    assert.deepEqual(progress, [[0, 4], [4, 4]]); assert.deepEqual(requests, ['bytes=7-10', 'bytes=7-10']);
    assert.deepEqual(new Uint8Array(entries.get(row.sha256)), row.body); assert.equal(cache.pending.size, 0);
    await assert.rejects(new AssetCache(memory().store, async () => new Response(null, { status: 404 })).preload('https://local/', [row]), /HTTP404|HTTP 404/);
    for (const patch of [{ path: '../bad' }, { bytes: -1 }, { bytes: NaN }, { sha256: 'bad' }]) await assert.rejects(new AssetCache(memory().store).preload('https://local/', [{ ...row, ...patch }]), /Invalid/);
    const full = new Uint8Array([0, 0, ...row.body, 0]);
    assert.deepEqual(new Uint8Array(await new AssetCache(memory().store, async () => new Response(full)).load('https://local/', { ...row, offset: 2 })), row.body);
    report.push({ control: 'Corrupt/invalid/range/HTTP/integrity/retry parity', variant: name });
  }
});

test('mixed verified records and malformed later records keep exact prefix progress', { timeout: 5000 }, async () => {
  const progressByVariant = [];
  for (const { AssetCache } of Object.values(variants)) {
    const { store } = memory(), byPath = new Map([largest, ...assets].map(row => [row.path, row]));
    const cache = new AssetCache(store, async url => new Response(byPath.get(new URL(url).pathname.slice(1)).body));
    await cache.load('https://local/', largest);
    const progress = []; await cache.preload('https://local/', [assets[0], largest, assets[1]], (done, total) => progress.push([done, total]));
    progressByVariant.push(progress);
    const badProgress = []; await assert.rejects(cache.preload('https://local/', [assets[2], { ...assets[3], bytes: -1 }], (done, total) => badProgress.push([done, total])), /Invalid/);
    assert.deepEqual(badProgress, [[0, 0], [1, 0]]);
  }
  assert.deepEqual(progressByVariant[0], progressByVariant[1]);
});

test('multiple errors choose the earliest input despite reverse completion', { timeout: 5000 }, async () => {
  const { store, entries } = memory(), first = { first: true }, later = { later: true }, rows = [largest, ...assets];
  const cache = new variants.candidate.AssetCache({ ...store, write: async (key, body) => {
    if (key === assets[0].sha256) { await new Promise(resolve => setTimeout(resolve, 10)); throw first; }
    if (key === assets[2].sha256) throw later;
    entries.set(key, body);
  } }, async url => new Response(rows.find(row => new URL(url).pathname.endsWith('/' + row.path)).body));
  await cache.load('https://local/', largest);
  await assert.rejects(cache.preload('https://local/', rows), error => error === first);
  assert.equal(cache.pending.size, 0); assert.equal(entries.size, 3);
});

test('actual IndexedDBAssetStore uses readonly/readwrite and only transaction completion commits', { timeout: 5000 }, async () => {
  const { IndexedDBAssetStore } = variants.candidate, transactions = [], db = { close() {}, transaction(name, mode) {
    const request = { result: undefined }, tx = { mode, objectStore: () => ({ get: () => request, put: (body, key) => { tx.put = { body, key }; } }), request }; transactions.push(tx); return tx;
  } };
  const factory = { open() { const request = { result: db }; queueMicrotask(() => request.onsuccess()); return request; } };
  const store = new IndexedDBAssetStore(factory), bytes = new ArrayBuffer(3); let ready = false;
  const read = store.read('key').then(value => { ready = true; return value; }); await until(() => transactions.length === 1);
  transactions[0].request.result = bytes; await tick(); assert.equal(ready, false); transactions[0].oncomplete(); assert.equal(await read, bytes); assert.equal(transactions[0].mode, 'readonly');
  ready = false; const write = store.write('key', bytes).then(() => { ready = true; }); await until(() => transactions.length === 2);
  assert.equal(transactions[1].put.body, bytes); assert.equal(transactions[1].mode, 'readwrite'); await tick(); assert.equal(ready, false); transactions[1].oncomplete(); await write; assert.equal(ready, true);
  const failure = { abort: true }, aborted = store.write('failed', bytes); await until(() => transactions.length === 3); transactions[2].error = failure; transactions[2].onabort(); await assert.rejects(aborted, error => error === failure);
  report.push({ control: 'Actual IndexedDBAssetStore transaction boundary and original abort identity', qualification: 'Native IDB request/transaction events are controlled; not a browser throughput result.' });
});

process.once('beforeExit', async () => {
  await writeFile(home + '/controls.json', JSON.stringify({ report, qualification: 'Actual private AssetCache source and real Response/WebCrypto controls. No browser, throughput or memory acceptance.' }, null, 2) + '\n');
  if (globalThis.__coverage__) await writeFile(home + '/coverage-raw.json', JSON.stringify(globalThis.__coverage__));
});
