import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const home='/tmp/asset-preload-window', source='/tmp/current-boot-allocation', root='/tmp/infected-active-current-20261104';
const sha=b=>createHash('sha256').update(b).digest('hex');
const common=JSON.parse(await readFile(source+'/io-manifest.json'));
const demand=JSON.parse(await readFile('/tmp/active-frame-current/preload-demand.json'));
const assets=JSON.parse(await readFile(root+'/infected/src/realworld/asset-manifest.json'));
const whole=assets.files.filter(a=>demand.currentPage.whole.paths.includes(a.path));
const records=[...whole,...demand.currentPageCityDescriptors];
if(sha(JSON.stringify(records))!==demand.currentPage.sourceSHA256)throw Error('Ordered complete asset descriptors differ');
const pairs=new Float64Array((records.length+1)*2);let sum=0;
pairs[1]=demand.currentPage.requestedBytes;
for(let i=0;i<records.length;i++){sum+=records[i].bytes;pairs[(i+1)*2]=sum;pairs[(i+1)*2+1]=demand.currentPage.requestedBytes;}
const persisted=[assets.members,...records];
const keys=[...new Set(persisted.map(a=>a.sha256))].sort();
const expected={count:records.length+1,total:sum,keysCount:keys.length,keysSHA256:sha(JSON.stringify(keys)),progressSHA256:sha(Buffer.from(pairs.buffer)),samples:[persisted[0],persisted[Math.floor(persisted.length/2)],persisted.at(-1)],orderedAssetsSHA256:sha(JSON.stringify(records)),largestBytes:Math.max(...records.map(a=>a.bytes)),tracedColdBytes:sum+assets.members.bytes};
await writeFile(home+'/expected.json',JSON.stringify(expected,null,2));
for(const [i,variant]of ['original','candidate'].entries()){
 const dir=home+'/'+variant;await mkdir(dir,{recursive:true});
 const manifest=structuredClone(common);
 if(variant==='candidate'){
  const row=manifest.files.find(r=>r.path==='yage/engine/data/AssetCache.ts');if(!row)throw Error('Missing actual engine path');
  const bytes=await readFile(home+'/candidate.ts');row.file=home+'/candidate.ts';row.bytes=bytes.length;row.sha256=sha(bytes);
 }
 manifest.purpose='Complete actual dataset/IndexedDB preload benchmark; no game or map preparation; '+variant;
 await writeFile(dir+'/source-manifest.json',JSON.stringify(manifest,null,2));
 await copyFile(source+'/pinned-source.mjs',dir+'/pinned-source.mjs');
 await copyFile(source+'/asset-plugin.mjs',dir+'/asset-plugin.mjs');
 await copyFile(source+'/response-accounting.mjs',dir+'/response-accounting.mjs');
 await copyFile(source+'/canonical-asset-pins.jsonl',dir+'/asset-pins.jsonl');
 const config=`import {readFileSync} from 'node:fs';
import {mergeConfig} from '/data/workspace/sky-harbor/worldmap-integration/infected/node_modules/vite/dist/node/index.js';
import base from '${root}/infected/vite.config.ts';
import {pinnedSource} from './pinned-source.mjs';
import {guardedAssets} from './asset-plugin.mjs';
const home=${JSON.stringify(dir)},root=${JSON.stringify(root)};
const fixture={name:'preload-fixture-only',configureServer(server){server.middlewares.use((req,res,next)=>{if(req.url!=='/preload-benchmark.html')return next();res.setHeader('Content-Type','text/html');res.end('<!doctype html><meta charset="utf-8"><title>Asset preload benchmark</title><script type="module" src="/@fs${home}/fixture.mjs"></script>');});}};
export default mergeConfig(base,{root:root+'/infected',publicDir:false,cacheDir:home+'/cache',plugins:[pinnedSource(JSON.parse(readFileSync(home+'/source-manifest.json')),root),fixture,guardedAssets({source:'${source}/pinned-public',target:home+'/pinned-public',fallback:'/data/workspace/sky-harbor/worldmap-integration/infected/public',ledger:home+'/asset-pins.jsonl',expectedManifest:root+'/infected/src/realworld/asset-manifest.json'})],optimizeDeps:{entries:[],include:['minecs','pixi.js','yage > @dimforge/rapier2d-deterministic-compat','yage > @json-editor/json-editor','yage > @pixi/sound','yage > ajv','yage > deep-object-diff','yage > js-base64','yage > l1-path-finder','yage > lodash','yage > nanoid','yage > ndarray','yage > peerjs','yage > pixi-spine','yage > pixi-viewport','yage > poly-decomp','yage > seedrandom','yage > socket.io-client','yage > toastify-js','yage > toposort','yage > url','polygon-clipping','@pixi/utils']},server:{host:'127.0.0.1',port:${5423+i},strictPort:true,hmr:false,watch:{ignored:['**/*']},fs:{allow:[home,${JSON.stringify(home)},root,'/data/workspace/sky-harbor/worldmap-integration/infected/node_modules','/data/workspace/sky-harbor/worldmap-integration/yage/node_modules']}}});
`;
 await writeFile(dir+'/config.mjs',config);
}
console.log(JSON.stringify(expected));
